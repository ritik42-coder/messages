# Messages 2.0

A rebuild of your `com.messages.app` SMS app (the APK you sent was version 1.0).
Same package name, same SMS features, but with a real theme engine, smooth motion,
and the delete / focus / selection features you asked for.

## What's in the box

| File | What it is |
|---|---|
| `Messages-2.0.apk` | Installable debug APK (versionCode 2, versionName 2.0) |
| `Messages-2.0-source.zip` | Complete Android Studio project |

## Install

1. Uninstall the old **Messages** app first. The package name is the same but the
   signing key is different (this is a debug build), so Android will refuse to
   install over it.
   Your SMS are stored in the phone's system database, not in the app, so
   uninstalling does **not** delete your messages.
2. Copy `Messages-2.0.apk` to the phone and open it. Allow "Install unknown apps"
   for the app you are installing from (Files / Chrome).
3. Open Messages and grant SMS + contacts access.

## Why the old build was laggy

The v1.0 APK was a single-file Compose app where every colour was a hardcoded
dark constant (`getBg`, `getSurf`, `getA1..A3`) and the `Aurora` background ran a
continuously animated gradient behind the whole list. That combination forces a
full re-composition and re-draw of every row on every frame, which is where the
jank came from. It also meant dark mode was the only mode.

What changed in 2.0:

- One `Pal` object per theme, provided through `LocalPal`. Switching themes is a
  colour animation, not a re-layout, and rows only recompose when their own
  message changes.
- The backdrop is a single `Canvas` draw pass. The optional drift is one float
  animation, not per-row gradients.
- `LazyColumn` uses stable keys and immutable data classes.
- Blur is only applied while a message is held (focus mode) and can be turned off.
- Search and the starred screen load off the main thread (v1 did the opposite).
- The 30 MB `material-icons-extended` dependency was replaced with 16 hand-written
  vectors, which is why the APK is 8 MB instead of 15 MB.

## Themes

12 hand-tuned palettes, all switchable live with an animated cross-fade:

**Light** — Ivory, Porcelain, Sage, Rose, Sky, Sand
**Dark** — Midnight, Aurora, Graphite, Ocean, Plum, Ember

Plus: System / Light / Dark mode, three bubble shapes (Round, Soft, Square),
and a text-size slider (85 % – 130 %).

## Message features

- **Long-press focus mode** — hold a message and the rest of the chat blurs and
  dims behind a sheet of actions.
- **Delete → particle burst** — the bubble bursts into 30 particles on an
  analytic path (one animated value, no per-particle objects), then the row
  collapses out of the list.
- **Undo** — a snackbar brings a deleted message straight back.
- **Recycle bin** — deleted messages are kept for 30 days with restore and
  "delete forever", plus an empty-all action.
- **Starred messages** — a saved vault, tap any entry to jump to the chat.
- **Multi-select** — select, copy, forward, star, share or delete in bulk.
- **Swipe a message right to quote-reply** it; the composer shows the quote.
- **Double-tap to react** — heart reaction, six emoji in the action sheet.
- **Pin** messages to the top of a chat.
- **Forward** any message to another conversation.
- **Message info** — timestamp, characters, SMS part count.
- **Search** across all conversations with message-level results.
- **OTP chip** — detects a code in the last incoming message and copies it in one tap.

## Project layout

```
app/src/main/java/com/messages/app/
  Theme.kt        12 palettes, animated AppTheme, persisted ThemeState
  Core.kt         models, SmsRepo (Telephony), Store (prefs), MessagesVM
  Widgets.kt      backdrop, avatar, buttons, ParticleBurst
  HomeScreen.kt   conversation list, search, new-chat picker
  ChatScreen.kt   bubbles, focus mode, selection, composer, sheets
  Settings.kt     settings, theme picker, recycle bin, starred
  App.kt          routes, splash, permission gate
  MainActivity.kt activity + notification receiver (inline reply)
  MIcon.kt        local icon vectors
```

## Build it yourself

Open `Messages-2.0-source.zip` in Android Studio (Ladybug or newer), let Gradle
sync, then Run. Or from the command line:

```
./gradlew assembleDebug
```

Toolchain used for this APK: AGP 8.5.0, Kotlin 1.9.24, Compose BOM 2024.06.00,
compileSdk 34, minSdk 24.

## Notes

- The APK is a **debug** build, signed with the standard Android debug key.
  For Play Store distribution, generate a release keystore and build
  `assembleRelease`.
- The app is not set as your default SMS app, so it cannot write back to the
  system SMS database. Deleting is handled by hiding the message locally and
  keeping a copy in the recycle bin; "delete forever" removes it from the
  system store when the app has permission.
- Everything runs on the device. No network calls, no analytics.
