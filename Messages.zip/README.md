# Messages

Native Android SMS app (Kotlin + Jetpack Compose). Real SIM SMS, notifications, OTP copy.

Build: push to GitHub, open the Actions tab, wait for the green tick, then download
Messages.apk from Releases (or from the run's Artifacts).

First run on Android 13+: App info > three dots > "Allow restricted settings", then open the app,
allow permissions and tap "Set" to make it your default SMS app.
