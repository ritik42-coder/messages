# Messages

Native Android SMS app (Kotlin + Jetpack Compose). Real SIM SMS, notifications, OTP copy.

Build: push to GitHub, open the Actions tab, wait for the green tick, then download
Messages.apk from Releases (or from the run's Artifacts).

First run on Android 13+: App info > three dots > "Allow restricted settings", then open the app,
allow permissions and tap "Set" to make it your default SMS app.

## What's new in 3.0

- **Swipe actions** — swipe a chat right to pin/unpin, left to delete. Swipe a message right to star it, left to delete it.
- **Quick copy for any number** — phone numbers, account numbers and PNRs get a one-tap copy chip under the message.
- **Read aloud** — hold a message (or open the chat menu) to hear it spoken by the phone's voice engine.
- **Text size slider + Elder-friendly mode** — scales every screen; elder mode also enlarges buttons.
- **Saved info vault** — pin PNRs, loan numbers and Wi-Fi passwords, searchable, unlocked with fingerprint / face / phone PIN. Hold a message and tap *Save to vault*.
- **Sender names instead of raw IDs** — AX-HDFCBK shows as **HDFC Bank**, VK-JIO as **Jio**, AD-PAYTM as **Paytm**, each with a brand coloured logo tile.
- **Send later with a real calendar + clock** — pick any date, hour, minute and AM/PM.
- **Bulk chat deletion** — top-bar selection mode with Select all, plus a wipe-away animation (no particles).
- **All contacts** — the compose screen now lists every contact with a draggable A–Z bar on the right.
