# Messages

Native Android SMS app (Kotlin + Jetpack Compose). Real SIM SMS, notifications, OTP copy.

Build: push to GitHub, open the Actions tab, wait for the green tick, then download
Messages.apk from Releases (or from the run's Artifacts).

First run on Android 13+: App info > three dots > "Allow restricted settings", then open the app,
allow permissions and tap "Set" to make it your default SMS app.

## What's new in 3.0

- **Swipe actions** — swipe a chat right to pin/unpin, left to delete. Swipe a message right to star it, left to delete it.
- **Quick copy for any number** — phone numbers, account numbers and PNRs get a one-tap copy chip under the message.
- **Read aloud** — hold a message (or open the chat menu) to hear it spoken by the phone's voice engine.
- **Text size slider + Elder-friendly mode** — scales every screen; elder mode also enlarges buttons.
- **Saved info vault** — pin PNRs, loan numbers and Wi-Fi passwords, searchable, unlocked with fingerprint / face / phone PIN. Hold a message and tap *Save to vault*.
- **Sender names instead of raw IDs** — AX-HDFCBK shows as **HDFC Bank**, VK-JIO as **Jio**, AD-PAYTM as **Paytm**, each with a brand coloured logo tile.
- **Send later with a real calendar + clock** — pick any date, hour, minute and AM/PM.
- **Bulk chat deletion** — top-bar selection mode with Select all, plus a wipe-away animation (no particles).
- **All contacts** — the compose screen now lists every contact with a draggable A–Z bar on the right.

## What's new in 4.0

- **Selection bar fixed** — when you select chats the Delete and Select all buttons now appear on top (they were drawn behind the list).
- **Undo send** — every message waits 5 seconds with a shrinking bar, so you can pull it back.
- **Export a chat as PDF** — chat menu > *Export chat as PDF*, timestamped and ready to share (bank disputes, complaints).
- **Translate any SMS** — hold a message > *Translate*. Hindi, Tamil, Bengali, Telugu, Marathi, Kannada, Malayalam, Gujarati and Punjabi, on-device.
- **Voice typing bar** — the waveform key next to the emoji key: speak, watch the live bars, send.
- **Announce messages** — Settings > *Announce messages aloud* speaks the sender and message when headphones or car Bluetooth are connected.
- **Spam report to 1909** — hold a message > *Report spam to 1909*, and every chat header now says whether the sender is a registered brand, an unregistered header or a short code.
- **Laptop companion** — menu > *Use from laptop*: scan the QR and read/reply to SMS in a browser on the same Wi-Fi, no account needed.
- **More life in the UI** — parallax gradient background, a slowly sweeping title gradient, and four new themes (Indigo Night, Neon, Sakura, Copper).
- **Better sender names** — IDs like JD-JIOCPN-P, JX-JioPay-S and AX-HDFCBK now resolve to Jio, JioPay and HDFC Bank.

## What's new in 5.0 — the moving UI

- **Theme blends, it doesn't snap** — tap any theme and the entire app cross-fades through colour over 0.4s (background, cards, text, accents, gradients).
- **Living background** — three colour blobs drift on separate 9s / 13s / 17s paths and breathe in size, instead of one slow sweep.
- **Collapsing header** — the Messages title shrinks and fades as you scroll, while the background slides at a different speed (parallax).
- **Shimmer skeletons** — the first time the list loads you see softly shimmering placeholder rows instead of an empty screen.
- **Sweeping title gradient** — the word Messages has a gradient that travels across it.
- **Live motion switch** — Settings > Live motion turns all of it off for battery, without changing the look otherwise.

## What's new in 5.1

- **OTP widget is private by default** — the code sits behind a real blur. Tap once to reveal it for 10 seconds, tap again to copy. After two minutes the widget stops showing the OTP at all.
- **Eight new themes** — Chhath, Monsoon, Peacock, Lagoon, Desert, Ivory, Cyber and Maroon. The **Chhath** theme has its own animated background: a setting sun with breathing rays and a shimmering river.
- **Vault 2.0, a mini DigiLocker** — tickets render as real tickets (PNR in mono type, dashed tear line, QR to scan at the gate); Aadhaar/PAN/DL as ID cards with masked numbers that reveal for 10 seconds; bank cards with a card face; admit cards, applications and results with a study layout. Filter by type, search everything, copy, share, edit, delete.

## What's new in 6.0

- **Tickets found in your messages** — the app reads your IRCTC and airline SMS and pulls out the PNR, train number and name, route, class, coach and berth, and journey date. A banner on the home screen tells you when one is waiting; one tap saves it as a ticket card. No API key, no server, nothing leaves the phone.
- **Check live status** — every ticket card has a button that copies the PNR and opens the official IRCTC enquiry page.
- **Journey reminder** — saving a ticket with a date schedules a notification three hours before departure.
- **Search all messages** — a real full-text search across every SMS on the phone, with the matched words highlighted; tap a result to jump into that chat. Also on the launcher icon as a long-press shortcut.
- **Launcher shortcuts** — long-press the Messages icon for New message, Search, Vault and Use from laptop.
- **Mark all as read** — one entry in the top menu.

## What's new in 7.0 — live themes

- **The theme picker is animated.** Every card now runs that theme's real background, not a flat swatch, and the ones with a moving scene are tagged **LIVE**.
- **Ten animated scenes**: drifting colour blobs, the Chhath sun over a river, monsoon rain, falling sakura petals, a neon synthwave grid, rising ocean bubbles, peacock rings, a twinkling galaxy, lava embers and drifting clouds.
- **Hero preview** at the top of Settings: the selected theme playing full size, with **Surprise me** to jump to a random one.
- **24 themes** — added Galaxy, Lava, Sky and Coral.

## What's new in 7.1

- **18 animated scene types, 31 themes.** New scenes: tide waves, orbiting planets, drifting fireflies, floating festival lamps with sparkles, a prism sweep, falling snow and a bouncing equaliser.
- **A proper theme gallery** — Settings > Theme opens a full screen with All / Live / Dark / Light filters, every card playing its own background.
- **Settings organised into sections** — Appearance, Messages, Privacy & Security, Storage and About, with the live theme preview on top and each row showing the real count (saved items, hidden chats, deleted messages).

## What's new in 8.0

- **Rules** — silence a sender, auto-delete old messages after N minutes, keep some forever, or forward them to another number. Runs on the phone, checked every 10 minutes.
- **Parcels & rides** — delivery messages become cards with courier, status and AWB plus a Track button; cab messages show vehicle number and ride OTP.
- **Bill calendar** — every due date from your bank and service SMS on a month grid, with a reminder two days before.
- **Broadcast lists** — one message to a saved group, sent as individual SMS so replies stay private.
- **Archive** — hide a conversation without deleting it; a new Archived filter in the chips shows them, and every chip now carries its count.
- **OTP history** — every code from the last 30 days, searchable and one tap to copy.
- **Emergency SOS** — hold for three seconds and your chosen contacts get an SMS with your location, no internet needed.

## What's new in 8.1

- **A real menu.** The three-dot menu is now eight quick tiles (Nearby, Money, Parcels, Bills, Rules, Vault, Laptop, SOS) over two tidy groups, with a header showing unread, tickets and saved items.
- **Shorter message menu.** Hold a message and you get a 4-wide grid of icon tiles instead of a tall list — Copy, Star, Forward, Speak, Translate, Vault, Share, Info, Select, Remind, Report, Delete.
- **Proper voices.** Read aloud now picks the highest-quality voice installed on the phone and can speak long chats in chunks. Settings > Read aloud voice lists every voice, male and female, HD or on-device, with a live sample and a speed slider.

## What's new in 8.2

- **Write in one language, send in another.** In any chat, type in English and tap the translate key next to the clock. Pick Hindi, Tamil, Bengali, Telugu, Marathi, Kannada, Malayalam, Gujarati or Punjabi, see exactly what will go out, then Send — or Edit first to tweak it. The language is remembered per contact, so the next message opens on the right one.

## What's new in 9.0 — make it yours

- **Personalise screen** (Settings > Personalise): pick any accent hue from fourteen dots, set bubble roundness from 8dp to 30dp, switch bubbles between filled and glass, choose a chat background (none, dots, grid or waves), pick the typeface (system, serif, mono), set row spacing (compact, normal, roomy) and square off your avatars. Everything previews live and applies across the whole app.
- **Ask your messages** — a new screen that answers questions in plain language: "bill due?", "balance", "last OTP", "where is my parcel", "next trip", "spending this month". Answered on the phone from your own SMS.
- **Twelve-tile menu** with Ask, Search, Broadcast and Look on a third row.

## What's new in 10.0 — the vault, rebuilt

- **It lives outside the app.** Your vault is an AES-256 encrypted file in `Downloads/MessagesVault`. Uninstalling Messages doesn't delete it; after a reinstall you enter the same recovery phrase and everything comes back.
- **Ten document types**, each with its own form and card: Aadhaar (tricolour card), PAN, bank card, bank account, passport/DL/voter, marksheet, ticket/PNR, password, Wi-Fi and anything else.
- **Attach any file** — images, PDFs, anything up to 25 MB — encrypted alongside the item.
- **In-app viewer** for images and multi-page PDFs, with a Download button that copies the decrypted file to your Downloads folder.
- **Secrets stay hidden**: numbers and passwords are masked until you tap the eye, and re-hide after 12 seconds.
- **No screenshots** while the vault is open (FLAG_SECURE), and nothing in the recents thumbnail.

## What's new in 10.1

- **Vault PIN** — first time you open the vault you save your phone number and choose a 6-digit PIN, typed twice on a big animated keypad. After that the vault opens with fingerprint, face or that PIN.
- **Forgot PIN, offline** — enter your number; if it matches the saved one, the app shows a one-time code as a notification. Type it, set a new PIN. No server, no internet, nothing leaves the phone.
- **New notification system** — five channels (Messages, One-time passwords, Offers, Reminders and trips, Vault codes), chat-style notifications that show the last three lines of the conversation, Mark read and Reply actions, and offers stay silent instead of buzzing.
