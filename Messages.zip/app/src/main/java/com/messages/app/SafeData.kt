package com.messages.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Everything that used to vanish on uninstall: vault PIN + phone, broadcast lists and their history,
 * rules, scheduled messages and a few lists. It is sealed with the vault key (so only the recovery
 * phrase can open it) and travels with the vault files into the safe copy.
 */
object SafeData {
    private val ex = Executors.newSingleThreadScheduledExecutor()
    private var pending: ScheduledFuture<*>? = null

    @Synchronized
    fun touch(ctx: Context) {
        val app = ctx.applicationContext
        pending?.cancel(false)
        pending = ex.schedule({
            try { writeNow(app) } catch (_: Throwable) { }
        }, 1500, TimeUnit.MILLISECONDS)
    }

    /** Writes the current data into the vault's safe copy, if the vault key is available. */
    fun writeNow(ctx: Context): Boolean {
        if (!VaultStore.unlocked && !VaultStore.unlockQuietly(ctx)) return false
        return VaultStore.saveMeta(ctx, snapshot(ctx))
    }

    private fun arr(l: Collection<String>): JSONArray {
        val a = JSONArray()
        l.forEach { a.put(it) }
        return a
    }

    private fun snapshot(ctx: Context): String {
        val s = Store(ctx)
        val o = JSONObject()
        o.put("v", 1)
        o.put("t", System.currentTimeMillis())
        o.put("bcasts", s.getStr("bcasts"))
        o.put("bcastlog", s.getStr("bcastlog"))
        o.put("rules", s.getStr("rules"))
        o.put("sched", s.getStr("sched"))
        o.put("sos", arr(s.sos))
        o.put("private", arr(s.privateSet))
        o.put("blocked", arr(s.blocked))
        o.put("archived", arr(s.archived))
        o.put("sec", VaultSecurity.exportSec(ctx))
        SecureCore.exportIdentity(ctx)?.let { o.put("scid", it) }
        o.put("sccon", SecureDb.get(ctx).exportContacts())
        return o.toString()
    }

    private fun mergeById(local: String, saved: String): String {
        val a = try { JSONArray(if (local.isEmpty()) "[]" else local) } catch (_: Exception) { JSONArray() }
        val b = try { JSONArray(if (saved.isEmpty()) "[]" else saved) } catch (_: Exception) { JSONArray() }
        val have = HashSet<Long>()
        for (i in 0 until a.length()) have.add(a.getJSONObject(i).optLong("id"))
        for (i in 0 until b.length()) {
            val x = b.getJSONObject(i)
            if (x.optLong("id") !in have) a.put(x)
        }
        return a.toString()
    }

    private fun strings(a: JSONArray?): Set<String> {
        val out = HashSet<String>()
        if (a != null) for (i in 0 until a.length()) out.add(a.optString(i))
        return out
    }

    /** After the vault opens: bring back whatever this install doesn't have yet. */
    fun restore(ctx: Context): Boolean {
        val json = VaultStore.loadMeta(ctx) ?: return false
        return try {
            val o = JSONObject(json)
            val s = Store(ctx)
            s.putStr("bcasts", mergeById(s.getStr("bcasts"), o.optString("bcasts", "")))
            s.putStr("bcastlog", mergeById(s.getStr("bcastlog"), o.optString("bcastlog", "")))
            s.putStr("rules", mergeById(s.getStr("rules"), o.optString("rules", "")))
            s.putStr("sched", mergeById(s.getStr("sched"), o.optString("sched", "")))
            s.sos = s.sos + strings(o.optJSONArray("sos"))
            s.privateSet = s.privateSet + strings(o.optJSONArray("private"))
            s.blocked = s.blocked + strings(o.optJSONArray("blocked"))
            s.archived = s.archived + strings(o.optJSONArray("archived"))
            o.optJSONObject("sec")?.let { VaultSecurity.importSec(ctx, it) }
            SecureCore.importIdentity(ctx, o.optJSONObject("scid"))
            SecureDb.get(ctx).importContacts(o.optJSONArray("sccon"))
            true
        } catch (_: Exception) { false }
    }
}
