@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Every theme, playing live, with filters. */
@Composable
fun ThemeGalleryScreen(vm: MessagesVM, onBack: () -> Unit) {
    val st by vm.settings.collectAsState()
    var filter by remember { mutableStateOf(0) }
    val list = remember(filter) {
        THEMES.filter {
            when (filter) {
                1 -> it.name in LIVE_THEMES
                2 -> it.dark
                3 -> !it.dark
                else -> true
            }
        }
    }
    Page("Themes", onBack, actions = {
        Text(
            THEMES.size.toString() + " themes", color = Dim, fontSize = 12.sp,
            modifier = Modifier.padding(end = 14.dp)
        )
    }) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Chip("All", filter == 0) { filter = 0 }
            Chip("Live", filter == 1) { filter = 1 }
            Chip("Dark", filter == 2) { filter = 2 }
            Chip("Light", filter == 3) { filter = 3 }
        }
        Text(
            "Each card plays its theme live. Tap one and the whole app blends into it.",
            color = Dim, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            itemsIndexed(list.chunked(2)) { _, pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    pair.forEach { t ->
                        val idx = THEMES.indexOf(t)
                        ThemeCard(t, st.theme == idx, Modifier.weight(1f)) { vm.setTheme(idx) }
                    }
                    if (pair.size < 2) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}
