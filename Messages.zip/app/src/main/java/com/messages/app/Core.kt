package com.messages.app

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- models

data class Msg(
    val id: Long,
    val threadId: Long,
    val address: String,
    val body: String,
    val date: Long,
    val outgoing: Boolean,
    val pending: Boolean = false,
    val failed: Boolean = false
)

data class Convo(
    val threadId: Long,
    val address: String,
    val name: String,
    val snippet: String,
    val date: Long,
    val unread: Int,
    val outgoing: Boolean
)

data class Chat(val threadId: Long, val address: String, val name: String)

data class Contact(val name: String, val number: String)

data class TrashItem(val msg: Msg, val deletedAt: Long)

// ---------------------------------------------------------------- formatting

private val hmFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
private val dayFmt = SimpleDateFormat("d MMM", Locale.getDefault())
private val fullFmt = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault())

fun hm(t: Long): String = hmFmt.format(Date(t))
fun dayLabel(t: Long): String {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = t }
    val sameYear = now.get(Calendar.YEAR) == then.get(Calendar.YEAR)
    val dayDiff = now.get(Calendar.DAY_OF_YEAR) - then.get(Calendar.DAY_OF_YEAR)
    return when {
        sameYear && dayDiff == 0 -> "Today"
        sameYear && dayDiff == 1 -> "Yesterday"
        sameYear -> dayFmt.format(Date(t))
        else -> SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(t))
    }
}

fun fullStamp(t: Long): String = fullFmt.format(Date(t))

fun sameDay(a: Long, b: Long): Boolean {
    val ca = Calendar.getInstance().apply { timeInMillis = a }
    val cb = Calendar.getInstance().apply { timeInMillis = b }
    return ca.get(Calendar.YEAR) == cb.get(Calendar.YEAR) &&
        ca.get(Calendar.DAY_OF_YEAR) == cb.get(Calendar.DAY_OF_YEAR)
}

fun listStamp(t: Long): String =
    if (sameDay(t, System.currentTimeMillis())) hm(t) else dayLabel(t)

fun initials(name: String): String {
    val parts = name.trim().split(" ").filter { it.isNotBlank() }
    return when {
        parts.isEmpty() -> "#"
        parts.size == 1 -> parts[0].take(1).uppercase(Locale.getDefault())
        else -> (parts[0].take(1) + parts[1].take(1)).uppercase(Locale.getDefault())
    }
}

fun looksLikeOtp(body: String): String? {
    val m = Regex("\\b(\\d{4,8})\\b").find(body) ?: return null
    val lower = body.lowercase(Locale.getDefault())
    val hint = lower.contains("otp") || lower.contains("code") || lower.contains("verif") || lower.contains("password")
    return if (hint) m.groupValues[1] else null
}

// ---------------------------------------------------------------- sms repo

class SmsRepo(private val ctx: Context) {

    @Volatile
    private var nameMap: Map<String, String>? = null

    private fun norm(n: String): String {
        val d = n.filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }

    fun names(): Map<String, String> {
        nameMap?.let { return it }
        val out = HashMap<String, String>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val nm = c.getString(0)
                    val no = c.getString(1)
                    if (nm != null && no != null) {
                        val k = norm(no)
                        if (k.isNotEmpty()) out[k] = nm
                    }
                }
            }
        } catch (_: Exception) {
        }
        nameMap = out
        return out
    }

    fun nameFor(address: String): String {
        val m = names()
        return m[norm(address)] ?: address.ifBlank { "Unknown" }
    }

    fun conversations(): List<Convo> {
        val rows = ArrayList<Convo>()
        val unread = HashMap<Long, Int>()
        try {
            val proj = arrayOf(
                Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY,
                Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ
            )
            ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI, proj, null, null,
                "${Telephony.Sms.DATE} DESC"
            )?.use { c ->
                val seen = HashSet<Long>()
                while (c.moveToNext()) {
                    val tid = c.getLong(0)
                    val type = c.getInt(4)
                    val read = c.getInt(5)
                    if (type == Telephony.Sms.MESSAGE_TYPE_INBOX && read == 0) {
                        unread[tid] = (unread[tid] ?: 0) + 1
                    }
                    if (!seen.add(tid)) continue
                    val addr = c.getString(1) ?: ""
                    rows.add(
                        Convo(
                            threadId = tid,
                            address = addr,
                            name = nameFor(addr),
                            snippet = c.getString(2) ?: "",
                            date = c.getLong(3),
                            unread = 0,
                            outgoing = type == Telephony.Sms.MESSAGE_TYPE_SENT
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return rows.map { it.copy(unread = unread[it.threadId] ?: 0) }
    }

    fun messages(threadId: Long): List<Msg> {
        val out = ArrayList<Msg>()
        try {
            val proj = arrayOf(
                Telephony.Sms._ID, Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE
            )
            ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI, proj,
                "${Telephony.Sms.THREAD_ID} = ?", arrayOf(threadId.toString()),
                "${Telephony.Sms.DATE} ASC, ${Telephony.Sms._ID} ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val type = c.getInt(5)
                    out.add(
                        Msg(
                            id = c.getLong(0),
                            threadId = c.getLong(1),
                            address = c.getString(2) ?: "",
                            body = c.getString(3) ?: "",
                            date = c.getLong(4),
                            outgoing = type == Telephony.Sms.MESSAGE_TYPE_SENT,
                            pending = type == Telephony.Sms.MESSAGE_TYPE_OUTBOX,
                            failed = type == Telephony.Sms.MESSAGE_TYPE_FAILED
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun send(address: String, body: String): Boolean {
        if (body.isBlank()) return false
        return try {
            val sm: SmsManager? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ctx.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            if (sm == null) return false
            val parts = sm.divideMessage(body)
            if (parts.size > 1) {
                sm.sendMultipartTextMessage(address, null, parts, null, null)
            } else {
                sm.sendTextMessage(address, null, body, null, null)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun markRead(threadId: Long) {
        try {
            val cv = ContentValues().apply { put(Telephony.Sms.READ, 1) }
            ctx.contentResolver.update(
                Telephony.Sms.CONTENT_URI, cv,
                "${Telephony.Sms.THREAD_ID} = ? AND ${Telephony.Sms.READ} = 0",
                arrayOf(threadId.toString())
            )
        } catch (_: Exception) {
        }
    }

    fun deleteMessage(id: Long): Boolean = try {
        ctx.contentResolver.delete(
            Telephony.Sms.CONTENT_URI, "${Telephony.Sms._ID} = ?", arrayOf(id.toString())
        ) > 0
    } catch (_: Exception) {
        false
    }

    fun deleteThread(threadId: Long): Boolean = try {
        ctx.contentResolver.delete(
            Telephony.Sms.CONTENT_URI, "${Telephony.Sms.THREAD_ID} = ?", arrayOf(threadId.toString())
        ) > 0
    } catch (_: Exception) {
        false
    }

    fun isDefault(): Boolean = try {
        Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName
    } catch (_: Exception) {
        false
    }

    fun threadFor(address: String): Long = try {
        Telephony.Threads.getOrCreateThreadId(ctx, address)
    } catch (_: Exception) {
        0L
    }

    fun contacts(query: String): List<Contact> {
        val out = ArrayList<Contact>()
        try {
            val proj = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val sel = if (query.isBlank()) null else ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?"
            val args = if (query.isBlank()) null else arrayOf("%$query%")
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, sel, args,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )?.use { c ->
                val seen = HashSet<String>()
                while (c.moveToNext() && out.size < 80) {
                    val nm = c.getString(0) ?: continue
                    val no = c.getString(1) ?: continue
                    if (seen.add(norm(no))) out.add(Contact(nm, no))
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}

// ---------------------------------------------------------------- local store

class Store(ctx: Context) {

    private val sp = ctx.getSharedPreferences("msg_store", Context.MODE_PRIVATE)

    private fun ids(key: String): MutableSet<Long> =
        (sp.getStringSet(key, emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toMutableSet()

    private fun putIds(key: String, v: Set<Long>) {
        sp.edit().putStringSet(key, v.map { it.toString() }.toSet()).apply()
    }

    fun hidden(): Set<Long> = ids("hidden")

    fun hide(id: Long) {
        val s = ids("hidden"); s.add(id); putIds("hidden", s)
    }

    fun unhide(id: Long) {
        val s = ids("hidden"); s.remove(id); putIds("hidden", s)
    }

    fun starred(): Set<Long> = ids("starred")

    fun toggleStar(id: Long): Boolean {
        val s = ids("starred")
        val on = if (s.contains(id)) { s.remove(id); false } else { s.add(id); true }
        putIds("starred", s)
        return on
    }

    fun pinned(): Set<Long> = ids("pinned")

    fun togglePin(id: Long): Boolean {
        val s = ids("pinned")
        val on = if (s.contains(id)) { s.remove(id); false } else { s.add(id); true }
        putIds("pinned", s)
        return on
    }

    fun mutedThreads(): Set<Long> = ids("muted")

    fun toggleMute(threadId: Long): Boolean {
        val s = ids("muted")
        val on = if (s.contains(threadId)) { s.remove(threadId); false } else { s.add(threadId); true }
        putIds("muted", s)
        return on
    }

    fun reactions(): Map<Long, String> {
        val raw = sp.getString("reactions", null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            val m = HashMap<Long, String>()
            o.keys().forEach { k -> k.toLongOrNull()?.let { m[it] = o.getString(k) } }
            m
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun setReaction(id: Long, emoji: String?) {
        val m = reactions().toMutableMap()
        if (emoji == null) m.remove(id) else m[id] = emoji
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), v) }
        sp.edit().putString("reactions", o.toString()).apply()
    }

    fun accentFor(threadId: Long): Int = sp.getInt("accent_$threadId", -1)

    fun setAccent(threadId: Long, idx: Int) {
        sp.edit().putInt("accent_$threadId", idx).apply()
    }

    // ---- recycle bin

    fun trash(): List<TrashItem> {
        val raw = sp.getString("trash", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val m = o.getJSONObject("m")
                TrashItem(
                    Msg(
                        id = m.getLong("id"),
                        threadId = m.getLong("tid"),
                        address = m.getString("addr"),
                        body = m.getString("body"),
                        date = m.getLong("date"),
                        outgoing = m.getBoolean("out")
                    ),
                    o.getLong("at")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeTrash(list: List<TrashItem>) {
        val arr = JSONArray()
        list.forEach { t ->
            val m = JSONObject()
                .put("id", t.msg.id).put("tid", t.msg.threadId)
                .put("addr", t.msg.address).put("body", t.msg.body)
                .put("date", t.msg.date).put("out", t.msg.outgoing)
            arr.put(JSONObject().put("m", m).put("at", t.deletedAt))
        }
        sp.edit().putString("trash", arr.toString()).apply()
    }

    fun addTrash(m: Msg) {
        val list = trash().filterNot { it.msg.id == m.id }.toMutableList()
        list.add(0, TrashItem(m, System.currentTimeMillis()))
        writeTrash(list)
        hide(m.id)
    }

    fun removeTrash(id: Long) {
        writeTrash(trash().filterNot { it.msg.id == id })
    }

    fun purgeTrash(days: Int = 30) {
        val cut = System.currentTimeMillis() - days * 24L * 60L * 60L * 1000L
        writeTrash(trash().filter { it.deletedAt > cut })
    }

    fun clearTrash() {
        writeTrash(emptyList())
    }
}

// ---------------------------------------------------------------- view model

class MessagesVM(app: Application) : AndroidViewModel(app) {

    val repo = SmsRepo(app)
    val store = Store(app)

    val convos = MutableStateFlow<List<Convo>>(emptyList())
    val msgs = MutableStateFlow<List<Msg>>(emptyList())
    val open = MutableStateFlow<Chat?>(null)
    val trash = MutableStateFlow<List<TrashItem>>(emptyList())
    val loaded = MutableStateFlow(false)
    val loading = MutableStateFlow(false)
    val contacts = MutableStateFlow<List<Contact>>(emptyList())
    val searchResults = MutableStateFlow<List<Msg>>(emptyList())
    val starredMsgs = MutableStateFlow<List<Msg>>(emptyList())
    private var searchJob: kotlinx.coroutines.Job? = null

    private val hidden = MutableStateFlow<Set<Long>>(emptySet())
    private val starred = MutableStateFlow<Set<Long>>(emptySet())
    private val pinned = MutableStateFlow<Set<Long>>(emptySet())
    private val reactions = MutableStateFlow<Map<Long, String>>(emptyMap())

    init {
        hidden.value = store.hidden()
        starred.value = store.starred()
        pinned.value = store.pinned()
        reactions.value = store.reactions()
        trash.value = store.trash()
        store.purgeTrash()
        refresh()
    }

    fun isStarred(id: Long) = starred.value.contains(id)
    fun isPinned(id: Long) = pinned.value.contains(id)
    fun reactionOf(id: Long) = reactions.value[id]

    fun refresh() {
        viewModelScope.launch {
            loading.value = true
            val list = withContext(Dispatchers.IO) { repo.conversations() }
            convos.value = list
            loading.value = false
            loaded.value = true
            open.value?.let { reloadMsgs(it.threadId) }
        }
    }

    fun openChat(chat: Chat) {
        open.value = chat
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.markRead(chat.threadId) }
            reloadMsgs(chat.threadId)
            convos.value = convos.value.map { if (it.threadId == chat.threadId) it.copy(unread = 0) else it }
        }
    }

    fun closeChat() {
        open.value = null
        msgs.value = emptyList()
        refresh()
    }

    fun reloadMsgs(threadId: Long) {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { repo.messages(threadId) }
            msgs.value = list.filterNot { hidden.value.contains(it.id) }
        }
    }

    fun startChat(address: String, name: String) {
        val tid = repo.threadFor(address)
        openChat(Chat(if (tid > 0) tid else address.hashCode().toLong(), address, name.ifBlank { repo.nameFor(address) }))
    }

    fun send(text: String, chat: Chat) {
        val body = text.trim()
        if (body.isEmpty()) return
        val ok = repo.send(chat.address, body)
        if (ok) {
            // optimistic bubble until the system database catches up
            val temp = Msg(
                id = -System.currentTimeMillis(),
                threadId = chat.threadId,
                address = chat.address,
                body = body,
                date = System.currentTimeMillis(),
                outgoing = true,
                pending = true
            )
            msgs.value = msgs.value + temp
            viewModelScope.launch {
                kotlinx.coroutines.delay(700)
                reloadMsgs(chat.threadId)
            }
        }
    }

    fun forwardTo(text: String, chat: Chat) {
        repo.send(chat.address, text)
        refresh()
    }

    fun trashMsg(m: Msg) {
        store.addTrash(m)
        hidden.value = store.hidden()
        msgs.value = msgs.value.filterNot { it.id == m.id }
        trash.value = store.trash()
        refresh()
    }

    fun restore(t: TrashItem) {
        store.unhide(t.msg.id)
        store.removeTrash(t.msg.id)
        hidden.value = store.hidden()
        trash.value = store.trash()
        reloadMsgs(t.msg.threadId)
        refresh()
    }

    fun deleteForever(t: TrashItem) {
        repo.deleteMessage(t.msg.id)
        store.removeTrash(t.msg.id)
        trash.value = store.trash()
    }

    fun emptyTrash() {
        trash.value.forEach { repo.deleteMessage(it.msg.id) }
        store.clearTrash()
        trash.value = emptyList()
    }

    fun toggleStar(id: Long) {
        store.toggleStar(id)
        starred.value = store.starred()
    }

    fun togglePin(id: Long) {
        store.togglePin(id)
        pinned.value = store.pinned()
    }

    fun react(id: Long, emoji: String?) {
        store.setReaction(id, emoji)
        reactions.value = store.reactions()
    }

    fun copy(text: String) {
        try {
            val cm = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("message", text))
        } catch (_: Exception) {
        }
    }

    fun loadContacts(q: String) {
        viewModelScope.launch {
            contacts.value = withContext(Dispatchers.IO) { repo.contacts(q) }
        }
    }

    fun search(q: String) {
        searchJob?.cancel()
        if (q.length < 2) {
            searchResults.value = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            kotlinx.coroutines.delay(180)
            searchResults.value = withContext(Dispatchers.IO) { searchMessages(q) }
        }
    }

    fun loadStarred() {
        viewModelScope.launch {
            val ids = store.starred()
            starredMsgs.value = withContext(Dispatchers.IO) {
                if (ids.isEmpty()) emptyList()
                else repo.conversations().flatMap { c ->
                    repo.messages(c.threadId).filter { ids.contains(it.id) }
                }.sortedByDescending { it.date }
            }
        }
    }

    fun searchMessages(q: String): List<Msg> {
        if (q.isBlank()) return emptyList()
        val out = ArrayList<Msg>()
        convos.value.take(40).forEach { c ->
            repo.messages(c.threadId).filter { it.body.contains(q, true) }.forEach { out.add(it) }
            if (out.size > 60) return@forEach
        }
        return out.sortedByDescending { it.date }.take(60)
    }
}
