package com.messages.app

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Telephony
import android.telephony.SmsManager

data class Convo(
    val threadId: Long, val address: String, val name: String, val snippet: String,
    val date: Long, val unread: Int, val code: String?, val outgoing: Boolean
)

data class Msg(
    val id: Long, val body: String, val date: Long, val outgoing: Boolean,
    val failed: Boolean, val pending: Boolean, val code: String?
)

data class Contact(val name: String, val number: String)
data class Chat(val threadId: Long, val address: String, val name: String)

fun nk(a: String): String = a.filter { it.isDigit() }.takeLast(10).ifEmpty { a }

object Otp {
    private val key = Regex(
        "\\b(otp|one[- ]?time|verification|verify|passcode|password|pin|code|login|security|authenticat\\w*)\\b|ओटीपी",
        RegexOption.IGNORE_CASE
    )
    private val dashed = Regex("\\b(\\d{3})[- ](\\d{3})\\b")
    private val num = Regex("(?<!\\d)(\\d{4,8})(?!\\d)")

    fun find(body: String): String? {
        if (!key.containsMatchIn(body)) return null
        dashed.find(body)?.let { return it.groupValues[1] + it.groupValues[2] }
        return num.find(body)?.groupValues?.get(1)
    }
}

class SmsRepo(private val ctx: Context) {
    private val cr get() = ctx.contentResolver
    private val names = HashMap<String, String>()

    fun isDefault(): Boolean = Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName

    fun name(address: String): String {
        names[address]?.let { return it }
        var n = address
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address))
            cr.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) n = it.getString(0) ?: address
            }
            names[address] = n
        } catch (_: Exception) { }
        return n
    }

    fun conversations(): List<Convo> {
        val map = LinkedHashMap<Long, Convo>()
        val unread = HashMap<Long, Int>()
        try {
            cr.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf("_id", "thread_id", "address", "body", "date", "type", "read"),
                null, null, "date DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n++ < 6000) {
                    val type = c.getInt(5)
                    if (type == 3) continue
                    val t = c.getLong(1)
                    if (type == 1 && c.getInt(6) == 0) unread[t] = (unread[t] ?: 0) + 1
                    if (!map.containsKey(t)) {
                        val addr = c.getString(2) ?: "Unknown"
                        val body = c.getString(3) ?: ""
                        map[t] = Convo(t, addr, name(addr), body, c.getLong(4), 0,
                            if (type == 1) Otp.find(body) else null, type != 1)
                    }
                }
            }
        } catch (_: SecurityException) { }
        return map.values.map { it.copy(unread = unread[it.threadId] ?: 0) }
    }

    fun messages(threadId: Long, address: String): List<Msg> {
        val out = ArrayList<Msg>()
        try {
            val sel = if (threadId > 0) "thread_id=?" else "address=?"
            val arg = if (threadId > 0) threadId.toString() else address
            cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "body", "date", "type"), sel, arrayOf(arg), "date ASC")?.use { c ->
                while (c.moveToNext()) {
                    val type = c.getInt(3)
                    if (type == 3) continue
                    val body = c.getString(1) ?: ""
                    out.add(Msg(c.getLong(0), body, c.getLong(2), type != 1, type == 5,
                        type == 4 || type == 6, if (type == 1) Otp.find(body) else null))
                }
            }
        } catch (_: SecurityException) { }
        return out
    }

    fun markRead(threadId: Long) {
        try {
            cr.update(Telephony.Sms.CONTENT_URI,
                ContentValues().apply { put("read", 1); put("seen", 1) },
                "thread_id=? AND read=0", arrayOf(threadId.toString()))
        } catch (_: Exception) { }
    }

    fun deleteThread(threadId: Long) {
        try { cr.delete(Telephony.Sms.CONTENT_URI, "thread_id=?", arrayOf(threadId.toString())) } catch (_: Exception) { }
    }

    fun threadFor(address: String): Long =
        try { Telephony.Threads.getOrCreateThreadId(ctx, address) } catch (_: Exception) { -1L }

    fun saveIncoming(address: String, body: String, date: Long) {
        try {
            cr.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
                put("address", address); put("body", body); put("date", date)
                put("read", 0); put("seen", 0)
            })
        } catch (_: Exception) { }
    }

    fun contacts(q: String): List<Contact> = try {
        val sel = if (q.isBlank()) null else "${Phone.DISPLAY_NAME} LIKE ? OR ${Phone.NUMBER} LIKE ?"
        val args = if (q.isBlank()) null else arrayOf("%$q%", "%$q%")
        val out = ArrayList<Contact>()
        cr.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), sel, args, "${Phone.DISPLAY_NAME} ASC")?.use { c ->
            while (c.moveToNext() && out.size < 80) out.add(Contact(c.getString(0) ?: "", c.getString(1) ?: ""))
        }
        out.distinctBy { it.name + nk(it.number) }
    } catch (_: Exception) { emptyList() }

    @Suppress("DEPRECATION")
    fun send(address: String, body: String) {
        val to = address.trim()
        if (to.isEmpty() || body.isBlank()) return
        var uri: Uri? = null
        try {
            uri = cr.insert(Telephony.Sms.CONTENT_URI, ContentValues().apply {
                put("address", to); put("body", body); put("date", System.currentTimeMillis())
                put("read", 1); put("type", 4)
            })
        } catch (_: Exception) { }
        try {
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            val parts = sm.divideMessage(body)
            val u = uri
            val sent: ArrayList<PendingIntent>? = if (u != null) {
                val pi = PendingIntent.getBroadcast(
                    ctx, (u.lastPathSegment ?: "0").hashCode(),
                    Intent(ctx, SentReceiver::class.java).setData(u),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                ArrayList<PendingIntent>().also { l -> repeat(parts.size) { l.add(pi) } }
            } else null
            sm.sendMultipartTextMessage(to, null, parts, sent, null)
        } catch (e: Exception) {
            uri?.let { try { cr.update(it, ContentValues().apply { put("type", 5) }, null, null) } catch (_: Exception) { } }
        }
    }
}

class SentReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val u = i.data ?: return
        val type = if (resultCode == Activity.RESULT_OK) 2 else 5
        try { c.contentResolver.update(u, ContentValues().apply { put("type", type) }, null, null) } catch (_: Exception) { }
    }
}
