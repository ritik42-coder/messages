package com.messages.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.util.Base64
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Pictures over plain SMS: the image is shrunk to a tiny WebP, base64-encoded and sent as
 * numbered text chunks. The receiving Messages app rebuilds the picture. Works on any SIM.
 */
@Suppress("DEPRECATION")
object SmsPic {
    private val RE = Regex("^~P([0-9a-z]{4})([0-9a-z]{2})([0-9a-z]{2})([A-Za-z0-9+/=]+)$")
    const val CHUNK = 148

    private fun fmt() = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    fun count(bytes: ByteArray): Int = (((bytes.size + 2) / 3) * 4 + CHUNK - 1) / CHUNK

    fun shrink(ctx: Context, uri: Uri, target: Int): ByteArray? {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 800 || o.outHeight / s > 800) s *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            } ?: return null
            var dim = 160
            var q = 45
            var last: ByteArray? = null
            for (iter in 0 until 40) {
                val k = minOf(1f, dim.toFloat() / maxOf(bmp.width, bmp.height))
                val b = if (k < 1f) Bitmap.createScaledBitmap(bmp, maxOf(8, (bmp.width * k).toInt()), maxOf(8, (bmp.height * k).toInt()), true) else bmp
                val bo = ByteArrayOutputStream()
                b.compress(fmt(), q, bo)
                val out = bo.toByteArray()
                last = out
                if (out.size <= target || dim <= 24) break
                if (q > 25) q -= 7 else dim = (dim * 0.85f).toInt()
            }
            return last
        } catch (_: Exception) { return null }
    }

    private fun b36(n: Int) = Integer.toString(n, 36).padStart(2, '0')

    fun chunksOf(bytes: ByteArray): List<String> {
        val s = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val id = java.util.UUID.randomUUID().toString().replace("-", "").take(4).lowercase()
        val parts = s.chunked(CHUNK)
        return parts.mapIndexed { i, d -> "~P$id${b36(i + 1)}${b36(parts.size)}$d" }
    }

    suspend fun send(ctx: Context, address: String, bytes: ByteArray, onProgress: (Int, Int) -> Unit = { _, _ -> }): Boolean {
        val sm: SmsManager = Sims.manager(ctx, address)
        val parts = chunksOf(bytes)
        for ((i, c) in parts.withIndex()) {
            try { sm.sendTextMessage(address, null, c, null, null) } catch (_: Exception) { return false }
            onProgress(i + 1, parts.size)
            delay(350)
        }
        return true
    }

    /** Returns true if this SMS was a picture chunk (so it must not be shown as a normal message). */
    fun onChunk(c: Context, addr: String, body: String): Boolean {
        val m = RE.find(body) ?: return false
        val id = m.groupValues[1]
        val idx = m.groupValues[2].toInt(36)
        val n = m.groupValues[3].toInt(36)
        val data = m.groupValues[4]
        if (n < 1 || idx < 1 || idx > n) return true
        val st = Store(c)
        val key = "pc_" + nk(addr) + "_" + id
        val o = try { JSONObject(st.getStr(key).ifEmpty { "{}" }) } catch (_: Exception) { JSONObject() }
        o.put(idx.toString(), data)
        st.putStr(key, o.toString())
        val mid = (nk(addr) + id).hashCode().toLong() and 0x7fffffffL
        val now = System.currentTimeMillis()
        val list = st.media
        val old = list.firstOrNull { it.id == mid }
        if (o.length() < n) {
            val rec = Media(mid, addr, "", "image/webp", old?.date ?: now, false, false, 3, "Receiving picture ${o.length()}/$n SMS")
            st.media = if (old == null) list + rec else list.map { if (it.id == mid) rec else it }
        } else {
            try {
                val sb = StringBuilder()
                for (i in 1..n) sb.append(o.optString(i.toString()))
                val bytes = Base64.decode(sb.toString(), Base64.DEFAULT)
                val dir = File(c.filesDir, "media").apply { mkdirs() }
                val f = File(dir, "pic_$mid.webp")
                f.writeBytes(bytes)
                val rec = Media(mid, addr, f.path, "image/webp", old?.date ?: now, false, false, 0, "")
                st.media = if (old == null) list + rec else list.map { if (it.id == mid) rec else it }
                Notifier.show(c, addr, "\uD83D\uDCF7 Photo")
            } catch (_: Exception) {
                st.media = list.filter { it.id != mid }
            }
            st.putStr(key, "")
        }
        Bus.tick.value++
        return true
    }
}
