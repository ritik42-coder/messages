package com.messages.app

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

class VoiceInfo(
    val name: String, val label: String, val locale: String,
    val quality: Int, val network: Boolean, val male: Boolean
) {
    val tag: String
        get() = listOf(
            if (quality >= Voice.QUALITY_HIGH) "HD" else "",
            if (network) "online" else "on-device",
            if (male) "male" else "female"
        ).filter { it.isNotEmpty() }.joinToString(" \u00B7 ")
}

/**
 * Speaks messages with the best voice the phone has, and lets the reader pick
 * a specific one (male / female, HD, online or offline).
 */
object Voice {
    private var engine: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var speaking = false

    val isSpeaking: Boolean get() = speaking

    fun speak(ctx: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val store = Store(ctx)
        val wanted = store.ttsVoice
        val rate = store.ttsRate
        if (engine == null) {
            val made = TextToSpeech(ctx.applicationContext) { status ->
                ready = status == TextToSpeech.SUCCESS
                val e = engine
                if (ready && e != null) {
                    tune(e, wanted, rate)
                    val p = pending
                    pending = null
                    if (p != null) say(p)
                }
            }
            engine = made
        }
        if (ready) {
            engine?.let { tune(it, wanted, rate) }
            say(t)
        } else pending = t
    }

    /** Picks the chosen voice, or the best one installed for this language. */
    private fun tune(e: TextToSpeech, wanted: String, rate: Float) {
        try {
            e.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            val all = try { e.voices } catch (_: Exception) { null }
            val chosen = if (wanted.isNotBlank()) all?.firstOrNull { it.name == wanted } else null
            val v = chosen ?: best(all)
            if (v != null) e.voice = v else e.language = pick(e)
            e.setSpeechRate(rate.coerceIn(0.6f, 1.6f))
            e.setPitch(1f)
        } catch (_: Exception) { }
    }

    private fun best(all: Set<Voice>?): Voice? {
        val list = all?.toList() ?: return null
        val lang = Locale.getDefault().language
        val local = list.filter { it.locale.language == lang }
        val indian = list.filter { it.locale.country.equals("IN", true) }
        val english = list.filter { it.locale.language == "en" }
        val pool = when {
            local.isNotEmpty() -> local
            indian.isNotEmpty() -> indian
            english.isNotEmpty() -> english
            else -> list
        }
        return pool.sortedWith(
            compareByDescending<Voice> { it.quality }
                .thenBy { it.isNetworkConnectionRequired }
                .thenBy { it.name.length }
        ).firstOrNull()
    }

    private fun pick(e: TextToSpeech): Locale {
        val want = listOf(Locale.getDefault(), Locale("en", "IN"), Locale.US, Locale.UK)
        for (l in want) {
            val r = try { e.isLanguageAvailable(l) } catch (_: Exception) { TextToSpeech.LANG_NOT_SUPPORTED }
            if (r >= TextToSpeech.LANG_AVAILABLE) return l
        }
        return Locale.US
    }

    private fun say(t: String) {
        val e = engine ?: return
        try {
            speaking = true
            // long chats are spoken in chunks so nothing gets cut off
            if (t.length <= 3500) {
                e.speak(t, TextToSpeech.QUEUE_FLUSH, null, "messages")
            } else {
                var i = 0
                var first = true
                while (i < t.length) {
                    val end = (i + 3500).coerceAtMost(t.length)
                    val chunk = t.substring(i, end)
                    e.speak(chunk, if (first) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "messages$i")
                    first = false
                    i = end
                }
            }
        } catch (_: Exception) { speaking = false }
    }

    fun stop() {
        speaking = false
        pending = null
        try { engine?.stop() } catch (_: Exception) { }
    }

    fun shutdown() {
        stop()
        try { engine?.shutdown() } catch (_: Exception) { }
        engine = null
        ready = false
    }

    /** Every voice this phone can speak with, best first. */
    fun listVoices(ctx: Context, done: (List<VoiceInfo>) -> Unit) {
        val holder = arrayOfNulls<TextToSpeech>(1)
        val made = TextToSpeech(ctx.applicationContext) { status ->
            val e = holder[0]
            val out = ArrayList<VoiceInfo>()
            if (status == TextToSpeech.SUCCESS && e != null) {
                try {
                    val lang = Locale.getDefault().language
                    e.voices?.forEach { v ->
                        if (v.locale.language == lang || v.locale.language == "en" || v.locale.country.equals("IN", true)) {
                            out.add(
                                VoiceInfo(
                                    v.name, pretty(v.name), v.locale.toString(),
                                    v.quality, v.isNetworkConnectionRequired, looksMale(v.name)
                                )
                            )
                        }
                    }
                } catch (_: Exception) { }
            }
            done(
                out.sortedWith(
                    compareByDescending<VoiceInfo> { it.quality }
                        .thenBy { it.network }
                        .thenBy { it.label }
                )
            )
            try { e?.shutdown() } catch (_: Exception) { }
        }
        holder[0] = made
    }

    /** Reads one line with a voice you haven't picked yet. */
    fun preview(ctx: Context, text: String, voiceName: String, rate: Float) {
        val holder = arrayOfNulls<TextToSpeech>(1)
        val made = TextToSpeech(ctx.applicationContext) { status ->
            val e = holder[0] ?: return@TextToSpeech
            if (status == TextToSpeech.SUCCESS) {
                try {
                    val all = try { e.voices } catch (_: Exception) { null }
                    val v = all?.firstOrNull { it.name == voiceName } ?: best(all)
                    if (v != null) e.voice = v else e.language = pick(e)
                    e.setSpeechRate(rate.coerceIn(0.6f, 1.6f))
                    e.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview")
                } catch (_: Exception) { }
            }
        }
        holder[0] = made
    }

    private fun pretty(name: String): String =
        name.replace("-", " ").replace("_", " ").split(" ")
            .filter { it.isNotBlank() }
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercaseChar() } }

    /** Voice names don't carry gender, so this is a best guess from the naming scheme. */
    private fun looksMale(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("male") && !n.contains("female") ||
            n.contains("-end-") || n.contains("-x-end") || n.contains("-m0") || n.contains("_m_")
    }
}
