package com.messages.app

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Small wrapper around the phone's text-to-speech engine for "Read aloud". */
object Voice {
    private var engine: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var speaking = false

    val isSpeaking: Boolean get() = speaking

    fun speak(ctx: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val e = engine
        if (e == null) {
            val made = TextToSpeech(ctx.applicationContext) { status ->
                ready = status == TextToSpeech.SUCCESS
                val en = engine
                if (ready && en != null) {
                    try {
                        en.language = pick(en)
                        en.setSpeechRate(0.96f)
                        en.setPitch(1f)
                    } catch (_: Exception) { }
                    val p = pending
                    pending = null
                    if (p != null) say(p)
                }
            }
            engine = made
        }
        if (ready) say(t) else pending = t
    }

    private fun pick(e: TextToSpeech): Locale {
        val want = arrayListOf<Locale>()
        val def = Locale.getDefault()
        want.add(def)
        want.add(Locale("en", "IN"))
        want.add(Locale.US)
        want.add(Locale.UK)
        for (l in want) {
            val r = try { e.isLanguageAvailable(l) } catch (_: Exception) { TextToSpeech.LANG_NOT_SUPPORTED }
            if (r >= TextToSpeech.LANG_AVAILABLE) return l
        }
        return Locale.US
    }

    private fun say(t: String) {
        try {
            speaking = true
            engine?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "messages")
        } catch (_: Exception) { speaking = false }
    }

    fun stop() {
        speaking = false
        pending = null
        try { engine?.stop() } catch (_: Exception) { }
    }

    fun shutdown() {
        stop()
        try { engine?.shutdown() } catch (_: Exception) { }
        engine = null
        ready = false
    }
}
