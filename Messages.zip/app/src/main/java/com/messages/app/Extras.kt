@file:OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import android.telephony.TelephonyManager

// ---------- latest OTP card ----------
@Composable
fun RollingDigit(ch: Char, i: Int, key: Any) {
    if (!ch.isDigit()) {
        Text(ch.toString(), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
        return
    }
    val target = ch - '0'
    val a = remember(key) { Animatable(0f) }
    LaunchedEffect(key) {
        delay(i * 90L)
        a.animateTo((target + 20).toFloat(), tween(900 + i * 90, easing = FastOutSlowInEasing))
    }
    Text(
        "${a.value.toInt() % 10}", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.graphicsLayer { val f = a.value - kotlin.math.floor(a.value); translationY = (0.5f - f) * 10f }
    )
}

@Composable
fun OtpCard(vm: MessagesVM) {
    val otp by vm.otp.collectAsState()
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(otp) {
        val ts = otp?.third ?: return@LaunchedEffect
        while (System.currentTimeMillis() - ts < 61_000L) { now = System.currentTimeMillis(); delay(250) }
        now = System.currentTimeMillis()
    }
    val o = otp
    val left = if (o == null) 0L else 60_000L - (now - o.third)
    val show = o != null && left > 0
    var keep by remember { mutableStateOf<Triple<String, String, Long>?>(null) }
    SideEffect { if (show) keep = o }
    AnimatedVisibility(
        show,
        enter = expandVertically(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) + fadeIn(tween(300)) + slideInVertically(tween(450)) { -it / 2 },
        exit = shrinkVertically(tween(350)) + fadeOut(tween(250))
    ) {
        keep?.let { k -> OtpCardBody(k, left) { vm.dismissOtp() } }
    }
}

@Composable
fun OtpCardBody(k: Triple<String, String, Long>, left: Long, onDismiss: () -> Unit) {
    val clip = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    var copied by remember(k.third) { mutableStateOf(false) }
    val prog = remember(k.third) { Animatable(0f) }
    LaunchedEffect(copied) {
        if (copied) { prog.snapTo(0f); prog.animateTo(1f, tween(900, easing = LinearOutSlowInEasing)); delay(1200); copied = false }
    }
    val frac by animateFloatAsState((left.coerceAtLeast(0L) / 60_000f), tween(260, easing = LinearEasing), label = "otpleft")
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier.padding(horizontal = 18.dp, vertical = 8.dp).fillMaxWidth()
            .shadow(18.dp, shape, ambientColor = A2, spotColor = A2).clip(shape).background(Brand).padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Lock, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Verification code \u2022 ${k.second}", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(Icons.Rounded.Close, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(22.dp).bounce(onClick = onDismiss))
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().burstParticles(prog), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                k.first.forEachIndexed { i, ch -> RollingDigit(ch, i, k.third) }
            }
            val bs by animateFloatAsState(if (copied) 1.08f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "cb")
            Row(
                Modifier.graphicsLayer { scaleX = bs; scaleY = bs }
                    .bounce(onClick = {
                        clip.setText(AnnotatedString(k.first)); copied = true
                        if (HapticsOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    })
                    .clip(RoundedCornerShape(50)).background(Color.White).padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AnimatedContent(copied, transitionSpec = { (scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) }, label = "ci") { c ->
                    Icon(if (c) Icons.Rounded.Check else Icons.Rounded.ContentCopy, null, tint = A2, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(6.dp))
                Text(if (copied) "Copied!" else "Copy", color = A2, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.25f))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(50)).background(Color.White))
        }
        Text("Hides in ${(left / 1000 + 1).coerceAtLeast(0)}s", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

// ---------- scam banner + smart pills ----------
@Composable
fun ScamBanner(s: ScamResult) {
    val col = if (s.risky) Color(0xFFFF3B30) else Color(0xFFFFB020)
    Row(
        Modifier.padding(top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(col.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Warning, null, tint = col, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            (if (s.risky) "Likely scam: " else "Be careful: ") + (s.reasons.firstOrNull() ?: "suspicious message"),
            color = col, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun SmartPill(a: SmartAct) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(done) { if (done) { delay(1500); done = false } }
    Row(
        Modifier.padding(top = 6.dp).bounce(onClick = {
            if (a.kind == "copy") { clip.setText(AnnotatedString(a.value)); done = true }
            else runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.value))) }
                .onFailure { Toast.makeText(ctx, "No app can open this", Toast.LENGTH_SHORT).show() }
        }).clip(RoundedCornerShape(50)).background(A2.copy(alpha = 0.18f)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            when { done -> Icons.Rounded.Check; a.kind == "copy" -> Icons.Rounded.ContentCopy; a.kind == "web" -> Icons.Rounded.LocalShipping; else -> Icons.Rounded.AccountBalanceWallet },
            null, tint = A2, modifier = Modifier.size(15.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(if (done) "Copied" else a.label, color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

// ---------- per-contact SIM ----------
@Composable
fun SimChip(address: String) {
    val ctx = LocalContext.current
    val dual = remember { try { ctx.getSystemService(TelephonyManager::class.java).phoneCount >= 2 } catch (_: Exception) { false } }
    var sims by remember { mutableStateOf(Sims.list(ctx)) }
    var cur by remember { mutableStateOf(Store(ctx).simFor(address)) }
    var open by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { sims = Sims.list(ctx); if (sims.size >= 2) open = true }
    if (!dual) return
    val label = sims.firstOrNull { it.subId == cur }?.label?.substringBefore(" \u2022") ?: "SIM"
    Box {
        Row(
            Modifier.bounce(onClick = { if (sims.isEmpty()) perm.launch(Manifest.permission.READ_PHONE_STATE) else open = true })
                .clip(RoundedCornerShape(50)).background(Surf2).padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.SimCard, null, tint = A2, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(label, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Default SIM") }, onClick = { Store(ctx).setSim(address, -1); cur = -1; open = false })
            sims.forEach { s -> DropdownMenuItem(text = { Text(s.label) }, onClick = { Store(ctx).setSim(address, s.subId); cur = s.subId; open = false }) }
        }
    }
}

// ---------- money & bills ----------
@Composable
fun CountUp(value: Double, color: Color, size: Int) {
    val a = remember(value) { Animatable(0f) }
    LaunchedEffect(value) { a.animateTo(value.toFloat(), tween(1100, easing = FastOutSlowInEasing)) }
    Text("\u20B9" + String.format(Locale.US, "%,.0f", a.value), color = color, fontSize = size.sp, fontWeight = FontWeight.ExtraBold)
}

@Composable
fun MoneyScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var data by remember { mutableStateOf<MoneyData?>(null) }
    LaunchedEffect(Unit) { data = withContext(Dispatchers.IO) { Money.compute(ctx) } }
    Page("Money & bills", onBack) {
        val d = data
        if (d == null) {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = A2) }
        } else LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
            item {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Brand).padding(18.dp)) {
                        Text("Spent this month", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                        CountUp(d.spent, Color.White, 26)
                    }
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Surf).padding(18.dp)) {
                        Text("Received", color = Dim, fontSize = 12.sp)
                        CountUp(d.received, Color(0xFF34D27B), 26)
                    }
                }
            }
            if (d.byWho.isNotEmpty()) {
                item { Text("WHERE IT WENT", color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 22.dp, top = 14.dp, bottom = 6.dp)) }
                item {
                    Column(Modifier.padding(horizontal = 14.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Surf).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        val mx = d.byWho.maxOf { it.second }.coerceAtLeast(1.0)
                        d.byWho.forEach { (who, amt) ->
                            val w = remember(who, amt) { Animatable(0f) }
                            LaunchedEffect(who, amt) { w.animateTo((amt / mx).toFloat(), tween(900, easing = FastOutSlowInEasing)) }
                            Column {
                                Row { Text(who, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f)); Text("\u20B9" + String.format(Locale.US, "%,.0f", amt), color = Dim, fontSize = 13.sp) }
                                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Surf2)) {
                                    Box(Modifier.fillMaxHeight().fillMaxWidth(w.value.coerceIn(0.02f, 1f)).clip(RoundedCornerShape(50)).background(Brand))
                                }
                            }
                        }
                    }
                }
            }
            item { Text("BILLS & DUE DATES", color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 22.dp, top = 18.dp, bottom = 6.dp)) }
            if (d.bills.isEmpty()) item { Text("No bills found in your recent messages.", color = Dim, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 22.dp)) }
            items(d.bills) { b ->
                val days = b.due?.let { ((it - System.currentTimeMillis()) / 86_400_000L).toInt() }
                Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(b.who + (b.amount?.let { "  \u2022  \u20B9" + String.format(Locale.US, "%,.0f", it) } ?: ""), color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            when { days == null -> "Due date not found"; days < 0 -> "Overdue by ${-days} days"; days == 0 -> "Due today"; else -> "Due in $days days" },
                            color = if (days != null && days <= 2) A3 else Dim, fontSize = 13.sp
                        )
                        Text(b.body, color = Dim, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    if (b.due != null && b.due > System.currentTimeMillis()) {
                        Box(Modifier.bounce(onClick = {
                            val at = maxOf(b.due - 2L * 86_400_000L, System.currentTimeMillis() + 60_000L)
                            vm.schedule("remind", b.address, b.body, at)
                            Toast.makeText(ctx, "Reminder set for " + fullDate(at), Toast.LENGTH_SHORT).show()
                        }).clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 14.dp, vertical = 8.dp)) {
                            Text("Remind", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
            item { Text("RECENT TRANSACTIONS", color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 22.dp, top = 18.dp, bottom = 6.dp)) }
            if (d.txns.isEmpty()) item { Text("No bank messages found this month.", color = Dim, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 22.dp)) }
            items(d.txns.take(25)) { t ->
                Row(Modifier.padding(horizontal = 14.dp, vertical = 3.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surf).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.who, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(fmt(t.date), color = Dim, fontSize = 12.sp)
                    }
                    Text((if (t.debit) "- " else "+ ") + "\u20B9" + String.format(Locale.US, "%,.0f", t.amount), color = if (t.debit) A3 else Color(0xFF34D27B), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

// ---------- backup & phone switch ----------
@Composable
fun BigAction(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.padding(horizontal = 14.dp, vertical = 5.dp).fillMaxWidth().bounce(onClick = onClick).clip(RoundedCornerShape(22.dp)).background(Surf).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(sub, color = Dim, fontSize = 13.sp)
        }
    }
}

@Composable
fun BackupScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isDef by vm.isDefault.collectAsState()
    val direct by Mesh.direct.collectAsState()
    val approved by Mesh.approved.collectAsState()
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            if (!isDef) msg = "Set Messages as the default SMS app first, then restore."
            else {
                busy = true; msg = "Restoring…"
                scope.launch {
                    val n = withContext(Dispatchers.IO) { Backup.restore(ctx, uri) }
                    busy = false; msg = "Restored $n new messages"; vm.refresh()
                }
            }
        }
    }
    Page("Backup & phone switch", onBack) {
        LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
            item { Text("Your messages never leave your phone. Backups are saved in Downloads/Messages/Backups.", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp)) }
            item {
                BigAction(Icons.Rounded.Backup, "Create backup", "Save all messages to a file") {
                    if (!busy) { busy = true; msg = "Creating backup…"; scope.launch {
                        val r = withContext(Dispatchers.IO) { Backup.create(ctx) }
                        busy = false; msg = if (r != null) "Saved ${r.second} messages in Downloads/Messages/Backups" else "Backup failed"
                    } }
                }
            }
            item { BigAction(Icons.Rounded.Restore, "Restore from backup", "Pick a backup file (needs default SMS app)") { if (!busy) restore.launch(arrayOf("application/json", "*/*")) } }
            item { Text("PHONE SWITCH (OFFLINE)", color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 22.dp, top = 16.dp, bottom = 4.dp)) }
            item { Text("On the new phone: install Messages, open Nearby, turn on Zone mode and scan this phone's QR. Then tap a name below to send the backup by Wi-Fi Direct, and restore it on the new phone.", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp)) }
            val targets = approved.entries.filter { it.key in direct }
            if (targets.isEmpty()) item { Text("No connected phone yet.", color = A3, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)) }
            items(targets, key = { it.key }) { e ->
                BigAction(Icons.Rounded.Send, "Send backup to ${e.value}", "Creates a fresh backup and sends it") {
                    if (!busy) { busy = true; msg = "Preparing backup…"; scope.launch {
                        val r = withContext(Dispatchers.IO) { Backup.create(ctx) }
                        msg = if (r == null) "Backup failed" else if (Mesh.sendFile(e.key, r.first)) "Sending ${r.second} messages to ${e.value}…" else "Could not send. Check the connection."
                        busy = false
                    } }
                }
            }
            if (msg.isNotEmpty()) item { Text(msg, color = A2, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.padding(22.dp)) }
        }
    }
}

// ---------- private chats + app lock ----------
@Composable
fun PrivateScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val convos by vm.convos.collectAsState()
    val priv by vm.privateSet.collectAsState()
    var ok by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { if (it.resultCode == Activity.RESULT_OK) ok = true }
    fun ask() {
        val i = authIntent(ctx)
        if (i == null) Toast.makeText(ctx, "Set a screen lock (PIN, pattern or fingerprint) on your phone first", Toast.LENGTH_LONG).show()
        else launcher.launch(i)
    }
    LaunchedEffect(Unit) { ask() }
    Page("Private chats", onBack) {
        if (!ok) {
            Column(Modifier.fillMaxSize().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Logo(80.dp)
                Spacer(Modifier.height(16.dp))
                Text("Private chats are locked", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                GradientButton("Unlock") { ask() }
            }
        } else {
            val list = convos.filter { nk(it.address) in priv }
            if (list.isEmpty()) EmptyState(Icons.Rounded.Lock, "No private chats", "Hold a conversation and tap Move to private")
            else {
                Text("Hold a chat to move it back to the main list.", color = Dim, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp))
                LazyColumn { items(list, key = { it.threadId }) { c -> ConvoRow(c, false, { vm.openChat(Chat(c.threadId, c.address, c.name)) }, { vm.togglePrivate(c.address) }) } }
            }
        }
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { if (it.resultCode == Activity.RESULT_OK) onUnlock() }
    fun ask() {
        val i = authIntent(ctx)
        if (i == null) onUnlock() else launcher.launch(i)
    }
    LaunchedEffect(Unit) { delay(300); ask() }
    Box(Modifier.fillMaxSize().background(Bg).blockTouches(), contentAlignment = Alignment.Center) {
        Aurora(Modifier.fillMaxSize())
        Column(Modifier.padding(36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Logo(96.dp)
            Spacer(Modifier.height(18.dp))
            GradText("Messages is locked", 26)
            Spacer(Modifier.height(24.dp))
            GradientButton("Unlock") { ask() }
        }
    }
}
