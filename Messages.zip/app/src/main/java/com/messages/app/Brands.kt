package com.messages.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp

/**
 * Sender IDs like AX-HDFCBK, VK-JIO or AD-PAYTM are meaningless to most people.
 * This turns them into a readable brand name plus a brand coloured tile.
 */
class BrandInfo(val name: String, val initials: String, val c1: Color, val c2: Color)

private fun br(n: String, i: String, c1: Long, c2: Long) = BrandInfo(n, i, Color(c1), Color(c2))

object Brands {
    // Order matters: longer / more specific keys first.
    private val table: List<Pair<List<String>, BrandInfo>> = listOf(
        listOf("HDFCLIFE", "HDFCL") to br("HDFC Life", "HL", 0xFF004C8F, 0xFFED232A),
        listOf("HDFCERGO") to br("HDFC Ergo", "HE", 0xFF004C8F, 0xFFFF6A00),
        listOf("HDFC") to br("HDFC Bank", "HD", 0xFF004C8F, 0xFFED232A),
        listOf("SBILIFE", "SBIL") to br("SBI Life", "SL", 0xFF2D2A70, 0xFF00A0DF),
        listOf("SBICARD", "SBIC") to br("SBI Card", "SC", 0xFF2D2A70, 0xFF00A0DF),
        listOf("SBI") to br("SBI", "SB", 0xFF2D2A70, 0xFF00A0DF),
        listOf("ICICI") to br("ICICI Bank", "IC", 0xFFAE282E, 0xFFF58220),
        listOf("AXISBK", "AXIS") to br("Axis Bank", "AX", 0xFF97144D, 0xFFED1164),
        listOf("KOTAK") to br("Kotak Bank", "KO", 0xFF003874, 0xFFED1C24),
        listOf("IDFC") to br("IDFC First", "ID", 0xFF9C1D26, 0xFFF26522),
        listOf("YESBANK", "YESB") to br("Yes Bank", "YE", 0xFF00518F, 0xFF00A0DF),
        listOf("PNB") to br("Punjab National Bank", "PN", 0xFF9C1D26, 0xFFF5A623),
        listOf("BANKOFBARODA", "BARB", "BOB") to br("Bank of Baroda", "BB", 0xFFF15A22, 0xFF002F6C),
        listOf("CANARA", "CNRB") to br("Canara Bank", "CA", 0xFF1B3A6B, 0xFFF5A623),
        listOf("UNIONBANK", "UBIN") to br("Union Bank", "UN", 0xFF1B3A6B, 0xFFE4002B),
        listOf("INDUSIND", "INDB") to br("IndusInd Bank", "II", 0xFF8E1B2E, 0xFFF0A03C),
        listOf("FEDERAL") to br("Federal Bank", "FE", 0xFF1F3C88, 0xFFF5A623),
        listOf("BANDHAN", "BDBL") to br("Bandhan Bank", "BA", 0xFFB11F2E, 0xFFF5A623),
        listOf("RBLBANK", "RBL") to br("RBL Bank", "RB", 0xFF1B3A6B, 0xFFE4002B),
        listOf("PAYTM") to br("Paytm", "PT", 0xFF00BAF2, 0xFF002970),
        listOf("PHONEPE", "PHPE") to br("PhonePe", "PP", 0xFF5F259F, 0xFF8E5BF0),
        listOf("GOOGLEPAY", "GPAY", "GOOGL") to br("Google Pay", "GP", 0xFF4285F4, 0xFF34A853),
        listOf("BHIM") to br("BHIM", "BH", 0xFF0F5FA6, 0xFFF5A623),
        listOf("AMAZONPRIME", "AMZNPR") to br("Prime Video", "PV", 0xFF00A8E1, 0xFF1A98FF),
        listOf("AMAZONPAY", "AMZNPY") to br("Amazon Pay", "AP", 0xFFFF9900, 0xFF232F3E),
        listOf("AMAZON", "AMZN") to br("Amazon", "AM", 0xFF232F3E, 0xFFFF9900),
        listOf("FLIPKART", "FKART", "FK") to br("Flipkart", "FK", 0xFF2874F0, 0xFFFFC200),
        listOf("MYNTRA") to br("Myntra", "MY", 0xFFFF3F6C, 0xFF7B2FF7),
        listOf("AJIO") to br("AJIO", "AJ", 0xFF2B2B2B, 0xFFD4AF37),
        listOf("MEESHO") to br("Meesho", "ME", 0xFF9F2089, 0xFFF43397),
        listOf("NYKAA") to br("Nykaa", "NY", 0xFFFC2779, 0xFFE80071),
        listOf("SWIGGYINSTAMART", "INSTAMART") to br("Instamart", "IM", 0xFFFC8019, 0xFFFF5200),
        listOf("SWIGGY") to br("Swiggy", "SW", 0xFFFC8019, 0xFFFF5200),
        listOf("ZOMATO") to br("Zomato", "ZO", 0xFFE23744, 0xFFCB202D),
        listOf("BLINKIT") to br("Blinkit", "BL", 0xFFF8CB46, 0xFF54B226),
        listOf("ZEPTO") to br("Zepto", "ZP", 0xFF5C2D91, 0xFFA855F7),
        listOf("BIGBASKET", "BIGB") to br("BigBasket", "BG", 0xFF84C225, 0xFF5A9E06),
        listOf("DMART") to br("DMart", "DM", 0xFF00794A, 0xFFF5A623),
        listOf("DOMINOS", "DOMIN") to br("Domino's", "DO", 0xFF006491, 0xFFE31837),
        listOf("MCDELIVERY", "MCD") to br("McDonald's", "MC", 0xFFDA291C, 0xFFFFC72C),
        listOf("KFC") to br("KFC", "KF", 0xFFB1001F, 0xFFE4002B),
        listOf("JIOPAY", "JIOMONEY") to br("JioPay", "JP", 0xFF0F5FA6, 0xFF00BAF2),
        listOf("JIOHOTSTAR", "HOTSTAR") to br("JioHotstar", "JH", 0xFF1F80E0, 0xFF0B3D91),
        listOf("JIOMART") to br("JioMart", "JM", 0xFF0F5FA6, 0xFF00A0DF),
        listOf("JIOFINANCE", "JIOFIN") to br("Jio Finance", "JF", 0xFF0F5FA6, 0xFF00A0DF),
        listOf("JIO") to br("Jio", "JI", 0xFF0F3CC9, 0xFF00A0DF),
        listOf("AIRTEL") to br("Airtel", "AI", 0xFFE40000, 0xFFFF6A00),
        listOf("VODAFONE", "VODA") to br("Vi", "VI", 0xFFED1C24, 0xFF8E2DE2),
        listOf("BSNL") to br("BSNL", "BS", 0xFF0F5FA6, 0xFF00A0DF),
        listOf("IRCTC", "INDIANRAIL", "RAILWAY", "IRCT") to br("IRCTC", "IR", 0xFF1B3A6B, 0xFFF5A623),
        listOf("UIDAI", "AADHAAR", "AADHAR") to br("Aadhaar", "AA", 0xFFF5A623, 0xFFE4002B),
        listOf("EPFO", "EPF") to br("EPFO", "EP", 0xFF1B3A6B, 0xFF00A0DF),
        listOf("INCOMETAX", "ITDEPT", "CBDT") to br("Income Tax", "IT", 0xFF1B3A6B, 0xFFF5A623),
        listOf("GSTN", "GST") to br("GST", "GS", 0xFF1B3A6B, 0xFFF5A623),
        listOf("LIC") to br("LIC", "LI", 0xFF003399, 0xFFF5A623),
        listOf("ZERODHA", "ZEROD") to br("Zerodha", "ZE", 0xFF387ED1, 0xFF1E5AA8),
        listOf("GROWW") to br("Groww", "GR", 0xFF00D09C, 0xFF0B7D68),
        listOf("CRED") to br("CRED", "CR", 0xFF0F0F0F, 0xFF3D3D3D),
        listOf("NAVI") to br("Navi", "NA", 0xFF3B5BFE, 0xFF6C4BFF),
        listOf("JUPITER") to br("Jupiter", "JU", 0xFFF5A623, 0xFF2B2B2B),
        listOf("SLICE") to br("Slice", "SL", 0xFF8E2DE2, 0xFF4A00E0),
        listOf("BAJAJALLIANZ", "BAJAJ") to br("Bajaj", "BJ", 0xFF0066B3, 0xFF00A0DF),
        listOf("TATAAIG", "TATA") to br("Tata", "TA", 0xFF486AAE, 0xFF0F3CC9),
        listOf("STARHEALTH", "STARHL") to br("Star Health", "SH", 0xFFE4002B, 0xFFF5A623),
        listOf("POLICYBAZAAR", "PBIZ") to br("Policybazaar", "PB", 0xFF1B3A6B, 0xFF00A0DF),
        listOf("ACKO") to br("Acko", "AK", 0xFF6C4BFF, 0xFF3B5BFE),
        listOf("APOLLO") to br("Apollo", "AO", 0xFF00847F, 0xFFF5A623),
        listOf("TATA1MG", "1MG") to br("Tata 1mg", "1M", 0xFFEF4A5B, 0xFF1B3A6B),
        listOf("PHARMEASY") to br("PharmEasy", "PH", 0xFF1B3A6B, 0xFF00A0DF),
        listOf("PRACTO") to br("Practo", "PR", 0xFF1B7FC4, 0xFF00A0DF),
        listOf("BOOKMYSHOW", "BMS") to br("BookMyShow", "BM", 0xFFDC3558, 0xFFF5A623),
        listOf("PVR", "INOX") to br("PVR INOX", "PV", 0xFFB1001F, 0xFFF5A623),
        listOf("REDBUS") to br("redBus", "RB", 0xFFD32F2F, 0xFFF5A623),
        listOf("MAKEMYTRIP", "MMT") to br("MakeMyTrip", "MM", 0xFFEB2226, 0xFF00A0DF),
        listOf("GOIBIBO") to br("Goibibo", "GO", 0xFFEB2226, 0xFFF5A623),
        listOf("CLEARTRIP") to br("Cleartrip", "CT", 0xFFF5A623, 0xFF1B3A6B),
        listOf("INDIGO") to br("IndiGo", "IN", 0xFF1B3A6B, 0xFF00A0DF),
        listOf("AIRINDIA") to br("Air India", "AR", 0xFFE4002B, 0xFFF5A623),
        listOf("VISTARA") to br("Vistara", "VS", 0xFF7A1F5C, 0xFFF5A623),
        listOf("SPICEJET") to br("SpiceJet", "SJ", 0xFFE4002B, 0xFFF5A623),
        listOf("IRONBOX") to br("IRONBOX", "IX", 0xFF1B3A6B, 0xFF00A0DF),
        listOf("DELHIVERY", "DELHIV") to br("Delhivery", "DE", 0xFFE4002B, 0xFF1B3A6B),
        listOf("DTDC") to br("DTDC", "DT", 0xFF1B3A6B, 0xFFF5A623),
        listOf("BLUEDART") to br("Blue Dart", "BD", 0xFF1B3A6B, 0xFFF5A623),
        listOf("EKART") to br("Ekart", "EK", 0xFF2874F0, 0xFFFFC200),
        listOf("SHADOWFAX") to br("Shadowfax", "SF", 0xFF1B3A6B, 0xFF00A0DF),
        listOf("INDIA_POST", "INDIAPOST") to br("India Post", "IP", 0xFFE4002B, 0xFF1B3A6B),
        listOf("NETFLIX") to br("Netflix", "NF", 0xFFE50914, 0xFF831010),
        listOf("SPOTIFY") to br("Spotify", "SP", 0xFF1DB954, 0xFF14833B),
        listOf("YOUTUBE", "YT") to br("YouTube", "YT", 0xFFFF0000, 0xFFC4302B),
        listOf("LINKEDIN") to br("LinkedIn", "LN", 0xFF0A66C2, 0xFF0077B5),
        listOf("UBER") to br("Uber", "UB", 0xFF111111, 0xFF3D3D3D),
        listOf("OLACABS", "OLA") to br("Ola", "OL", 0xFFF5A623, 0xFF2B2B2B),
        listOf("RAPIDO") to br("Rapido", "RA", 0xFFFFD200, 0xFF2B2B2B),
        listOf("ATHER") to br("Ather", "AT", 0xFF1B3A6B, 0xFF00A0DF),
        listOf("TATAMOTORS", "MARUTI", "HYUNDAI") to br("Car service", "CS", 0xFF1B3A6B, 0xFF00A0DF),
        listOf("HERO", "TVS") to br("Two wheeler", "TW", 0xFF1B3A6B, 0xFF00A0DF)
    )

    /** Returns the brand behind a sender ID such as AX-HDFCBK, or null for a real phone number. */
    fun of(address: String): BrandInfo? {
        val raw = address.trim().uppercase()
        if (raw.none { it.isLetter() }) return null
        var key = raw
        // drop the operator / telemarketer prefix, e.g. JD-, VK-, AD-, TM-, AX-
        val first = key.indexOf('-')
        if (first in 1..3) key = key.substring(first + 1)
        // drop a trailing promotional flag, e.g. -P, -S, -G
        val last = key.lastIndexOf('-')
        if (last > 0 && key.length - last <= 3) key = key.substring(0, last)
        key = key.filter { it.isLetterOrDigit() }
        if (key.length < 3) return null
        for ((keys, brand) in table) {
            for (k in keys) {
                if (key.startsWith(k) || (k.length >= 4 && key.contains(k))) return brand
            }
        }
        return null
    }

    fun display(address: String): String? = of(address)?.name
}

@Composable
fun BrandTile(b: BrandInfo, size: Dp) {
    val brush = remember(b) { Brush.linearGradient(listOf(b.c1, b.c2)) }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(brush),
        contentAlignment = Alignment.Center
    ) {
        Text(
            b.initials, color = Color.White, fontWeight = FontWeight.ExtraBold,
            fontSize = (size.value * 0.36f).sp, letterSpacing = (-0.5).sp
        )
    }
}

/** Brand tile for sender IDs, normal avatar for people. */
@Composable
fun SenderAvatar(address: String, name: String, size: Dp) {
    val b = remember(address) { Brands.of(address) }
    if (b != null) BrandTile(b, size) else Avatar(name, size)
}
