package com.messages.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Saved(val id: Long, val address: String, val body: String, val date: Long, val outgoing: Boolean, val at: Long = 0L)
data class Sched(val id: Long, val kind: String, val address: String, val body: String, val at: Long)
data class VaultItem(val id: Long, val label: String, val value: String, val kind: String, val at: Long)

data class Media(
    val id: Long, val address: String, val path: String, val mime: String, val date: Long,
    val outgoing: Boolean, val read: Boolean, val status: Int, val text: String
)

fun Media.toMsg() = Msg(-id, text, date, outgoing, status == 2, status == 1, null,
    if (mime == "text/plain") null else path, mime)

object Bus { val tick = kotlinx.coroutines.flow.MutableStateFlow(0) }

class Store(c: Context) {
    private val sp = c.applicationContext.getSharedPreferences("store", Context.MODE_PRIVATE)

    var lock: Boolean
        get() = sp.getBoolean("lock", false)
        set(v) { sp.edit().putBoolean("lock", v).apply() }
    var hideNotif: Boolean
        get() = sp.getBoolean("hidenotif", false)
        set(v) { sp.edit().putBoolean("hidenotif", v).apply() }
    var autoOtp: Boolean
        get() = sp.getBoolean("autootp", false)
        set(v) { sp.edit().putBoolean("autootp", v).apply() }
    var privateSet: Set<String>
        get() = (sp.getStringSet("private", emptySet()) ?: emptySet()).toSet()
        set(v) { sp.edit().putStringSet("private", v).apply() }
    fun simFor(addr: String): Int = sp.getInt("sim_" + nk(addr), -1)
    fun setSim(addr: String, id: Int) { sp.edit().putInt("sim_" + nk(addr), id).apply() }
    fun setLastOtp(code: String, from: String, ts: Long) { putStr("lastotp", code + "\u0001" + from + "\u0001" + ts) }
    fun clearOtp() { putStr("lastotp", "") }
    fun lastOtp(): Triple<String, String, Long>? {
        val p = getStr("lastotp").split("\u0001")
        return if (p.size == 3) Triple(p[0], p[1], p[2].toLongOrNull() ?: 0L) else null
    }

    fun getStr(k: String): String = sp.getString(k, "") ?: ""
    fun putStr(k: String, v: String) { sp.edit().putString(k, v).apply() }

    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var system: Boolean
        get() = sp.getBoolean("system", true)
        set(v) { sp.edit().putBoolean("system", v).apply() }
    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) { sp.edit().putBoolean("haptics", v).apply() }
    var textScale: Float
        get() = sp.getFloat("textscale", 1f).coerceIn(0.85f, 1.7f)
        set(v) { sp.edit().putFloat("textscale", v.coerceIn(0.85f, 1.7f)).apply() }
    var elder: Boolean
        get() = sp.getBoolean("elder", false)
        set(v) { sp.edit().putBoolean("elder", v).apply() }
    var vault: List<VaultItem>
        get() = try {
            val a = JSONArray(sp.getString("vault", "[]") ?: "[]")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                VaultItem(o.getLong("id"), o.optString("l", ""), o.optString("v", ""), o.optString("k", "other"), o.optLong("t", 0L))
            }
        } catch (_: Exception) { emptyList() }
        set(v) {
            val a = JSONArray()
            v.forEach {
                a.put(JSONObject().put("id", it.id).put("l", it.label).put("v", it.value).put("k", it.kind).put("t", it.at))
            }
            sp.edit().putString("vault", a.toString()).apply()
        }
    var pinned: Set<Long>
        get() = (sp.getStringSet("pinned", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
        set(v) { sp.edit().putStringSet("pinned", v.map { it.toString() }.toSet()).apply() }
    var blocked: Set<String>
        get() = (sp.getStringSet("blocked", emptySet()) ?: emptySet()).toSet()
        set(v) { sp.edit().putStringSet("blocked", v).apply() }
    var starred: List<Saved>
        get() = readSaved("starred")
        set(v) = writeSaved("starred", v)
    var trash: List<Saved>
        get() = readSaved("trash")
        set(v) = writeSaved("trash", v)
    var reactions: Map<Long, String>
        get() {
            val o = JSONObject(sp.getString("react", "{}") ?: "{}")
            return o.keys().asSequence().associate { it.toLong() to o.getString(it) }
        }
        set(v) { sp.edit().putString("react", JSONObject(v.mapKeys { it.key.toString() }).toString()).apply() }
    var sched: List<Sched>
        get() {
            val a = JSONArray(sp.getString("sched", "[]") ?: "[]")
            return (0 until a.length()).map { val o = a.getJSONObject(it); Sched(o.getLong("id"), o.getString("k"), o.getString("a"), o.getString("b"), o.getLong("t")) }
        }
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(JSONObject().put("id", it.id).put("k", it.kind).put("a", it.address).put("b", it.body).put("t", it.at)) }
            sp.edit().putString("sched", a.toString()).apply()
        }

    var media: List<Media>
        get() = try {
            val a = JSONArray(sp.getString("media", "[]") ?: "[]")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Media(o.getLong("id"), o.getString("a"), o.getString("p"), o.getString("m"), o.getLong("d"),
                    o.getBoolean("o"), o.getBoolean("r"), o.getInt("s"), o.optString("t", ""))
            }
        } catch (_: Exception) { emptyList() }
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(JSONObject().put("id", it.id).put("a", it.address).put("p", it.path).put("m", it.mime).put("d", it.date).put("o", it.outgoing).put("r", it.read).put("s", it.status).put("t", it.text)) }
            sp.edit().putString("media", a.toString()).apply()
        }

    private fun readSaved(key: String): List<Saved> = try {
        val a = JSONArray(sp.getString(key, "[]") ?: "[]")
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Saved(o.getLong("id"), o.getString("a"), o.getString("b"), o.getLong("d"), o.getBoolean("o"), o.optLong("t", 0L))
        }
    } catch (_: Exception) { emptyList() }

    private fun writeSaved(key: String, v: List<Saved>) {
        val a = JSONArray()
        v.forEach { a.put(JSONObject().put("id", it.id).put("a", it.address).put("b", it.body).put("d", it.date).put("o", it.outgoing).put("t", it.at)) }
        sp.edit().putString(key, a.toString()).apply()
    }
}
