package com.messages.app

import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream

data class Peer(val id: String, val name: String, val lat: Double?, val lon: Double?, val seen: Long, val hops: Int)
data class MMsg(
    val id: String, val conv: String, val fromId: String, val fromName: String, val text: String,
    val ts: Long, val mine: Boolean, val file: String?, val mime: String?, val status: Int
)
data class Group(val gid: String, val name: String, val members: List<String>, val names: List<String>)
data class Req(
    val fromId: String, val name: String, val text: String, val ts: Long,
    val gid: String?, val gname: String?, val members: List<String>, val names: List<String>
)
data class MFile(val id: String, val name: String, val mime: String, val size: Long, val uri: String, val ts: Long, val mine: Boolean, val who: String)

/** Offline mesh on top of Google Nearby Connections (Bluetooth / BLE / Wi-Fi Direct, no internet). */
object Mesh {
    const val SERVICE = "com.messages.app.mesh"
    private lateinit var app: Context
    private lateinit var store: Store
    private var ready = false
    private var client: ConnectionsClient? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    var myId = ""
        private set
    val myNameFlow = MutableStateFlow("")
    private val myName: String get() = myNameFlow.value
    var foreground = false

    val running = MutableStateFlow(false)
    val status = MutableStateFlow("Off")
    val peers = MutableStateFlow<Map<String, Peer>>(emptyMap())
    val direct = MutableStateFlow<Set<String>>(emptySet())
    val approved = MutableStateFlow<Map<String, String>>(emptyMap())
    val requests = MutableStateFlow<List<Req>>(emptyList())
    val groups = MutableStateFlow<List<Group>>(emptyList())
    val msgs = MutableStateFlow<List<MMsg>>(emptyList())
    val files = MutableStateFlow<List<MFile>>(emptyList())
    val unread = MutableStateFlow<Map<String, Int>>(emptyMap())
    val me = MutableStateFlow<Pair<Double, Double>?>(null)
    val openConv = MutableStateFlow<String?>(null)
    val qrWaiting = MutableStateFlow(false)

    private val conn = HashMap<String, String>()          // endpointId -> peerId
    private val found = HashMap<String, Pair<String, String>>() // endpointId -> (peerId, name)
    private val connecting = HashSet<String>()
    private val seen = LinkedHashSet<String>()
    private val pendingOut = HashSet<String>()
    private val outbox = ArrayList<JSONObject>()
    private val metas = HashMap<Long, JSONObject>()
    private val incoming = HashMap<Long, Pair<String, Payload>>()
    private var qrTarget: String? = null

    fun init(c: Context) {
        if (ready) return
        ready = true
        app = c.applicationContext
        store = Store(app)
        myId = store.getStr("mesh_id").ifEmpty { java.util.UUID.randomUUID().toString().replace("-", "").take(8).also { store.putStr("mesh_id", it) } }
        myNameFlow.value = store.getStr("mesh_name").ifEmpty { (Build.MODEL ?: "Phone").take(16) }
        approved.value = loadApproved(); groups.value = loadGroups(); msgs.value = loadMsgs(); files.value = loadFiles()
    }

    fun setName(n: String) {
        val t = n.trim().replace("|", "").take(16)
        if (t.isEmpty()) return
        myNameFlow.value = t; store.putStr("mesh_name", t)
        if (running.value) { stop(); start() }
    }

    // ---------------- lifecycle ----------------
    fun start() {
        if (running.value || !ready) return
        val c = Nearby.getConnectionsClient(app)
        client = c
        running.value = true
        status.value = "Starting…"
        val adv = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        c.startAdvertising("$myName|$myId", SERVICE, lifecycle, adv)
            .addOnSuccessListener { status.value = "Visible • looking for people nearby" }
            .addOnFailureListener { status.value = "Can't start: " + (it.message ?: "error") }
        val dis = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        c.startDiscovery(SERVICE, discovery, dis)
            .addOnFailureListener { status.value = "Can't scan: " + (it.message ?: "error") }
        startLocation()
        scope.launch { while (running.value) { delay(10_000); beacon(); flush(); prune() } }
        try { ContextCompat.startForegroundService(app, Intent(app, MeshService::class.java)) } catch (_: Exception) { }
    }

    fun stop() {
        running.value = false
        status.value = "Off"
        try { client?.stopAdvertising() } catch (_: Exception) { }
        try { client?.stopDiscovery() } catch (_: Exception) { }
        try { client?.stopAllEndpoints() } catch (_: Exception) { }
        conn.clear(); found.clear(); connecting.clear(); direct.value = emptySet()
        stopLocation()
        try { app.stopService(Intent(app, MeshService::class.java)) } catch (_: Exception) { }
    }

    // ---------------- connections ----------------
    private fun parse(s: String): Pair<String, String> {
        val i = s.lastIndexOf('|')
        return if (i < 0) s to s else s.substring(0, i) to s.substring(i + 1)
    }

    private fun connect(ep: String) {
        if (ep in conn || ep in connecting) return
        connecting.add(ep)
        client?.requestConnection("$myName|$myId", ep, lifecycle)?.addOnFailureListener { connecting.remove(ep) }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(ep: String, info: DiscoveredEndpointInfo) {
            val (name, id) = parse(info.endpointName)
            if (id == myId) return
            found[ep] = id to name
            touch(id, name, null, null, 0)
            if (qrTarget == id || (myId > id && conn.size + connecting.size < 4)) connect(ep)
        }
        override fun onEndpointLost(ep: String) { found.remove(ep) }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(ep: String, info: ConnectionInfo) {
            val (name, id) = parse(info.endpointName)
            found[ep] = id to name
            connecting.add(ep)
            client?.acceptConnection(ep, payloadCb)
        }
        override fun onConnectionResult(ep: String, r: ConnectionResolution) {
            connecting.remove(ep)
            if (r.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                val (id, name) = found[ep] ?: return
                conn[ep] = id
                direct.value = conn.values.toSet()
                touch(id, name, null, null, 0)
                beacon()
                flush()
                if (qrTarget == id) {
                    qrTarget = null
                    sendRaw(base("acc", id).put("ts", System.currentTimeMillis()))
                }
            }
        }
        override fun onDisconnected(ep: String) {
            conn.remove(ep); connecting.remove(ep)
            direct.value = conn.values.toSet()
        }
    }

    // ---------------- payloads ----------------
    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(ep: String, p: Payload) {
            when (p.type) {
                Payload.Type.BYTES -> p.asBytes()?.let { handle(ep, String(it, Charsets.UTF_8)) }
                Payload.Type.FILE -> {
                    val pid = conn[ep]
                    if (pid == null || pid !in approved.value) { client?.cancelPayload(p.id); return }
                    incoming[p.id] = ep to p
                }
                else -> { }
            }
        }
        override fun onPayloadTransferUpdate(ep: String, u: PayloadTransferUpdate) {
            if (u.status == PayloadTransferUpdate.Status.SUCCESS) {
                val inc = incoming.remove(u.payloadId) ?: return
                receiveFile(inc.first, inc.second)
            } else if (u.status == PayloadTransferUpdate.Status.FAILURE) incoming.remove(u.payloadId)
        }
    }

    private fun newId() = java.util.UUID.randomUUID().toString().replace("-", "").take(12)

    private fun base(k: String, to: String): JSONObject =
        JSONObject().put("id", newId()).put("k", k).put("from", myId).put("fn", myName).put("to", to).put("ttl", 5).put("h", 0)

    private fun sendRaw(o: JSONObject, except: String? = null): Boolean {
        val c = client ?: return false
        val t = conn.keys.filter { it != except }
        if (t.isEmpty()) return false
        c.sendPayload(t, Payload.fromBytes(o.toString().toByteArray(Charsets.UTF_8)))
        return true
    }

    private fun flush() {
        if (outbox.isEmpty() || conn.isEmpty()) return
        val now = System.currentTimeMillis()
        val keep = ArrayList<JSONObject>()
        for (o in outbox) {
            if (now - o.optLong("ts") > 3_600_000L) continue
            if (sendRaw(o)) {
                msgs.value = msgs.value.map { if (it.id == o.optString("id")) it.copy(status = 0) else it }
            } else keep.add(o)
        }
        outbox.clear(); outbox.addAll(keep)
        saveMsgs()
    }

    private fun beacon() {
        val o = base("pres", "*").put("ttl", 3)
        me.value?.let { o.put("lat", it.first).put("lon", it.second) }
        seen.add(o.getString("id"))
        sendRaw(o)
    }

    private fun prune() {
        val now = System.currentTimeMillis()
        peers.value = peers.value.filter { now - it.value.seen < 90_000L || it.key in conn.values }
    }

    private fun touch(id: String, name: String, lat: Double?, lon: Double?, hops: Int) {
        if (id == myId) return
        val old = peers.value[id]
        val now = System.currentTimeMillis()
        val h = if (old != null && now - old.seen < 20_000L) minOf(old.hops, hops) else hops
        peers.value = peers.value + (id to Peer(id, name, lat ?: old?.lat, lon ?: old?.lon, now, h))
    }

    private fun handle(ep: String, s: String) {
        val o = try { JSONObject(s) } catch (_: Exception) { return }
        val id = o.optString("id")
        if (id.isEmpty() || !seen.add(id)) return
        if (seen.size > 1500) { val iter = seen.iterator(); repeat(300) { if (iter.hasNext()) { iter.next(); iter.remove() } } }
        val k = o.optString("k")
        val from = o.optString("from")
        if (from == myId || from.isEmpty()) return
        val name = o.optString("fn", "?")
        val to = o.optString("to", "*")
        val ttl = o.optInt("ttl", 1)
        val h = o.optInt("h", 0)
        if (k == "fmeta") { metas[o.optLong("pid")] = o; return }
        if (ttl > 1) {
            val f = JSONObject(s)
            f.put("ttl", ttl - 1); f.put("h", h + 1)
            sendRaw(f, except = ep)
        }
        val lat = o.optDouble("lat"); val lon = o.optDouble("lon")
        touch(from, name, if (lat.isNaN()) null else lat, if (lon.isNaN()) null else lon, h)
        if (k == "pres") return
        val forMe = to == myId || to == "*" || (to.startsWith("g:") && groups.value.any { it.gid == to.substring(2) })
        if (!forMe) return
        val text = o.optString("t")
        val ts = o.optLong("ts", System.currentTimeMillis())
        when (k) {
            "msg" -> {
                if (to == myId && from !in approved.value) return
                val conv = when { to == "*" -> "zone"; to.startsWith("g:") -> to; else -> from }
                incomingMsg(MMsg(id, conv, from, name, text, ts, false, null, null, 0))
            }
            "req" -> {
                if (from !in approved.value && requests.value.none { it.fromId == from && it.gid == null }) {
                    requests.value = requests.value + Req(from, name, text, ts, null, null, emptyList(), emptyList())
                    ping("Chat request from $name", text, from)
                }
            }
            "acc" -> if (from in pendingOut || qrWaiting.value) { pendingOut.remove(from); approve(from, name) }
            "dec" -> pendingOut.remove(from)
            "grp" -> {
                val gid = o.optString("gid")
                if (groups.value.none { it.gid == gid } && requests.value.none { it.gid == gid }) {
                    requests.value = requests.value + Req(from, name, "", ts, gid, o.optString("gn"), jarr(o.optJSONArray("m")), jarr(o.optJSONArray("n")))
                    ping("Group invite from $name", o.optString("gn"), "g:$gid")
                }
            }
        }
    }

    private fun jarr(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

    private fun ping(title: String, body: String, conv: String) {
        if (!foreground || openConv.value != conv) Notifier.mesh(app, title, body, conv)
    }

    private fun incomingMsg(m: MMsg) {
        msgs.value = msgs.value + m
        saveMsgs()
        if (openConv.value != m.conv) unread.value = unread.value + (m.conv to ((unread.value[m.conv] ?: 0) + 1))
        if (m.conv != "zone" || !foreground) ping(if (m.conv == "zone" || m.conv.startsWith("g:")) "${m.fromName} (nearby)" else m.fromName, m.text, m.conv)
    }

    fun markRead(conv: String) { if (unread.value.containsKey(conv)) unread.value = unread.value - conv }

    // ---------------- actions ----------------
    private fun approve(id: String, name: String) {
        approved.value = approved.value + (id to name)
        store.putStr("mesh_ok", JSONObject(approved.value as Map<*, *>).toString())
    }

    fun sendText(conv: String, text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        val isPeer = conv != "zone" && !conv.startsWith("g:")
        val k = if (isPeer && conv !in approved.value) "req" else "msg"
        if (k == "req" && msgs.value.any { it.conv == conv && it.mine }) return false
        if (k == "req") pendingOut.add(conv)
        val to = if (conv == "zone") "*" else conv
        val ts = System.currentTimeMillis()
        val o = base(k, to).put("t", t).put("ts", ts)
        seen.add(o.getString("id"))
        val ok = sendRaw(o)
        if (!ok) outbox.add(o)
        msgs.value = msgs.value + MMsg(o.getString("id"), conv, myId, myName, t, ts, true, null, null, if (ok) 0 else 1)
        saveMsgs()
        return true
    }

    fun acceptRequest(r: Req) {
        requests.value = requests.value - r
        if (r.gid == null) {
            approve(r.fromId, r.name)
            if (r.text.isNotEmpty()) incomingMsg(MMsg(newId(), r.fromId, r.fromId, r.name, r.text, r.ts, false, null, null, 0))
            sendRaw(base("acc", r.fromId).put("ts", System.currentTimeMillis()))
        } else {
            groups.value = groups.value + Group(r.gid, r.gname ?: "Group", r.members, r.names)
            saveGroups()
        }
    }

    fun declineRequest(r: Req) {
        requests.value = requests.value - r
        if (r.gid == null) sendRaw(base("dec", r.fromId))
    }

    fun createGroup(name: String, members: List<Peer>) {
        val gid = newId().take(8)
        val ids = listOf(myId) + members.map { it.id }
        val names = listOf(myName) + members.map { it.name }
        groups.value = groups.value + Group(gid, name, ids, names)
        saveGroups()
        for (m in members) {
            val o = base("grp", m.id).put("gid", gid).put("gn", name).put("m", JSONArray(ids)).put("n", JSONArray(names)).put("ts", System.currentTimeMillis())
            seen.add(o.getString("id"))
            if (!sendRaw(o)) outbox.add(o)
        }
        openConv.value = "g:$gid"
    }

    fun onQr(raw: String): Boolean {
        val p = raw.split("|")
        if (p.size < 3 || p[0] != "MSGQR1") return false
        val id = p[1]
        val name = p.drop(2).joinToString("|")
        if (id == myId) return false
        approve(id, name)
        touch(id, name, null, null, 0)
        if (id in conn.values) {
            sendRaw(base("acc", id).put("ts", System.currentTimeMillis()))
        } else {
            qrTarget = id
            found.entries.firstOrNull { it.value.first == id }?.let { connect(it.key) }
        }
        openConv.value = id
        return true
    }

    // ---------------- files ----------------
    fun sendFile(peerId: String, uri: Uri): Boolean {
        val ep = conn.entries.firstOrNull { it.value == peerId }?.key ?: return false
        if (peerId !in approved.value) return false
        var name = "file"; var size = 0L
        try {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst()) { name = it.getString(0) ?: name; size = it.getLong(1) }
            }
        } catch (_: Exception) { }
        val mime = app.contentResolver.getType(uri) ?: "application/octet-stream"
        return try {
            val pfd = app.contentResolver.openFileDescriptor(uri, "r") ?: return false
            val payload = Payload.fromFile(pfd)
            val meta = base("fmeta", peerId).put("pid", payload.id).put("name", name).put("mime", mime).put("size", size).put("ttl", 1)
            client?.sendPayload(ep, Payload.fromBytes(meta.toString().toByteArray(Charsets.UTF_8)))
            client?.sendPayload(ep, payload)
            val ts = System.currentTimeMillis()
            files.value = files.value + MFile(newId(), name, mime, size, uri.toString(), ts, true, approved.value[peerId] ?: peerId)
            msgs.value = msgs.value + MMsg(newId(), peerId, myId, myName, "\uD83D\uDCCE $name", ts, true, uri.toString(), mime, 0)
            saveFiles(); saveMsgs()
            true
        } catch (_: Exception) { false }
    }

    private fun receiveFile(ep: String, p: Payload) {
        val peerId = conn[ep] ?: return
        val meta = metas.remove(p.id)
        val name = meta?.optString("name")?.ifEmpty { null } ?: "file_${p.id}"
        val mime = meta?.optString("mime")?.ifEmpty { null }
            ?: (MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream")
        scope.launch {
            val saved = withContext(Dispatchers.IO) {
                try {
                    val f = p.asFile()
                    val input: InputStream? = when {
                        f == null -> null
                        Build.VERSION.SDK_INT >= 29 -> f.asUri()?.let { app.contentResolver.openInputStream(it) }
                        else -> f.asJavaFile()?.inputStream()
                    }
                    input?.use { saveToMessagesFolder(name, mime, it) }
                } catch (_: Exception) { null }
            }
            if (saved != null) {
                val ts = System.currentTimeMillis()
                val who = approved.value[peerId] ?: peerId
                files.value = files.value + MFile(newId(), name, mime, meta?.optLong("size") ?: 0L, saved.toString(), ts, false, who)
                saveFiles()
                incomingMsg(MMsg(newId(), peerId, peerId, who, "\uD83D\uDCCE $name", ts, false, saved.toString(), mime, 0))
            }
        }
    }

    fun folderFor(mime: String): String = when {
        mime.startsWith("image") -> "Images"
        mime.startsWith("video") -> "Videos"
        mime.startsWith("audio") -> "Audio"
        mime.contains("pdf") || mime.startsWith("text") || mime.contains("word") || mime.contains("sheet") ||
            mime.contains("presentation") || mime.contains("officedocument") -> "Documents"
        else -> "Others"
    }

    private fun saveToMessagesFolder(name: String, mime: String, src: InputStream): Uri? {
        val folder = folderFor(mime)
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Messages/$folder")
            }
            val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
            app.contentResolver.openOutputStream(uri)?.use { out -> src.copyTo(out) }
            return uri
        }
        val dir = File(app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Messages/$folder").apply { mkdirs() }
        val f = File(dir, name)
        f.outputStream().use { out -> src.copyTo(out) }
        return Uri.fromFile(f)
    }

    // ---------------- location ----------------
    private val locL = object : LocationListener {
        override fun onLocationChanged(l: Location) { me.value = l.latitude to l.longitude }
        override fun onProviderEnabled(p: String) { }
        override fun onProviderDisabled(p: String) { }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(p: String?, s: Int, b: Bundle?) { }
    }

    private fun startLocation() {
        try {
            val lm = app.getSystemService(LocationManager::class.java)
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try {
                    lm.requestLocationUpdates(p, 5000L, 3f, locL, Looper.getMainLooper())
                    lm.getLastKnownLocation(p)?.let { if (me.value == null) me.value = it.latitude to it.longitude }
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    private fun stopLocation() {
        try { app.getSystemService(LocationManager::class.java).removeUpdates(locL) } catch (_: Exception) { }
    }

    // ---------------- persistence ----------------
    private fun loadApproved(): Map<String, String> = try {
        val o = JSONObject(store.getStr("mesh_ok").ifEmpty { "{}" })
        o.keys().asSequence().associateWith { o.getString(it) }
    } catch (_: Exception) { emptyMap() }

    private fun saveGroups() {
        val a = JSONArray()
        groups.value.forEach { a.put(JSONObject().put("g", it.gid).put("n", it.name).put("m", JSONArray(it.members)).put("nn", JSONArray(it.names))) }
        store.putStr("mesh_groups", a.toString())
    }

    private fun loadGroups(): List<Group> = try {
        val a = JSONArray(store.getStr("mesh_groups").ifEmpty { "[]" })
        (0 until a.length()).map { val o = a.getJSONObject(it); Group(o.getString("g"), o.getString("n"), jarr(o.optJSONArray("m")), jarr(o.optJSONArray("nn"))) }
    } catch (_: Exception) { emptyList() }

    private fun saveMsgs() {
        val a = JSONArray()
        msgs.value.takeLast(400).forEach {
            a.put(JSONObject().put("id", it.id).put("c", it.conv).put("f", it.fromId).put("n", it.fromName).put("t", it.text)
                .put("ts", it.ts).put("m", it.mine).put("fl", it.file ?: "").put("mi", it.mime ?: "").put("s", it.status))
        }
        store.putStr("mesh_msgs", a.toString())
    }

    private fun loadMsgs(): List<MMsg> = try {
        val a = JSONArray(store.getStr("mesh_msgs").ifEmpty { "[]" })
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            MMsg(o.getString("id"), o.getString("c"), o.getString("f"), o.getString("n"), o.getString("t"), o.getLong("ts"),
                o.getBoolean("m"), o.optString("fl").ifEmpty { null }, o.optString("mi").ifEmpty { null }, o.optInt("s"))
        }
    } catch (_: Exception) { emptyList() }

    private fun saveFiles() {
        val a = JSONArray()
        files.value.takeLast(300).forEach {
            a.put(JSONObject().put("id", it.id).put("n", it.name).put("m", it.mime).put("s", it.size).put("u", it.uri).put("ts", it.ts).put("o", it.mine).put("w", it.who))
        }
        store.putStr("mesh_files", a.toString())
    }

    private fun loadFiles(): List<MFile> = try {
        val a = JSONArray(store.getStr("mesh_files").ifEmpty { "[]" })
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            MFile(o.getString("id"), o.getString("n"), o.getString("m"), o.getLong("s"), o.getString("u"), o.getLong("ts"), o.getBoolean("o"), o.getString("w"))
        }
    } catch (_: Exception) { emptyList() }
}

class MeshService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationManagerCompat.from(this).createNotificationChannel(
            NotificationChannelCompat.Builder("mesh_fg", NotificationManagerCompat.IMPORTANCE_LOW).setName("Offline zone").build()
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).putExtra("mesh", true), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "mesh_fg").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Offline zone is on").setContentText("People nearby can reach you without internet")
            .setContentIntent(open).setOngoing(true).build()
        try {
            ServiceCompat.startForeground(this, 4711, n, if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0)
        } catch (_: Exception) { stopSelf() }
        return START_STICKY
    }
}
