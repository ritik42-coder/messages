package com.messages.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object EmojiData {
    val cats: List<Pair<String, List<String>>> = listOf(
        "😀" to "😀 😃 😄 😁 😆 😅 😂 🤣 🥲 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫡 🤭 🫢 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 👽 👾 🤖",
        "👋" to "👋 🤚 ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 🫶 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🧠 👀 👅 👄",
        "❤️" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 😻 💌 💋 🔥 ✨ 🌟 ⭐ 💫 💥 💯 💢 💦 💨 🎉 🎊",
        "🐶" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🦎 🐙 🦑 🐠 🐬 🐳 🦈 🐘 🦒 🐪 🌸 🌹 🌻 🌲 🍀",
        "🍔" to "🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍒 🥭 🍍 🥥 🥝 🍅 🥑 🌽 🥕 🍞 🧀 🍳 🥞 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍜 🍝 🍣 🍱 🍛 🍚 🍦 🍩 🍪 🎂 🍰 🍫 🍿 ☕ 🍵 🥤 🍺 🍷",
        "⚽" to "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏏 🏑 🏸 🥊 🎯 🎮 🎲 🧩 🎨 🎬 🎤 🎧 🎸 🎹 🥁 🏆 🥇 🥈 🥉 🚴 🏊 🧘",
        "🚗" to "🚗 🚕 🚌 🏍️ 🚲 ✈️ 🚀 🚁 ⛵ 🏠 🏫 🏥 🌍 🌙 ☀️ ⛅ 🌧️ ⚡ ❄️ 🌈 📱 💻 📷 🔋 💡 📚 ✏️ 📌 🔑 🔒 🎁 💰 💳 ⏰ 📞"
    ).map { (icon, all) -> icon to all.split(" ").filter { it.isNotEmpty() } }

    val quick = listOf("\u2764\uFE0F", "\uD83D\uDE02", "\uD83D\uDE2E", "\uD83D\uDE22", "\uD83D\uDE4F", "\uD83D\uDC4D", "\uD83D\uDD25")

    /** True for a message that is only one to three emoji, so it can be shown big with no bubble. */
    fun isJumbo(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || t.length > 24) return false
        var count = 0
        var i = 0
        while (i < t.length) {
            val cp = t.codePointAt(i)
            i += Character.charCount(cp)
            val joiner = cp == 0x200D || cp == 0xFE0F || cp in 0x1F3FB..0x1F3FF
            val emoji = cp in 0x1F300..0x1FAFF || cp in 0x2600..0x27BF || cp in 0x1F000..0x1F2FF || cp == 0x2B50 || cp == 0x2B55 || cp == 0x2764 || cp == 0x203C || cp == 0x2049
            if (joiner) continue
            if (!emoji) return false
            count++
        }
        return count in 1..3
    }
}

@Composable
fun ScEmojiPanel(onPick: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth().height(268.dp).background(Surf)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
            EmojiData.cats.forEachIndexed { i, c ->
                Box(
                    Modifier.weight(1f).padding(horizontal = 2.dp).clip(CircleShape)
                        .background(if (i == tab) A2.copy(alpha = 0.25f) else androidx.compose.ui.graphics.Color.Transparent)
                        .bounce(onClick = { tab = i }).padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) { Text(c.first, fontSize = 20.sp) }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(46.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(EmojiData.cats[tab].second) { e ->
                Box(Modifier.size(46.dp).bounce(onClick = { onPick(e) }), contentAlignment = Alignment.Center) {
                    Text(e, fontSize = 26.sp)
                }
            }
        }
    }
}
