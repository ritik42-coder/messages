@file:OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import android.graphics.Bitmap
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

fun nearbyPerms(): Array<String> = buildList {
    add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT >= 31) {
        add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT)
    }
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
}.toTypedArray()

fun hasNearbyPerms(c: Context) = nearbyPerms().all { c.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

fun qrBitmap(text: String, size: Int = 600): ImageBitmap {
    val m = com.google.zxing.qrcode.QRCodeWriter().encode(text, com.google.zxing.BarcodeFormat.QR_CODE, size, size)
    val px = IntArray(size * size) { i -> if (m.get(i % size, i / size)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt() }
    return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888).asImageBitmap()
}

fun openFile(ctx: Context, uri: String, mime: String?) {
    runCatching {
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), mime ?: "*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }.onFailure { Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show() }
}

fun shareFile(ctx: Context, uri: String, mime: String?) {
    runCatching {
        val i = Intent(Intent.ACTION_SEND).setType(mime ?: "*/*").putExtra(Intent.EXTRA_STREAM, Uri.parse(uri)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share file"))
    }.onFailure { Toast.makeText(ctx, "Can't share this file", Toast.LENGTH_SHORT).show() }
}

fun sizeText(b: Long): String = when {
    b <= 0 -> ""
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "${b / 1024} KB"
    else -> "%.1f MB".format(b / 1048576.0)
}

// ---------- radar "map" ----------
@Composable
fun Radar(me: Pair<Double, Double>?, peers: List<Peer>, direct: Set<String>, ok: Set<String>, onPick: (Peer) -> Unit) {
    val t = rememberInfiniteTransition(label = "radar")
    val sweep by t.animateFloat(0f, 360f, infiniteRepeatable(tween(3600, easing = LinearEasing)), label = "sw")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800)), label = "pl")
    val rel = remember(me, peers) {
        peers.map { p ->
            if (me != null && p.lat != null && p.lon != null) {
                val dx = (p.lon - me.second) * 111320.0 * kotlin.math.cos(Math.toRadians(me.first))
                val dy = (p.lat - me.first) * 110540.0
                Triple(dx, dy, hypot(dx, dy))
            } else null
        }
    }
    val maxD = rel.filterNotNull().maxOfOrNull { it.third } ?: 0.0
    val ring = listOf(25.0, 50.0, 100.0, 200.0, 500.0, 1000.0, 2000.0, 5000.0, 20000.0).firstOrNull { it >= maxD * 1.05 } ?: (maxD * 1.1)
    Column(Modifier.padding(horizontal = 14.dp)) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(330.dp).clip(RoundedCornerShape(28.dp)).background(Surf)) {
            val wpx = constraints.maxWidth.toFloat()
            val hpx = constraints.maxHeight.toFloat()
            val cx = wpx / 2f
            val cy = hpx / 2f
            val r = min(wpx, hpx) / 2f * 0.8f
            Canvas(Modifier.fillMaxSize()) {
                val c = Offset(cx, cy)
                for (k in 1..3) drawCircle(Dim.copy(alpha = 0.25f), radius = r * k / 3f, center = c, style = Stroke(width = 1.5f * density))
                drawLine(Dim.copy(alpha = 0.18f), Offset(cx - r, cy), Offset(cx + r, cy), strokeWidth = density)
                drawLine(Dim.copy(alpha = 0.18f), Offset(cx, cy - r), Offset(cx, cy + r), strokeWidth = density)
                rotate(sweep, pivot = c) {
                    drawArc(A2.copy(alpha = 0.28f), startAngle = -45f, sweepAngle = 45f, useCenter = true, topLeft = Offset(cx - r, cy - r), size = Size(2 * r, 2 * r))
                    drawLine(A2, c, Offset(cx + r, cy), strokeWidth = 2.5f * density)
                }
                drawCircle(A2.copy(alpha = 0.45f * (1f - pulse)), radius = 12f * density + 40f * density * pulse, center = c)
                drawCircle(Brand, radius = 9f * density, center = c)
            }
            peers.forEachIndexed { i, p ->
                val d = rel[i]
                val x: Float
                val y: Float
                if (d != null) { x = cx + (d.first / ring).toFloat() * r; y = cy - (d.second / ring).toFloat() * r }
                else { val a = (i * 2.399963).toFloat() + 0.6f; x = cx + kotlin.math.cos(a) * r * 0.92f; y = cy + kotlin.math.sin(a) * r * 0.92f }
                val col = if (p.id in ok) Color(0xFF34D27B) else if (p.id in direct) A2 else A3
                Column(
                    Modifier.offset { IntOffset((x - 40.dp.toPx()).roundToInt(), (y - 16.dp.toPx()).roundToInt()) }.width(80.dp).bounce(onClick = { onPick(p) }),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(16.dp).clip(CircleShape).background(col).border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape))
                    Text(p.name, color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Text(
            if (me == null) "Waiting for GPS… people without a location are placed on the outer ring"
            else "Outer ring ≈ ${ring.toInt()} m  •  green = chat approved, purple = connected",
            color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, start = 6.dp)
        )
    }
}

@Composable
fun PeerRow(p: Peer, direct: Boolean, approved: Boolean, onClick: () -> Unit) {
    Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(p.name, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(if (direct) "Connected • in range" else if (p.hops > 0) "${p.hops + 1} hops away (via mesh)" else "In range", color = Dim, fontSize = 12.sp)
        }
        Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text(if (approved) "Chat" else "Request", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
fun ConvRow(icon: ImageVector?, title: String, last: String, ts: Long, unread: Int, name: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().bounce(onClick = onClick).padding(horizontal = 12.dp, vertical = 3.dp).clip(RoundedCornerShape(22.dp)).background(if (unread > 0) Surf2 else Surf).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) Box(Modifier.size(50.dp).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White) }
        else Avatar(name, 50.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(last, color = Dim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Column(horizontalAlignment = Alignment.End) {
            if (ts > 0) Text(fmt(ts), color = Dim, fontSize = 11.sp)
            if (unread > 0) { Spacer(Modifier.height(4.dp)); Badge(unread) }
        }
    }
}

// ---------- hub ----------
@Composable
fun NearbyScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val running by Mesh.running.collectAsState()
    val status by Mesh.status.collectAsState()
    val peers by Mesh.peers.collectAsState()
    val direct by Mesh.direct.collectAsState()
    val approved by Mesh.approved.collectAsState()
    val requests by Mesh.requests.collectAsState()
    val groups by Mesh.groups.collectAsState()
    val msgs by Mesh.msgs.collectAsState()
    val unread by Mesh.unread.collectAsState()
    val files by Mesh.files.collectAsState()
    val me by Mesh.me.collectAsState()
    val myName by Mesh.myNameFlow.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var showQr by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf<Peer?>(null) }
    var keepPick by remember { mutableStateOf<Peer?>(null) }
    var newGroup by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var sendTo by remember { mutableStateOf<String?>(null) }
    var cat by remember { mutableStateOf(0) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    SideEffect { if (pick != null) keepPick = pick }
    LaunchedEffect(Unit) { while (true) { delay(5000); now = System.currentTimeMillis() } }
    var granted by remember { mutableStateOf(hasNearbyPerms(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasNearbyPerms(ctx)
        if (granted) Mesh.start() else Toast.makeText(ctx, "Bluetooth, nearby devices and location permissions are needed", Toast.LENGTH_LONG).show()
    }
    fun toggle(on: Boolean) { if (on) { if (granted) Mesh.start() else permLauncher.launch(nearbyPerms()) } else Mesh.stop() }
    fun scan() {
        if (!granted) { permLauncher.launch(nearbyPerms()); return }
        Mesh.start()
        val o = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        GmsBarcodeScanning.getClient(ctx, o).startScan()
            .addOnSuccessListener { b ->
                val ok = b.rawValue?.let { Mesh.onQr(it) } == true
                Toast.makeText(ctx, if (ok) "Contact added. Connecting…" else "Not a Messages QR code", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { Toast.makeText(ctx, "Scanner unavailable (needs Google Play services)", Toast.LENGTH_LONG).show() }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val to = sendTo
        if (to != null) uris.forEach { if (!Mesh.sendFile(to, it)) Toast.makeText(ctx, "Not connected to that person right now", Toast.LENGTH_SHORT).show() }
    }
    DisposableEffect(showQr) { Mesh.qrWaiting.value = showQr; onDispose { Mesh.qrWaiting.value = false } }
    val visible = remember(peers, now) { peers.values.filter { now - it.seen < 60_000L || it.id in direct }.sortedBy { it.hops } }
    val blurR by animateDpAsState(if (pick != null) 14.dp else 0.dp, tween(250), label = "nb")

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().blur(blurR)) {
            Page("Nearby (offline)", onBack, actions = {
                IconBtn(Icons.Rounded.QrCode) { if (!granted) permLauncher.launch(nearbyPerms()) else { Mesh.start(); showQr = true } }
                IconBtn(Icons.Rounded.QrCodeScanner) { scan() }
            }) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Surf).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Zone mode", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(myName, color = A2, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.bounce(onClick = { rename = true }))
                        }
                        Text(status, color = Dim, fontSize = 12.sp)
                    }
                    Switch(checked = running, onCheckedChange = { toggle(it) }, colors = SwitchDefaults.colors(checkedTrackColor = A2, checkedThumbColor = Color.White))
                }
                Row(Modifier.padding(horizontal = 18.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Radar", "Chats", "Files").forEachIndexed { i, s -> Chip(s + if (i == 1 && requests.isNotEmpty()) " (${requests.size})" else "", tab == i) { tab = i } }
                }
                when (tab) {
                    0 -> LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
                        item { Radar(me, visible, direct, approved.keys, { pick = it }) }
                        item { Text("PEOPLE IN YOUR ZONE (${visible.size})", color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 22.dp, top = 14.dp, bottom = 6.dp)) }
                        if (visible.isEmpty()) item { Text(if (running) "Nobody found yet. Ask friends nearby to turn on Zone mode." else "Turn on Zone mode to see and be seen by people nearby, with no internet.", color = Dim, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 22.dp)) }
                        items(visible, key = { it.id }) { p -> PeerRow(p, p.id in direct, p.id in approved) { Mesh.openConv.value = p.id } }
                    }
                    1 -> LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
                        items(requests) { r ->
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf2).padding(14.dp)) {
                                Text(if (r.gid == null) "${r.name} wants to chat" else "${r.name} invited you to \"${r.gname}\"", color = Ink, fontWeight = FontWeight.Bold)
                                if (r.text.isNotEmpty()) Text(r.text, color = Dim, fontSize = 14.sp, maxLines = 3)
                                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Box(Modifier.bounce(onClick = { Mesh.acceptRequest(r) }).clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 20.dp, vertical = 8.dp)) { Text("Accept", color = Color.White, fontWeight = FontWeight.Bold) }
                                    Box(Modifier.bounce(onClick = { Mesh.declineRequest(r) }).clip(RoundedCornerShape(50)).background(Surf).padding(horizontal = 20.dp, vertical = 8.dp)) { Text("Decline", color = A3, fontWeight = FontWeight.Bold) }
                                }
                            }
                        }
                        item {
                            val z = msgs.lastOrNull { it.conv == "zone" }
                            ConvRow(Icons.Rounded.Forum, "Area chat", z?.let { "${it.fromName}: ${it.text}" } ?: "Everyone nearby can talk here", z?.ts ?: 0L, unread["zone"] ?: 0, "Area") { Mesh.openConv.value = "zone" }
                        }
                        items(groups, key = { it.gid }) { g ->
                            val l = msgs.lastOrNull { it.conv == "g:${g.gid}" }
                            ConvRow(Icons.Rounded.Groups, g.name, l?.let { "${it.fromName}: ${it.text}" } ?: "${g.members.size} members", l?.ts ?: 0L, unread["g:${g.gid}"] ?: 0, g.name) { Mesh.openConv.value = "g:${g.gid}" }
                        }
                        items(approved.entries.toList(), key = { it.key }) { e ->
                            val l = msgs.lastOrNull { it.conv == e.key }
                            ConvRow(null, e.value, l?.text ?: "Say hello", l?.ts ?: 0L, unread[e.key] ?: 0, e.value) { Mesh.openConv.value = e.key }
                        }
                        item {
                            Box(Modifier.padding(horizontal = 18.dp, vertical = 12.dp).fillMaxWidth().bounce(onClick = { newGroup = true }).clip(RoundedCornerShape(26.dp)).background(Surf).padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                                Text("+ New offline group", color = A2, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    else -> LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
                        item {
                            Column(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
                                Text("Send a file (Wi-Fi Direct / Bluetooth, no internet)", color = Ink, fontWeight = FontWeight.Bold)
                                val targets = visible.filter { it.id in direct && it.id in approved }
                                if (targets.isEmpty()) Text("Connect and approve a person first (Radar tab).", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    targets.forEach { p -> QuickChip("To ${p.name}") { sendTo = p.id; pickFiles.launch("*/*") } }
                                }
                                Text("Received files are saved in Downloads/Messages/ (Images, Videos, Audio, Documents, Others).", color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("All", "Images", "Videos", "Audio", "Documents", "Others").forEachIndexed { i, s -> Chip(s, cat == i) { cat = i } }
                                }
                            }
                        }
                        val shown = files.filter { cat == 0 || Mesh.folderFor(it.mime) == listOf("", "Images", "Videos", "Audio", "Documents", "Others")[cat] }.sortedByDescending { it.ts }
                        if (shown.isEmpty()) item { EmptyState(Icons.Rounded.Folder, "No files yet", "Files you send or receive appear here") }
                        items(shown, key = { it.id }) { f ->
                            Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth().bounce(onClick = { openFile(ctx, f.uri, f.mime) }).clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Surf2), contentAlignment = Alignment.Center) {
                                    Icon(when (Mesh.folderFor(f.mime)) { "Images" -> Icons.Rounded.Image; "Videos" -> Icons.Rounded.Videocam; "Audio" -> Icons.Rounded.AudioFile; "Documents" -> Icons.Rounded.Description; else -> Icons.Rounded.InsertDriveFile }, null, tint = A2)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(f.name, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text((if (f.mine) "Sent to " else "From ") + f.who + "  •  " + sizeText(f.size) + "  •  " + fmt(f.ts), color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                IconBtn(Icons.Rounded.Share, A2) { shareFile(ctx, f.uri, f.mime) }
                            }
                        }
                    }
                }
            }
        }

        Scrim(pick != null, { pick = null }) {
            keepPick?.let { p ->
                Row(Modifier.padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(p.name, 46.dp); Spacer(Modifier.width(12.dp))
                    Text(p.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                ActionCard(buildList {
                    add(Act(Icons.Rounded.Forum, if (p.id in approved) "Open chat" else "Send chat request") { pick = null; Mesh.openConv.value = p.id })
                    if (p.id in direct && p.id in approved) add(Act(Icons.Rounded.AttachFile, "Send files") { pick = null; sendTo = p.id; pickFiles.launch("*/*") })
                })
            }
        }

        AnimatedVisibility(showQr, enter = fadeIn(tween(200)) + scaleIn(spring(Spring.DampingRatioMediumBouncy), initialScale = 0.85f), exit = fadeOut(tween(150))) {
            val bmp = remember(myName) { qrBitmap("MSGQR1|${Mesh.myId}|$myName") }
            Box(Modifier.fillMaxSize().background(Bg).blockTouches(), contentAlignment = Alignment.Center) {
                Aurora(Modifier.fillMaxSize())
                Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    GradText("My QR code", 30)
                    Spacer(Modifier.height(6.dp))
                    Text("Ask your friend to scan this in Messages > Nearby. You become contacts and can chat and share files offline.", color = Dim, fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(22.dp))
                    Box(Modifier.clip(RoundedCornerShape(28.dp)).background(Color.White).padding(16.dp)) { Image(bmp, null, Modifier.size(260.dp)) }
                    Spacer(Modifier.height(14.dp))
                    Text(myName, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(24.dp))
                    GradientButton("Done") { showQr = false }
                }
            }
        }

        if (rename) {
            var n by remember { mutableStateOf(myName) }
            AlertDialog(
                onDismissRequest = { rename = false }, containerColor = Surf2,
                title = { Text("Your name in the zone", color = Ink) },
                text = { SearchField(n, { n = it }, "Name") },
                confirmButton = { TextButton(onClick = { Mesh.setName(n); rename = false }) { Text("Save", color = A2) } },
                dismissButton = { TextButton(onClick = { rename = false }) { Text("Cancel", color = Dim) } }
            )
        }
        if (newGroup) {
            var gname by remember { mutableStateOf("") }
            var chosen by remember { mutableStateOf(setOf<String>()) }
            AlertDialog(
                onDismissRequest = { newGroup = false }, containerColor = Surf2,
                title = { Text("New offline group", color = Ink) },
                text = {
                    Column {
                        SearchField(gname, { gname = it }, "Group name")
                        Spacer(Modifier.height(10.dp))
                        if (visible.isEmpty()) Text("No people in your zone yet.", color = Dim)
                        visible.forEach { p ->
                            Row(Modifier.fillMaxWidth().bounce(onClick = { chosen = if (p.id in chosen) chosen - p.id else chosen + p.id }).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                SelDot(p.id in chosen)
                                Text(p.name, color = Ink, fontSize = 16.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val m = visible.filter { it.id in chosen }
                        if (gname.isNotBlank() && m.isNotEmpty()) { Mesh.createGroup(gname.trim(), m); newGroup = false; tab = 1 }
                        else Toast.makeText(ctx, "Enter a name and pick people", Toast.LENGTH_SHORT).show()
                    }) { Text("Create", color = A2) }
                },
                dismissButton = { TextButton(onClick = { newGroup = false }) { Text("Cancel", color = Dim) } }
            )
        }
    }
}

// ---------- mesh chat ----------
@Composable
fun MeshChatScreen(conv: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val msgs by Mesh.msgs.collectAsState()
    val approved by Mesh.approved.collectAsState()
    val groups by Mesh.groups.collectAsState()
    val peers by Mesh.peers.collectAsState()
    val direct by Mesh.direct.collectAsState()
    val list = remember(msgs, conv) { msgs.filter { it.conv == conv }.asReversed() }
    var text by remember { mutableStateOf("") }
    val isGroup = conv.startsWith("g:")
    val isPeer = conv != "zone" && !isGroup
    val title = when {
        conv == "zone" -> "Area chat"
        isGroup -> groups.firstOrNull { "g:" + it.gid == conv }?.name ?: "Group"
        else -> approved[conv] ?: peers[conv]?.name ?: "Person"
    }
    val sub = when {
        conv == "zone" -> "Everyone in your zone, no internet"
        isGroup -> (groups.firstOrNull { "g:" + it.gid == conv }?.members?.size ?: 0).toString() + " members"
        conv in direct -> "Connected"
        peers[conv] != null -> "In your zone (relayed)"
        else -> "Out of range"
    }
    val waiting = isPeer && conv !in approved && msgs.any { it.conv == conv && it.mine }
    LaunchedEffect(conv, msgs.size) { Mesh.markRead(conv) }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { if (!Mesh.sendFile(conv, it)) Toast.makeText(ctx, "Needs a direct connection and approval", Toast.LENGTH_SHORT).show() }
    }
    fun send() {
        if (!Mesh.sendText(conv, text)) { Toast.makeText(ctx, "Waiting for them to accept your request", Toast.LENGTH_SHORT).show(); return }
        text = ""
    }
    Column(Modifier.fillMaxSize().background(Bg).blockTouches().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.ArrowBack) { onBack() }
            if (conv == "zone" || isGroup) Box(Modifier.size(42.dp).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) { Icon(if (isGroup) Icons.Rounded.Groups else Icons.Rounded.Forum, null, tint = Color.White) }
            else Avatar(title, 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(sub, color = Dim, fontSize = 12.sp)
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), reverseLayout = true, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            items(list, key = { it.id }) { m ->
                Column(Modifier.fillMaxWidth().animateItemPlacement(), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
                    if (!m.mine && (conv == "zone" || isGroup)) Text(m.fromName, color = A2, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp, bottom = 2.dp))
                    BubbleBody(
                        Msg(m.id.hashCode().toLong(), m.text, m.ts, m.mine, false, m.status == 1, null),
                        null, false,
                        onTap = { m.file?.let { openFile(ctx, it, m.mime) } }, onLong = { m.file?.let { shareFile(ctx, it, m.mime) } }
                    )
                }
            }
        }
        if (waiting) Text("Request sent. You can chat once they accept.", color = Dim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(4.dp))
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Bottom) {
            if (isPeer && conv in approved) Box(Modifier.size(46.dp).bounce(onClick = { pickFiles.launch("*/*") }), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.AttachFile, null, tint = Dim) }
            Box(Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(Surf).padding(horizontal = 18.dp, vertical = 14.dp)) {
                if (text.isEmpty()) Text(if (isPeer && conv !in approved) "Write a chat request…" else "Message", color = Dim, fontSize = 16.sp)
                BasicTextField(value = text, onValueChange = { text = it }, maxLines = 5, textStyle = TextStyle(color = Ink, fontSize = 16.sp), cursorBrush = SolidColor(A2), modifier = Modifier.fillMaxWidth())
            }
            AnimatedVisibility(text.isNotBlank(), enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn() + expandHorizontally(), exit = scaleOut() + fadeOut() + shrinkHorizontally()) {
                Box(Modifier.padding(start = 8.dp).size(50.dp).bounce(onClick = { send() }).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Send, null, tint = Color.White) }
            }
        }
    }
}
