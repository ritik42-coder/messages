package com.messages.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * The vault lives as an encrypted file in your Downloads folder, not inside the app.
 * Uninstalling Messages does not touch it, and a reinstall can read it back with the
 * recovery phrase. On the same install a hardware-backed key unlocks it silently.
 */
object VaultStore {
    private const val DIR = "Download/MessagesVault"
    private const val FOLDER = "MessagesVault"
    private const val HEAD = "vault.hdr"
    private const val BODY = "vault.dat"
    private const val META = "vault.meta"
    private const val ALIAS = "messages_vault_wrap"
    private const val ITER = 120_000

    private var key: SecretKeySpec? = null
    private var ready = false

    val unlocked: Boolean get() = ready

    // ---------------- crypto ----------------
    private fun derive(pass: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(pass.toCharArray(), salt, ITER, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(f.generateSecret(spec).encoded, "AES")
    }

    private fun encrypt(k: SecretKeySpec, plain: ByteArray): ByteArray {
        val iv = ByteArray(12)
        SecureRandom().nextBytes(iv)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv))
        val out = c.doFinal(plain)
        return iv + out
    }

    private fun decrypt(k: SecretKeySpec, data: ByteArray): ByteArray? = try {
        if (data.size < 13) null else {
            val iv = data.copyOfRange(0, 12)
            val body = data.copyOfRange(12, data.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, iv))
            c.doFinal(body)
        }
    } catch (_: Exception) { null }

    private fun keystoreKey(): SecretKey? = try {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) existing.secretKey
        else {
            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            gen.init(
                KeyGenParameterSpec.Builder(
                    ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build()
            )
            gen.generateKey()
        }
    } catch (_: Exception) { null }

    private fun wrapWithKeystore(ctx: Context, raw: ByteArray) {
        val k = keystoreKey() ?: return
        try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, k)
            val blob = c.iv + c.doFinal(raw)
            ctx.getSharedPreferences("vaultks", Context.MODE_PRIVATE).edit()
                .putString("wrapped", android.util.Base64.encodeToString(blob, android.util.Base64.NO_WRAP)).apply()
        } catch (_: Exception) { }
    }

    private fun unwrapFromKeystore(ctx: Context): ByteArray? {
        val k = keystoreKey() ?: return null
        val s = ctx.getSharedPreferences("vaultks", Context.MODE_PRIVATE).getString("wrapped", "") ?: return null
        if (s.isEmpty()) return null
        return try {
            val blob = android.util.Base64.decode(s, android.util.Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, blob.copyOfRange(0, 12)))
            c.doFinal(blob.copyOfRange(12, blob.size))
        } catch (_: Exception) { null }
    }

    // ---------------- files ----------------
    // The app keeps its own copy inside private storage (always readable), and mirrors every write to a
    // folder the person chose (survives uninstall). Without a chosen folder it still mirrors into Downloads.
    private fun internalDir(ctx: Context): File {
        val d = File(ctx.filesDir, "vault")
        d.mkdirs()
        return d
    }

    private fun legacyDir(): File {
        val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER)
        d.mkdirs()
        return d
    }

    private fun findUri(ctx: Context, name: String): Uri? {
        if (Build.VERSION.SDK_INT < 29) {
            val f = File(legacyDir(), name)
            return if (f.exists()) Uri.fromFile(f) else null
        }
        return try {
            ctx.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, arrayOf("_id"),
                MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=?",
                arrayOf("$DIR/", name), null
            )?.use { c -> if (c.moveToFirst()) Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0).toString()) else null }
        } catch (_: Exception) { null }
    }

    private fun legacyWrite(ctx: Context, name: String, bytes: ByteArray): Boolean = try {
        if (Build.VERSION.SDK_INT < 29) {
            File(legacyDir(), name).writeBytes(bytes)
            true
        } else {
            val existing = findUri(ctx, name)
            // only touch a file we own; never create "name (1)" copies next to someone else's
            val uri = existing ?: ctx.contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, DIR)
                }
            )
            if (uri == null) false else {
                ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
                true
            }
        }
    } catch (_: Exception) { false }

    private fun legacyRead(ctx: Context, name: String): ByteArray? = try {
        if (Build.VERSION.SDK_INT < 29) {
            val f = File(legacyDir(), name)
            if (f.exists()) f.readBytes() else null
        } else findUri(ctx, name)?.let { ctx.contentResolver.openInputStream(it)?.use { s -> s.readBytes() } }
    } catch (_: Exception) { null }

    private fun mirrorWrite(ctx: Context, name: String, bytes: ByteArray) {
        try {
            if (SafeMirror.hasTree(ctx)) SafeMirror.write(ctx, name, bytes)
            else legacyWrite(ctx, name, bytes)
        } catch (_: Exception) { }
    }

    private fun writeFile(ctx: Context, name: String, bytes: ByteArray): Boolean {
        var ok = false
        try {
            val dir = internalDir(ctx)
            val tmp = File(dir, "$name.tmp")
            tmp.writeBytes(bytes)
            val f = File(dir, name)
            if (f.exists()) f.delete()
            ok = tmp.renameTo(f)
        } catch (_: Exception) { }
        mirrorWrite(ctx, name, bytes)
        return ok
    }

    private fun readFile(ctx: Context, name: String): ByteArray? {
        try {
            val f = File(internalDir(ctx), name)
            if (f.exists()) return f.readBytes()
        } catch (_: Exception) { }
        val found = (try { SafeMirror.read(ctx, name) } catch (_: Exception) { null }) ?: legacyRead(ctx, name)
        if (found != null) {
            // cache it inside the app so every later read is instant and reliable
            try { File(internalDir(ctx), name).writeBytes(found) } catch (_: Exception) { }
        }
        return found
    }

    private fun deleteFile(ctx: Context, name: String) {
        try { File(internalDir(ctx), name).delete() } catch (_: Exception) { }
        try { SafeMirror.delete(ctx, name) } catch (_: Exception) { }
        try {
            if (Build.VERSION.SDK_INT < 29) File(legacyDir(), name).delete()
            else findUri(ctx, name)?.let { ctx.contentResolver.delete(it, null, null) }
        } catch (_: Exception) { }
    }

    /** Copies every vault file into the chosen folder. Returns how many files were written. */
    fun mirrorAll(ctx: Context): Int {
        if (!SafeMirror.hasTree(ctx)) return 0
        var n = 0
        try {
            internalDir(ctx).listFiles()?.forEach { f ->
                if (f.isFile && !f.name.endsWith(".tmp")) {
                    if (SafeMirror.write(ctx, f.name, f.readBytes())) n++
                }
            }
        } catch (_: Exception) { }
        if (n > 0) SafeMirror.markSync(ctx)
        return n
    }

    /**
     * Fresh install: the person picks the folder that holds the old vault files. We copy them into
     * the app and keep using that folder as the safe copy. Returns the number of files restored.
     */
    fun importFromTree(ctx: Context, tree: Uri): Int {
        var n = 0
        try {
            val all = SafeMirror.list(ctx, tree)
            if (all.none { it.first == HEAD }) return 0
            val dir = internalDir(ctx)
            for ((name, uri) in all) {
                val wanted = name == HEAD || name == BODY || name == META || name.endsWith(".enc")
                if (!wanted) continue
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: continue
                File(dir, name).writeBytes(bytes)
                n++
            }
            if (n > 0) SafeMirror.setTree(ctx, tree)
        } catch (_: Exception) { }
        return n
    }

    // ---------------- setup / unlock ----------------
    fun isSetup(ctx: Context): Boolean = readFile(ctx, HEAD) != null

    /** First run: makes the key, protects it with the phrase and with the phone's keystore. */
    fun setup(ctx: Context, pass: String): Boolean = try {
        val raw = ByteArray(32)
        SecureRandom().nextBytes(raw)
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val kdf = derive(pass, salt)
        val header = salt + encrypt(kdf, raw)
        if (!writeFile(ctx, HEAD, header)) false else {
            key = SecretKeySpec(raw, "AES")
            ready = true
            wrapWithKeystore(ctx, raw)
            save(ctx, emptyList())
            true
        }
    } catch (_: Exception) { false }

    /** Same install: the keystore key opens it with no phrase. */
    fun unlockQuietly(ctx: Context): Boolean {
        if (ready) return true
        val raw = unwrapFromKeystore(ctx) ?: return false
        key = SecretKeySpec(raw, "AES")
        ready = true
        return true
    }

    /** New phone or reinstall: the phrase rebuilds the key. */
    fun unlock(ctx: Context, pass: String): Boolean {
        return try {
            val header = readFile(ctx, HEAD)
            if (header == null || header.size < 17) false
            else {
                val salt = header.copyOfRange(0, 16)
                val raw = decrypt(derive(pass, salt), header.copyOfRange(16, header.size))
                if (raw == null) false
                else {
                    key = SecretKeySpec(raw, "AES")
                    ready = true
                    wrapWithKeystore(ctx, raw)
                    true
                }
            }
        } catch (_: Exception) { false }
    }

    fun lock() {
        key = null
        ready = false
    }

    /** Forgets the phrase-protected header, e.g. when the vault is wiped. */
    fun destroy(ctx: Context) {
        deleteFile(ctx, HEAD)
        deleteFile(ctx, BODY)
        lock()
    }

    // ---------------- extra data (PIN, phone, broadcast lists, rules ...) ----------------
    fun saveMeta(ctx: Context, json: String): Boolean {
        val k = key ?: return false
        return try { writeFile(ctx, META, encrypt(k, json.toByteArray(Charsets.UTF_8))) } catch (_: Exception) { false }
    }

    fun loadMeta(ctx: Context): String? {
        val k = key ?: return null
        val blob = readFile(ctx, META) ?: return null
        val plain = decrypt(k, blob) ?: return null
        return try { String(plain, Charsets.UTF_8) } catch (_: Exception) { null }
    }

    // ---------------- items ----------------
    fun load(ctx: Context): List<VaultItem> {
        val k = key ?: return emptyList()
        val body = readFile(ctx, BODY) ?: return emptyList()
        val plain = decrypt(k, body) ?: return emptyList()
        return try { decode(String(plain, Charsets.UTF_8)) } catch (_: Exception) { emptyList() }
    }

    fun save(ctx: Context, items: List<VaultItem>): Boolean {
        val k = key ?: return false
        return try { writeFile(ctx, BODY, encrypt(k, encode(items).toByteArray(Charsets.UTF_8))) } catch (_: Exception) { false }
    }

    // ---------------- attachments ----------------
    fun putAttachment(ctx: Context, bytes: ByteArray, name: String, mime: String): VaultRef? {
        val k = key ?: return null
        val id = "f" + System.currentTimeMillis() + (100..999).random()
        return try {
            if (writeFile(ctx, id + ".enc", encrypt(k, bytes))) VaultRef(id, name, mime, bytes.size.toLong()) else null
        } catch (_: Exception) { null }
    }

    fun readAttachment(ctx: Context, ref: VaultRef): ByteArray? {
        val k = key ?: return null
        val blob = readFile(ctx, ref.id + ".enc") ?: return null
        return decrypt(k, blob)
    }

    fun deleteAttachment(ctx: Context, ref: VaultRef) = deleteFile(ctx, ref.id + ".enc")

    /** Copies the decrypted file into Downloads so other apps can open it. */
    fun export(ctx: Context, ref: VaultRef): Boolean {
        return try {
            val bytes = readAttachment(ctx, ref)
            val name = ref.name.ifBlank { "vault-file" }
            if (bytes == null) false
            else if (Build.VERSION.SDK_INT < 29) {
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name).writeBytes(bytes)
                true
            } else {
                val uri = ctx.contentResolver.insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, ref.mime.ifBlank { "application/octet-stream" })
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Messages")
                    }
                )
                if (uri == null) false else {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    true
                }
            }
        } catch (_: Exception) { false }
    }

    // ---------------- json ----------------
    fun encode(items: List<VaultItem>): String {
        val arr = JSONArray()
        for (i in items) {
            val o = JSONObject()
                .put("id", i.id).put("l", i.label).put("v", i.value).put("k", i.kind)
                .put("t", i.at).put("s", i.sub).put("w", i.whenMs)
            val f = JSONObject()
            i.fields.forEach { (kk, vv) -> f.put(kk, vv) }
            o.put("f", f)
            val fl = JSONArray()
            i.files.forEach { r ->
                fl.put(JSONObject().put("id", r.id).put("n", r.name).put("m", r.mime).put("z", r.size))
            }
            o.put("fl", fl)
            arr.put(o)
        }
        return arr.toString()
    }

    fun decode(json: String): List<VaultItem> {
        val out = ArrayList<VaultItem>()
        val arr = JSONArray(json)
        for (idx in 0 until arr.length()) {
            val o = arr.getJSONObject(idx)
            val fields = HashMap<String, String>()
            o.optJSONObject("f")?.let { f ->
                f.keys().forEach { k -> fields[k] = f.optString(k, "") }
            }
            val files = ArrayList<VaultRef>()
            o.optJSONArray("fl")?.let { fl ->
                for (j in 0 until fl.length()) {
                    val r = fl.getJSONObject(j)
                    files.add(VaultRef(r.optString("id"), r.optString("n"), r.optString("m"), r.optLong("z", 0L)))
                }
            }
            out.add(
                VaultItem(
                    o.optLong("id"), o.optString("l", ""), o.optString("v", ""), o.optString("k", "other"),
                    o.optLong("t", 0L), o.optString("s", ""), o.optLong("w", 0L), fields, files
                )
            )
        }
        return out
    }
}
