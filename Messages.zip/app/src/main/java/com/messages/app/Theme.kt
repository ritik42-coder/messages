package com.messages.app

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * A single theme definition. Every colour the app uses lives here so switching
 * a theme is one state change instead of a re-composition storm.
 */
data class Pal(
    val id: String,
    val name: String,
    val dark: Boolean,
    val bg: Color,
    val surf: Color,
    val surf2: Color,
    val line: Color,
    val ink: Color,
    val dim: Color,
    val a1: Color,
    val a2: Color,
    val a3: Color
) {
    val brand: Brush get() = Brush.linearGradient(listOf(a1, a2))
    val brandTri: Brush get() = Brush.linearGradient(listOf(a1, a2, a3))
    val glass: Color get() = if (dark) Color.White.copy(alpha = 0.06f) else Color.Black.copy(alpha = 0.04f)
}

object Pals {

    val light = listOf(
        Pal("ivory", "Ivory", false, c(0xFFFBF7F0), c(0xFFFFFFFF), c(0xFFF3EDE3), c(0xFFE8DFD1), c(0xFF1B1A17), c(0xFF7C7264), c(0xFFC98A4B), c(0xFF8E6BC8), c(0xFF4FA3A5)),
        Pal("porcelain", "Porcelain", false, c(0xFFF6F7FC), c(0xFFFFFFFF), c(0xFFEDEFF8), c(0xFFE1E4F2), c(0xFF14161C), c(0xFF6B7185), c(0xFF5B6CFF), c(0xFF9B5BFF), c(0xFF35C4C8)),
        Pal("sage", "Sage", false, c(0xFFF3F7F2), c(0xFFFFFFFF), c(0xFFE9F0E8), c(0xFFDBE6DA), c(0xFF16211A), c(0xFF64756A), c(0xFF3E8E6E), c(0xFF7FB069), c(0xFF2F7FA8)),
        Pal("rose", "Rose", false, c(0xFFFDF5F7), c(0xFFFFFFFF), c(0xFFF9E9EE), c(0xFFF0DAE2), c(0xFF22141A), c(0xFF87646E), c(0xFFE05C7F), c(0xFFC0508F), c(0xFFF09A6C)),
        Pal("sky", "Sky", false, c(0xFFF2F7FD), c(0xFFFFFFFF), c(0xFFE8F0FB), c(0xFFD8E5F6), c(0xFF101A26), c(0xFF5D6E85), c(0xFF3B82F6), c(0xFF22B8CF), c(0xFF6366F1)),
        Pal("sand", "Sand", false, c(0xFFFAF6EE), c(0xFFFFFFFF), c(0xFFF2EBDD), c(0xFFE7DCC8), c(0xFF211D15), c(0xFF7A705C), c(0xFFC2703D), c(0xFFA9834B), c(0xFF6B8E5A))
    )

    val dark = listOf(
        Pal("midnight", "Midnight", true, c(0xFF0B0D14), c(0xFF12151F), c(0xFF1A1F2C), c(0xFF262C3C), c(0xFFF2F4FA), c(0xFF98A1B8), c(0xFF7C8BFF), c(0xFFB06BFF), c(0xFF35D0D8)),
        Pal("aurora", "Aurora", true, c(0xFF060A12), c(0xFF0E1420), c(0xFF16203A), c(0xFF22304F), c(0xFFEAF2FF), c(0xFF8FA3C4), c(0xFF4F8CFF), c(0xFFA855F7), c(0xFF22D3EE)),
        Pal("graphite", "Graphite", true, c(0xFF0E0E10), c(0xFF17171A), c(0xFF212126), c(0xFF2E2E35), c(0xFFF5F5F7), c(0xFF9A9AA4), c(0xFF9AA0AA), c(0xFF6B7280), c(0xFF38BDF8)),
        Pal("ocean", "Ocean", true, c(0xFF05121A), c(0xFF0A1C26), c(0xFF102A38), c(0xFF16394B), c(0xFFE6F7FF), c(0xFF86A9B8), c(0xFF22D3EE), c(0xFF0EA5E9), c(0xFF14B8A6)),
        Pal("plum", "Plum", true, c(0xFF140A18), c(0xFF1E0F24), c(0xFF2A1432), c(0xFF3A1C45), c(0xFFF7E9FF), c(0xFFA98BB8), c(0xFFC084FC), c(0xFFF472B6), c(0xFF818CF8)),
        Pal("ember", "Ember", true, c(0xFF150D0A), c(0xFF1F1410), c(0xFF2B1B15), c(0xFF3C261D), c(0xFFFFF1E8), c(0xFFB89A8B), c(0xFFFB923C), c(0xFFF43F5E), c(0xFFFACC15))
    )

    val all: List<Pal> = light + dark

    fun byId(id: String, isDark: Boolean): Pal =
        all.firstOrNull { it.id == id && it.dark == isDark }
            ?: (if (isDark) dark.first() else light.first())
}

private fun c(v: Long) = Color(v)

val LocalPal = staticCompositionLocalOf { Pals.dark.first() }

/** Persisted appearance state. Cheap mutable state, no DataStore dependency. */
class ThemeState(ctx: Context) {
    private val sp = ctx.getSharedPreferences("msg_theme", Context.MODE_PRIVATE)

    /** 0 = follow system, 1 = light, 2 = dark */
    var mode: MutableState<Int> = mutableStateOf(sp.getInt("mode", 0))
    var lightId: MutableState<String> = mutableStateOf(sp.getString("lightId", "porcelain") ?: "porcelain")
    var darkId: MutableState<String> = mutableStateOf(sp.getString("darkId", "midnight") ?: "midnight")
    var bubbleStyle: MutableState<Int> = mutableStateOf(sp.getInt("bubble", 0))
    var fontScale: MutableState<Float> = mutableStateOf(sp.getFloat("font", 1f))
    var haptics: MutableState<Boolean> = mutableStateOf(sp.getBoolean("haptics", true))
    var particles: MutableState<Boolean> = mutableStateOf(sp.getBoolean("particles", true))
    var focusBlur: MutableState<Boolean> = mutableStateOf(sp.getBoolean("focusBlur", true))
    var animatedBg: MutableState<Boolean> = mutableStateOf(sp.getBoolean("animatedBg", true))

    fun save() {
        sp.edit()
            .putInt("mode", mode.value)
            .putString("lightId", lightId.value)
            .putString("darkId", darkId.value)
            .putInt("bubble", bubbleStyle.value)
            .putFloat("font", fontScale.value)
            .putBoolean("haptics", haptics.value)
            .putBoolean("particles", particles.value)
            .putBoolean("focusBlur", focusBlur.value)
            .putBoolean("animatedBg", animatedBg.value)
            .apply()
    }

    fun isDark(): Boolean = when (mode.value) {
        1 -> false
        2 -> true
        else -> false
    }
}

@Composable
fun resolvePal(state: ThemeState): Pal {
    val sysDark = isSystemInDarkTheme()
    val dark = when (state.mode.value) {
        1 -> false
        2 -> true
        else -> sysDark
    }
    return Pals.byId(if (dark) state.darkId.value else state.lightId.value, dark)
}

/**
 * Animated theme wrapper: every colour tweens, so switching themes feels like a
 * cross-fade instead of a hard flip.
 */
@Composable
fun AppTheme(state: ThemeState, content: @Composable () -> Unit) {
    val target = resolvePal(state)
    val spec = tween<Color>(durationMillis = 420)
    val p = Pal(
        id = target.id,
        name = target.name,
        dark = target.dark,
        bg = animateColorAsState(target.bg, spec, label = "bg").value,
        surf = animateColorAsState(target.surf, spec, label = "surf").value,
        surf2 = animateColorAsState(target.surf2, spec, label = "surf2").value,
        line = animateColorAsState(target.line, spec, label = "line").value,
        ink = animateColorAsState(target.ink, spec, label = "ink").value,
        dim = animateColorAsState(target.dim, spec, label = "dim").value,
        a1 = animateColorAsState(target.a1, spec, label = "a1").value,
        a2 = animateColorAsState(target.a2, spec, label = "a2").value,
        a3 = animateColorAsState(target.a3, spec, label = "a3").value
    )
    val scheme = if (p.dark) {
        darkColorScheme(
            primary = p.a1, onPrimary = Color.White, secondary = p.a2, tertiary = p.a3,
            background = p.bg, onBackground = p.ink, surface = p.surf, onSurface = p.ink,
            surfaceVariant = p.surf2, onSurfaceVariant = p.dim, outline = p.line,
            error = Color(0xFFFF6B6B)
        )
    } else {
        lightColorScheme(
            primary = p.a1, onPrimary = Color.White, secondary = p.a2, tertiary = p.a3,
            background = p.bg, onBackground = p.ink, surface = p.surf, onSurface = p.ink,
            surfaceVariant = p.surf2, onSurfaceVariant = p.dim, outline = p.line,
            error = Color(0xFFD92D20)
        )
    }
    CompositionLocalProvider(LocalPal provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
