@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Bills {
    /** Nudges you two days before a due date. */
    fun remind(ctx: Context, b: Bill) {
        val due = b.due ?: return
        val at = due - 2L * 86_400_000L
        if (at <= System.currentTimeMillis() + 60_000L) return
        try {
            val am = ctx.getSystemService(AlarmManager::class.java) ?: return
            val pi = PendingIntent.getBroadcast(
                ctx, ((b.address + due).hashCode() and 0x7FFFFFFF),
                Intent(ctx, BillReceiver::class.java)
                    .putExtra("title", "Bill due in 2 days \u00B7 " + b.who)
                    .putExtra(
                        "body",
                        (if (b.amount != null) "\u20B9" + b.amount.toInt() + "  \u00B7  " else "") +
                            "due " + SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(due))
                    ),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.set(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Exception) { }
    }
}

class BillReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifier.trip(c, i.getStringExtra("title") ?: "Bill due soon", i.getStringExtra("body") ?: "")
    }
}

@Composable
fun BillsScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var data by remember { mutableStateOf<MoneyData?>(null) }
    var month by remember {
        mutableStateOf(
            Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
        )
    }
    LaunchedEffect(Unit) { data = withContext(Dispatchers.IO) { Money.compute(ctx) } }
    val bills = data?.bills ?: emptyList()
    val monthKey = month.get(Calendar.YEAR) * 100 + month.get(Calendar.MONTH)
    val dueDays = remember(bills, monthKey) {
        val set = HashSet<Int>()
        for (b in bills) {
            val d = b.due ?: continue
            val cal = Calendar.getInstance().apply { timeInMillis = d }
            if (cal.get(Calendar.YEAR) * 100 + cal.get(Calendar.MONTH) == monthKey) set.add(cal.get(Calendar.DAY_OF_MONTH))
        }
        set
    }
    val monthBills = remember(bills, monthKey) {
        bills.filter {
            val d = it.due ?: return@filter false
            val cal = Calendar.getInstance().apply { timeInMillis = d }
            cal.get(Calendar.YEAR) * 100 + cal.get(Calendar.MONTH) == monthKey
        }
    }

    Page("Bills", onBack) {
        if (data == null) {
            EmptyState(Icons.Rounded.Description, "Reading your messages…")
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 26.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 12.dp)) {
                        IconBtn(Icons.Rounded.ChevronLeft, Dim) {
                            month = (month.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
                        }
                        Text(
                            SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(month.timeInMillis)),
                            color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                        )
                        IconBtn(Icons.Rounded.ChevronRight, Dim) {
                            month = (month.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
                        }
                    }
                }
                item {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        Row(Modifier.fillMaxWidth()) {
                            listOf("S", "M", "T", "W", "T", "F", "S").forEach { d ->
                                Text(d, color = Dim, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                            }
                        }
                        val first = (month.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
                        val offset = first.get(Calendar.DAY_OF_WEEK) - 1
                        val total = first.getActualMaximum(Calendar.DAY_OF_MONTH)
                        val rows = (offset + total + 6) / 7
                        for (r in 0 until rows) {
                            Row(Modifier.fillMaxWidth()) {
                                for (c in 0 until 7) {
                                    val day = r * 7 + c - offset + 1
                                    Box(Modifier.weight(1f).height(40.dp), contentAlignment = Alignment.Center) {
                                        if (day in 1..total) {
                                            val isToday = dayStart(System.currentTimeMillis()) ==
                                                dayStart((month.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, day) }.timeInMillis)
                                            val hasBill = day in dueDays
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Box(
                                                    Modifier.size(30.dp).clip(CircleShape)
                                                        .background(if (hasBill) A1 else if (isToday) Surf2 else Color.Transparent),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        "$day",
                                                        color = if (hasBill) Color.White else if (isToday) A2 else Ink,
                                                        fontSize = 13.sp, fontWeight = if (hasBill || isToday) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                }
                                                if (hasBill) {
                                                    Box(Modifier.padding(top = 2.dp).size(4.dp).clip(CircleShape).background(A2))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                item { SectionLabel(if (monthBills.isEmpty()) "NOTHING DUE THIS MONTH" else "DUE THIS MONTH") }
                if (monthBills.isEmpty() && bills.isEmpty()) {
                    item {
                        EmptyState(Icons.Rounded.Description, "No bills found", "Bills are read from your bank and service SMS")
                    }
                }
                items(monthBills.size) { i ->
                    val b = monthBills[i]
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(b.who.ifBlank { b.address }, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(
                                (if (b.amount != null) "\u20B9" + b.amount.toInt() + "  \u00B7  " else "") +
                                    "due " + (b.due?.let { SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(it)) } ?: "\u2014"),
                                color = Dim, fontSize = 13.sp
                            )
                        }
                        Box(
                            Modifier.bounce(onClick = {
                                Bills.remind(ctx, b)
                                android.widget.Toast.makeText(ctx, "Will remind you 2 days before", android.widget.Toast.LENGTH_SHORT).show()
                            }).clip(RoundedCornerShape(50)).background(Surf2).padding(horizontal = 14.dp, vertical = 8.dp)
                        ) { Text("Remind", color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                if (bills.isNotEmpty()) {
                    item { SectionLabel("ALL BILLS FOUND") }
                    items(bills.size) { i ->
                        val b = bills[i]
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp).padding(start = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Description, null, tint = Dim, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                (b.who.ifBlank { b.address }) + "  " +
                                    (if (b.amount != null) "\u20B9" + b.amount.toInt() else "") + "  " +
                                    (b.due?.let { SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(it)) } ?: ""),
                                color = Dim, fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
