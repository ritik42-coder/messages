package com.messages.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/**
 * Tiny hand-rolled icon set. The full material-icons-extended artefact is ~30 MB
 * of classes which slows dexing and bloats the APK, so the handful of icons this
 * app needs live here instead.
 */
object MIcon {

    private fun ico(name: String, path: String): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            addPath(pathData = addPathNodes(path), fill = SolidColor(Color.White))
        }.build()

    val Copy: ImageVector by lazy {
        ico(
            "copy",
            "M16,1H4C2.9,1 2,1.9 2,3v14h2V3h12V1zM19,5H8C6.9,5 6,5.9 6,7v14c0,1.1 0.9,2 2,2h11c1.1,0 2,-0.9 2,-2V7C21,5.9 20.1,5 19,5zM19,21H8V7h11V21z"
        )
    }

    val Forward: ImageVector by lazy {
        ico("forward", "M12,8V4l8,8l-8,8v-4H4V8H12z")
    }

    val Reply: ImageVector by lazy {
        ico("reply", "M10,9V5l-7,7l7,7v-4.1c5,0 8.5,1.6 11,5.1C20,15 17,10 10,9z")
    }

    val Pin: ImageVector by lazy {
        ico(
            "pin",
            "M16,9V4l1,0c0.55,0 1,-0.45 1,-1s-0.45,-1 -1,-1H7C6.45,2 6,2.45 6,3s0.45,1 1,1l1,0v5c0,1.66 -1.34,3 -3,3v2h5.97v7l1,1l1,-1v-7H19v-2C17.34,12 16,10.66 16,9z"
        )
    }

    val StarBorder: ImageVector by lazy {
        ico(
            "star_border",
            "M22,9.24l-7.19,-0.62L12,2L9.19,8.63L2,9.24l5.46,4.73L5.82,21L12,17.27L18.18,21l-1.63,-7.03L22,9.24zM12,15.4l-3.76,2.27l1,-4.28l-3.32,-2.88l4.38,-0.38L12,6.1l1.71,4.04l4.38,0.38l-3.32,2.88l1,4.28L12,15.4z"
        )
    }

    val SelectAll: ImageVector by lazy {
        ico(
            "select_all",
            "M3,5h2V3C3.9,3 3,3.9 3,5zM3,13h2v-2H3V13zM7,21h2v-2H7V21zM3,9h2V7H3V9zM13,3h-2v2h2V3zM19,3v2h2C21,3.9 20.1,3 19,3zM5,21v-2H3C3,20.1 3.9,21 5,21zM3,17h2v-2H3V17zM9,3H7v2h2V3zM11,21h2v-2h-2V21zM19,13h2v-2h-2V13zM19,21c1.1,0 2,-0.9 2,-2h-2V21zM19,9h2V7h-2V9zM19,17h2v-2h-2V17zM15,21h2v-2h-2V21zM15,5h2V3h-2V5z"
        )
    }

    val CheckBox: ImageVector by lazy {
        ico(
            "checkbox",
            "M19,3H5C3.9,3 3,3.9 3,5v14c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2V5C21,3.9 20.1,3 19,3zM10,17l-5,-5l1.41,-1.41L10,14.17l7.59,-7.59L19,8L10,17z"
        )
    }

    val CheckBoxBlank: ImageVector by lazy {
        ico(
            "checkbox_blank",
            "M19,5v14H5V5H19M19,3H5C3.9,3 3,3.9 3,5v14c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2V5C21,3.9 20.1,3 19,3L19,3z"
        )
    }

    val Bubble: ImageVector by lazy {
        ico(
            "bubble",
            "M20,2H4C2.9,2 2,2.9 2,4v18l4,-4h14c1.1,0 2,-0.9 2,-2V4C22,2.9 21.1,2 20,2zM20,16H6l-2,2V4h16V16z"
        )
    }

    val MarkRead: ImageVector by lazy {
        ico(
            "mark_read",
            "M20,2H4C2.9,2 2,2.9 2,4v18l4,-4h14c1.1,0 2,-0.9 2,-2V4C22,2.9 21.1,2 20,2zM7.5,13.5l-2.5,-2.5l1.4,-1.4l1.1,1.1l3.5,-3.5l1.4,1.4L7.5,13.5zM17,11h-5V9h5V11z"
        )
    }

    val Vibration: ImageVector by lazy {
        ico(
            "vibration",
            "M0,15h2V9H0V15zM3,17h2V7H3V17zM22,9v6h2V9H22zM19,17h2V7h-2V17zM16.5,3h-9C6.67,3 6,3.67 6,4.5v15C6,20.33 6.67,21 7.5,21h9c0.83,0 1.5,-0.67 1.5,-1.5v-15C18,3.67 17.33,3 16.5,3zM16,19H8V5h8V19z"
        )
    }

    val DoneAll: ImageVector by lazy {
        ico(
            "done_all",
            "M18,7l-1.41,-1.41l-6.34,6.34l1.41,1.41L18,7zM22.24,5.59L11.66,16.17L7.48,12l-1.41,1.41L11.66,19l12,-12L22.24,5.59zM0.41,13.41L6,19l1.41,-1.41L1.83,12L0.41,13.41z"
        )
    }

    val Sparkle: ImageVector by lazy {
        ico(
            "sparkle",
            "M19,9l1.25,-2.75L23,5l-2.75,-1.25L19,1l-1.25,2.75L15,5l2.75,1.25L19,9zM11.5,9.5L9,4L6.5,9.5L1,12l5.5,2.5L9,20l2.5,-5.5L17,12l-5.5,-2.5zM19,15l-1.25,2.75L15,19l2.75,1.25L19,23l1.25,-2.75L23,19l-2.75,-1.25L19,15z"
        )
    }

    val TrashForever: ImageVector by lazy {
        ico(
            "trash_forever",
            "M6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6V19zM8.46,11.88l1.41,-1.41L12,12.59l2.12,-2.12l1.41,1.41L13.41,14l2.12,2.12l-1.41,1.41L12,15.41l-2.12,2.12l-1.41,-1.41L10.59,14L8.46,11.88zM15.5,4l-1,-1h-5l-1,1H5v2h14V4H15.5z"
        )
    }

    val TrashSweep: ImageVector by lazy {
        ico(
            "trash_sweep",
            "M15,16h4v2h-4V16zM15,8h7v2h-7V8zM15,12h6v2h-6V12zM3,18c0,1.1 0.9,2 2,2h6c1.1,0 2,-0.9 2,-2V8H3V18zM14,5h-3l-1,-1H6L5,5H2v2h12V5z"
        )
    }

    val Restore: ImageVector by lazy {
        ico(
            "restore",
            "M19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4zM6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6V19zM12,9l4,4h-2.5v4h-3v-4H8L12,9z"
        )
    }

    val Lock: ImageVector by lazy {
        ico(
            "lock",
            "M18,8h-1V6c0,-2.76 -2.24,-5 -5,-5S7,3.24 7,6v2H6c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V10C20,8.9 19.1,8 18,8zM12,17c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2s2,0.9 2,2S13.1,17 12,17zM15.1,8H8.9V6c0,-1.71 1.39,-3.1 3.1,-3.1s3.1,1.39 3.1,3.1V8z"
        )
    }
}
