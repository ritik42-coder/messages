package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// =============================================================================================
// 1. Expiry reminders
// =============================================================================================

object VaultExpiry {
    private const val DAY = 86_400_000L

    fun startOfToday(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** The date a document stops being valid: the one you set, or read from "valid till" / card expiry. */
    fun expiryOf(v: VaultItem): Long {
        val set = v.fields["exp"]?.toLongOrNull() ?: 0L
        if (set > 0L) return set
        val valid = v.fields["valid"].orEmpty().trim()
        if (valid.isNotEmpty()) {
            try {
                val f = SimpleDateFormat("dd/MM/yyyy", Locale.US)
                f.isLenient = false
                val d = f.parse(valid)
                if (d != null) return d.time
            } catch (_: Exception) { }
        }
        val ex = v.fields["expiry"].orEmpty().trim()
        if (ex.isNotEmpty()) {
            val m = Regex("(\\d{1,2})\\s*/\\s*(\\d{2,4})").find(ex)
            if (m != null) {
                val mo = m.groupValues[1].toInt()
                var yr = m.groupValues[2].toInt()
                if (yr < 100) yr += 2000
                if (mo in 1..12) {
                    val c = Calendar.getInstance()
                    c.clear()
                    c.set(yr, mo - 1, 1)
                    c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH))
                    return c.timeInMillis
                }
            }
        }
        return 0L
    }

    fun daysLeft(ms: Long): Int = Math.floorDiv(ms - startOfToday(), DAY).toInt()

    class Due(val item: VaultItem, val at: Long, val days: Int)

    fun due(items: List<VaultItem>, within: Int): List<Due> {
        val out = ArrayList<Due>()
        for (v in items) {
            val e = expiryOf(v)
            if (e <= 0L) continue
            val d = daysLeft(e)
            if (d <= within && d >= -365) out.add(Due(v, e, d))
        }
        return out.sortedBy { it.days }
    }

    fun text(d: Int): String = when {
        d < -1 -> "expired " + (-d) + " days ago"
        d == -1 -> "expired yesterday"
        d == 0 -> "expires today"
        d == 1 -> "expires tomorrow"
        else -> "expires in $d days"
    }

    /** One quiet check every morning at 9. Safe to call as often as you like. */
    fun schedule(ctx: Context) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java) ?: return
            val pi = PendingIntent.getBroadcast(
                ctx, 7421, Intent(ctx, VaultExpiryReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val c = Calendar.getInstance()
            c.set(Calendar.HOUR_OF_DAY, 9)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        } catch (_: Exception) { }
    }
}

class VaultExpiryReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try {
            if (!VaultStore.isSetup(c)) return
            if (!VaultStore.unlocked && !VaultStore.unlockQuietly(c)) return
            val marks = setOf(30, 14, 7, 3, 1, 0)
            VaultExpiry.due(VaultStore.load(c), 30).filter { it.days in marks }.forEach { d ->
                Notifier.vaultExpiry(c, d.item.id.toInt(), "Document expiring", vaultTitle(d.item) + " " + VaultExpiry.text(d.days))
            }
        } catch (_: Throwable) { }
    }
}

@Composable
fun ExpiryBanner(items: List<VaultItem>, onOpen: (VaultItem) -> Unit) {
    val due = remember(items) { VaultExpiry.due(items, 60).take(3) }
    AnimatedVisibility(
        due.isNotEmpty(),
        enter = expandVertically(spring()) + fadeIn(),
        exit = shrinkVertically() + fadeOut()
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp)
        ) {
            Text("Expiring soon", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            due.forEach { d ->
                val col = if (d.days < 0) A3 else if (d.days <= 7) Gold else A2
                Row(
                    Modifier.fillMaxWidth().bounce(onClick = { onOpen(d.item) }).padding(top = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(col))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        vaultTitle(d.item), color = Ink, fontSize = 13.sp, modifier = Modifier.weight(1f),
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(VaultExpiry.text(d.days), color = col, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** A date row for the editor. Stores the day in values["exp"]. */
@Composable
fun ExpiryField(values: MutableMap<String, String>) {
    val ctx = LocalContext.current
    val cur = values["exp"]?.toLongOrNull() ?: 0L
    Text(
        "EXPIRY REMINDER", color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 0.6.sp, modifier = Modifier.padding(top = 12.dp, bottom = 3.dp)
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.bounce(onClick = {
                val c = Calendar.getInstance()
                if (cur > 0L) c.timeInMillis = cur
                android.app.DatePickerDialog(
                    ctx,
                    { _, y, m, d ->
                        val p = Calendar.getInstance()
                        p.clear()
                        p.set(y, m, d)
                        values["exp"] = p.timeInMillis.toString()
                    },
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
                ).show()
            }).clip(RoundedCornerShape(50)).background(Surf).padding(horizontal = 14.dp, vertical = 9.dp)
        ) {
            Text(
                if (cur > 0L) SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(cur)) else "Set date",
                color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold
            )
        }
        if (cur > 0L) {
            Spacer(Modifier.width(8.dp))
            Text(
                "Clear", color = A3, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.bounce(onClick = { values.remove("exp") }).padding(8.dp)
            )
        }
    }
    Text(
        "You get a reminder 30, 14, 7, 3 and 1 day before, and on the day.",
        color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
    )
}

// =============================================================================================
// 2. Document scanner (Google's on-device scanner: edge detection, crop, perspective, filters)
// =============================================================================================

@Composable
fun rememberDocScanner(onResult: (pdf: Uri?, pages: List<Uri>) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val res = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
            if (res != null) {
                val pages = ArrayList<Uri>()
                res.pages?.forEach { pages.add(it.imageUri) }
                onResult(res.pdf?.uri, pages)
            }
        }
    }
    return {
        val act = ctx.findActivity()
        if (act == null) {
            Toast.makeText(ctx, "Can't open the scanner here", Toast.LENGTH_SHORT).show()
        } else {
            val opts = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(12)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG, GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
            GmsDocumentScanning.getClient(opts).getStartScanIntent(act)
                .addOnSuccessListener { sender -> launcher.launch(IntentSenderRequest.Builder(sender).build()) }
                .addOnFailureListener {
                    Toast.makeText(ctx, "The scanner needs Google Play services on this phone", Toast.LENGTH_LONG).show()
                }
        }
    }
}

/** Turns a finished scan into an encrypted vault attachment, then wipes the scanner's plain copies. */
fun importScan(ctx: Context, pdf: Uri?, pages: List<Uri>): VaultRef? {
    var out: VaultRef? = null
    try {
        val stamp = SimpleDateFormat("dd MMM HH-mm", Locale.getDefault()).format(Date())
        if (pdf != null) {
            val b = ctx.contentResolver.openInputStream(pdf)?.use { it.readBytes() }
            if (b != null) out = VaultStore.putAttachment(ctx, b, "Scan $stamp.pdf", "application/pdf")
        } else if (pages.isNotEmpty()) {
            val b = ctx.contentResolver.openInputStream(pages[0])?.use { it.readBytes() }
            if (b != null) out = VaultStore.putAttachment(ctx, b, "Scan $stamp.jpg", "image/jpeg")
        }
    } catch (_: Exception) { }
    try {
        pdf?.path?.let { File(it).delete() }
        pages.forEach { u -> u.path?.let { File(it).delete() } }
    } catch (_: Exception) { }
    return out
}

// =============================================================================================
// 3. Masked + watermarked sharing
// =============================================================================================

/** Keeps the last 4 letters or digits, hides the rest: 1234 5678 9012 becomes XXXX XXXX 9012. */
fun maskKeep4(s: String): String {
    var seen = 0
    val sb = StringBuilder()
    for (i in s.length - 1 downTo 0) {
        val ch = s[i]
        if (ch.isLetterOrDigit()) {
            sb.append(if (seen < 4) ch else 'X')
            seen++
        } else sb.append(ch)
    }
    return sb.reverse().toString()
}

fun vaultMaskedText(v: VaultItem): String {
    val k = vaultKind(v.kind)
    val sb = StringBuilder(vaultTitle(v)).append('\n')
    k.fields.forEach { f ->
        if (f.key == "cvv" || f.key == "pin" || f.key == "password") return@forEach
        val raw = if (f.key == k.primary) v.value.ifBlank { v.fields[f.key].orEmpty() } else v.fields[f.key].orEmpty()
        if (raw.isBlank()) return@forEach
        sb.append(f.label).append(": ").append(if (f.secret) maskKeep4(raw) else raw).append('\n')
    }
    return sb.toString().trim()
}

object Watermark {
    private fun dir(ctx: Context): File {
        val d = File(ctx.cacheDir, "shared")
        d.mkdirs()
        d.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000L) it.delete() }
        return d
    }

    private fun decode(b: ByteArray, max: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, o2) ?: return null
        val ori = try {
            android.media.ExifInterface(ByteArrayInputStream(b))
                .getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)
        } catch (_: Exception) { android.media.ExifInterface.ORIENTATION_NORMAL }
        val deg = when (ori) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        return if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
    }

    private fun stamp(b: Bitmap, text: String): Bitmap {
        val out = b.copy(Bitmap.Config.ARGB_8888, true)
        val cv = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = android.graphics.Color.argb(100, 90, 90, 90)
        p.textSize = out.width / 22f
        p.isFakeBoldText = true
        val step = p.measureText(text) + out.width * 0.12f
        val gap = out.width * 0.22f
        cv.save()
        cv.rotate(-28f, out.width / 2f, out.height / 2f)
        var y = -out.height.toFloat()
        var row = 0
        while (y < out.height * 2f) {
            var x = -out.width.toFloat() + (row % 2) * step / 2f
            while (x < out.width * 2f) {
                cv.drawText(text, x, y, p)
                x += step
            }
            y += gap
            row++
        }
        cv.restore()
        return out
    }

    private fun renderPdf(ctx: Context, bytes: ByteArray, width: Int, maxPages: Int): List<Bitmap> {
        val out = ArrayList<Bitmap>()
        var pfd: ParcelFileDescriptor? = null
        val f = File(ctx.cacheDir, "vault_wm.pdf")
        try {
            FileOutputStream(f).use { it.write(bytes) }
            pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
            val r = PdfRenderer(pfd)
            for (i in 0 until r.pageCount.coerceAtMost(maxPages)) {
                val page = r.openPage(i)
                val h = (width * page.height / page.width.toFloat()).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                out.add(bmp)
            }
            r.close()
        } catch (_: Exception) {
        } finally {
            try { pfd?.close() } catch (_: Exception) { }
            f.delete()
        }
        return out
    }

    /** A copy of the attachment with "purpose, date" printed diagonally across it. */
    fun make(ctx: Context, ref: VaultRef, purpose: String): Pair<File, String>? {
        val bytes = VaultStore.readAttachment(ctx, ref) ?: return null
        val text = (if (purpose.isBlank()) "Shared copy" else purpose.trim()) + "  \u2022  " +
            SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        val d = dir(ctx)
        return try {
            if (ref.mime.startsWith("image")) {
                val bmp = decode(bytes, 2200) ?: return null
                val w = stamp(bmp, text)
                val f = File(d, "shared_" + System.currentTimeMillis() + ".jpg")
                FileOutputStream(f).use { w.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                Pair(f, "image/jpeg")
            } else if (ref.mime == "application/pdf") {
                val pages = renderPdf(ctx, bytes, 1240, 20)
                if (pages.isEmpty()) return null
                val doc = PdfDocument()
                val paint = Paint(Paint.FILTER_BITMAP_FLAG)
                pages.forEachIndexed { i, pg ->
                    val w = stamp(pg, text)
                    val ph = (595f * w.height / w.width).toInt()
                    val page = doc.startPage(PdfDocument.PageInfo.Builder(595, ph, i + 1).create())
                    page.canvas.drawBitmap(w, null, RectF(0f, 0f, 595f, ph.toFloat()), paint)
                    doc.finishPage(page)
                }
                val f = File(d, "shared_" + System.currentTimeMillis() + ".pdf")
                FileOutputStream(f).use { doc.writeTo(it) }
                doc.close()
                Pair(f, "application/pdf")
            } else null
        } catch (_: Throwable) { null }
    }
}

fun vaultShareFile(ctx: Context, f: File, mime: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "com.messages.app.vaultshare", f)
        val i = Intent(Intent.ACTION_SEND).setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (_: Exception) {
        Toast.makeText(ctx, "Couldn't share this file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun ShareRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).bounce(onClick = onClick)
            .clip(RoundedCornerShape(16.dp)).background(Surf).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = A2, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Dim, fontSize = 11.sp, maxLines = 2)
        }
    }
}

@Composable
fun ShareDialog(v: VaultItem, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var purpose by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val shareable = v.files.filter { it.mime.startsWith("image") || it.mime == "application/pdf" }
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() }, containerColor = Surf2,
        title = { Text("Share safely", color = Ink) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                ShareRow(
                    Icons.Rounded.VisibilityOff, "Masked details",
                    "Only the last 4 digits show. PINs, CVV and passwords are never included."
                ) {
                    try {
                        ctx.startActivity(
                            Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, vaultMaskedText(v)), "Share"
                            )
                        )
                    } catch (_: Exception) { }
                    onClose()
                }
                if (shareable.isNotEmpty()) {
                    Text(
                        "WATERMARKED COPY", color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        letterSpacing = 0.6.sp, modifier = Modifier.padding(top = 16.dp, bottom = 3.dp)
                    )
                    InputField(purpose, { purpose = it }, "Why are you sharing? e.g. KYC for Airtel", single = true)
                    Text(
                        "The reason and today's date are printed across the picture, so a leaked copy can be traced.",
                        color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                    shareable.forEach { r ->
                        ShareRow(fileIcon(r.mime), if (busy) "Preparing…" else r.name, "Send with watermark") {
                            if (!busy) {
                                busy = true
                                scope.launch {
                                    val res = withContext(Dispatchers.IO) { Watermark.make(ctx, r, purpose) }
                                    busy = false
                                    if (res == null) Toast.makeText(ctx, "Couldn't prepare this file", Toast.LENGTH_SHORT).show()
                                    else {
                                        vaultShareFile(ctx, res.first, res.second)
                                        onClose()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { if (!busy) onClose() }) { Text("Cancel", color = Dim) } }
    )
}

// =============================================================================================
// 4. Intruder photo
// =============================================================================================

class IntruderShot(val ref: VaultRef, val at: Long)

object Intruder {
    private fun sp(c: Context) = c.getSharedPreferences("vaultsec", Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = sp(c).getBoolean("intruder", false)

    fun setEnabled(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("intruder", on).apply()
        SafeData.touch(c)
    }

    fun rawLog(c: Context): String = sp(c).getString("intr", "[]") ?: "[]"

    fun log(c: Context): List<IntruderShot> {
        val out = ArrayList<IntruderShot>()
        try {
            val a = JSONArray(rawLog(c))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(IntruderShot(VaultRef(o.getString("id"), o.getString("n"), o.getString("m"), o.optLong("z")), o.optLong("t")))
            }
        } catch (_: Exception) { }
        return out
    }

    private fun add(c: Context, ref: VaultRef, at: Long) {
        val a = JSONArray()
        a.put(JSONObject().put("id", ref.id).put("n", ref.name).put("m", ref.mime).put("z", ref.size).put("t", at))
        try {
            val old = JSONArray(rawLog(c))
            for (i in 0 until old.length()) if (a.length() < 30) a.put(old.get(i))
        } catch (_: Exception) { }
        sp(c).edit().putString("intr", a.toString()).apply()
        SafeData.touch(c)
    }

    fun clear(c: Context) {
        sp(c).edit().putString("intr", "[]").apply()
        SafeData.touch(c)
    }

    fun hasCamera(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun store(app: Context, jpeg: ByteArray, rot: Int) {
        try {
            if (!VaultStore.unlocked && !VaultStore.unlockQuietly(app)) return
            var bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return
            if (rot != 0) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
            val at = System.currentTimeMillis()
            val name = "Intruder " + SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(at)) + ".jpg"
            val ref = VaultStore.putAttachment(app, out.toByteArray(), name, "image/jpeg") ?: return
            add(app, ref, at)
        } catch (_: Throwable) { }
    }

    /** Quietly takes one front-camera photo. Does nothing unless the feature is on and allowed. */
    fun snap(act: ComponentActivity) {
        val app = act.applicationContext
        if (!enabled(app) || !hasCamera(app)) return
        try {
            val fut = ProcessCameraProvider.getInstance(act)
            fut.addListener({
                try {
                    val provider = fut.get()
                    val capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                    provider.unbindAll()
                    provider.bindToLifecycle(act, CameraSelector.DEFAULT_FRONT_CAMERA, capture)
                    val exec = ContextCompat.getMainExecutor(act)
                    // give auto-exposure a moment so the photo isn't black
                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            capture.takePicture(exec, object : ImageCapture.OnImageCapturedCallback() {
                                override fun onCaptureSuccess(image: ImageProxy) {
                                    try {
                                        val buf = image.planes[0].buffer
                                        val bytes = ByteArray(buf.remaining())
                                        buf.get(bytes)
                                        val rot = image.imageInfo.rotationDegrees
                                        image.close()
                                        Thread { store(app, bytes, rot) }.start()
                                    } catch (_: Throwable) {
                                        try { image.close() } catch (_: Throwable) { }
                                    }
                                    try { provider.unbindAll() } catch (_: Throwable) { }
                                }

                                override fun onError(exception: ImageCaptureException) {
                                    try { provider.unbindAll() } catch (_: Throwable) { }
                                }
                            })
                        } catch (_: Throwable) {
                            try { provider.unbindAll() } catch (_: Throwable) { }
                        }
                    }, 700L)
                } catch (_: Throwable) { }
            }, ContextCompat.getMainExecutor(act))
        } catch (_: Throwable) { }
    }
}

// =============================================================================================
// 5. Decoy vault (opens with the decoy PIN) and the security screen
// =============================================================================================

@Composable
fun DecoyVault(onBack: () -> Unit, onLock: () -> Unit = {}) {
    val now = System.currentTimeMillis()
    val day = 86_400_000L
    val items = remember {
        listOf(
            VaultItem(
                id = 1, label = "", value = "4821 7733 9015", kind = "aadhaar", at = now - day * 40,
                fields = mapOf("number" to "4821 7733 9015", "name" to "Rahul Kumar", "dob" to "14/08/1999")
            ),
            VaultItem(
                id = 2, label = "", value = "BKLPK4821J", kind = "pan", at = now - day * 55,
                fields = mapOf("number" to "BKLPK4821J", "name" to "Rahul Kumar")
            ),
            VaultItem(
                id = 3, label = "Home Wi-Fi", value = "", kind = "password", at = now - day * 12,
                fields = mapOf("user" to "home-router", "password" to "welcome1234")
            )
        )
    }
    Page("Vault", onBack, actions = { IconBtn(Icons.Rounded.Lock) { onLock() } }) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Lock, null, tint = A2, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(6.dp))
            Text("3 items \u00B7 AES-256 encrypted", color = Dim, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 30.dp)) {
            items(items, key = { it.id }) { v ->
                VaultCard(v, onClick = { }, onFile = { })
            }
        }
    }
}

@Composable
private fun ShieldCard(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp)).background(Surf).padding(16.dp)
    ) { content() }
}

@Composable
fun VaultShield(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Intruder.enabled(ctx) && Intruder.hasCamera(ctx)) }
    var decoy by remember { mutableStateOf(VaultSecurity.hasDecoy(ctx)) }
    var shots by remember { mutableStateOf(Intruder.log(ctx)) }
    var settingDecoy by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<IntruderShot?>(null) }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            on = true
            Intruder.setEnabled(ctx, true)
        } else Toast.makeText(ctx, "Camera permission is needed for this", Toast.LENGTH_SHORT).show()
    }

    Box(Modifier.fillMaxSize()) {
        Page("Vault security", onBack) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                ShieldCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.PhotoCamera, null, tint = A2, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Intruder photo", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "After 3 wrong PINs the front camera quietly takes a photo and keeps it here, encrypted.",
                                color = Dim, fontSize = 12.sp
                            )
                        }
                        Switch(
                            checked = on,
                            onCheckedChange = { want ->
                                if (want) {
                                    if (Intruder.hasCamera(ctx)) {
                                        on = true
                                        Intruder.setEnabled(ctx, true)
                                    } else camPerm.launch(Manifest.permission.CAMERA)
                                } else {
                                    on = false
                                    Intruder.setEnabled(ctx, false)
                                }
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = A2, checkedThumbColor = Color.White)
                        )
                    }
                    if (shots.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        shots.take(8).forEach { s ->
                            Row(
                                Modifier.fillMaxWidth().bounce(onClick = { viewing = s }).padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Security, null, tint = A3, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(s.at)),
                                    color = Ink, fontSize = 13.sp, modifier = Modifier.weight(1f)
                                )
                                Text("View", color = A2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            "Clear log", color = A3, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.bounce(onClick = { Intruder.clear(ctx); shots = emptyList() }).padding(vertical = 8.dp)
                        )
                    }
                }
                ShieldCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.VisibilityOff, null, tint = A2, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Decoy PIN", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(
                                if (decoy) "A second PIN is set. It opens a harmless fake vault if someone makes you unlock it."
                                else "A second PIN that opens a harmless fake vault if someone makes you unlock it.",
                                color = Dim, fontSize = 12.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip(if (decoy) "Change" else "Set decoy PIN", true) { settingDecoy = true }
                        if (decoy) Chip("Remove", false) { VaultSecurity.clearDecoy(ctx); decoy = false }
                    }
                }
                Spacer(Modifier.height(30.dp))
            }
        }
        viewing?.let { s ->
            val dummy = VaultItem(0L, "Intruder photo", "", "password", s.at)
            FileViewer(dummy, s.ref, onClose = { viewing = null })
        }
    }

    if (settingDecoy) {
        var pin by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { settingDecoy = false }, containerColor = Surf2,
            title = { Text("Decoy PIN", color = Ink) },
            text = {
                Column {
                    Text("Choose 6 digits. It must be different from your real PIN.", color = Dim, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    InputField(pin, { pin = it.filter { c -> c.isDigit() }.take(6); err = null }, "6-digit decoy PIN", single = true)
                    err?.let { Text(it, color = A3, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pin.length != 6) err = "Enter 6 digits"
                    else if (VaultSecurity.checkPin(ctx, pin)) err = "That's your real PIN. Pick a different one."
                    else {
                        VaultSecurity.setDecoy(ctx, pin)
                        decoy = true
                        settingDecoy = false
                    }
                }) { Text("Save", color = A2, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { settingDecoy = false }) { Text("Cancel", color = Dim) } }
        )
    }
}
