package com.messages.app

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/** Records a voice note on the phone. Nothing is sent anywhere until you let go of the button. */
object VoiceRec {
    class Note(val file: File, val durMs: Long, val wf: String)

    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var startAt = 0L
    private val amps = ArrayList<Int>()

    @Suppress("DEPRECATION")
    private fun legacy(): MediaRecorder = MediaRecorder()

    fun start(ctx: Context): Boolean {
        quiet()
        return try {
            val f = File(ctx.cacheDir, "vn_" + System.currentTimeMillis() + ".m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else legacy()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(32000)
            r.setAudioEncodingBitRate(48000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            startAt = SystemClock.elapsedRealtime()
            amps.clear()
            true
        } catch (_: Throwable) {
            quiet()
            false
        }
    }

    /** 0..1 loudness right now. Also remembers it for the waveform. */
    fun level(): Float {
        val r = rec ?: return 0f
        val a = try { r.maxAmplitude } catch (_: Throwable) { 0 }
        amps.add(a)
        return Math.sqrt(a / 32767.0).toFloat().coerceIn(0f, 1f)
    }

    fun elapsed(): Long = if (rec == null) 0L else SystemClock.elapsedRealtime() - startAt

    fun stop(): Note? {
        val r = rec ?: return null
        val f = file ?: return null
        val dur = SystemClock.elapsedRealtime() - startAt
        rec = null
        file = null
        return try {
            r.stop()
            r.release()
            if (dur < 600L || !f.exists()) { f.delete(); null } else Note(f, dur, waveform())
        } catch (_: Throwable) {
            try { r.release() } catch (_: Throwable) { }
            f.delete()
            null
        }
    }

    fun cancel() { quiet() }

    private fun quiet() {
        rec?.let {
            try { it.stop() } catch (_: Throwable) { }
            try { it.release() } catch (_: Throwable) { }
        }
        file?.delete()
        rec = null
        file = null
    }

    private fun waveform(): String {
        val n = 40
        val out = ByteArray(n)
        if (amps.isNotEmpty()) {
            for (i in 0 until n) {
                val from = i * amps.size / n
                val to = maxOf(from + 1, (i + 1) * amps.size / n)
                var mx = 0
                for (j in from until minOf(to, amps.size)) mx = maxOf(mx, amps[j])
                out[i] = (Math.sqrt(mx / 32767.0) * 255).toInt().coerceIn(8, 255).toByte()
            }
        }
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    /** Turns the stored waveform text back into bar heights, 0..1. */
    fun bars(wf: String): List<Float> {
        return try {
            val b = Base64.decode(wf, Base64.NO_WRAP)
            if (b.isEmpty()) List(40) { 0.2f } else b.map { (it.toInt() and 0xFF) / 255f }
        } catch (_: Throwable) { List(40) { 0.2f } }
    }
}

/** One voice note plays at a time. Speed can be 1x, 1.5x or 2x. */
object VoicePlay {
    val playingRow = MutableStateFlow(-1L)
    val progress = MutableStateFlow(0f)
    val speed = MutableStateFlow(1f)

    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val p = mp ?: return
            try {
                if (p.isPlaying) {
                    progress.value = p.currentPosition.toFloat() / p.duration.coerceAtLeast(1)
                    h.postDelayed(this, 50)
                }
            } catch (_: Throwable) { }
        }
    }

    fun toggle(path: String, row: Long) {
        if (playingRow.value == row) { stop(); return }
        stop()
        try {
            val p = MediaPlayer()
            p.setDataSource(path)
            p.prepare()
            p.setOnCompletionListener { stop() }
            p.start()
            mp = p
            applySpeed(p)
            playingRow.value = row
            progress.value = 0f
            h.post(tick)
        } catch (_: Throwable) { stop() }
    }

    fun cycleSpeed() {
        speed.value = when (speed.value) { 1f -> 1.5f; 1.5f -> 2f; else -> 1f }
        mp?.let { applySpeed(it) }
    }

    private fun applySpeed(p: MediaPlayer) {
        try { p.playbackParams = p.playbackParams.setSpeed(speed.value) } catch (_: Throwable) { }
    }

    fun stop() {
        h.removeCallbacks(tick)
        try { mp?.release() } catch (_: Throwable) { }
        mp = null
        playingRow.value = -1L
        progress.value = 0f
    }
}
