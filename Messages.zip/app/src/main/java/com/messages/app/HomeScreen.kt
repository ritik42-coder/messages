package com.messages.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    vm: MessagesVM,
    theme: ThemeState,
    onOpen: (Chat) -> Unit,
    onSettings: () -> Unit,
    onNew: () -> Unit
) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val convos by vm.convos.collectAsStateWithLifecycle()
    val loaded by vm.loaded.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    var sheetFor by remember { mutableStateOf<Convo?>(null) }
    var deleteTarget by remember { mutableStateOf<Convo?>(null) }

    val list = remember(q, convos) {
        if (q.isBlank()) convos
        else convos.filter { it.name.contains(q, true) || it.address.contains(q) || it.snippet.contains(q, true) }
    }
    val msgHits by vm.searchResults.collectAsStateWithLifecycle()
    androidx.compose.runtime.LaunchedEffect(q) { vm.search(q) }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (searchOpen) {
                Row(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(p.surf)
                        .border(1.dp, p.line, RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Search, null, tint = p.dim, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (q.isEmpty()) Text("Search messages", color = p.dim, fontSize = 14.sp)
                        BasicTextField(
                            value = q,
                            onValueChange = { q = it },
                            textStyle = androidx.compose.ui.text.TextStyle(color = p.ink, fontSize = 14.sp),
                            cursorBrush = p.brand,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (q.isNotEmpty()) {
                        IconBtn(Icons.Rounded.Close, { q = "" }, size = 16.dp)
                    }
                }
                IconBtn(Icons.Rounded.Close, { searchOpen = false; q = "" })
            } else {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Messages",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = p.ink
                    )
                    Text(
                        "${convos.size} conversations",
                        color = p.dim, fontSize = 12.sp
                    )
                }
                IconBtn(Icons.Rounded.Search, onClick = { searchOpen = true })
                IconBtn(Icons.Rounded.Settings, onSettings)
            }
        }

        if (!loaded) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(8) { i ->
                    SkeletonRow(i)
                }
            }
        } else if (list.isEmpty() && msgHits.isEmpty()) {
            EmptyState(
                MIcon.Bubble,
                if (q.isBlank()) "No messages yet" else "Nothing matches",
                if (q.isBlank()) "Your conversations will appear here." else "Try another word or number."
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 10.dp, end = 10.dp, bottom = 100.dp
                )
            ) {
                if (msgHits.isNotEmpty()) {
                    item(key = "hdr") {
                        SectionLabel("Message matches")
                    }
                    items(msgHits, key = { "s${it.id}" }) { m ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    val c = convos.firstOrNull { it.threadId == m.threadId }
                                    onOpen(
                                        Chat(
                                            m.threadId,
                                            c?.address ?: m.address,
                                            c?.name ?: vm.repo.nameFor(m.address)
                                        )
                                    )
                                }
                                .padding(horizontal = 10.dp, vertical = 10.dp)
                        ) {
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(p.brand),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.Search, null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    vm.repo.nameFor(m.address), color = p.ink,
                                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                                )
                                Text(m.body, color = p.dim, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                    item(key = "hdr2") { SectionLabel("Conversations") }
                }
                items(list, key = { it.threadId }) { c ->
                    ConvoRow(
                        c = c,
                        onClick = { onOpen(Chat(c.threadId, c.address, c.name)) },
                        onLongClick = { sheetFor = c }
                    )
                }
            }
        }
    }

        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 26.dp)
                .size(58.dp)
                .clip(CircleShape)
                .background(p.brand)
                .clickable { onNew() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
    }

    val c = sheetFor
    if (c != null) {
        ModalBottomSheet(
            onDismissRequest = { sheetFor = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = p.surf
        ) {
            Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(c.name, 44.dp, seed = c.address.hashCode())
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(c.name, color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(c.address, color = p.dim, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                HomeAction(MIcon.MarkRead, "Mark as read") {
                    vm.repo.markRead(c.threadId); vm.refresh(); sheetFor = null
                }
                HomeAction(
                    MIcon.Vibration,
                    if (vm.store.mutedThreads().contains(c.threadId)) "Unmute notifications" else "Mute notifications"
                ) {
                    vm.store.toggleMute(c.threadId); sheetFor = null
                }
                HomeAction(MIcon.DoneAll, "Copy number") {
                    vm.copy(c.address); sheetFor = null
                }
                HomeAction(Icons.Rounded.Delete, "Delete conversation", danger = true) {
                    deleteTarget = c; sheetFor = null
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    val d = deleteTarget
    if (d != null) {
        ModalBottomSheet(
            onDismissRequest = { deleteTarget = null },
            containerColor = p.surf
        ) {
            Column(Modifier.padding(22.dp).navigationBarsPadding()) {
                Text("Delete conversation?", color = p.ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "All messages with ${d.name} will be removed from this device.",
                    color = p.dim, fontSize = 13.sp
                )
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(p.glass)
                            .clickable { deleteTarget = null },
                        contentAlignment = Alignment.Center
                    ) { Text("Cancel", color = p.ink, fontSize = 14.sp) }
                    Box(
                        Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFFFF4D4D))
                            .clickable {
                                vm.repo.deleteThread(d.threadId)
                                vm.refresh()
                                deleteTarget = null
                            },
                        contentAlignment = Alignment.Center
                    ) { Text("Delete", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun HomeAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    danger: Boolean = false,
    onClick: () -> Unit
) {
    val p = LocalPal.current
    val tint = if (danger) Color(0xFFFF6B6B) else p.ink
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConvoRow(c: Convo, onClick: () -> Unit, onLongClick: () -> Unit) {
    val p = LocalPal.current
    val unread = c.unread > 0
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 10.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Avatar(c.name, 50.dp, seed = c.address.hashCode())
            if (unread) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .size(11.dp)
                        .clip(CircleShape)
                        .background(p.a3)
                        .border(2.dp, p.bg, CircleShape)
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    c.name, color = p.ink,
                    fontSize = 15.sp,
                    fontWeight = if (unread) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(6.dp))
                Text(listStamp(c.date), color = if (unread) p.a1 else p.dim, fontSize = 11.sp)
            }
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (if (c.outgoing) "You: " else "") + c.snippet.replace("\n", " "),
                    color = if (unread) p.ink else p.dim,
                    fontSize = 12.5.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                if (unread) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .clip(CircleShape)
                            .background(p.brand)
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text("${c.unread}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SkeletonRow(i: Int) {
    val p = LocalPal.current
    val w by animateDpAsState(if (i % 2 == 0) 210.dp else 150.dp, tween(400), label = "w")
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp).clip(CircleShape).background(p.glass))
        Spacer(Modifier.width(12.dp))
        Column {
            Box(Modifier.width(110.dp).height(11.dp).clip(RoundedCornerShape(6.dp)).background(p.glass))
            Spacer(Modifier.height(8.dp))
            Box(Modifier.width(w).height(9.dp).clip(RoundedCornerShape(6.dp)).background(p.glass))
        }
    }
}

// ------------------------------------------------------------------ new chat

@Composable
fun NewChatScreen(vm: MessagesVM, onBack: () -> Unit, onStart: (Chat) -> Unit) {
    val p = LocalPal.current
    var q by remember { mutableStateOf("") }
    val contacts by vm.contacts.collectAsStateWithLifecycle()

    androidx.compose.runtime.LaunchedEffect(q) { vm.loadContacts(q) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBtn(Icons.Rounded.ArrowBack, onBack)
            Text(
                "New message", color = p.ink, fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(50))
                .background(p.surf)
                .border(1.dp, p.line, RoundedCornerShape(50))
                .padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Person, null, tint = p.dim, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) {
                if (q.isEmpty()) Text("Name or number", color = p.dim, fontSize = 14.sp)
                BasicTextField(
                    value = q, onValueChange = { q = it },
                    textStyle = androidx.compose.ui.text.TextStyle(color = p.ink, fontSize = 14.sp),
                    cursorBrush = p.brand,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        if (q.isNotBlank() && q.any { it.isDigit() }) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onStart(Chat(0, q, vm.repo.nameFor(q))) }
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(p.brand),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Send to $q", color = p.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("New conversation", color = p.dim, fontSize = 11.sp)
                }
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(contacts, key = { it.number }) { c ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onStart(Chat(0, c.number, c.name)) }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(c.name, 42.dp, seed = c.number.hashCode())
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(c.name, color = p.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        Text(c.number, color = p.dim, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}
