package com.messages.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.OpenableColumns
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections

/**
 * Encrypted files go here. The server only ever sees random bytes under a random name.
 * This and SecureCore are the only places in the app that touch the network.
 */
object SecureBlob {
    private fun conn(path: String, method: String): HttpURLConnection {
        val c = URL(SecureConfig.SB_URL.trimEnd('/') + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 40_000
        c.setRequestProperty("apikey", SecureConfig.SB_KEY)
        if (SecureConfig.SB_KEY.startsWith("eyJ")) c.setRequestProperty("Authorization", "Bearer " + SecureConfig.SB_KEY)
        return c
    }

    private fun obj(name: String) = SecureConfig.SB_BUCKET + "/" + SecureConfig.SB_PREFIX + name

    fun upload(name: String, file: File, onPct: (Int) -> Unit): Boolean {
        val c = try { conn("/storage/v1/object/" + obj(name), "POST") } catch (_: Exception) { return false }
        return try {
            c.doOutput = true
            c.setFixedLengthStreamingMode(file.length())
            c.setRequestProperty("Content-Type", "application/octet-stream")
            c.setRequestProperty("x-upsert", "false")
            val total = file.length().coerceAtLeast(1L)
            var sent = 0L
            FileInputStream(file).use { ins ->
                c.outputStream.use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        sent += n
                        onPct((sent * 100 / total).toInt())
                    }
                }
            }
            c.responseCode in 200..299
        } catch (_: Exception) { false } finally { c.disconnect() }
    }

    fun download(name: String, dst: File, onPct: (Int) -> Unit): Boolean {
        for (route in listOf("/storage/v1/object/public/", "/storage/v1/object/authenticated/")) {
            val c = try { conn(route + obj(name), "GET") } catch (_: Exception) { continue }
            try {
                if (c.responseCode !in 200..299) continue
                val total = c.contentLengthLong.coerceAtLeast(1L)
                var got = 0L
                c.inputStream.use { ins ->
                    FileOutputStream(dst).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            got += n
                            onPct((got * 100 / total).toInt().coerceAtMost(99))
                        }
                    }
                }
                return true
            } catch (_: Exception) {
            } finally { c.disconnect() }
        }
        return false
    }

    /** Removes the file from the server. A missing file counts as removed. */
    fun delete(name: String): Boolean {
        if (name.isEmpty() || !SecureConfig.storageReady()) return false
        val c = try { conn("/storage/v1/object/" + obj(name), "DELETE") } catch (_: Exception) { return false }
        return try {
            val code = c.responseCode
            code in 200..299 || code == 404
        } catch (_: Exception) { false } finally { c.disconnect() }
    }
}

/** Keeps listening in the background when "Instant mode" is on. */
class SecureService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationManagerCompat.from(this).createNotificationChannel(
            NotificationChannelCompat.Builder("sc_fg", NotificationManagerCompat.IMPORTANCE_LOW).setName("Secure chat (instant)").build()
        )
        val n = NotificationCompat.Builder(this, "sc_fg").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Secure chat is listening").setContentText("New messages arrive instantly")
            .setOngoing(true).build()
        try {
            ServiceCompat.startForeground(
                this, 4712, n,
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING else 0
            )
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        SecureCore.start(applicationContext)
        return START_STICKY
    }
}

/**
 * The online side of Secure Chat. SMS never calls into this object.
 * Firebase carries tiny encrypted envelopes under one private node; Supabase carries encrypted file bytes.
 * Phone numbers never leave the phone: people are known to the servers only by a random key-based id.
 */
object SecureCore {
    val tick = MutableStateFlow(0)
    val status = MutableStateFlow("")
    val progress = MutableStateFlow<Map<Long, Int>>(emptyMap())

    @Volatile var openCid: String? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val downloading: MutableSet<Long> = Collections.synchronizedSet(HashSet<Long>())
    private var started = false
    private var netWatching = false
    private lateinit var appCtx: Context

    private fun bump() { tick.value = tick.value + 1 }

    private fun prefs(c: Context) = c.getSharedPreferences("scprefs", Context.MODE_PRIVATE)
    fun ghost(c: Context): Boolean = prefs(c).getBoolean("ghost", false)
    fun setGhost(c: Context, on: Boolean) { prefs(c).edit().putBoolean("ghost", on).apply() }
    fun instant(c: Context): Boolean = prefs(c).getBoolean("instant", false)
    fun setInstant(c: Context, on: Boolean) { prefs(c).edit().putBoolean("instant", on).apply() }

    // ------------------------------------------------------------------ identity
    class Me(val priv: ByteArray, val pub: ByteArray, val id: String)

    @Volatile private var me: Me? = null

    fun identity(ctx: Context): Me {
        me?.let { return it }
        synchronized(this) {
            me?.let { return it }
            val sp = ctx.applicationContext.getSharedPreferences("scid", Context.MODE_PRIVATE)
            var priv = sp.getString("priv", null)?.let { SecureCrypto.unwrap(it) }
            var pub = sp.getString("pub", null)?.let { SecureCrypto.unb64(it) }
            if (priv == null || pub == null) {
                val k = SecureCrypto.newKeys()
                priv = k.priv
                pub = k.pub
                sp.edit().putString("priv", SecureCrypto.wrap(k.priv)).putString("pub", SecureCrypto.b64(k.pub))
                    .putBoolean("used", false).apply()
                SafeData.touch(ctx)
            }
            val m = Me(priv!!, pub!!, SecureCrypto.idOf(pub!!))
            me = m
            return m
        }
    }

    private fun markUsed(ctx: Context) {
        ctx.applicationContext.getSharedPreferences("scid", Context.MODE_PRIVATE).edit().putBoolean("used", true).apply()
    }

    /** For the safe copy. Never creates an identity, only exports one that exists. */
    fun exportIdentity(ctx: Context): JSONObject? {
        val sp = ctx.getSharedPreferences("scid", Context.MODE_PRIVATE)
        val w = sp.getString("priv", null) ?: return null
        val pub = sp.getString("pub", null) ?: return null
        val raw = SecureCrypto.unwrap(w) ?: return null
        return JSONObject().put("priv", SecureCrypto.b64(raw)).put("pub", pub)
    }

    /** After a reinstall: brings the old identity back, unless this install has already started a new one in use. */
    fun importIdentity(ctx: Context, o: JSONObject?) {
        if (o == null) return
        val sp = ctx.getSharedPreferences("scid", Context.MODE_PRIVATE)
        val priv = o.optString("priv", "")
        val pub = o.optString("pub", "")
        if (priv.isEmpty() || pub.isEmpty()) return
        if (sp.getString("pub", null) == pub) return
        if (sp.getBoolean("used", false)) return
        try {
            sp.edit().putString("priv", SecureCrypto.wrap(SecureCrypto.unb64(priv))).putString("pub", pub)
                .putBoolean("used", false).apply()
            me = null
            started = false
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ firebase plumbing
    private fun fbApp(ctx: Context): FirebaseApp {
        return try {
            FirebaseApp.getInstance(SecureConfig.FB_NAME)
        } catch (_: IllegalStateException) {
            FirebaseApp.initializeApp(
                ctx.applicationContext,
                FirebaseOptions.Builder()
                    .setApiKey(SecureConfig.FB_API_KEY).setApplicationId(SecureConfig.FB_APP_ID)
                    .setProjectId(SecureConfig.FB_PROJECT).setDatabaseUrl(SecureConfig.FB_DB).build(),
                SecureConfig.FB_NAME
            )
        }
    }

    private fun db(ctx: Context) = FirebaseDatabase.getInstance(fbApp(ctx), SecureConfig.FB_DB)
    private fun ref(ctx: Context, path: String) = db(ctx).getReference(SecureConfig.ROOT + "/" + path)

    private fun online(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            cm?.activeNetwork != null
        } catch (_: Exception) { true }
    }

    private fun watchNetwork(ctx: Context) {
        if (netWatching) return
        netWatching = true
        try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { start(appCtx) }
            })
        } catch (_: Exception) { }
    }

    fun start(ctx: Context) {
        appCtx = ctx.applicationContext
        watchNetwork(appCtx)
        if (started) return
        if (!online(appCtx)) { status.value = "Offline. Messages are saved and will send when you're back online."; return }
        started = true
        status.value = "Connecting…"
        try {
            val m = identity(appCtx)
            val auth = FirebaseAuth.getInstance(fbApp(appCtx))
            val email = m.id + "@securechat.local"
            val pw = SecureCrypto.authSecret(m.priv)
            auth.signInWithEmailAndPassword(email, pw).addOnCompleteListener { t ->
                if (t.isSuccessful) attach(m, auth)
                else auth.createUserWithEmailAndPassword(email, pw).addOnCompleteListener { t2 ->
                    if (t2.isSuccessful) attach(m, auth)
                    else {
                        started = false
                        status.value = "Couldn't sign in. Turn on Email/Password sign-in in Firebase, then try again."
                    }
                }
            }
        } catch (_: Throwable) {
            started = false
            status.value = "Secure chat couldn't start"
        }
    }

    private fun attach(m: Me, auth: FirebaseAuth) {
        val uid = auth.currentUser?.uid ?: run { started = false; return }
        // claim our id once, then listen. The claim is create-only, so nobody else can take it afterwards.
        ref(appCtx, "owners/" + m.id).setValue(uid).addOnCompleteListener {
            ref(appCtx, "inbox/" + m.id).addChildEventListener(object : ChildEventListener {
                override fun onChildAdded(s: DataSnapshot, previous: String?) {
                    val key = s.key ?: return
                    @Suppress("UNCHECKED_CAST")
                    val v = s.value as? Map<String, Any?> ?: return
                    scope.launch { handleIncoming(key, v) }
                }
                override fun onChildChanged(s: DataSnapshot, previous: String?) { }
                override fun onChildRemoved(s: DataSnapshot) { }
                override fun onChildMoved(s: DataSnapshot, previous: String?) { }
                override fun onCancelled(e: DatabaseError) {
                    status.value = "Secure chat can't read its inbox. Check the Firebase rules."
                }
            })
            ref(appCtx, "acks/" + m.id).addChildEventListener(object : ChildEventListener {
                override fun onChildAdded(s: DataSnapshot, previous: String?) {
                    val key = s.key ?: return
                    @Suppress("UNCHECKED_CAST")
                    val v = s.value as? Map<String, Any?> ?: return
                    scope.launch { handleAck(key, v) }
                }
                override fun onChildChanged(s: DataSnapshot, previous: String?) { }
                override fun onChildRemoved(s: DataSnapshot) { }
                override fun onChildMoved(s: DataSnapshot, previous: String?) { }
                override fun onCancelled(e: DatabaseError) { }
            })
            status.value = "Online \u00B7 end-to-end encrypted"
            scope.launch {
                purgeExpired(appCtx)
                retryUnsent(appCtx)
                downloadPending(appCtx, null)
            }
        }
    }

    // ------------------------------------------------------------------ sending envelopes
    private fun putEnvelope(ctx: Context, c: ScContact, payload: JSONObject, done: (Boolean) -> Unit) {
        try {
            val m = identity(ctx)
            val s = SecureCrypto.seal(m.priv, m.id, c.id, SecureCrypto.unb64(c.pub), payload.toString().toByteArray(Charsets.UTF_8))
            if (s == null) { done(false); return }
            val node = ref(ctx, "inbox/" + c.id).push()
            val map = hashMapOf<String, Any>(
                "f" to m.id, "e" to s.eph, "s" to s.salt, "i" to s.iv, "c" to s.ct, "t" to System.currentTimeMillis()
            )
            node.setValue(map).addOnCompleteListener { done(it.isSuccessful) }
        } catch (_: Throwable) { done(false) }
    }

    private fun sendAck(ctx: Context, c: ScContact, mid: String, state: Int) {
        try {
            val m = identity(ctx)
            ref(ctx, "acks/" + c.id).push().setValue(hashMapOf<String, Any>("m" to mid, "s" to state, "f" to m.id))
        } catch (_: Throwable) { }
    }

    // ------------------------------------------------------------------ receiving
    private fun handleIncoming(key: String, v: Map<String, Any?>) {
        val ctx = appCtx
        val store = SecureDb.get(ctx)
        val me = identity(ctx)
        try {
            val from = v["f"] as? String ?: return
            val c = store.contact(from)
            val sealed = SecureCrypto.Sealed(
                v["e"] as? String ?: "", v["s"] as? String ?: "", v["i"] as? String ?: "", v["c"] as? String ?: ""
            )
            val plain = if (c != null) SecureCrypto.open(me.priv, me.id, from, SecureCrypto.unb64(c.pub), sealed) else null
            if (c != null && plain != null) {
                val p = JSONObject(String(plain, Charsets.UTF_8))
                val mid = p.optString("mid", "")
                val ttl = p.optInt("x", 0)
                val now = System.currentTimeMillis()
                val exp = if (ttl > 0) now + ttl * 1000L else 0L
                val here = openCid == c.id
                markUsed(ctx)
                when (p.optString("k")) {
                    "text" -> {
                        val row = store.addMsg(ScMsg(0, mid, c.id, false, "text", p.optString("b"), "", "", 0, "", "", "", 2, now, exp, here))
                        if (row > 0) { store.touch(c.id, now); afterReceive(ctx, c, mid, here) }
                    }
                    "file" -> {
                        val row = store.addMsg(
                            ScMsg(
                                0, mid, c.id, false, p.optString("kind", "file"), "", p.optString("n", "file"),
                                p.optString("m", "application/octet-stream"), p.optLong("z"), "", p.optString("r"),
                                p.optString("fk"), 0, now, exp, here
                            )
                        )
                        if (row > 0) {
                            store.touch(c.id, now)
                            afterReceive(ctx, c, mid, here)
                            if (here) downloadNow(ctx, row)
                        }
                    }
                    "del" -> {
                        val old = store.msgByMid(c.id, p.optString("mid"))
                        if (old != null) removeLocal(old)
                    }
                    "burn" -> wipeLocal(ctx, c.id)
                }
                bump()
            }
        } catch (_: Throwable) {
        } finally {
            // delivered to this phone; nothing stays on the server
            try { ref(ctx, "inbox/" + me.id + "/" + key).removeValue() } catch (_: Throwable) { }
        }
    }

    private fun afterReceive(ctx: Context, c: ScContact, mid: String, here: Boolean) {
        sendAck(ctx, c, mid, 2)
        if (here && !ghost(ctx)) sendAck(ctx, c, mid, 3)
        if (!here) notifyIncoming(ctx)
    }

    private fun handleAck(key: String, v: Map<String, Any?>) {
        val ctx = appCtx
        try {
            val from = v["f"] as? String ?: return
            val mid = v["m"] as? String ?: return
            val st = (v["s"] as? Number)?.toInt() ?: return
            SecureDb.get(ctx).raiseState(from, mid, st.coerceIn(1, 3))
            bump()
        } catch (_: Throwable) {
        } finally {
            try { ref(ctx, "acks/" + identity(ctx).id + "/" + key).removeValue() } catch (_: Throwable) { }
        }
    }

    private fun notifyIncoming(ctx: Context) {
        try {
            NotificationManagerCompat.from(ctx).createNotificationChannel(
                NotificationChannelCompat.Builder("sc_msgs", NotificationManagerCompat.IMPORTANCE_DEFAULT).setName("Secure chat").build()
            )
            val open = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
            val b = NotificationCompat.Builder(ctx, "sc_msgs").setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Secure chat").setContentText("You have a new secure message")
                .setAutoCancel(true).setCategory(NotificationCompat.CATEGORY_MESSAGE)
            if (open != null) {
                b.setContentIntent(
                    android.app.PendingIntent.getActivity(ctx, 0, open, android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
                )
            }
            NotificationManagerCompat.from(ctx).notify(4713, b.build())
        } catch (_: SecurityException) { } catch (_: Throwable) { }
    }

    // ------------------------------------------------------------------ files on the phone, organised
    private fun folderOf(kind: String) = when (kind) { "image" -> "images"; "video" -> "videos"; else -> "files" }

    fun localFile(ctx: Context, cid: String, kind: String, name: String): File {
        val dir = File(ctx.filesDir, "securechat/" + cid + "/" + folderOf(kind))
        dir.mkdirs()
        val safe = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(80).ifBlank { "file" }
        return File(dir, System.currentTimeMillis().toString() + "_" + safe)
    }

    private fun removeLocal(m: ScMsg) {
        if (m.path.isNotEmpty()) try { File(m.path).delete() } catch (_: Exception) { }
        if (m.remote.isNotEmpty() && SecureConfig.storageReady() && (m.out || m.state != 2)) SecureBlob.delete(m.remote)
        SecureDb.get(appCtx).delMsg(m.row)
    }

    private fun wipeLocal(ctx: Context, cid: String) {
        val store = SecureDb.get(ctx)
        for (m in store.msgs(cid)) {
            if (m.remote.isNotEmpty() && SecureConfig.storageReady() && (m.out || m.state != 2)) SecureBlob.delete(m.remote)
        }
        store.wipe(cid)
        try { File(ctx.filesDir, "securechat/" + cid).deleteRecursively() } catch (_: Exception) { }
    }

    fun purgeExpired(ctx: Context) {
        val store = SecureDb.get(ctx)
        val now = System.currentTimeMillis()
        var any = false
        for (m in store.expired(now)) { removeLocal(m); any = true }
        // files nobody collected within a week are taken off the server
        for (m in store.staleUploads(now - 7L * 86_400_000L)) {
            SecureBlob.delete(m.remote)
            store.setRemote(m.row, "", m.fkey)
            store.setState(m.row, 9)
            any = true
        }
        if (any) bump()
    }

    // ------------------------------------------------------------------ sending
    fun sendText(ctx: Context, cid: String, text: String) {
        val store = SecureDb.get(ctx)
        val c = store.contact(cid) ?: return
        val t = text.trim()
        if (t.isEmpty()) return
        start(ctx)
        markUsed(ctx)
        val now = System.currentTimeMillis()
        val mid = SecureCrypto.hex(SecureCrypto.random(8))
        val exp = if (c.ttl > 0) now + c.ttl * 1000L else 0L
        val row = store.addMsg(ScMsg(0, mid, cid, true, "text", t, "", "", 0, "", "", "", 0, now, exp, true))
        store.touch(cid, now)
        bump()
        scope.launch { deliver(ctx, row) }
    }

    private fun deliver(ctx: Context, row: Long) {
        val store = SecureDb.get(ctx)
        val m = store.msg(row) ?: return
        val c = store.contact(m.cid) ?: return
        val p = JSONObject().put("mid", m.mid).put("x", c.ttl)
        if (m.kind == "text") p.put("k", "text").put("b", m.body)
        else p.put("k", "file").put("kind", m.kind).put("n", m.fname).put("m", m.mime).put("z", m.size)
            .put("r", m.remote).put("fk", m.fkey)
        putEnvelope(ctx, c, p) { ok ->
            if (ok) store.raiseState(m.cid, m.mid, 1) else store.setState(row, 0)
            bump()
        }
    }

    fun sendFile(ctx: Context, cid: String, uri: Uri) {
        val store = SecureDb.get(ctx)
        val c = store.contact(cid) ?: return
        start(ctx)
        markUsed(ctx)
        scope.launch {
            try {
                var name = "file"
                try {
                    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                        if (it.moveToFirst()) name = it.getString(0) ?: "file"
                    }
                } catch (_: Exception) { }
                val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
                val kind = if (mime.startsWith("image/")) "image" else if (mime.startsWith("video/")) "video" else "file"
                val dst = localFile(ctx, cid, kind, name)
                ctx.contentResolver.openInputStream(uri)?.use { ins -> FileOutputStream(dst).use { out -> ins.copyTo(out) } }
                if (!dst.exists() || dst.length() == 0L) { bump(); return@launch }
                val now = System.currentTimeMillis()
                val mid = SecureCrypto.hex(SecureCrypto.random(8))
                val exp = if (c.ttl > 0) now + c.ttl * 1000L else 0L
                val row = store.addMsg(ScMsg(0, mid, cid, true, kind, "", name, mime, dst.length(), dst.absolutePath, "", "", 0, now, exp, true))
                store.touch(cid, now)
                bump()
                uploadAndSend(ctx, row)
            } catch (_: Throwable) { bump() }
        }
    }

    private fun setPct(row: Long, pct: Int?) {
        progress.value = if (pct == null) progress.value - row else progress.value + (row to pct)
    }

    private fun uploadAndSend(ctx: Context, row: Long) {
        val store = SecureDb.get(ctx)
        val m = store.msg(row) ?: return
        if (!SecureConfig.storageReady()) { store.setState(row, 9); bump(); status.value = "File storage isn't set up yet"; return }
        val src = File(m.path)
        if (!src.exists()) { store.setState(row, 9); bump(); return }
        var remote = m.remote
        var fkey = m.fkey
        val tmp = File(ctx.cacheDir, "scup_" + row + ".enc")
        try {
            if (remote.isEmpty()) {
                val key = SecureCrypto.random(32)
                val name = SecureCrypto.hex(SecureCrypto.random(16))
                setPct(row, 0)
                SecureCrypto.encryptFile(src, tmp, key)
                val ok = SecureBlob.upload(name, tmp) { setPct(row, it) }
                if (!ok) { store.setState(row, 9); return }
                remote = name
                fkey = SecureCrypto.b64(key)
                store.setRemote(row, remote, fkey)
            }
        } catch (_: Throwable) {
            store.setState(row, 9)
            return
        } finally {
            tmp.delete()
            setPct(row, null)
            bump()
        }
        deliver(ctx, row)
    }

    fun retry(ctx: Context, row: Long) {
        start(ctx)
        scope.launch {
            val m = SecureDb.get(ctx).msg(row) ?: return@launch
            if (!m.out) { downloadNow(ctx, row); return@launch }
            SecureDb.get(ctx).setState(row, 0)
            bump()
            if (m.kind == "text") deliver(ctx, row) else uploadAndSend(ctx, row)
        }
    }

    private fun retryUnsent(ctx: Context) {
        for (m in SecureDb.get(ctx).unsent()) {
            if (m.kind == "text") deliver(ctx, m.row) else uploadAndSend(ctx, m.row)
        }
    }

    // ------------------------------------------------------------------ downloading
    fun downloadPending(ctx: Context, cid: String?) {
        for (m in SecureDb.get(ctx).pendingDownloads(cid)) downloadNow(ctx, m.row)
    }

    private fun downloadNow(ctx: Context, row: Long) {
        val store = SecureDb.get(ctx)
        val m = store.msg(row) ?: return
        if (m.out || m.state == 2 || m.remote.isEmpty()) return
        if (!downloading.add(row)) return
        store.setState(row, 1)
        setPct(row, 0)
        bump()
        val tmp = File(ctx.cacheDir, "scdl_" + row + ".enc")
        val out = localFile(ctx, m.cid, m.kind, m.fname)
        var ok = false
        try {
            ok = SecureBlob.download(m.remote, tmp) { setPct(row, it) } &&
                SecureCrypto.decryptFile(tmp, out, SecureCrypto.unb64(m.fkey))
        } catch (_: Throwable) { ok = false }
        tmp.delete()
        if (ok) {
            store.setFile(row, out.absolutePath, 2)
            // saved safely on this phone, so it can leave the server now
            if (SecureBlob.delete(m.remote)) store.setRemote(row, "", m.fkey)
        } else {
            out.delete()
            store.setState(row, 9)
        }
        setPct(row, null)
        downloading.remove(row)
        bump()
    }

    // ------------------------------------------------------------------ chats
    fun openChat(ctx: Context, cid: String) {
        openCid = cid
        start(ctx)
        val store = SecureDb.get(ctx)
        scope.launch {
            purgeExpired(ctx)
            val c = store.contact(cid) ?: return@launch
            val unseen = store.msgs(cid).filter { !it.out && !it.seen }
            store.markSeen(cid)
            if (!ghost(ctx)) for (m in unseen) sendAck(ctx, c, m.mid, 3)
            bump()
            downloadPending(ctx, cid)
        }
    }

    fun closeChat() { openCid = null }

    fun setTimer(ctx: Context, cid: String, seconds: Int) {
        SecureDb.get(ctx).setTtl(cid, seconds)
        bump()
    }

    /** Removes a message you sent from both phones, and its file from the server. */
    fun unsend(ctx: Context, row: Long) {
        scope.launch {
            val store = SecureDb.get(ctx)
            val m = store.msg(row) ?: return@launch
            val c = store.contact(m.cid)
            if (m.out && c != null) putEnvelope(ctx, c, JSONObject().put("k", "del").put("mid", m.mid)) { }
            removeLocal(m)
            bump()
        }
    }

    fun deleteForMe(ctx: Context, row: Long) {
        scope.launch {
            val m = SecureDb.get(ctx).msg(row) ?: return@launch
            removeLocal(m)
            bump()
        }
    }

    /** Wipes the whole chat here and on the other phone. */
    fun burn(ctx: Context, cid: String) {
        scope.launch {
            val c = SecureDb.get(ctx).contact(cid)
            if (c != null) putEnvelope(ctx, c, JSONObject().put("k", "burn")) { }
            wipeLocal(ctx, cid)
            bump()
        }
    }

    // ------------------------------------------------------------------ invites (travel by normal SMS)
    private val inviteRx = Regex("SC1:([A-Za-z0-9_-]{86,88})")

    fun hasInvite(body: String): Boolean = inviteRx.containsMatchIn(body)

    fun inviteText(ctx: Context): String =
        "Let's chat securely on Messages. Open this text in the Messages app and tap Connect.\nSC1:" +
            SecureCrypto.b64(identity(ctx).pub)

    /** Sent over plain SMS, so nothing about it goes online. */
    fun sendInvite(ctx: Context, number: String) {
        val n = number.trim()
        if (n.isEmpty()) return
        markUsed(ctx)
        scope.launch { SmsRepo(ctx).send(n, inviteText(ctx)) }
    }

    /** Links the number that sent the invite to the key inside it. Returns an error message, or null on success. */
    fun acceptInvite(ctx: Context, address: String, body: String): String? {
        val m = inviteRx.find(body) ?: return "That isn't a secure chat invite"
        val raw = try { SecureCrypto.unb64(m.groupValues[1]) } catch (_: Exception) { return "That invite is damaged" }
        if (SecureCrypto.pubFromRaw(raw) == null) return "That invite isn't valid"
        val id = SecureCrypto.idOf(raw)
        if (id == identity(ctx).id) return "That's your own invite"
        val store = SecureDb.get(ctx)
        val old = store.contact(id)
        val name = try { SmsRepo(ctx).name(address) } catch (_: Exception) { address }
        store.saveContact(ScContact(id, name, address, SecureCrypto.b64(raw), old?.ttl ?: 0, old?.last ?: System.currentTimeMillis()))
        SafeData.touch(ctx)
        bump()
        return null
    }

    /** A short code both people can read out to be sure nobody swapped the keys. */
    fun safetyCode(ctx: Context, c: ScContact): String {
        val a = SecureCrypto.unb64(c.pub)
        val b = identity(ctx).pub
        val first = if (SecureCrypto.hex(a) < SecureCrypto.hex(b)) a else b
        val second = if (first === a) b else a
        val h = SecureCrypto.sha256(first + second)
        val sb = StringBuilder()
        for (i in 0 until 6) {
            val v = ((h[i * 2].toInt() and 0xFF) shl 8 or (h[i * 2 + 1].toInt() and 0xFF)) % 10000
            sb.append(String.format("%04d", v))
            if (i < 5) sb.append(' ')
        }
        return sb.toString()
    }
}
