package com.messages.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract

/**
 * A folder the person picks once (Storage Access Framework). Files written there are not owned by
 * this app, so they survive uninstall and a fresh install can read them again by picking the folder.
 */
object SafeMirror {
    private const val P = "safemirror"

    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    /** The chosen folder, but only while we still hold permission to write to it. */
    fun tree(c: Context): Uri? {
        val s = sp(c).getString("tree", "") ?: ""
        if (s.isEmpty()) return null
        val u = Uri.parse(s)
        val ok = try {
            c.contentResolver.persistedUriPermissions.any { it.uri == u && it.isWritePermission }
        } catch (_: Exception) { false }
        return if (ok) u else null
    }

    fun hasTree(c: Context): Boolean = tree(c) != null

    fun setTree(c: Context, u: Uri) {
        try {
            c.contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) { }
        sp(c).edit().putString("tree", u.toString()).apply()
    }

    fun clear(c: Context) { sp(c).edit().remove("tree").apply() }

    fun lastSync(c: Context): Long = sp(c).getLong("last", 0L)
    fun markSync(c: Context) { sp(c).edit().putLong("last", System.currentTimeMillis()).apply() }

    /** Short readable name of the folder, e.g. "Download/MessagesVault". */
    fun label(c: Context): String {
        val u = tree(c) ?: return ""
        return try {
            val id = DocumentsContract.getTreeDocumentId(u)
            id.substringAfter(":", id)
        } catch (_: Exception) { "chosen folder" }
    }

    private fun rootDoc(t: Uri): Uri =
        DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t))

    /** Every file directly inside a folder: name to uri. */
    fun list(c: Context, t: Uri): List<Pair<String, Uri>> {
        val out = ArrayList<Pair<String, Uri>>()
        try {
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(t, DocumentsContract.getTreeDocumentId(t))
            c.contentResolver.query(
                kids,
                arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null, null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val id = cur.getString(0) ?: continue
                    val name = cur.getString(1) ?: continue
                    out.add(name to DocumentsContract.buildDocumentUriUsingTree(t, id))
                }
            }
        } catch (_: Exception) { }
        return out
    }

    private fun find(c: Context, t: Uri, name: String): Uri? = list(c, t).firstOrNull { it.first == name }?.second

    fun write(c: Context, name: String, bytes: ByteArray): Boolean {
        val t = tree(c) ?: return false
        return try {
            val uri = find(c, t, name)
                ?: DocumentsContract.createDocument(c.contentResolver, rootDoc(t), "application/octet-stream", name)
                ?: return false
            c.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
            true
        } catch (_: Exception) { false }
    }

    fun read(c: Context, name: String): ByteArray? {
        val t = tree(c) ?: return null
        return try {
            val uri = find(c, t, name) ?: return null
            c.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (_: Exception) { null }
    }

    fun delete(c: Context, name: String) {
        val t = tree(c) ?: return
        try {
            val uri = find(c, t, name) ?: return
            DocumentsContract.deleteDocument(c.contentResolver, uri)
        } catch (_: Exception) { }
    }
}
