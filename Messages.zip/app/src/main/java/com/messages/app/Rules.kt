@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class RuleAction(val id: String, val label: String, val argHint: String)

val RULE_ACTIONS = listOf(
    RuleAction("delete", "Auto-delete", "60"),
    RuleAction("mute", "Mute notifications", ""),
    RuleAction("keep", "Never auto-delete", ""),
    RuleAction("forward", "Forward to number", "9876543210")
)

fun ruleActionLabel(r: Rule): String = when (r.action) {
    "delete" -> "Delete after " + r.arg + " min"
    "mute" -> "Silent, no notification"
    "keep" -> "Keep forever"
    "forward" -> "Forward to " + r.arg
    else -> r.action
}

object Rules {
    fun hits(r: Rule, address: String, body: String): Boolean {
        val m = r.match.trim()
        if (m.isEmpty()) return false
        return if (r.kind == "sender") {
            val a = address.uppercase()
            val brand = Brands.of(address)?.name?.uppercase() ?: ""
            a.contains(m.uppercase()) || nk(address).contains(nk(m)) || brand.contains(m.uppercase())
        } else {
            body.contains(m, true)
        }
    }

    fun muted(ctx: Context, address: String, body: String): Boolean =
        Store(ctx).rules.any { it.action == "mute" && hits(it, address, body) }

    fun forwardTarget(ctx: Context, address: String, body: String): String? =
        Store(ctx).rules.firstOrNull { it.action == "forward" && hits(it, address, body) }?.arg?.takeIf { it.isNotBlank() }

    fun kept(ctx: Context, address: String): Boolean =
        Store(ctx).rules.any { it.action == "keep" && hits(it, address, "") }
}

@Composable
fun RulesScreen(vm: MessagesVM, onBack: () -> Unit) {
    val rules by vm.rules.collectAsState()
    var editing by remember { mutableStateOf<Rule?>(null) }
    var adding by remember { mutableStateOf(false) }
    Page("Rules", onBack, actions = {
        IconBtn(Icons.Rounded.Add, A2) { adding = true }
    }) {
        Text(
            "Automations run on the phone. A rule can silence a sender, delete old messages or forward them on.",
            color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp)
        )
        if (rules.isEmpty()) {
            EmptyState(Icons.Rounded.Checklist, "No rules yet", "Tap + to silence a sender or clear out old OTPs")
        } else LazyColumn(contentPadding = PaddingValues(bottom = 26.dp)) {
            items(rules, key = { it.id }) { r ->
                Box(Modifier.animateItemPlacement()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(20.dp)).background(Surf)
                            .bounce(onClick = { editing = r }).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Surf2),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                when (r.action) {
                                    "mute" -> Icons.Rounded.Block
                                    "delete" -> Icons.Rounded.Delete
                                    "forward" -> Icons.Rounded.Forward
                                    else -> Icons.Rounded.Lock
                                },
                                null, tint = A2, modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                (if (r.kind == "sender") "From " else "Mentions ") + r.match,
                                color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(ruleActionLabel(r), color = Dim, fontSize = 13.sp)
                        }
                        Icon(
                            Icons.Rounded.DeleteOutline, null, tint = Dim,
                            modifier = Modifier.size(20.dp).bounce(onClick = { vm.deleteRule(r) })
                        )
                    }
                }
            }
        }

        if (adding || editing != null) {
            RuleDialog(editing, onCancel = { adding = false; editing = null }) { kind, match, action, arg ->
                if (editing == null) vm.saveRule(kind, match, action, arg)
                else vm.updateRule(editing!!.copy(kind = kind, match = match, action = action, arg = arg))
                adding = false
                editing = null
            }
        }
    }
}

@Composable
fun RuleDialog(existing: Rule?, onCancel: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var kind by remember { mutableStateOf(existing?.kind ?: "sender") }
    var match by remember { mutableStateOf(existing?.match ?: "") }
    var action by remember { mutableStateOf(existing?.action ?: "mute") }
    var arg by remember { mutableStateOf(existing?.arg ?: "60") }
    AlertDialog(
        onDismissRequest = onCancel, containerColor = Surf2,
        title = { Text(if (existing == null) "New rule" else "Edit rule", color = Ink) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Sender", kind == "sender") { kind = "sender" }
                    Chip("Message text", kind == "keyword") { kind = "keyword" }
                }
                Spacer(Modifier.height(10.dp))
                InputField(
                    match, { match = it },
                    if (kind == "sender") "Sender — e.g. PAYTM, HDFC, 98765 43210" else "Word — e.g. OTP, offer, salary"
                )
                Spacer(Modifier.height(12.dp))
                Text("THEN", color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RULE_ACTIONS.forEach { a ->
                        Chip(a.label, action == a.id) { action = a.id; arg = a.argHint.ifBlank { arg } }
                    }
                }
                if (action == "delete" || action == "forward") {
                    Spacer(Modifier.height(10.dp))
                    InputField(
                        arg, { arg = it },
                        if (action == "delete") "Minutes before deleting" else "Number to forward to"
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("Runs quietly in the background. Nothing leaves the phone.", color = Dim, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (match.isNotBlank()) onSave(kind, match.trim(), action, arg.trim())
            }) { Text("Save", color = A2, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Dim) } }
    )
}
