package com.messages.app

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/** A person you chat with securely. The phone number lives only here, on this phone. */
class ScContact(
    val id: String, val name: String, val phone: String, val pub: String, val ttl: Int, val last: Long
)

/**
 * out: 0 incoming, 1 outgoing.
 * state, outgoing: 0 sending, 1 sent, 2 delivered, 3 seen, 9 failed.
 * state, incoming: 0 waiting to download, 1 downloading, 2 ready, 9 failed.
 */
class ScMsg(
    val row: Long, val mid: String, val cid: String, val out: Boolean, val kind: String, val body: String,
    val fname: String, val mime: String, val size: Long, val path: String, val remote: String,
    val fkey: String, val state: Int, val ts: Long, val exp: Long, val seen: Boolean
)

/** Everything you have received or sent lives here, on the phone, so chats open with no internet. */
class SecureDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "securechat.db", null, 1) {
    companion object {
        @Volatile private var inst: SecureDb? = null
        fun get(c: Context): SecureDb =
            inst ?: synchronized(this) { inst ?: SecureDb(c.applicationContext).also { inst = it } }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE contacts(id TEXT PRIMARY KEY, name TEXT, phone TEXT, pub TEXT, " +
                "ttl INTEGER DEFAULT 0, last INTEGER DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE msgs(_id INTEGER PRIMARY KEY AUTOINCREMENT, mid TEXT, cid TEXT, dir INTEGER, kind TEXT, " +
                "body TEXT, fname TEXT, mime TEXT, size INTEGER, path TEXT, remote TEXT, fkey TEXT, " +
                "state INTEGER, ts INTEGER, exp INTEGER, seen INTEGER)"
        )
        db.execSQL("CREATE INDEX msgs_cid ON msgs(cid, ts)")
        db.execSQL("CREATE UNIQUE INDEX msgs_mid ON msgs(mid, cid)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) { }

    private fun contactOf(c: Cursor) = ScContact(
        c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getInt(4), c.getLong(5)
    )

    private fun msgOf(c: Cursor) = ScMsg(
        c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getInt(3) == 1, c.getString(4) ?: "text",
        c.getString(5) ?: "", c.getString(6) ?: "", c.getString(7) ?: "", c.getLong(8), c.getString(9) ?: "",
        c.getString(10) ?: "", c.getString(11) ?: "", c.getInt(12), c.getLong(13), c.getLong(14), c.getInt(15) == 1
    )

    private val MSG_COLS = "_id,mid,cid,dir,kind,body,fname,mime,size,path,remote,fkey,state,ts,exp,seen"
    private val CON_COLS = "id,name,phone,pub,ttl,last"

    // ---- contacts
    fun contacts(): List<ScContact> {
        val out = ArrayList<ScContact>()
        readableDatabase.rawQuery("SELECT $CON_COLS FROM contacts ORDER BY last DESC, name", null).use { c ->
            while (c.moveToNext()) out.add(contactOf(c))
        }
        return out
    }

    fun contact(id: String): ScContact? =
        readableDatabase.rawQuery("SELECT $CON_COLS FROM contacts WHERE id=?", arrayOf(id)).use { c ->
            if (c.moveToFirst()) contactOf(c) else null
        }

    fun saveContact(c: ScContact) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO contacts($CON_COLS) VALUES(?,?,?,?,?,?)",
            arrayOf<Any>(c.id, c.name, c.phone, c.pub, c.ttl, c.last)
        )
    }

    fun touch(id: String, ts: Long) {
        writableDatabase.execSQL("UPDATE contacts SET last=? WHERE id=?", arrayOf<Any>(ts, id))
    }

    fun setTtl(id: String, ttl: Int) {
        writableDatabase.execSQL("UPDATE contacts SET ttl=? WHERE id=?", arrayOf<Any>(ttl, id))
    }

    fun contactCount(): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM contacts", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun messageCount(): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM msgs", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun exportContacts(): JSONArray {
        val a = JSONArray()
        for (c in contacts()) {
            a.put(JSONObject().put("id", c.id).put("n", c.name).put("p", c.phone).put("k", c.pub).put("x", c.ttl))
        }
        return a
    }

    fun importContacts(a: JSONArray?) {
        if (a == null) return
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id", "")
            if (id.isEmpty() || contact(id) != null) continue
            saveContact(ScContact(id, o.optString("n", ""), o.optString("p", ""), o.optString("k", ""), o.optInt("x", 0), 0L))
        }
    }

    // ---- messages
    fun addMsg(m: ScMsg): Long =
        writableDatabase.compileStatement(
            "INSERT OR IGNORE INTO msgs(mid,cid,dir,kind,body,fname,mime,size,path,remote,fkey,state,ts,exp,seen) " +
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        ).use { s ->
            s.bindString(1, m.mid); s.bindString(2, m.cid); s.bindLong(3, if (m.out) 1 else 0)
            s.bindString(4, m.kind); s.bindString(5, m.body); s.bindString(6, m.fname); s.bindString(7, m.mime)
            s.bindLong(8, m.size); s.bindString(9, m.path); s.bindString(10, m.remote); s.bindString(11, m.fkey)
            s.bindLong(12, m.state.toLong()); s.bindLong(13, m.ts); s.bindLong(14, m.exp); s.bindLong(15, if (m.seen) 1 else 0)
            s.executeInsert()
        }

    fun msgs(cid: String): List<ScMsg> {
        val out = ArrayList<ScMsg>()
        readableDatabase.rawQuery("SELECT $MSG_COLS FROM msgs WHERE cid=? ORDER BY ts, _id", arrayOf(cid)).use { c ->
            while (c.moveToNext()) out.add(msgOf(c))
        }
        return out
    }

    fun msg(row: Long): ScMsg? =
        readableDatabase.rawQuery("SELECT $MSG_COLS FROM msgs WHERE _id=?", arrayOf(row.toString())).use { c ->
            if (c.moveToFirst()) msgOf(c) else null
        }

    fun msgByMid(cid: String, mid: String): ScMsg? =
        readableDatabase.rawQuery("SELECT $MSG_COLS FROM msgs WHERE cid=? AND mid=?", arrayOf(cid, mid)).use { c ->
            if (c.moveToFirst()) msgOf(c) else null
        }

    fun lastMsg(cid: String): ScMsg? =
        readableDatabase.rawQuery("SELECT $MSG_COLS FROM msgs WHERE cid=? ORDER BY ts DESC, _id DESC LIMIT 1", arrayOf(cid)).use { c ->
            if (c.moveToFirst()) msgOf(c) else null
        }

    fun unread(cid: String): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM msgs WHERE cid=? AND dir=0 AND seen=0", arrayOf(cid)).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }

    fun markSeen(cid: String) {
        writableDatabase.execSQL("UPDATE msgs SET seen=1 WHERE cid=? AND dir=0 AND seen=0", arrayOf<Any>(cid))
    }

    fun setState(row: Long, state: Int) {
        writableDatabase.execSQL("UPDATE msgs SET state=? WHERE _id=?", arrayOf<Any>(state, row))
    }

    /** Only moves an outgoing message forward (sent, delivered, seen), never back. */
    fun raiseState(cid: String, mid: String, state: Int) {
        writableDatabase.execSQL(
            "UPDATE msgs SET state=? WHERE cid=? AND mid=? AND dir=1 AND state<? AND state<>9",
            arrayOf<Any>(state, cid, mid, state)
        )
    }

    fun setFile(row: Long, path: String, state: Int) {
        writableDatabase.execSQL("UPDATE msgs SET path=?, state=? WHERE _id=?", arrayOf<Any>(path, state, row))
    }

    fun setRemote(row: Long, remote: String, fkey: String) {
        writableDatabase.execSQL("UPDATE msgs SET remote=?, fkey=? WHERE _id=?", arrayOf<Any>(remote, fkey, row))
    }

    fun delMsg(row: Long) {
        writableDatabase.execSQL("DELETE FROM msgs WHERE _id=?", arrayOf<Any>(row))
    }

    fun wipe(cid: String) {
        writableDatabase.execSQL("DELETE FROM msgs WHERE cid=?", arrayOf<Any>(cid))
    }

    fun expired(now: Long): List<ScMsg> {
        val out = ArrayList<ScMsg>()
        readableDatabase.rawQuery("SELECT $MSG_COLS FROM msgs WHERE exp>0 AND exp<=?", arrayOf(now.toString())).use { c ->
            while (c.moveToNext()) out.add(msgOf(c))
        }
        return out
    }

    /** Incoming files that still need downloading. */
    fun pendingDownloads(cid: String?): List<ScMsg> {
        val out = ArrayList<ScMsg>()
        val sql = "SELECT $MSG_COLS FROM msgs WHERE dir=0 AND kind<>'text' AND state IN (0,1,9) AND remote<>''" +
            (if (cid != null) " AND cid=?" else "") + " ORDER BY ts"
        readableDatabase.rawQuery(sql, if (cid != null) arrayOf(cid) else null).use { c ->
            while (c.moveToNext()) out.add(msgOf(c))
        }
        return out
    }

    /** Outgoing messages that never made it out. */
    fun unsent(): List<ScMsg> {
        val out = ArrayList<ScMsg>()
        readableDatabase.rawQuery("SELECT $MSG_COLS FROM msgs WHERE dir=1 AND state IN (0,9) ORDER BY ts", null).use { c ->
            while (c.moveToNext()) out.add(msgOf(c))
        }
        return out
    }

    /** Outgoing files uploaded long ago that the other side never collected. */
    fun staleUploads(before: Long): List<ScMsg> {
        val out = ArrayList<ScMsg>()
        readableDatabase.rawQuery(
            "SELECT $MSG_COLS FROM msgs WHERE dir=1 AND kind<>'text' AND remote<>'' AND state=1 AND ts<?",
            arrayOf(before.toString())
        ).use { c -> while (c.moveToNext()) out.add(msgOf(c)) }
        return out
    }
}
