package com.messages.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
private fun TopBar(title: String, onBack: () -> Unit, action: (@Composable () -> Unit)? = null) {
    val p = LocalPal.current
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 6.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBtn(Icons.Rounded.ArrowBack, onBack)
        Text(
            title, color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
        )
        action?.invoke()
    }
}

@Composable
private fun Card2(content: @Composable () -> Unit) {
    val p = LocalPal.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(p.surf)
            .border(1.dp, p.line.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) { content() }
}

@Composable
private fun SettingRow(
    title: String,
    sub: String? = null,
    trailing: @Composable () -> Unit
) {
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = p.dim, fontSize = 11.sp)
        }
        trailing()
    }
}

@Composable
fun SettingsScreen(
    vm: MessagesVM,
    theme: ThemeState,
    onBack: () -> Unit,
    onThemes: () -> Unit,
    onTrash: () -> Unit,
    onStarred: () -> Unit
) {
    val p = LocalPal.current
    val trash by vm.trash.collectAsStateWithLifecycle()
    var starCount by remember { mutableStateOf(vm.store.starred().size) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Settings", onBack)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 16.dp, end = 16.dp, bottom = 40.dp
            )
        ) {
            item {
                SectionLabel("Appearance")
                Card2 {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onThemes() }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            resolvePal(theme).a1,
                                            resolvePal(theme).a2,
                                            resolvePal(theme).a3
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(MIcon.Sparkle, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Theme", color = p.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(
                                "${resolvePal(theme).name} · ${Pals.all.size} themes",
                                color = p.dim, fontSize = 11.sp
                            )
                        }
                        Text("Browse", color = p.a1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("System", theme.mode.value == 0) { theme.mode.value = 0; theme.save() }
                        Pill("Light", theme.mode.value == 1) { theme.mode.value = 1; theme.save() }
                        Pill("Dark", theme.mode.value == 2) { theme.mode.value = 2; theme.save() }
                    }
                }
            }

            item {
                SectionLabel("Bubbles & text")
                Card2 {
                    Text("Bubble shape", color = p.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Round", theme.bubbleStyle.value == 0) { theme.bubbleStyle.value = 0; theme.save() }
                        Pill("Soft", theme.bubbleStyle.value == 1) { theme.bubbleStyle.value = 1; theme.save() }
                        Pill("Square", theme.bubbleStyle.value == 2) { theme.bubbleStyle.value = 2; theme.save() }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "Text size  ${(theme.fontScale.value * 100).toInt()}%",
                        color = p.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Slider(
                        value = theme.fontScale.value,
                        onValueChange = { theme.fontScale.value = it },
                        onValueChangeFinished = { theme.save() },
                        valueRange = 0.85f..1.3f,
                        colors = SliderDefaults.colors(
                            thumbColor = p.a1,
                            activeTrackColor = p.a1,
                            inactiveTrackColor = p.line
                        )
                    )
                }
            }

            item {
                SectionLabel("Motion")
                Card2 {
                    SettingRow("Particle burst", "Messages explode into particles when deleted") {
                        Switch(
                            checked = theme.particles.value,
                            onCheckedChange = { theme.particles.value = it; theme.save() },
                            colors = SwitchDefaults.colors(checkedTrackColor = p.a1)
                        )
                    }
                    SettingRow("Focus blur", "Blur the rest of the chat while holding a message") {
                        Switch(
                            checked = theme.focusBlur.value,
                            onCheckedChange = { theme.focusBlur.value = it; theme.save() },
                            colors = SwitchDefaults.colors(checkedTrackColor = p.a1)
                        )
                    }
                    SettingRow("Animated background", "Slow drifting aurora behind the list") {
                        Switch(
                            checked = theme.animatedBg.value,
                            onCheckedChange = { theme.animatedBg.value = it; theme.save() },
                            colors = SwitchDefaults.colors(checkedTrackColor = p.a1)
                        )
                    }
                    SettingRow("Haptics", "Vibrate on long-press and send") {
                        Switch(
                            checked = theme.haptics.value,
                            onCheckedChange = { theme.haptics.value = it; theme.save() },
                            colors = SwitchDefaults.colors(checkedTrackColor = p.a1)
                        )
                    }
                }
            }

            item {
                SectionLabel("Library")
                Card2 {
                    SettingRow("Starred messages", "$starCount saved") {
                        IconBtn(Icons.Rounded.Star, onStarred, tint = p.a3, size = 20.dp)
                    }
                    SettingRow("Recycle bin", "${trash.size} deleted · auto-clears in 30 days") {
                        IconBtn(MIcon.TrashSweep, onTrash, tint = p.a1, size = 20.dp)
                    }
                    SettingRow("Default SMS app", if (vm.repo.isDefault()) "This app is default" else "Set in system settings") {
                        Icon(
                            Icons.Rounded.Check, null,
                            tint = if (vm.repo.isDefault()) p.a1 else p.dim,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            item {
                SectionLabel("About")
                Card2 {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Info, null, tint = p.dim, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Messages 2.0", color = p.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(
                                "Rebuilt for smooth 60 fps motion, 12 themes, particle delete and a recycle bin.",
                                color = p.dim, fontSize = 11.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
fun ThemeScreen(theme: ThemeState, onBack: () -> Unit) {
    val p = LocalPal.current
    var preview by remember { mutableStateOf(theme.mode.value) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Themes", onBack)
        Row(
            Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Pill("System", preview == 0) { preview = 0; theme.mode.value = 0; theme.save() }
            Pill("Light", preview == 1) { preview = 1; theme.mode.value = 1; theme.save() }
            Pill("Dark", preview == 2) { preview = 2; theme.mode.value = 2; theme.save() }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)
        ) {
            item { SectionLabel("Premium light") }
            items(Pals.light.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { pal ->
                        ThemeCard(
                            pal = pal,
                            selected = theme.lightId.value == pal.id,
                            onClick = { theme.lightId.value = pal.id; theme.mode.value = 1; theme.save() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }
            item { SectionLabel("Premium dark") }
            items(Pals.dark.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { pal ->
                        ThemeCard(
                            pal = pal,
                            selected = theme.darkId.value == pal.id,
                            onClick = { theme.darkId.value = pal.id; theme.mode.value = 2; theme.save() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun ThemeCard(
    pal: Pal,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalPal.current
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(pal.bg)
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) p.a1 else p.line.copy(alpha = 0.5f),
                RoundedCornerShape(18.dp)
            )
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(pal.a1, pal.a2, pal.a3)))
        ) {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(16.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.9f)))
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier
                        .height(8.dp)
                        .width(48.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White.copy(alpha = 0.55f))
                )
            }
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Check, null, tint = pal.a1, modifier = Modifier.size(12.dp))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(pal.name, color = pal.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(
            if (pal.dark) "Dark" else "Light",
            color = pal.ink.copy(alpha = 0.55f), fontSize = 10.sp
        )
    }
}

@Composable
fun TrashScreen(vm: MessagesVM, onBack: () -> Unit) {
    val p = LocalPal.current
    val trash by vm.trash.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        TopBar("Recycle bin", onBack) {
            if (trash.isNotEmpty()) {
                IconBtn(MIcon.TrashSweep, { vm.emptyTrash() }, tint = Color(0xFFFF6B6B))
            }
        }
        if (trash.isEmpty()) {
            EmptyState(
                MIcon.Restore,
                "Recycle bin is empty",
                "Deleted messages stay here for 30 days so you can bring them back."
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)
            ) {
                items(trash, key = { it.msg.id }) { t ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(p.surf)
                            .border(1.dp, p.line.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                vm.repo.nameFor(t.msg.address),
                                color = p.ink, fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                            )
                            val days = ((30L * 24 * 60 * 60 * 1000 - (System.currentTimeMillis() - t.deletedAt)) / (24 * 60 * 60 * 1000L))
                            Text("${days.coerceAtLeast(0)}d left", color = p.dim, fontSize = 10.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(t.msg.body, color = p.dim, fontSize = 13.sp, maxLines = 3)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(p.glass)
                                    .clickable { vm.restore(t) }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(MIcon.Restore, null, tint = p.a1, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Restore", color = p.a1, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(p.glass)
                                    .clickable { vm.deleteForever(t) }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(MIcon.TrashForever, null, tint = Color(0xFFFF6B6B), modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Delete forever", color = Color(0xFFFF6B6B), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StarredScreen(vm: MessagesVM, onBack: () -> Unit, onOpen: (Chat) -> Unit) {
    val p = LocalPal.current
    val convos by vm.convos.collectAsStateWithLifecycle()
    val all by vm.starredMsgs.collectAsStateWithLifecycle()
    androidx.compose.runtime.LaunchedEffect(Unit) { vm.loadStarred() }
    Column(Modifier.fillMaxSize()) {
        TopBar("Starred messages", onBack)
        if (all.isEmpty()) {
            EmptyState(
                MIcon.StarBorder,
                "No starred messages",
                "Long-press any message and tap Star to keep it here."
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)
            ) {
                items(all, key = { it.id }) { m ->
                    val c = convos.firstOrNull { it.threadId == m.threadId }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(p.surf)
                            .border(1.dp, p.line.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                            .clickable {
                                onOpen(
                                    Chat(
                                        m.threadId,
                                        c?.address ?: m.address,
                                        c?.name ?: vm.repo.nameFor(m.address)
                                    )
                                )
                            }
                            .padding(14.dp)
                    ) {
                        Avatar(c?.name ?: m.address, 36.dp, seed = m.address.hashCode())
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    c?.name ?: vm.repo.nameFor(m.address),
                                    color = p.ink, fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                                )
                                Text(listStamp(m.date), color = p.dim, fontSize = 10.sp)
                            }
                            Spacer(Modifier.height(3.dp))
                            Text(m.body, color = p.ink, fontSize = 13.sp, maxLines = 4)
                        }
                        IconBtn(Icons.Rounded.Star, {
                            vm.toggleStar(m.id); vm.loadStarred()
                        }, tint = p.a3, size = 16.dp)
                    }
                }
            }
        }
    }
}
