@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun Page(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).blockTouches().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.ArrowBack) { onBack() }
            Text(title, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            actions()
        }
        content()
    }
}

@Composable
fun SavedRow(vm: MessagesVM, s: Saved, sub: String, onClick: (() -> Unit)?, trailing: @Composable RowScope.() -> Unit) {
    val name = remember(s.address) { vm.repo.name(s.address) }
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.bounce(onClick = onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 4.dp).clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SenderAvatar(s.address, name, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.body, color = Ink, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Dim, fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
fun BinScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val trash by vm.trash.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    Page("Recycle bin", onBack, actions = {
        if (trash.isNotEmpty()) Text("Empty", color = A3, fontWeight = FontWeight.Bold, modifier = Modifier.bounce(onClick = { vm.emptyTrash() }).padding(12.dp))
    }) {
        Text("Deleted messages stay here for 30 days.", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp))
        if (trash.isEmpty()) EmptyState(Icons.Rounded.Delete, "Recycle bin is empty")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(trash.sortedByDescending { it.at }, key = { "${it.id}_${it.at}" }) { s ->
                Box(Modifier.animateItemPlacement()) {
                    SavedRow(vm, s, "Deleted " + fmt(s.at), null) {
                        IconBtn(Icons.Rounded.Restore, A2) {
                            if (isDef) vm.restore(listOf(s)) else Toast.makeText(ctx, "Set as default SMS app to restore", Toast.LENGTH_SHORT).show()
                        }
                        IconBtn(Icons.Rounded.DeleteForever, A3) { vm.purge(s) }
                    }
                }
            }
        }
    }
}

@Composable
fun StarredScreen(vm: MessagesVM, onBack: () -> Unit) {
    val starred by vm.starred.collectAsState()
    Page("Starred messages", onBack) {
        if (starred.isEmpty()) EmptyState(Icons.Rounded.Star, "No starred messages", "Hold a message and tap Star")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(starred.sortedByDescending { it.date }, key = { it.id }) { s ->
                Box(Modifier.animateItemPlacement()) {
                    SavedRow(vm, s, fullDate(s.date), { vm.startChat(s.address) }) {
                        IconBtn(Icons.Rounded.Star, Gold) { vm.unstar(s) }
                    }
                }
            }
        }
    }
}

@Composable
fun ScheduledScreen(vm: MessagesVM, onBack: () -> Unit) {
    val sched by vm.sched.collectAsState()
    Page("Scheduled", onBack) {
        if (sched.isEmpty()) EmptyState(Icons.Rounded.Schedule, "Nothing scheduled", "Use the clock button in a chat to send later")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(sched.sortedBy { it.at }, key = { it.id }) { s ->
                val name = remember(s.address) { vm.repo.name(s.address) }
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (s.kind == "send") Icons.Rounded.Schedule else Icons.Rounded.Alarm, null, tint = A2)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text((if (s.kind == "send") "Send to " else "Remind: ") + name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(s.body, color = Ink, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(fullDate(s.at), color = Dim, fontSize = 12.sp)
                    }
                    IconBtn(Icons.Rounded.Close, A3) { vm.cancelSched(s) }
                }
            }
        }
    }
}

@Composable
fun BlockedScreen(vm: MessagesVM, onBack: () -> Unit) {
    val blocked by vm.blocked.collectAsState()
    Page("Blocked numbers", onBack) {
        Text("Messages from blocked numbers are saved silently, hidden from your list and never notify you. Block numbers from a chat or by holding a conversation.", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp))
        if (blocked.isEmpty()) EmptyState(Icons.Rounded.Block, "No blocked numbers")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(blocked.toList(), key = { it }) { n ->
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(n, 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(n, color = Ink, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text("Unblock", color = A2, fontWeight = FontWeight.Bold, modifier = Modifier.bounce(onClick = { vm.toggleBlock(n) }).padding(8.dp))
                }
            }
        }
    }
}

@Composable
fun ThemeCard(t: AppTheme, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val bw by animateDpAsState(if (sel) 3.dp else 1.dp, tween(250), label = "bw")
    val live = t.name in LIVE_THEMES
    Box(
        modifier.bounce(onClick = onClick).clip(shape).background(t.bg)
            .border(bw, if (sel) t.a2 else t.dim.copy(alpha = 0.32f), shape)
    ) {
        SceneBackground(t.name, t.a1, t.a2, t.a3, t.dark, Modifier.matchParentSize(), still = !MotionOn)
        Column(Modifier.fillMaxWidth().height(158.dp).padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    t.name, color = t.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                if (sel) Icon(Icons.Rounded.CheckCircle, null, tint = t.a2, modifier = Modifier.size(18.dp))
            }
            if (live) {
                Text(
                    "LIVE", color = t.a2, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.4.sp
                )
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.align(Alignment.Start).clip(RoundedCornerShape(14.dp))
                    .background(t.surf2.copy(alpha = 0.90f)).padding(horizontal = 11.dp, vertical = 6.dp)
            ) { Text("Hey there!", color = t.ink, fontSize = 11.sp) }
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.align(Alignment.End).clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(t.a1, t.a2, t.a3)))
                    .padding(horizontal = 11.dp, vertical = 6.dp)
            ) { Text("OTP 482910", color = Color.White, fontSize = 11.sp) }
        }
    }
}

@Composable
fun SettingRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Dim, fontSize = 13.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = A2, checkedThumbColor = Color.White))
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text, color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp,
        modifier = Modifier.padding(start = 6.dp, top = 8.dp)
    )
}

@Composable
fun LinkRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf)
            .bounce(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = A2, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (sub.isNotEmpty()) Text(sub, color = Dim, fontSize = 13.sp)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = Dim, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun SettingsScreen(vm: MessagesVM, onBack: () -> Unit, onVault: () -> Unit = {}) {
    val st by vm.settings.collectAsState()
    val vault by vm.vault.collectAsState()
    val trash by vm.trash.collectAsState()
    val priv by vm.privateSet.collectAsState()
    val ctx = LocalContext.current
    val cur = THEMES[st.theme.coerceIn(0, THEMES.lastIndex)]
    val store = remember { Store(ctx) }
    var voiceName by remember { mutableStateOf(store.ttsVoice) }
    var voiceRate by remember { mutableStateOf(store.ttsRate) }
    var showVoices by remember { mutableStateOf(false) }

    Page("Settings", onBack) {
        LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {

            item {
                val hshape = RoundedCornerShape(26.dp)
                Box(
                    Modifier.fillMaxWidth().height(178.dp).clip(hshape)
                        .border(1.dp, cur.dim.copy(alpha = 0.30f), hshape)
                ) {
                    SceneBackground(cur.name, cur.a1, cur.a2, cur.a3, cur.dark, Modifier.matchParentSize(), still = !st.motion)
                    Column(Modifier.fillMaxSize().padding(18.dp)) {
                        Text(
                            "LIVE THEME", color = cur.a2, fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp
                        )
                        Text(cur.name, color = cur.ink, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.weight(1f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.bounce(onClick = {
                                    val others = (0 until THEMES.size).filter { it != st.theme }
                                    vm.setTheme(others.random())
                                }).clip(RoundedCornerShape(50))
                                    .background(Brush.linearGradient(listOf(cur.a1, cur.a3)))
                                    .padding(horizontal = 16.dp, vertical = 9.dp)
                            ) {
                                Text("Surprise me", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text("Tap a card to blend", color = cur.dim, fontSize = 11.sp)
                        }
                    }
                }
            }

            item { SectionLabel("APPEARANCE") }
            item {
                LinkRow(
                    Icons.Rounded.Palette, "Personalise",
                    "Accent colour, bubble shape, background, typeface, spacing"
                ) { vm.goto.value = "personalise" }
            }
            item {
                LinkRow(
                    Icons.Rounded.Palette, "Theme",
                    cur.name + "  \u00B7  " + THEMES.size + " themes, " + LIVE_THEMES.size + " live"
                ) { vm.goto.value = "themes" }
            }
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Text size", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text("Scales every screen in the app", color = Dim, fontSize = 13.sp)
                        }
                        Text("${(st.textScale * 100).toInt()}%", color = A2, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = st.textScale, onValueChange = { vm.setTextScale(it) },
                        valueRange = 0.85f..1.6f, steps = 14,
                        colors = SliderDefaults.colors(thumbColor = A2, activeTrackColor = A2, inactiveTrackColor = Surf2)
                    )
                    Text(
                        "Aa  Hello, this is how your messages will look.", color = Ink, fontSize = 15.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            item { SettingRow("Elder-friendly mode", "Bigger text and bigger buttons, easier for parents and grandparents", st.elder) { vm.setElder(it) } }
            item { SettingRow("Live motion", "Moving backgrounds and smooth blends. Turn off to save battery", st.motion) { vm.setMotion(it) } }
            item { SettingRow("Follow system light/dark", "Switches between a light and dark theme automatically", st.system) { vm.setSystem(it) } }

            item { SectionLabel("MESSAGES") }
            item { SettingRow("Announce messages aloud", "Speaks the sender and message when headphones or car Bluetooth are connected", st.announce) { vm.setAnnounce(it) } }
            item {
                LinkRow(
                    Icons.Rounded.VolumeUp, "Read aloud voice",
                    if (voiceName.isBlank()) "Best voice on this phone \u00B7 tap to choose male or female"
                    else voiceName.replace("-", " ")
                ) { showVoices = true }
            }
            item { SettingRow("Hide notification text", "Notifications only say New message", st.hideNotif) { vm.setHideNotif(it) } }
            item { SettingRow("Auto-delete old OTPs", "Move one-time-password messages older than 1 day to the Recycle bin", st.autoOtp) { vm.setAutoOtp(it) } }
            item { SettingRow("Haptic feedback", "Gentle vibration on touches", st.haptics) { vm.setHaptics(it) } }

            item { SectionLabel("PRIVACY & SECURITY") }
            item {
                SettingRow(
                    "App lock",
                    "Ask for your fingerprint / PIN when opening Messages and hide it from recent apps",
                    st.lock
                ) { on ->
                    if (on && authIntent(ctx) == null) Toast.makeText(ctx, "Set a screen lock on your phone first", Toast.LENGTH_LONG).show()
                    else vm.setLock(on)
                }
            }
            item {
                LinkRow(
                    Icons.Rounded.Fingerprint, "Saved info vault",
                    if (vault.isEmpty()) "Tickets, IDs, cards and passwords"
                    else vault.size.toString() + if (vault.size == 1) " item behind your fingerprint" else " items behind your fingerprint"
                ) { onVault() }
            }
            item {
                LinkRow(
                    Icons.Rounded.Lock, "Private chats",
                    if (priv.isEmpty()) "Hidden from the list until you unlock"
                    else priv.size.toString() + " hidden conversation" + (if (priv.size == 1) "" else "s")
                ) { vm.goto.value = "private" }
            }

            item { SectionLabel("STORAGE") }
            item {
                LinkRow(
                    Icons.Rounded.Delete, "Recycle bin",
                    if (trash.isEmpty()) "Deleted messages stay 30 days"
                    else trash.size.toString() + " deleted messages, kept 30 days"
                ) { vm.goto.value = "bin" }
            }
            item {
                LinkRow(Icons.Rounded.Backup, "Backup & phone switch", "Save every SMS to a file and restore on a new phone") {
                    vm.goto.value = "backup"
                }
            }
            item {
                LinkRow(Icons.Rounded.Schedule, "Scheduled messages", "Send later and reminders") { vm.goto.value = "sched" }
            }

            item { SectionLabel("ABOUT") }
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Logo(38.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Messages 7.1", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("SMS only \u00B7 nothing leaves your phone", color = Dim, fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Smart OTP copy, scam shield, tickets, vault, laptop companion and 31 live themes. " +
                            "No account, no ads, no analytics.",
                        color = Dim, fontSize = 12.sp
                    )
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
        if (showVoices) {
            VoiceDialog(voiceName, voiceRate, onCancel = { showVoices = false }) { name, rate ->
                store.ttsVoice = name
                store.ttsRate = rate
                voiceName = name
                voiceRate = rate
                showVoices = false
            }
        }
    }
}

/** Pick the voice that reads messages, with a live sample. */
@Composable
fun VoiceDialog(current: String, rate0: Float, onCancel: () -> Unit, onPick: (String, Float) -> Unit) {
    val ctx = LocalContext.current
    var voices by remember { mutableStateOf(emptyList<VoiceInfo>()) }
    var loading by remember { mutableStateOf(true) }
    var sel by remember { mutableStateOf(current) }
    var rate by remember { mutableStateOf(rate0) }
    val sample = "Hello, this is how I will read your messages."
    LaunchedEffect(Unit) {
        Voice.listVoices(ctx) { list ->
            voices = list
            loading = false
        }
    }
    AlertDialog(
        onDismissRequest = onCancel, containerColor = Surf2,
        title = { Text("Read aloud voice", color = Ink) },
        text = {
            Column {
                Text(
                    when {
                        loading -> "Looking for voices on this phone\u2026"
                        voices.isEmpty() -> "This phone has only the default voice installed."
                        else -> voices.size.toString() + " voices found. Tap one to hear it."
                    },
                    color = Dim, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Speed", color = Ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(String.format("%.2f", rate) + "x", color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = rate, onValueChange = { rate = it }, valueRange = 0.7f..1.4f, steps = 6,
                    colors = SliderDefaults.colors(thumbColor = A2, activeTrackColor = A2, inactiveTrackColor = Surf)
                )
                LazyColumn(Modifier.heightIn(max = 280.dp)) {
                    item {
                        Row(
                            Modifier.fillMaxWidth().bounce(onClick = {
                                sel = ""
                                Voice.preview(ctx, sample, "", rate)
                            }).padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Best available", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text("Picks the highest quality voice on this phone", color = Dim, fontSize = 11.sp)
                            }
                            if (sel.isBlank()) Icon(Icons.Rounded.CheckCircle, null, tint = A2, modifier = Modifier.size(18.dp))
                        }
                    }
                    items(voices.size) { i ->
                        val v = voices[i]
                        Row(
                            Modifier.fillMaxWidth().bounce(onClick = {
                                sel = v.name
                                Voice.preview(ctx, sample, v.name, rate)
                            }).padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    v.label, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(v.tag + "  \u00B7  " + v.locale, color = Dim, fontSize = 11.sp)
                            }
                            if (sel == v.name) Icon(Icons.Rounded.CheckCircle, null, tint = A2, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onPick(sel, rate) }) { Text("Use this", color = A2, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Dim) } }
    )
}

class CRow(val key: String, val header: String?, val contact: Contact?)

fun contactRows(list: List<Contact>): List<CRow> {
    val out = ArrayList<CRow>()
    var cur = ""
    for (c in list) {
        val ch = c.name.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar() ?: '#'
        val l = if (ch in 'A'..'Z') ch.toString() else "#"
        if (l != cur) {
            cur = l
            out.add(CRow("h$l", l, null))
        }
        out.add(CRow("c" + nk(c.number), null, c))
    }
    return out
}

/** The A-Z strip on the right edge: touch or slide to jump straight to a letter. */
@Composable
fun AlphabetBar(letters: List<String>, active: String?, modifier: Modifier = Modifier, onLetter: (String) -> Unit, onRelease: () -> Unit) {
    var barH by remember { mutableStateOf(1f) }
    fun pick(y: Float) {
        val n = letters.size
        if (n == 0) return
        val i = ((y / barH) * n).toInt().coerceIn(0, n - 1)
        onLetter(letters[i])
    }
    Column(
        modifier.width(26.dp).fillMaxHeight().padding(vertical = 6.dp)
            .onSizeChanged { barH = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onDragStart = { pick(it.y) },
                    onDragEnd = { onRelease() },
                    onDragCancel = { onRelease() },
                    onVerticalDrag = { ch, _ -> pick(ch.position.y) }
                )
            }
            .pointerInput(letters) {
                detectTapGestures(onPress = { off -> pick(off.y); tryAwaitRelease(); onRelease() })
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEach { l ->
            Text(
                l, color = if (l == active) A2 else Dim,
                fontSize = if (l == active) 13.sp else 10.sp,
                fontWeight = if (l == active) FontWeight.ExtraBold else FontWeight.Bold
            )
        }
    }
}

@Composable
fun NewChatScreen(vm: MessagesVM, title: String, onClose: () -> Unit, onPick: (String, String) -> Unit) {
    var q by remember { mutableStateOf("") }
    var res by remember { mutableStateOf(emptyList<Contact>()) }
    var loadedOnce by remember { mutableStateOf(false) }
    LaunchedEffect(q) {
        delay(120)
        res = withContext(Dispatchers.IO) { vm.repo.contacts(q.trim()) }
        loadedOnce = true
    }
    val rows = remember(res) { contactRows(res) }
    val letters = remember(rows) { rows.mapNotNull { it.header } }
    val indexOf = remember(rows) {
        val m = HashMap<String, Int>()
        rows.forEachIndexed { i, r -> r.header?.let { m[it] = i } }
        m
    }
    val state = rememberLazyListState()
    var active by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    fun jump(l: String) {
        active = l
        val i = indexOf[l] ?: return
        scope.launch { state.scrollToItem(i) }
    }
    Box(Modifier.fillMaxSize().background(Bg).blockTouches()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(start = 18.dp, end = 6.dp)) {
            Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(Icons.Rounded.Close) { onClose() }
                Text(title, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.padding(end = 12.dp)) { SearchField(q, { q = it }, "Search all contacts", autofocus = true) }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.weight(1f)) {
                LazyColumn(state = state, contentPadding = PaddingValues(bottom = 24.dp, end = 26.dp)) {
                    if (q.count { it.isDigit() } >= 3) {
                        item {
                            Row(
                                Modifier.fillMaxWidth().bounce(onClick = { onPick(q.trim(), q.trim()) }).padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(46.dp).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.Send, null, tint = Color.White)
                                }
                                Spacer(Modifier.width(14.dp))
                                Text("Send to ${q.trim()}", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    itemsIndexed(rows, key = { _, r -> r.key }) { i, r ->
                        val h = r.header
                        val c = r.contact
                        if (h != null) {
                            Text(
                                h, color = A2, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(start = 6.dp, top = 16.dp, bottom = 4.dp)
                            )
                        } else if (c != null) {
                            Appear(if (i < 12) i else 0) {
                                Row(
                                    Modifier.fillMaxWidth().bounce(onClick = { onPick(c.number, c.name) }).padding(vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Avatar(c.name, 44.dp)
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(c.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(c.number, color = Dim, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                    if (loadedOnce && res.isEmpty()) {
                        item {
                            Text(
                                "No contacts matched. Type a number to send to a new one.",
                                color = Dim, fontSize = 14.sp, modifier = Modifier.padding(20.dp)
                            )
                        }
                    }
                }
                if (letters.size > 3) {
                    AlphabetBar(
                        letters, active,
                        modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight(),
                        onLetter = { jump(it) },
                        onRelease = { active = null }
                    )
                }
                val bubble by animateFloatAsState(if (active != null) 1f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "ab")
                if (bubble > 0.02f) {
                    Box(
                        Modifier.align(Alignment.Center).graphicsLayer { scaleX = bubble; scaleY = bubble; alpha = bubble.coerceIn(0f, 1f) }
                            .size(76.dp).clip(CircleShape).background(Surf2),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(active ?: "", color = A2, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}

/** Searches every message on the phone, not just the conversation list. */
@Composable
fun highlight(text: String, q: String, color: Color): AnnotatedString {
    if (q.isBlank()) return AnnotatedString(text)
    val out = AnnotatedString.Builder()
    val low = text.lowercase()
    val ql = q.lowercase()
    var i = 0
    while (i < text.length) {
        val j = low.indexOf(ql, i)
        if (j < 0) {
            out.append(text.substring(i))
            break
        }
        out.append(text.substring(i, j))
        out.withStyle(SpanStyle(color = color, fontWeight = FontWeight.Bold)) {
            append(text.substring(j, (j + q.length).coerceAtMost(text.length)))
        }
        i = j + q.length
    }
    return out.toAnnotatedString()
}

@Composable
fun SearchScreen(vm: MessagesVM, onBack: () -> Unit, onOpen: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    var res by remember { mutableStateOf(emptyList<MsgHit>()) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(q) {
        if (q.trim().length < 2) {
            res = emptyList()
            busy = false
            return@LaunchedEffect
        }
        busy = true
        delay(220)
        res = withContext(Dispatchers.IO) { vm.repo.searchAll(q.trim()) }
        busy = false
    }
    Page("Search messages", onBack) {
        Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
            SearchField(q, { q = it }, "Search every message", autofocus = true)
        }
        Text(
            when {
                q.trim().length < 2 -> "Type at least two letters"
                busy -> "Searching…"
                res.isEmpty() -> "No matches"
                else -> res.size.toString() + " matches"
            },
            color = Dim, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp)
        )
        if (res.isEmpty() && q.trim().length >= 2 && !busy) {
            EmptyState(Icons.Rounded.Search, "Nothing found", "Try a shorter word or a number")
        } else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            itemsIndexed(res) { _, h ->
                Row(
                    Modifier.fillMaxWidth().bounce(onClick = { onOpen(h.address) })
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(20.dp)).background(Surf).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SenderAvatar(h.address, h.name, 42.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                h.name, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(fmt(h.date), color = Dim, fontSize = 11.sp)
                        }
                        Text(
                            highlight(h.body, q.trim(), A2), color = Dim, fontSize = 13.sp,
                            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
