@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun Page(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).blockTouches().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.ArrowBack) { onBack() }
            Text(title, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            actions()
        }
        content()
    }
}

@Composable
fun SavedRow(vm: MessagesVM, s: Saved, sub: String, onClick: (() -> Unit)?, trailing: @Composable RowScope.() -> Unit) {
    val name = remember(s.address) { vm.repo.name(s.address) }
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.bounce(onClick = onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 4.dp).clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(name, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.body, color = Ink, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Dim, fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
fun BinScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val trash by vm.trash.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    Page("Recycle bin", onBack, actions = {
        if (trash.isNotEmpty()) Text("Empty", color = A3, fontWeight = FontWeight.Bold, modifier = Modifier.bounce(onClick = { vm.emptyTrash() }).padding(12.dp))
    }) {
        Text("Deleted messages stay here for 30 days.", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp))
        if (trash.isEmpty()) EmptyState(Icons.Rounded.Delete, "Recycle bin is empty")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(trash.sortedByDescending { it.at }, key = { "${it.id}_${it.at}" }) { s ->
                Box(Modifier.animateItemPlacement()) {
                    SavedRow(vm, s, "Deleted " + fmt(s.at), null) {
                        IconBtn(Icons.Rounded.Restore, A2) {
                            if (isDef) vm.restore(listOf(s)) else Toast.makeText(ctx, "Set as default SMS app to restore", Toast.LENGTH_SHORT).show()
                        }
                        IconBtn(Icons.Rounded.DeleteForever, A3) { vm.purge(s) }
                    }
                }
            }
        }
    }
}

@Composable
fun StarredScreen(vm: MessagesVM, onBack: () -> Unit) {
    val starred by vm.starred.collectAsState()
    Page("Starred messages", onBack) {
        if (starred.isEmpty()) EmptyState(Icons.Rounded.Star, "No starred messages", "Hold a message and tap Star")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(starred.sortedByDescending { it.date }, key = { it.id }) { s ->
                Box(Modifier.animateItemPlacement()) {
                    SavedRow(vm, s, fullDate(s.date), { vm.startChat(s.address) }) {
                        IconBtn(Icons.Rounded.Star, Gold) { vm.unstar(s) }
                    }
                }
            }
        }
    }
}

@Composable
fun ScheduledScreen(vm: MessagesVM, onBack: () -> Unit) {
    val sched by vm.sched.collectAsState()
    Page("Scheduled", onBack) {
        if (sched.isEmpty()) EmptyState(Icons.Rounded.Schedule, "Nothing scheduled", "Use the clock button in a chat to send later")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(sched.sortedBy { it.at }, key = { it.id }) { s ->
                val name = remember(s.address) { vm.repo.name(s.address) }
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (s.kind == "send") Icons.Rounded.Schedule else Icons.Rounded.Alarm, null, tint = A2)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text((if (s.kind == "send") "Send to " else "Remind: ") + name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(s.body, color = Ink, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(fullDate(s.at), color = Dim, fontSize = 12.sp)
                    }
                    IconBtn(Icons.Rounded.Close, A3) { vm.cancelSched(s) }
                }
            }
        }
    }
}

@Composable
fun BlockedScreen(vm: MessagesVM, onBack: () -> Unit) {
    val blocked by vm.blocked.collectAsState()
    Page("Blocked numbers", onBack) {
        Text("Messages from blocked numbers are saved silently, hidden from your list and never notify you. Block numbers from a chat or by holding a conversation.", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp))
        if (blocked.isEmpty()) EmptyState(Icons.Rounded.Block, "No blocked numbers")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(blocked.toList(), key = { it }) { n ->
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(n, 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(n, color = Ink, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text("Unblock", color = A2, fontWeight = FontWeight.Bold, modifier = Modifier.bounce(onClick = { vm.toggleBlock(n) }).padding(8.dp))
                }
            }
        }
    }
}

@Composable
fun ThemeCard(t: AppTheme, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val bw by animateDpAsState(if (sel) 3.dp else 1.dp, tween(250), label = "bw")
    Column(modifier.bounce(onClick = onClick).clip(shape).background(t.bg).border(bw, if (sel) t.a2 else t.dim.copy(alpha = 0.35f), shape).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t.name, color = t.ink, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (sel) Icon(Icons.Rounded.CheckCircle, null, tint = t.a2, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.align(Alignment.Start).clip(RoundedCornerShape(14.dp)).background(t.surf2).padding(horizontal = 12.dp, vertical = 7.dp)) { Text("Hey there!", color = t.ink, fontSize = 12.sp) }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.align(Alignment.End).clip(RoundedCornerShape(14.dp)).background(t.brand).padding(horizontal = 12.dp, vertical = 7.dp)) { Text("OTP 482910", color = Color.White, fontSize = 12.sp) }
    }
}

@Composable
fun SettingRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Dim, fontSize = 13.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = A2, checkedThumbColor = Color.White))
    }
}

@Composable
fun SettingsScreen(vm: MessagesVM, onBack: () -> Unit) {
    val st by vm.settings.collectAsState()
    Page("Themes & settings", onBack) {
        LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("THEME", color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
            itemsIndexed(THEMES.chunked(2)) { r, pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    pair.forEachIndexed { c, t -> ThemeCard(t, st.theme == r * 2 + c, Modifier.weight(1f)) { vm.setTheme(r * 2 + c) } }
                    if (pair.size < 2) Spacer(Modifier.weight(1f))
                }
            }
            item { Text("GENERAL", color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
            item { SettingRow("Follow system light/dark", "Switches between a light and dark theme automatically", st.system) { vm.setSystem(it) } }
            item { SettingRow("Haptic feedback", "Gentle vibration on touches", st.haptics) { vm.setHaptics(it) } }
        }
    }
}

@Composable
fun NewChatScreen(vm: MessagesVM, title: String, onClose: () -> Unit, onPick: (String, String) -> Unit) {
    var q by remember { mutableStateOf("") }
    var res by remember { mutableStateOf(emptyList<Contact>()) }
    LaunchedEffect(q) { delay(120); res = withContext(Dispatchers.IO) { vm.repo.contacts(q.trim()) } }
    Column(Modifier.fillMaxSize().background(Bg).blockTouches().statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 18.dp)) {
        Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.Close) { onClose() }
            Text(title, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        SearchField(q, { q = it }, "Type a name or number", autofocus = true)
        Spacer(Modifier.height(12.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            if (q.count { it.isDigit() } >= 3) {
                item {
                    Row(Modifier.fillMaxWidth().bounce(onClick = { onPick(q.trim(), q.trim()) }).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Send, null, tint = Color.White) }
                        Spacer(Modifier.width(14.dp))
                        Text("Send to ${q.trim()}", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            itemsIndexed(res) { i, c ->
                Appear(i) {
                    Row(Modifier.fillMaxWidth().bounce(onClick = { onPick(c.number, c.name) }).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.name, 46.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(c.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text(c.number, color = Dim, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
