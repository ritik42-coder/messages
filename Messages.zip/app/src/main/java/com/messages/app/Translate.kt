package com.messages.app

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

/** On-device translation of an SMS, with script detection so one tap is enough. */
object Translate {
    private val names = mapOf(
        "en" to "English", "hi" to "Hindi", "bn" to "Bengali", "ta" to "Tamil",
        "te" to "Telugu", "kn" to "Kannada", "ml" to "Malayalam", "gu" to "Gujarati",
        "mr" to "Marathi", "pa" to "Punjabi", "or" to "Odia", "ur" to "Urdu"
    )

    fun name(code: String): String = names[code] ?: code

    /** Guesses the language from the script the message is written in. */
    fun detect(text: String): String {
        val count = HashMap<String, Int>()
        for (ch in text) {
            val c = ch.code
            val lang = when (c) {
                in 0x0900..0x097F -> "hi"
                in 0x0980..0x09FF -> "bn"
                in 0x0A00..0x0A7F -> "pa"
                in 0x0A80..0x0AFF -> "gu"
                in 0x0B00..0x0B7F -> "or"
                in 0x0B80..0x0BFF -> "ta"
                in 0x0C00..0x0C7F -> "te"
                in 0x0C80..0x0CFF -> "kn"
                in 0x0D00..0x0D7F -> "ml"
                in 0x0600..0x06FF -> "ur"
                else -> null
            }
            if (lang != null) count[lang] = (count[lang] ?: 0) + 1
        }
        if (count.isEmpty()) return "en"
        return count.maxByOrNull { it.value }?.key ?: "en"
    }

    fun run(text: String, target: String, done: (String?) -> Unit) {
        val src = detect(text)
        if (src == target || text.isBlank()) {
            done(text)
            return
        }
        try {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(target)
                .build()
            val client = Translation.getClient(options)
            client.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    client.translate(text)
                        .addOnSuccessListener { r -> done(r); client.close() }
                        .addOnFailureListener { done(null); client.close() }
                }
                .addOnFailureListener {
                    done(null)
                    client.close()
                }
        } catch (_: Exception) {
            done(null)
        }
    }
}
