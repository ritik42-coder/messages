package com.messages.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

sealed interface Route {
    data object Home : Route
    data class ChatRoute(val chat: Chat) : Route
    data object Settings : Route
    data object Themes : Route
    data object Trash : Route
    data object Starred : Route
    data object NewChat : Route
}

val PERMS: Array<String> = buildList {
    add(Manifest.permission.READ_SMS)
    add(Manifest.permission.SEND_SMS)
    add(Manifest.permission.RECEIVE_SMS)
    add(Manifest.permission.READ_CONTACTS)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

fun hasPerms(ctx: android.content.Context): Boolean =
    PERMS.all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

@Composable
fun Root(vm: MessagesVM, theme: ThemeState) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasPerms(ctx)) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = hasPerms(ctx) }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(PERMS)
    }

    AppTheme(theme) {
        val p = LocalPal.current
        Box(Modifier.fillMaxSize().background(p.bg)) {
            AuroraBackdrop(theme.animatedBg.value)
            if (granted) {
                App(vm, theme)
            } else {
                PermissionGate { launcher.launch(PERMS) }
            }
        }
    }
}

@Composable
fun App(vm: MessagesVM, theme: ThemeState) {
    var route by remember { mutableStateOf<Route>(Route.Home) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(820)
        splash = false
    }

    BackHandler(enabled = route != Route.Home) { route = Route.Home }

    Box(Modifier.fillMaxSize()) {
        Crossfade(targetState = route, animationSpec = tween(230), label = "route") { r ->
            when (r) {
                is Route.Home -> HomeScreen(
                    vm = vm,
                    theme = theme,
                    onOpen = { c -> vm.openChat(c); route = Route.ChatRoute(c) },
                    onSettings = { route = Route.Settings },
                    onNew = { route = Route.NewChat }
                )

                is Route.ChatRoute -> ChatScreen(
                    vm = vm,
                    chat = r.chat,
                    theme = theme,
                    onBack = { vm.closeChat(); route = Route.Home }
                )

                is Route.Settings -> SettingsScreen(
                    vm = vm,
                    theme = theme,
                    onBack = { route = Route.Home },
                    onThemes = { route = Route.Themes },
                    onTrash = { route = Route.Trash },
                    onStarred = { route = Route.Starred }
                )

                is Route.Themes -> ThemeScreen(theme) { route = Route.Settings }

                is Route.Trash -> TrashScreen(vm) { route = Route.Settings }

                is Route.Starred -> StarredScreen(
                    vm = vm,
                    onBack = { route = Route.Settings },
                    onOpen = { c -> vm.openChat(c); route = Route.ChatRoute(c) }
                )

                is Route.NewChat -> NewChatScreen(
                    vm = vm,
                    onBack = { route = Route.Home },
                    onStart = { c -> vm.openChat(c); route = Route.ChatRoute(c) }
                )
            }
        }

        AnimatedVisibility(
            visible = splash,
            enter = fadeIn(tween(120)),
            exit = fadeOut(tween(420))
        ) {
            SplashView()
        }
    }
}

@Composable
private fun SplashView() {
    val p = LocalPal.current
    var popped by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (popped) 1f else 0.7f, tween(520), label = "splash")
    LaunchedEffect(Unit) { popped = true }
    Box(
        Modifier
            .fillMaxSize()
            .background(p.bg),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(p.a1, p.a2, p.a3))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    MIcon.Bubble, null,
                    tint = Color.White,
                    modifier = Modifier.size(42.dp)
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "Messages",
                color = p.ink,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
            Text("smooth · themed · yours", color = p.dim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PermissionGate(onAsk: () -> Unit) {
    val p = LocalPal.current
    Column(
        Modifier
            .fillMaxSize()
            .padding(30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(p.a1, p.a2))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Lock, null, tint = Color.White, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text(
            "Your messages stay on this phone",
            color = p.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Messages needs SMS and contact access to show your conversations. Nothing leaves the device.",
            color = p.dim, fontSize = 13.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        GradientButton("Allow access", onAsk, Modifier.padding(horizontal = 20.dp))
    }
}
