package com.messages.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Base64
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

enum class HandPhase { IDLE, READY, ARMED, HOLDING, SENDING, SENT, INCOMING, RECEIVING, RECEIVED }

/** Where the hand is in the camera, 0..1 (already mirrored to match the on-screen preview). */
class HandPos(val x: Float, val y: Float, val gesture: String)

/**
 * The hand-recognition model (about 8 MB). It is downloaded once, the first time Hand share is opened,
 * and then everything runs on the phone.
 */
object HandModel {
    const val URL_ADDR = "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task"

    fun file(c: Context) = File(File(c.filesDir, "models"), "gesture_recognizer.task")
    fun ready(c: Context): Boolean = file(c).let { it.exists() && it.length() > 4_000_000L }

    fun download(c: Context, onPct: (Int) -> Unit): Boolean {
        val dst = file(c)
        dst.parentFile?.mkdirs()
        val tmp = File(dst.parentFile, "gesture_recognizer.part")
        val conn = try { URL(URL_ADDR).openConnection() as HttpURLConnection } catch (_: Exception) { return false }
        return try {
            conn.connectTimeout = 20_000
            conn.readTimeout = 40_000
            if (conn.responseCode !in 200..299) return false
            val total = conn.contentLengthLong.coerceAtLeast(1L)
            var got = 0L
            conn.inputStream.use { ins ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        onPct((got * 100 / total).toInt().coerceAtMost(99))
                    }
                }
            }
            if (tmp.length() < 4_000_000L) { tmp.delete(); return false }
            if (dst.exists()) dst.delete()
            val ok = tmp.renameTo(dst)
            if (ok) onPct(100)
            ok
        } catch (_: Exception) {
            tmp.delete()
            false
        } finally { conn.disconnect() }
    }
}

/** Watches the front camera and reports "open", "fist", "other" or "none", with the palm position. */
class HandVision(ctx: Context) : ImageAnalysis.Analyzer {
    private var rec: GestureRecognizer? = null
    @Volatile private var closed = false

    init {
        try {
            val bytes = HandModel.file(ctx).readBytes()
            val bb = ByteBuffer.allocateDirect(bytes.size)
            bb.put(bytes)
            bb.rewind()
            val opts = GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(bb).build())
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { res, _ -> onResult(res) }
                .setErrorListener { }
                .build()
            rec = GestureRecognizer.createFromOptions(ctx.applicationContext, opts)
        } catch (_: Throwable) { rec = null }
    }

    val ok: Boolean get() = rec != null

    override fun analyze(image: ImageProxy) {
        val r = rec
        if (r == null || closed) { image.close(); return }
        var bmp: Bitmap? = null
        var rot = 0
        try {
            bmp = image.toBitmap()
            rot = image.imageInfo.rotationDegrees
        } catch (_: Throwable) { }
        image.close()
        val b = bmp ?: return
        try {
            val mp = BitmapImageBuilder(b).build()
            val po = ImageProcessingOptions.builder().setRotationDegrees(rot).build()
            r.recognizeAsync(mp, po, SystemClock.uptimeMillis())
        } catch (_: Throwable) { }
    }

    private fun onResult(res: GestureRecognizerResult) {
        val gs = res.gestures()
        val ls = res.landmarks()
        if (gs.isEmpty() || gs[0].isEmpty()) {
            HandShare.post("none", 0.5f, 0.5f)
            return
        }
        val name = gs[0][0].categoryName()
        val score = gs[0][0].score()
        val g = when {
            score < 0.55f -> "other"
            name == "Open_Palm" -> "open"
            name == "Closed_Fist" -> "fist"
            else -> "other"
        }
        var x = 0.5f
        var y = 0.5f
        if (ls.isNotEmpty() && ls[0].size > 9) {
            x = 1f - ls[0][9].x()
            y = ls[0][9].y()
        }
        HandShare.post(g, x, y)
    }

    fun close() {
        closed = true
        try { rec?.close() } catch (_: Throwable) { }
        rec = null
    }
}

/**
 * Grab a photo with a closing hand on one phone, release it with an opening hand on another.
 * The photo travels phone to phone over Nearby (Bluetooth / Wi-Fi Direct), with no internet and no server.
 */
object HandShare {
    private const val SERVICE = "com.messages.app.hand"
    private val h = Handler(Looper.getMainLooper())

    val phase = MutableStateFlow(HandPhase.IDLE)
    val peers = MutableStateFlow(0)
    val progress = MutableStateFlow(0)
    val status = MutableStateFlow("")
    val hand = MutableStateFlow<HandPos?>(null)
    val outgoing = MutableStateFlow<Bitmap?>(null)
    val incomingThumb = MutableStateFlow<Bitmap?>(null)
    val fromName = MutableStateFlow("")
    val received = MutableStateFlow<String?>(null)
    val events = MutableSharedFlow<String>(extraBufferCapacity = 16)

    private lateinit var app: Context
    private var client: ConnectionsClient? = null
    private var active = false
    private var myId = ""
    private var myName = ""
    private var resumeMesh = false

    private val conn = HashMap<String, String>()          // endpoint -> id
    private val found = HashMap<String, Pair<String, String>>() // endpoint -> (id, name)
    private val connecting = HashSet<String>()

    private var photoFile: File? = null
    private var xfer = ""
    private var holderEp = ""
    private var sendId = 0L
    private var recvId = 0L
    private var recvPayload: Payload? = null
    private var grabAt = 0L
    private var armedAt = 0L
    private var incomingAt = 0L
    private var lastOpenAt = 0L
    private var openRun = 0
    private var fistRun = 0

    private fun ev(s: String) { events.tryEmit(s) }

    private val holdTimeout = Runnable { if (phase.value == HandPhase.HOLDING) release(false) }
    private val incomingTimeout = Runnable {
        if (phase.value == HandPhase.INCOMING) { holderEp = ""; phase.value = baseMode() }
    }
    private val receiveTimeout = Runnable {
        if (phase.value == HandPhase.RECEIVING) {
            recvPayload?.let { client?.cancelPayload(it.id) }
            recvPayload = null
            status.value = "It didn't arrive. Ask them to hold it again."
            phase.value = baseMode()
        }
    }

    private fun baseMode(): HandPhase = if (photoFile != null) HandPhase.READY else HandPhase.IDLE

    // ---------------------------------------------------------------- lifecycle
    fun begin(ctx: Context) {
        if (active) return
        app = ctx.applicationContext
        active = true
        val st = Store(app)
        myId = st.getStr("hand_id").ifEmpty {
            java.util.UUID.randomUUID().toString().replace("-", "").take(8).also { st.putStr("hand_id", it) }
        }
        myName = (Build.MODEL ?: "Phone").replace("|", "").take(16)
        // Mesh and Hand share both use Nearby; run one at a time
        resumeMesh = try { Mesh.running.value } catch (_: Throwable) { false }
        if (resumeMesh) try { Mesh.stop() } catch (_: Throwable) { }
        val c = Nearby.getConnectionsClient(app)
        client = c
        c.startAdvertising("$myName|$myId", SERVICE, lifecycle, AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
            .addOnSuccessListener { status.value = "Looking for phones nearby" }
            .addOnFailureListener { status.value = "Can't start: " + (it.message ?: "error") }
        c.startDiscovery(SERVICE, discovery, DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
            .addOnFailureListener { status.value = "Can't scan: " + (it.message ?: "error") }
    }

    fun end() {
        if (!active) return
        active = false
        h.removeCallbacks(holdTimeout); h.removeCallbacks(incomingTimeout); h.removeCallbacks(receiveTimeout)
        try { client?.stopAdvertising() } catch (_: Throwable) { }
        try { client?.stopDiscovery() } catch (_: Throwable) { }
        try { client?.stopAllEndpoints() } catch (_: Throwable) { }
        conn.clear(); found.clear(); connecting.clear()
        peers.value = 0
        clearPhoto()
        incomingThumb.value = null
        received.value = null
        hand.value = null
        phase.value = HandPhase.IDLE
        if (resumeMesh) try { Mesh.start() } catch (_: Throwable) { }
        resumeMesh = false
    }

    // ---------------------------------------------------------------- photo to send
    private fun decode(ctx: Context, uri: android.net.Uri, max: Int): Bitmap? {
        return try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var s = 1
            while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: return null
            val ori = try {
                android.media.ExifInterface(ByteArrayInputStream(bytes))
                    .getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)
            } catch (_: Exception) { android.media.ExifInterface.ORIENTATION_NORMAL }
            val deg = when (ori) {
                android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            val big = maxOf(bmp.width, bmp.height)
            if (big > max) {
                val f = max.toFloat() / big
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt().coerceAtLeast(1), (bmp.height * f).toInt().coerceAtLeast(1), true)
            }
            bmp
        } catch (_: Throwable) { null }
    }

    /** Call off the main thread. Prepares the picture that will travel. */
    fun setPhoto(ctx: Context, uri: android.net.Uri): Boolean {
        val bmp = decode(ctx, uri, 2560) ?: return false
        return try {
            val f = File(ctx.cacheDir, "hand_out.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            photoFile = f
            val preview = if (maxOf(bmp.width, bmp.height) > 1080) {
                val s = 1080f / maxOf(bmp.width, bmp.height)
                Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            } else bmp
            outgoing.value = preview
            h.post {
                if (phase.value == HandPhase.IDLE || phase.value == HandPhase.READY) phase.value = HandPhase.READY
            }
            true
        } catch (_: Throwable) { false }
    }

    fun clearPhoto() {
        photoFile?.delete()
        photoFile = null
        outgoing.value = null
        h.post { if (phase.value == HandPhase.READY || phase.value == HandPhase.ARMED) phase.value = HandPhase.IDLE }
    }

    // ---------------------------------------------------------------- gestures
    /** Called from the camera thread. */
    fun post(g: String, x: Float, y: Float) { h.post { onFrame(g, x, y) } }

    private fun onFrame(g: String, x: Float, y: Float) {
        if (!active) return
        val now = SystemClock.uptimeMillis()
        hand.value = if (g == "none") null else HandPos(x, y, g)
        openRun = if (g == "open") openRun + 1 else 0
        fistRun = if (g == "fist") fistRun + 1 else 0
        if (openRun >= 3) lastOpenAt = now
        when (phase.value) {
            HandPhase.READY -> if (openRun >= 3) {
                phase.value = HandPhase.ARMED
                armedAt = now
                ev("arm")
            }
            HandPhase.ARMED -> when {
                fistRun >= 3 && now - lastOpenAt < 4000L -> grab()
                openRun >= 3 -> armedAt = now
                now - armedAt > 6000L -> phase.value = HandPhase.READY
            }
            HandPhase.HOLDING -> if (openRun >= 4 && now - grabAt > 1500L) release(true)
            HandPhase.INCOMING -> if (openRun >= 3 && now - incomingAt > 450L) want()
            else -> { }
        }
    }

    // ---------------------------------------------------------------- sender side
    private fun send(ep: String?, o: JSONObject) {
        val bytes = o.toString().toByteArray(Charsets.UTF_8)
        if (ep == null) conn.keys.forEach { client?.sendPayload(it, Payload.fromBytes(bytes)) }
        else client?.sendPayload(ep, Payload.fromBytes(bytes))
    }

    private fun thumbB64(): String {
        val b = outgoing.value ?: return ""
        return try {
            val s = 72f / maxOf(b.width, b.height)
            val t = Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true)
            val out = ByteArrayOutputStream()
            t.compress(Bitmap.CompressFormat.JPEG, 55, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (_: Throwable) { "" }
    }

    private fun grab() {
        if (photoFile == null) return
        xfer = java.util.UUID.randomUUID().toString().take(8)
        grabAt = SystemClock.uptimeMillis()
        phase.value = HandPhase.HOLDING
        status.value = ""
        ev("grab")
        send(null, JSONObject().put("t", "hold").put("x", xfer).put("n", myName).put("th", thumbB64()))
        h.removeCallbacks(holdTimeout)
        h.postDelayed(holdTimeout, 14_000L)
    }

    private fun release(returned: Boolean) {
        h.removeCallbacks(holdTimeout)
        send(null, JSONObject().put("t", "drop").put("x", xfer))
        xfer = ""
        phase.value = baseMode()
        ev(if (returned) "return" else "expire")
    }

    private fun serve(ep: String) {
        val f = photoFile ?: return
        h.removeCallbacks(holdTimeout)
        phase.value = HandPhase.SENDING
        progress.value = 0
        ev("send")
        try {
            val p = Payload.fromFile(f)
            sendId = p.id
            client?.sendPayload(ep, p)
        } catch (_: Throwable) {
            status.value = "Couldn't send. Try again."
            phase.value = baseMode()
        }
    }

    // ---------------------------------------------------------------- receiver side
    private fun want() {
        if (holderEp.isEmpty()) return
        h.removeCallbacks(incomingTimeout)
        phase.value = HandPhase.RECEIVING
        progress.value = 0
        ev("want")
        send(holderEp, JSONObject().put("t", "want").put("x", xfer))
        h.removeCallbacks(receiveTimeout)
        h.postDelayed(receiveTimeout, 25_000L)
    }

    private fun finishReceive(p: Payload) {
        Thread {
            try {
                val dir = File(app.filesDir, "hand")
                dir.mkdirs()
                val name = "HandShare_" + System.currentTimeMillis() + ".jpg"
                val dst = File(dir, name)
                val f = p.asFile()
                val uri = f?.asUri()
                if (uri != null) app.contentResolver.openInputStream(uri)?.use { ins -> FileOutputStream(dst).use { ins.copyTo(it) } }
                else f?.asJavaFile()?.let { src -> src.inputStream().use { ins -> FileOutputStream(dst).use { ins.copyTo(it) } } }
                if (!dst.exists() || dst.length() == 0L) throw IllegalStateException("empty")
                saveToGallery(app, dst, name)
                h.post {
                    h.removeCallbacks(receiveTimeout)
                    received.value = dst.absolutePath
                    phase.value = HandPhase.RECEIVED
                    ev("got")
                }
            } catch (_: Throwable) {
                h.post {
                    h.removeCallbacks(receiveTimeout)
                    status.value = "The photo didn't arrive. Try again."
                    phase.value = baseMode()
                }
            }
        }.start()
    }

    private fun saveToGallery(ctx: Context, src: File, name: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Hand Share")
                }
                val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                if (u != null) ctx.contentResolver.openOutputStream(u)?.use { out -> src.inputStream().use { it.copyTo(out) } }
            }
        } catch (_: Throwable) { }
    }

    /** Dismiss the "got it" card. */
    fun dismissReceived() {
        received.value = null
        incomingThumb.value = null
        phase.value = baseMode()
    }

    /** Dismiss the "sent" card. */
    fun dismissSent() {
        clearPhoto()
        phase.value = HandPhase.IDLE
    }

    // ---------------------------------------------------------------- nearby plumbing
    private fun parse(s: String): Pair<String, String> {
        val i = s.lastIndexOf('|')
        return if (i < 0) s to s else s.substring(0, i) to s.substring(i + 1)
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(ep: String, info: DiscoveredEndpointInfo) {
            val (name, id) = parse(info.endpointName)
            if (id == myId) return
            found[ep] = id to name
            // one side asks, the other accepts
            if (myId > id && ep !in conn && ep !in connecting) {
                connecting.add(ep)
                client?.requestConnection("$myName|$myId", ep, lifecycle)?.addOnFailureListener { connecting.remove(ep) }
            }
        }
        override fun onEndpointLost(ep: String) { found.remove(ep) }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(ep: String, info: ConnectionInfo) {
            val (name, id) = parse(info.endpointName)
            found[ep] = id to name
            connecting.add(ep)
            client?.acceptConnection(ep, payloadCb)
        }
        override fun onConnectionResult(ep: String, r: ConnectionResolution) {
            connecting.remove(ep)
            if (r.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                conn[ep] = found[ep]?.first ?: ep
                peers.value = conn.size
                status.value = "Connected to " + (found[ep]?.second ?: "a phone")
                // a late joiner should still see a photo that is being held right now
                if (phase.value == HandPhase.HOLDING) {
                    send(ep, JSONObject().put("t", "hold").put("x", xfer).put("n", myName).put("th", thumbB64()))
                }
            }
        }
        override fun onDisconnected(ep: String) {
            conn.remove(ep); connecting.remove(ep)
            peers.value = conn.size
        }
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(ep: String, p: Payload) {
            when (p.type) {
                Payload.Type.BYTES -> p.asBytes()?.let { handle(ep, String(it, Charsets.UTF_8)) }
                Payload.Type.FILE -> {
                    // only the photo we asked for, from the phone that was holding it
                    if (phase.value == HandPhase.RECEIVING && ep == holderEp) {
                        recvId = p.id
                        recvPayload = p
                    } else client?.cancelPayload(p.id)
                }
                else -> { }
            }
        }

        override fun onPayloadTransferUpdate(ep: String, u: PayloadTransferUpdate) {
            val pct = if (u.totalBytes > 0) (u.bytesTransferred * 100 / u.totalBytes).toInt() else 0
            if (u.payloadId == sendId && sendId != 0L) {
                progress.value = pct
                when (u.status) {
                    PayloadTransferUpdate.Status.SUCCESS -> {
                        sendId = 0L
                        phase.value = HandPhase.SENT
                        progress.value = 100
                        ev("sent")
                    }
                    PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                        sendId = 0L
                        status.value = "Couldn't send. Try again."
                        phase.value = baseMode()
                    }
                    else -> { }
                }
            } else if (u.payloadId == recvId && recvId != 0L) {
                progress.value = pct
                when (u.status) {
                    PayloadTransferUpdate.Status.SUCCESS -> {
                        val p = recvPayload
                        recvId = 0L
                        recvPayload = null
                        if (p != null) finishReceive(p)
                    }
                    PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                        recvId = 0L
                        recvPayload = null
                        h.removeCallbacks(receiveTimeout)
                        status.value = "The photo didn't arrive. Try again."
                        phase.value = baseMode()
                    }
                    else -> { }
                }
            }
        }
    }

    private fun handle(ep: String, text: String) {
        try {
            val o = JSONObject(text)
            when (o.optString("t")) {
                "hold" -> {
                    val p = phase.value
                    if (p == HandPhase.HOLDING || p == HandPhase.SENDING || p == HandPhase.RECEIVING) return
                    xfer = o.optString("x")
                    holderEp = ep
                    fromName.value = o.optString("n", "A phone")
                    incomingThumb.value = try {
                        val b = Base64.decode(o.optString("th"), Base64.NO_WRAP)
                        if (b.isEmpty()) null else BitmapFactory.decodeByteArray(b, 0, b.size)
                    } catch (_: Throwable) { null }
                    incomingAt = SystemClock.uptimeMillis()
                    openRun = 0
                    phase.value = HandPhase.INCOMING
                    ev("incoming")
                    h.removeCallbacks(incomingTimeout)
                    h.postDelayed(incomingTimeout, 15_000L)
                }
                "drop" -> if (phase.value == HandPhase.INCOMING && o.optString("x") == xfer) {
                    h.removeCallbacks(incomingTimeout)
                    holderEp = ""
                    phase.value = baseMode()
                }
                "want" -> if (phase.value == HandPhase.HOLDING && o.optString("x") == xfer) serve(ep)
            }
        } catch (_: Throwable) { }
    }
}
