package com.messages.app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.security.AlgorithmParameters
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPublicKeySpec
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * All the cryptography for Secure Chat, using only standard Android/JCA primitives:
 *  - identity: an ECDH P-256 key pair per install
 *  - messages: a fresh ephemeral key per message mixed with the sender's own key, HKDF-SHA256, AES-256-GCM
 *  - files: a random AES-256 key per file, encrypted in 1 MB authenticated chunks (so servers see only noise)
 */
object SecureCrypto {
    private val rnd = SecureRandom()
    private const val CHUNK = 1 shl 20

    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    fun unb64(s: String): ByteArray = Base64.decode(s, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

    fun random(n: Int): ByteArray {
        val b = ByteArray(n)
        rnd.nextBytes(b)
        return b
    }

    fun hex(b: ByteArray): String {
        val sb = StringBuilder()
        for (x in b) sb.append(String.format("%02x", x))
        return sb.toString()
    }

    fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data)
    }

    /** HKDF-SHA256, one output block (32 bytes). */
    fun hkdf(ikm: ByteArray, salt: ByteArray, info: String): ByteArray {
        val prk = hmac(if (salt.isEmpty()) ByteArray(32) else salt, ikm)
        return hmac(prk, info.toByteArray(Charsets.UTF_8) + byteArrayOf(1))
    }

    // ---------------------------------------------------------------- keys
    private val curve: ECParameterSpec by lazy {
        val ap = AlgorithmParameters.getInstance("EC")
        ap.init(ECGenParameterSpec("secp256r1"))
        ap.getParameterSpec(ECParameterSpec::class.java)
    }
    private val P = BigInteger("ffffffff00000001000000000000000000000000ffffffffffffffffffffffff", 16)
    private val B = BigInteger("5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b", 16)

    class Keys(val priv: ByteArray, val pub: ByteArray)

    fun newKeys(): Keys {
        val g = KeyPairGenerator.getInstance("EC")
        g.initialize(ECGenParameterSpec("secp256r1"))
        val kp = g.generateKeyPair()
        return Keys(kp.private.encoded, rawPub(kp.public as ECPublicKey))
    }

    private fun fix32(v: BigInteger): ByteArray {
        val b = v.toByteArray()
        val out = ByteArray(32)
        if (b.size >= 32) System.arraycopy(b, b.size - 32, out, 0, 32)
        else System.arraycopy(b, 0, out, 32 - b.size, b.size)
        return out
    }

    private fun rawPub(k: ECPublicKey): ByteArray = byteArrayOf(4) + fix32(k.w.affineX) + fix32(k.w.affineY)

    /** Rebuilds a public key from its 65-byte form, refusing anything that is not a real point on the curve. */
    fun pubFromRaw(raw: ByteArray): PublicKey? {
        if (raw.size != 65 || raw[0].toInt() != 4) return null
        val x = BigInteger(1, raw.copyOfRange(1, 33))
        val y = BigInteger(1, raw.copyOfRange(33, 65))
        if (x >= P || y >= P) return null
        val lhs = y.multiply(y).mod(P)
        val rhs = x.multiply(x).multiply(x).subtract(x.multiply(BigInteger.valueOf(3))).add(B).mod(P)
        if (lhs != rhs) return null
        return try {
            KeyFactory.getInstance("EC").generatePublic(ECPublicKeySpec(ECPoint(x, y), curve))
        } catch (_: Exception) { null }
    }

    fun privFromBytes(b: ByteArray): PrivateKey = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(b))

    /** A short stable id for a public key. This is what Firebase sees, never a phone number. */
    fun idOf(pubRaw: ByteArray): String = hex(sha256(pubRaw)).substring(0, 32)

    /** The hidden sign-in password, derived from the private key so a restored key signs into the same account. */
    fun authSecret(priv: ByteArray): String = b64(hkdf(priv, "sc1-auth-salt".toByteArray(), "SC1-auth"))

    private fun ecdh(priv: PrivateKey, pub: PublicKey): ByteArray {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(priv)
        ka.doPhase(pub, true)
        return ka.generateSecret()
    }

    // ---------------------------------------------------------------- messages
    class Sealed(val eph: String, val salt: String, val iv: String, val ct: String)

    private fun gcm(mode: Int, key: ByteArray, iv: ByteArray, aad: ByteArray): Cipher {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        c.updateAAD(aad)
        return c
    }

    fun seal(myPriv: ByteArray, myId: String, toId: String, toPubRaw: ByteArray, plain: ByteArray): Sealed? {
        return try {
            val toPub = pubFromRaw(toPubRaw) ?: return null
            val g = KeyPairGenerator.getInstance("EC")
            g.initialize(ECGenParameterSpec("secp256r1"))
            val eph = g.generateKeyPair()
            val s1 = ecdh(eph.private, toPub)
            val s2 = ecdh(privFromBytes(myPriv), toPub)
            val salt = random(16)
            val key = hkdf(s1 + s2, salt, "SC1-msg")
            val iv = random(12)
            val ct = gcm(Cipher.ENCRYPT_MODE, key, iv, "$myId>$toId".toByteArray()).doFinal(plain)
            Sealed(b64(rawPub(eph.public as ECPublicKey)), b64(salt), b64(iv), b64(ct))
        } catch (_: Exception) { null }
    }

    fun open(myPriv: ByteArray, myId: String, fromId: String, fromPubRaw: ByteArray, s: Sealed): ByteArray? {
        return try {
            val ephPub = pubFromRaw(unb64(s.eph)) ?: return null
            val fromPub = pubFromRaw(fromPubRaw) ?: return null
            val priv = privFromBytes(myPriv)
            val key = hkdf(ecdh(priv, ephPub) + ecdh(priv, fromPub), unb64(s.salt), "SC1-msg")
            gcm(Cipher.DECRYPT_MODE, key, unb64(s.iv), "$fromId>$myId".toByteArray()).doFinal(unb64(s.ct))
        } catch (_: Exception) { null }
    }

    // ---------------------------------------------------------------- files (chunked AES-GCM)
    private fun readFully(ins: InputStream, buf: ByteArray, len: Int = buf.size): Int {
        var n = 0
        while (n < len) {
            val r = ins.read(buf, n, len - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun aad(idx: Int, end: Boolean): ByteArray =
        byteArrayOf((idx shr 24).toByte(), (idx shr 16).toByte(), (idx shr 8).toByte(), idx.toByte(), if (end) 1 else 0)

    private fun int4(v: Int): ByteArray = byteArrayOf((v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())

    private fun writeChunk(out: OutputStream, key: ByteArray, idx: Int, end: Boolean, buf: ByteArray, n: Int) {
        val iv = random(12)
        val ct = gcm(Cipher.ENCRYPT_MODE, key, iv, aad(idx, end)).doFinal(buf, 0, n)
        out.write(int4(ct.size))
        out.write(iv)
        out.write(ct)
    }

    fun encryptFile(src: File, dst: File, key: ByteArray, onBytes: (Long) -> Unit = {}) {
        FileInputStream(src).use { ins ->
            FileOutputStream(dst).use { out ->
                val buf = ByteArray(CHUNK)
                var idx = 0
                var done = 0L
                while (true) {
                    val n = readFully(ins, buf)
                    if (n <= 0) break
                    writeChunk(out, key, idx, false, buf, n)
                    idx++
                    done += n
                    onBytes(done)
                    if (n < buf.size) break
                }
                // a sealed end marker, so a truncated download can never pass as complete
                writeChunk(out, key, idx, true, buf, 0)
            }
        }
    }

    /** Returns true only if every chunk verified and the end marker was present. */
    fun decryptFile(src: File, dst: File, key: ByteArray): Boolean {
        return try {
            var sawEnd = false
            FileInputStream(src).use { ins ->
                FileOutputStream(dst).use { out ->
                    var idx = 0
                    val head = ByteArray(4)
                    val iv = ByteArray(12)
                    while (!sawEnd) {
                        val h = readFully(ins, head)
                        if (h == 0) break
                        if (h < 4) throw IllegalStateException("short")
                        val len = ((head[0].toInt() and 0xFF) shl 24) or ((head[1].toInt() and 0xFF) shl 16) or
                            ((head[2].toInt() and 0xFF) shl 8) or (head[3].toInt() and 0xFF)
                        if (len < 16 || len > CHUNK + 16) throw IllegalStateException("size")
                        if (readFully(ins, iv) < 12) throw IllegalStateException("iv")
                        val ct = ByteArray(len)
                        if (readFully(ins, ct) < len) throw IllegalStateException("ct")
                        var plain: ByteArray? = null
                        try {
                            plain = gcm(Cipher.DECRYPT_MODE, key, iv, aad(idx, false)).doFinal(ct)
                        } catch (_: Exception) {
                            gcm(Cipher.DECRYPT_MODE, key, iv, aad(idx, true)).doFinal(ct)
                            sawEnd = true
                        }
                        if (plain != null) out.write(plain)
                        idx++
                    }
                }
            }
            sawEnd
        } catch (_: Exception) { false }
    }

    // ---------------------------------------------------------------- key wrapping with the phone's keystore
    private const val WRAP_ALIAS = "sc_wrap"

    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(WRAP_ALIAS, null)
        if (existing is SecretKey) return existing
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(WRAP_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return g.generateKey()
    }

    fun wrap(plain: ByteArray): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, wrapKey())
        return b64(c.iv + c.doFinal(plain))
    }

    fun unwrap(s: String): ByteArray? {
        return try {
            val b = unb64(s)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, wrapKey(), GCMParameterSpec(128, b.copyOfRange(0, 12)))
            c.doFinal(b, 12, b.size - 12)
        } catch (_: Exception) { null }
    }
}
