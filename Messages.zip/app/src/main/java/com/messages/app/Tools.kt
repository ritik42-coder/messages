@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.provider.Telephony
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ==================== broadcast lists ====================
@Composable
fun BroadcastScreen(vm: MessagesVM, onBack: () -> Unit) {
    val lists by vm.broadcasts.collectAsState()
    var adding by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf<Broadcast?>(null) }
    Page("Broadcast lists", onBack, actions = {
        IconBtn(Icons.Rounded.Add, A2) { adding = true }
    }) {
        Text(
            "Send one message to everyone in a list. Each person gets their own SMS, so replies stay private.",
            color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp)
        )
        if (lists.isEmpty()) {
            EmptyState(Icons.Rounded.Groups, "No lists yet", "Tap + to group the people you text together")
        } else LazyColumn(contentPadding = PaddingValues(bottom = 26.dp)) {
            items(lists, key = { it.id }) { b ->
                Box(Modifier.animateItemPlacement()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(22.dp)).background(Surf).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                                .background(Brush.linearGradient(listOf(A1, A3))),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.Groups, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(b.name, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                b.numbers.size.toString() + if (b.numbers.size == 1) " person" else " people",
                                color = Dim, fontSize = 13.sp
                            )
                        }
                        Box(
                            Modifier.bounce(onClick = { sending = b }).clip(RoundedCornerShape(50))
                                .background(Brand).padding(horizontal = 14.dp, vertical = 8.dp)
                        ) { Text("Send", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            Icons.Rounded.DeleteOutline, null, tint = Dim,
                            modifier = Modifier.size(20.dp).bounce(onClick = { vm.deleteBroadcast(b.id) })
                        )
                    }
                }
            }
        }

        if (adding) {
            BroadcastDialog(vm, null, onCancel = { adding = false }) { name, nums ->
                vm.saveBroadcast(name, nums)
                adding = false
            }
        }
        sending?.let { b ->
            SendBroadcastDialog(b, onCancel = { sending = null }) { text ->
                vm.sendBroadcast(b, text)
                sending = null
            }
        }
    }
}

@Composable
fun BroadcastDialog(
    vm: MessagesVM, existing: Broadcast?, onCancel: () -> Unit,
    onSave: (String, List<String>) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var q by remember { mutableStateOf("") }
    var res by remember { mutableStateOf(emptyList<Contact>()) }
    val sel = remember { mutableStateListOf<String>() }
    LaunchedEffect(Unit) { existing?.numbers?.let { sel.addAll(it) } }
    LaunchedEffect(q) {
        delay(150)
        res = withContext(Dispatchers.IO) { vm.repo.contacts(q.trim()) }
    }
    AlertDialog(
        onDismissRequest = onCancel, containerColor = Surf2,
        title = { Text("New broadcast list", color = Ink) },
        text = {
            Column {
                InputField(name, { name = it }, "List name — e.g. RWA notices")
                Spacer(Modifier.height(8.dp))
                InputField(q, { q = it }, "Search contacts")
                Spacer(Modifier.height(6.dp))
                Text(sel.size.toString() + " selected", color = A2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyColumn(Modifier.heightIn(max = 300.dp)) {
                    items(res.take(80), key = { nk(it.number) }) { c ->
                        val on = sel.any { nk(it) == nk(c.number) }
                        Row(
                            Modifier.fillMaxWidth().bounce(onClick = {
                                if (on) sel.removeAll { nk(it) == nk(c.number) } else sel.add(c.number)
                            }).padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(c.name, 34.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.name, color = Ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(c.number, color = Dim, fontSize = 12.sp)
                            }
                            if (on) Icon(Icons.Rounded.CheckCircle, null, tint = A2, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank() && sel.isNotEmpty()) onSave(name.trim(), sel.toList())
            }) { Text("Save", color = A2, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Dim) } }
    )
}

@Composable
fun SendBroadcastDialog(b: Broadcast, onCancel: () -> Unit, onSend: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel, containerColor = Surf2,
        title = { Text("Send to " + b.name, color = Ink) },
        text = {
            Column {
                Text(b.numbers.size.toString() + " people will each get a separate SMS.", color = Dim, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                InputField(text, { text = it }, "Your message", single = false)
            }
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onSend(text.trim()) }) {
                Text("Send", color = A2, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Dim) } }
    )
}

// ==================== OTP history ====================
class OtpEntry(val code: String, val from: String, val at: Long)

object OtpLog {
    fun scan(ctx: Context, days: Int = 30): List<OtpEntry> {
        val since = System.currentTimeMillis() - days * 86_400_000L
        val out = ArrayList<OtpEntry>()
        try {
            ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf("address", "body", "date"), "date > ?", arrayOf(since.toString()), "date DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 300) {
                    val b = c.getString(1) ?: continue
                    val code = Otp.find(b) ?: continue
                    out.add(OtpEntry(code, c.getString(0) ?: "", c.getLong(2)))
                }
            }
        } catch (_: Exception) { }
        return out
    }
}

@Composable
fun OtpHistoryScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var list by remember { mutableStateOf(emptyList<OtpEntry>()) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { list = withContext(Dispatchers.IO) { OtpLog.scan(ctx) } }
    val shown = remember(list, q) {
        if (q.isBlank()) list
        else list.filter { it.code.contains(q) || it.from.contains(q, true) || vm.repo.name(it.from).contains(q, true) }
    }
    Page("OTP history", onBack) {
        Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
            SearchField(q, { q = it }, "Search codes or senders")
        }
        Text(
            "Last 30 days \u00B7 " + list.size + " codes",
            color = Dim, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp)
        )
        if (shown.isEmpty()) EmptyState(Icons.Rounded.Lock, "No codes found", "OTPs you receive will be listed here")
        else LazyColumn(contentPadding = PaddingValues(bottom = 26.dp)) {
            items(shown.size) { i ->
                val e = shown[i]
                var tick by remember(e.at) { mutableStateOf(false) }
                LaunchedEffect(tick) { if (tick) { delay(1200); tick = false } }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(20.dp)).background(Surf)
                        .bounce(onClick = { clip.setText(AnnotatedString(e.code)); tick = true }).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            e.code, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 3.sp, fontFamily = FontFamily.Monospace
                        )
                        Text(
                            vm.repo.name(e.from) + "  \u00B7  " + fmt(e.at),
                            color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Icon(
                        if (tick) Icons.Rounded.Check else Icons.Rounded.ContentCopy, null,
                        tint = if (tick) A2 else Dim, modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

// ==================== emergency SOS ====================
private fun lastLocationLink(ctx: Context): String? {
    if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
    ) return null
    return try {
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        val loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)
        loc?.let { "https://maps.google.com/?q=" + it.latitude + "," + it.longitude }
    } catch (_: Exception) { null }
}

@Composable
fun SosScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val contacts by vm.sos.collectAsState()
    val store = remember { Store(ctx) }
    var adding by remember { mutableStateOf(false) }
    var sent by remember { mutableStateOf(false) }
    val p = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    fun fire() {
        if (contacts.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            val link = lastLocationLink(ctx)
            val msg = "SOS \u2014 I need help." + (if (link != null) " My location: " + link else " Please call me.")
            for (n in contacts) vm.repo.send(n, msg)
            withContext(Dispatchers.Main) { sent = true }
        }
    }

    Page("Emergency SOS", onBack, actions = {
        IconBtn(Icons.Rounded.Add, A2) { adding = true }
    }) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Hold the button for three seconds and everyone on your list gets an SMS with your location. Works without internet.",
                color = Dim, fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 10.dp)
            )
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.size(200.dp).pointerInput(contacts) {
                    detectTapGestures(onPress = {
                        if (contacts.isEmpty()) return@detectTapGestures
                        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                        }
                        val job = scope.launch { p.animateTo(1f, tween(3000, easing = LinearEasing)) }
                        tryAwaitRelease()
                        job.cancel()
                        if (p.value >= 0.97f) {
                            fire()
                        } else {
                            scope.launch { p.animateTo(0f, tween(220)) }
                        }
                    })
                },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 10.dp.toPx()
                    val r = size.minDimension / 2f - stroke
                    drawCircle(Color(0xFF2A2A3D), radius = r, center = center, style = Stroke(width = stroke))
                    if (p.value > 0.001f) {
                        drawArc(
                            brush = Brush.sweepGradient(listOf(A1, A2, A3, A1)),
                            startAngle = -90f, sweepAngle = 360f * p.value, useCenter = false,
                            topLeft = Offset(center.x - r, center.y - r),
                            size = androidx.compose.ui.geometry.Size(r * 2f, r * 2f),
                            style = Stroke(width = stroke, cap = StrokeCap.Round)
                        )
                    }
                }
                val fill = if (contacts.isEmpty()) {
                    Modifier.background(Surf2)
                } else {
                    Modifier.background(Brush.radialGradient(listOf(Color(0xFFE53935), Color(0xFFB71C1C))))
                }
                Box(
                    Modifier.size(150.dp).clip(CircleShape).then(fill),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SOS", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                        Text(
                            if (contacts.isEmpty()) "add a contact" else "hold 3s",
                            color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            if (sent) {
                Text("SOS sent to " + contacts.size + " contacts", color = A2, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                LaunchedEffect(sent) { delay(4000); sent = false }
            }
            Spacer(Modifier.height(10.dp))
            SectionLabel("YOUR PEOPLE")
            if (contacts.isEmpty()) {
                Text("Nobody yet. Tap + to add the numbers who should hear from you.", color = Dim, fontSize = 13.sp)
            } else Column(Modifier.fillMaxWidth()) {
                contacts.forEach { n ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(vm.repo.name(n), 38.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(vm.repo.name(n), color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(n, color = Dim, fontSize = 12.sp)
                        }
                        Icon(
                            Icons.Rounded.Close, null, tint = Dim,
                            modifier = Modifier.size(18.dp).bounce(onClick = { vm.saveSos(contacts - n) })
                        )
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text(
                "Your location is only read at the moment you send.",
                color = Dim, fontSize = 11.sp, modifier = Modifier.padding(bottom = 14.dp)
            )
        }

        if (adding) {
            var q by remember { mutableStateOf("") }
            var res by remember { mutableStateOf(emptyList<Contact>()) }
            LaunchedEffect(q) { delay(150); res = withContext(Dispatchers.IO) { vm.repo.contacts(q.trim()) } }
            AlertDialog(
                onDismissRequest = { adding = false }, containerColor = Surf2,
                title = { Text("Add a contact", color = Ink) },
                text = {
                    Column {
                        InputField(q, { q = it }, "Search contacts")
                        Spacer(Modifier.height(6.dp))
                        LazyColumn(Modifier.heightIn(max = 320.dp)) {
                            items(res.take(80), key = { nk(it.number) }) { c ->
                                Row(
                                    Modifier.fillMaxWidth().bounce(onClick = {
                                        vm.saveSos(contacts + c.number)
                                        adding = false
                                    }).padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Avatar(c.name, 34.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(c.name, color = Ink, fontSize = 14.sp)
                                        Text(c.number, color = Dim, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { adding = false }) { Text("Close", color = Dim) } }
            )
        }
    }
}
