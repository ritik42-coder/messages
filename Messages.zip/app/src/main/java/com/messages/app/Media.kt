@file:OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import kotlin.math.abs

// ---------- clickable links inside message text ----------
val LINK_RE = Regex(
    "(https?://\\S+|www\\.\\S+|[\\w.+-]+@[\\w-]+\\.[\\w.-]+|(?<!\\d)\\+?\\d[\\d -]{8,13}\\d(?!\\d))",
    RegexOption.IGNORE_CASE
)

fun linkify(body: String, linkColor: Color): AnnotatedString = buildAnnotatedString {
    append(body)
    for (r in LINK_RE.findAll(body)) {
        val s = r.value.trimEnd('.', ',', ')', ';', '!', '?')
        if (s.isEmpty()) continue
        val target = when {
            s.startsWith("http", true) -> s
            s.startsWith("www.", true) -> "https://$s"
            s.contains('@') -> "mailto:$s"
            else -> "tel:" + s.filter { it.isDigit() || it == '+' }
        }
        val a = r.range.first
        addStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline, fontWeight = FontWeight.SemiBold), a, a + s.length)
        addStringAnnotation("link", target, a, a + s.length)
    }
}

@Composable
fun LinkText(body: String, color: Color, linkColor: Color, onTap: () -> Unit, onLong: () -> Unit, risky: Boolean = false) {
    val ctx = LocalContext.current
    val h = LocalHapticFeedback.current
    val ann = remember(body, linkColor) { linkify(body, linkColor) }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    var pending by remember { mutableStateOf<String?>(null) }
    Text(
        ann, color = color, fontSize = 16.sp, onTextLayout = { layout = it },
        modifier = Modifier.pointerInput(ann) {
            detectTapGestures(
                onLongPress = { if (HapticsOn) h.performHapticFeedback(HapticFeedbackType.LongPress); onLong() },
                onTap = { pos ->
                    val off = layout?.getOffsetForPosition(pos)
                    val link = off?.let { o -> ann.getStringAnnotations("link", o, o).firstOrNull()?.item }
                    if (link != null) {
                        if (risky && !link.startsWith("tel:")) pending = link
                        else runCatching {
                            ctx.startActivity(Intent(if (link.startsWith("tel:")) Intent.ACTION_DIAL else Intent.ACTION_VIEW, Uri.parse(link)))
                        }
                    } else onTap()
                }
            )
        }
    )
    pending?.let { link ->
        AlertDialog(
            onDismissRequest = { pending = null }, containerColor = Surf2,
            title = { Text("This looks like a scam", color = Color(0xFFFF3B30)) },
            text = { Text("Don't open links or enter passwords, OTPs or card details from messages like this.\n\n$link", color = Dim) },
            confirmButton = { TextButton(onClick = { pending = null }) { Text("Stay safe", color = A2) } },
            dismissButton = { TextButton(onClick = { pending = null; runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) } }) { Text("Open anyway", color = Dim) } }
        )
    }
}

// ---------- pictures ----------
object Thumbs {
    private val cache = android.util.LruCache<String, ImageBitmap>(24)
    fun get(path: String, max: Int): ImageBitmap? {
        val key = "$path@$max"
        cache.get(key)?.let { return it }
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
            val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
            val ib = bmp.asImageBitmap()
            cache.put(key, ib)
            return ib
        } catch (_: Exception) { return null }
    }
}

@Composable
fun ImageThumb(path: String, full: Boolean = false) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { Thumbs.get(path, if (full) 1600 else 600) }
    }
    val b = bmp
    if (full) {
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
    } else {
        Box(Modifier.size(width = 220.dp, height = 170.dp).clip(RoundedCornerShape(18.dp)).background(Surf), contentAlignment = Alignment.Center) {
            if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Rounded.Image, null, tint = Dim)
        }
    }
}

// ---------- voice ----------
@Suppress("DEPRECATION")
class Recorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    fun start(): Boolean = try {
        val f = File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.amr")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
        r.setOutputFile(f.absolutePath)
        r.prepare(); r.start()
        rec = r; file = f
        true
    } catch (_: Exception) { false }

    fun stop(): File? {
        val r = rec ?: return null
        rec = null
        return try { r.stop(); r.release(); file } catch (_: Exception) { try { r.release() } catch (_: Exception) { }; null }
    }

    fun cancel() {
        if (rec != null) { stop(); file?.delete() }
    }
}

object Player {
    val playing = MutableStateFlow<String?>(null)
    private var mp: MediaPlayer? = null
    fun stop() {
        try { mp?.stop() } catch (_: Exception) { }
        try { mp?.release() } catch (_: Exception) { }
        mp = null; playing.value = null
    }
    fun toggle(path: String) {
        if (playing.value == path) { stop(); return }
        stop()
        try {
            val m = MediaPlayer()
            m.setDataSource(path); m.prepare()
            m.setOnCompletionListener { stop() }
            m.start()
            mp = m; playing.value = path
        } catch (_: Exception) { }
    }
}

@Composable
fun VoiceBubble(path: String, outgoing: Boolean) {
    val playing by Player.playing.collectAsState()
    val on = playing == path
    val t = rememberInfiniteTransition(label = "vb")
    val ph by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "ph")
    val c = if (outgoing) Color.White else A2
    Row(Modifier.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).bounce(onClick = { Player.toggle(path) }).clip(CircleShape)
                .background(if (outgoing) Color.White.copy(alpha = 0.25f) else Surf),
            contentAlignment = Alignment.Center
        ) { Icon(if (on) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = c) }
        Spacer(Modifier.width(10.dp))
        Canvas(Modifier.width(120.dp).height(28.dp)) {
            val n = 20
            val w = size.width / n
            for (i in 0 until n) {
                val base = 0.3f + 0.5f * abs(sin(i * 1.7f + (path.hashCode() % 7)))
                val h = size.height * (if (on) 0.25f + 0.7f * abs(sin(ph + i * 0.5f)) else base)
                drawRoundRect(c.copy(alpha = if (on) 1f else 0.6f), Offset(i * w + w * 0.2f, (size.height - h) / 2f), Size(w * 0.6f, h), CornerRadius(w))
            }
        }
    }
}

@Composable
fun RecordBar(secs: Int, onCancel: () -> Unit, onSend: () -> Unit) {
    val t = rememberInfiniteTransition(label = "rec")
    val pulse by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "pulse")
    val ph by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "rph")
    Row(
        Modifier.fillMaxWidth().padding(10.dp).clip(RoundedCornerShape(30.dp)).background(Surf).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBtn(Icons.Rounded.Delete, A3) { onCancel() }
        Box(Modifier.size(12.dp).graphicsLayer { alpha = pulse }.clip(CircleShape).background(Color(0xFFFF3B30)))
        Spacer(Modifier.width(10.dp))
        Text("%d:%02d".format(secs / 60, secs % 60), color = Ink, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(12.dp))
        Canvas(Modifier.weight(1f).height(32.dp)) {
            val n = 22
            val w = size.width / n
            for (i in 0 until n) {
                val h = size.height * (0.25f + 0.65f * abs(sin(ph + i * 0.6f)))
                drawRoundRect(A2, Offset(i * w + w * 0.2f, (size.height - h) / 2f), Size(w * 0.6f, h), CornerRadius(w))
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.size(46.dp).bounce(onClick = onSend).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Send, null, tint = Color.White)
        }
    }
}

// ---------- emoji ----------
val EMOJI: List<List<String>> = listOf(
    ("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😛 😜 🤪 🤗 🤔 😐 😑 😶 🙄 😏 😴 😪 😷 🤒 🥵 🥶 😎 🤓 😕 😟 🙁 😮 😲 😳 🥺 😢 😭 😤 😡 🤬 😱 😨 🤯 🥳 😌 😬 🤤 😈 💀 🤡 👻 🤖").split(" "),
    ("👍 👎 👏 🙌 🙏 💪 ✌️ 🤞 👌 🤝 👋 ✋ 🤙 👊 ✊ 🤟 🤘 👈 👉 👆 👇 ☝️ ✍️ 🤳 💅 🙋 🤷 🤦 🙇 💃 🕺 🚶 🏃 👀 👅 👄 🧠").split(" "),
    ("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 💕 💖 💗 💘 💝 💯 🔥 ✨ ⭐ 🌟 🎉 🎊 ✅ ❌ ⚠️ ❓ ❗ 💥 💫 💤 🎯 🏆 🥇 💎 🔔 📌").split(" "),
    ("🎂 🎁 🍕 🍔 🍟 🍿 🍩 🍫 ☕ 🍵 🍻 🍷 ⚽ 🏏 🏀 🎮 🎵 🎧 📱 💻 📷 📚 ✏️ 💡 💰 🚗 🏍️ ✈️ 🚀 🏠 🌙 ☀️ 🌈 ☔ ❄️ 🌸 🌹 🐶 🐱 🐼 🦁 🐒").split(" ")
)

@Composable
fun EmojiPanel(onPick: (String) -> Unit) {
    var cat by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth().height(270.dp).background(Surf).padding(top = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            EMOJI.forEachIndexed { i, l ->
                val a by animateFloatAsState(if (cat == i) 1f else 0.45f, tween(200), label = "ca")
                Text(l[0], fontSize = 24.sp, modifier = Modifier.bounce(onClick = { cat = i }).graphicsLayer { alpha = a }.padding(horizontal = 14.dp, vertical = 6.dp))
            }
        }
        LazyVerticalGrid(columns = GridCells.Fixed(8), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
            items(EMOJI[cat]) { e ->
                Text(e, fontSize = 26.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().bounce(onClick = { onPick(e) }).padding(vertical = 8.dp))
            }
        }
    }
}
