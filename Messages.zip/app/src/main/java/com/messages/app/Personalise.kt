@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PersonaliseScreen(vm: MessagesVM, onBack: () -> Unit) {
    Page("Personalise", onBack) {
        LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            // live preview
            item {
                val r = Look.radius.dp
                val tail = if (Look.radius > 14) 6.dp else (Look.radius / 2).dp
                val inShape = RoundedCornerShape(r, r, r, tail)
                val outShape = RoundedCornerShape(r, r, tail, r)
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Bg)
                        .border(1.dp, Dim.copy(alpha = 0.25f), RoundedCornerShape(24.dp)).padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar("Anish", 34.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Anish", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("Preview", color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.clip(inShape)
                            .background(if (Look.glass) Surf2.copy(alpha = 0.55f) else Surf2, inShape)
                            .then(
                                if (Look.glass) Modifier.border(1.dp, Dim.copy(alpha = 0.35f), inShape) else Modifier
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            "Your messages will look like this.", color = Ink, fontSize = 15.sp,
                            fontFamily = Look.family
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier.align(Alignment.End).clip(outShape)
                            .background(Brand, outShape)
                            .then(
                                if (Look.glass) Modifier.border(1.dp, Color.White.copy(alpha = 0.3f), outShape) else Modifier
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text("Perfect.", color = Color.White, fontSize = 15.sp, fontFamily = Look.family)
                    }
                }
            }

            // accent
            item {
                Column {
                    SectionLabel("ACCENT COLOUR")
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AccentDot(-1) { vm.setAccentHue(-1) }
                        listOf(0, 25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 325).forEach { h ->
                            AccentDot(h) { vm.setAccentHue(h) }
                        }
                    }
                    Text(
                        if (Look.hue < 0) "Using the theme's own colours" else "Overriding every gradient in the app",
                        color = Dim, fontSize = 12.sp
                    )
                }
            }

            // bubble shape
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Bubble roundness", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(Look.radius.toString() + "dp", color = A2, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = Look.radius.toFloat(), onValueChange = { vm.setBubbleRadius(it.toInt()) },
                        valueRange = 8f..30f, steps = 21,
                        colors = SliderDefaults.colors(thumbColor = A2, activeTrackColor = A2, inactiveTrackColor = Surf2)
                    )
                }
            }

            item {
                ChoiceRow("Bubble style", listOf("Filled", "Glass"), if (Look.glass) 1 else 0) {
                    vm.setBubbleGlass(it == 1)
                }
            }
            item {
                ChoiceRow("Chat background", listOf("None", "Dots", "Grid", "Waves"), Look.pattern) {
                    vm.setChatPattern(it)
                }
            }
            item {
                ChoiceRow("Typeface", listOf("System", "Serif", "Mono"), Look.font) { vm.setFontFamily(it) }
            }
            item {
                ChoiceRow("Row spacing", listOf("Compact", "Normal", "Roomy"), Look.density) { vm.setDensity(it) }
            }
            item {
                ChoiceRow("Avatars", listOf("Circle", "Rounded"), Look.avatar) { vm.setAvatarShape(it) }
            }

            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf)
                        .bounce(onClick = {
                            vm.setAccentHue(-1)
                            vm.setBubbleRadius(22)
                            vm.setBubbleGlass(false)
                            vm.setChatPattern(0)
                            vm.setFontFamily(0)
                            vm.setDensity(1)
                            vm.setAvatarShape(0)
                        }).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Restore, null, tint = A3, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Reset to the theme's defaults", color = A3, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun AccentDot(hue: Int, onClick: () -> Unit) {
    val on = Look.hue == hue
    val brush = if (hue < 0) Brand else Brush.linearGradient(
        listOf(
            Color.hsv(hue.toFloat(), 0.66f, 0.98f),
            Color.hsv(((hue + 40) % 360).toFloat(), 0.80f, 0.86f)
        )
    )
    Box(
        Modifier.size(38.dp).clip(CircleShape).background(brush)
            .then(if (on) Modifier.border(3.dp, Ink, CircleShape) else Modifier)
            .bounce(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (hue < 0) Icon(Icons.Rounded.Palette, null, tint = Color.White, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun ChoiceRow(title: String, options: List<String>, selected: Int, onPick: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.width(112.dp)
        )
        Row(
            Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEachIndexed { i, label ->
                Box(
                    Modifier.bounce(onClick = { onPick(i) }).clip(RoundedCornerShape(50))
                        .background(if (selected == i) A1 else Surf2)
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(
                        label, color = if (selected == i) Color.White else Dim,
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
