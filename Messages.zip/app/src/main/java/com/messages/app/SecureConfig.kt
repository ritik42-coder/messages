package com.messages.app

/**
 * Settings for the online Secure Chat. This is the ONLY place that knows about the servers.
 * SMS code never reads this file and never touches the network.
 *
 * Firebase values are the public web config of the shared project (safe to ship).
 * Supabase values are the same project, key and bucket BharatChat already uses; our files stay inside the securechat/ folder.
 */
object SecureConfig {
    const val FB_NAME = "securechat"
    const val FB_API_KEY = "AIzaSyAOBY17jm7dg3KveDmSI6Y6Ui8RqbQ_7k8"
    const val FB_APP_ID = "1:389655524565:web:801a3b898e537a9eef9e5c"
    const val FB_PROJECT = "bharatchat-d37fa"
    const val FB_DB = "https://bharatchat-d37fa-default-rtdb.asia-southeast1.firebasedatabase.app"

    /** Everything we write in Realtime Database lives under this one node, away from BharatChat's data. */
    const val ROOT = "securechat_v1"

    const val SB_URL = "https://qliqlkcsjuzrmaxixbgw.supabase.co"
    const val SB_KEY = "sb_publishable_RO8W0tWgKsI52OPQXjjAdA_xHI__Wi_"   // public client key, same as BharatChat uses
    const val SB_BUCKET = "images"                     // the bucket BharatChat already uses
    const val SB_PREFIX = "securechat/"                // our files live only inside this folder

    fun storageReady(): Boolean =
        !SB_URL.startsWith("PASTE") && !SB_KEY.startsWith("PASTE") && !SB_BUCKET.startsWith("PASTE")
}
