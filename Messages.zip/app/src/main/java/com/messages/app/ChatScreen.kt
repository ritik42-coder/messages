package com.messages.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlin.math.abs

private sealed interface RowItem {
    data class Day(val t: Long) : RowItem
    data class Bubble(val m: Msg) : RowItem
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(
    vm: MessagesVM,
    chat: Chat,
    theme: ThemeState,
    onBack: () -> Unit
) {
    val p = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val all by vm.msgs.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val listState = rememberLazyListState()

    var selection by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var focusId by remember { mutableStateOf<Long?>(null) }
    var sheetFor by remember { mutableStateOf<Msg?>(null) }
    var forwardOf by remember { mutableStateOf<List<Msg>>(emptyList()) }
    var infoFor by remember { mutableStateOf<Msg?>(null) }
    var replyTo by remember { mutableStateOf<Msg?>(null) }
    var input by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var burstTick by remember { mutableIntStateOf(0) }
    var burstAt by remember { mutableStateOf(Offset.Zero) }
    var overlayPos by remember { mutableStateOf(Offset.Zero) }

    val selecting = selection.isNotEmpty()
    var starredIds by remember { mutableStateOf(vm.store.starred()) }
    var pinnedIds by remember { mutableStateOf(vm.store.pinned()) }
    var reactionMap by remember { mutableStateOf(vm.store.reactions()) }
    var refreshTick by remember { mutableIntStateOf(0) }

    val rows = remember(all, deleting, refreshTick) {
        val out = ArrayList<RowItem>()
        var lastDay = 0L
        all.forEach { m ->
            if (!sameDay(m.date, lastDay)) {
                out.add(RowItem.Day(m.date))
                lastDay = m.date
            }
            out.add(RowItem.Bubble(m))
        }
        out
    }

    LaunchedEffect(all.size) {
        if (all.isNotEmpty()) listState.animateScrollToItem((rows.size - 1).coerceAtLeast(0))
    }

    fun doDelete(list: List<Msg>, origin: Offset) {
        if (list.isEmpty()) return
        if (theme.particles.value) {
            burstAt = origin
            burstTick += 1
        }
        if (theme.haptics.value) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        deleting = deleting + list.map { it.id }
        scope.launch {
            kotlinx.coroutines.delay(260)
            list.forEach { vm.trashMsg(it) }
            deleting = deleting - list.map { it.id }.toSet()
            selection = emptySet()
            val res = snackbar.showSnackbar(
                message = if (list.size == 1) "Message moved to Recycle Bin" else "${list.size} messages moved",
                actionLabel = "UNDO",
                withDismissAction = true
            )
            if (res == SnackbarResult.ActionPerformed) {
                list.forEach { m -> vm.restore(TrashItem(m, System.currentTimeMillis())) }
            }
        }
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        // ---------------------------------------------------------- top bar
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selecting) {
                IconBtn(Icons.Rounded.Close, { selection = emptySet() })
                Text(
                    "${selection.size}",
                    color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                IconBtn(MIcon.Copy, {
                    vm.copy(selection.mapNotNull { id -> all.firstOrNull { it.id == id }?.body }.joinToString("\n"))
                    scope.launch { snackbar.showSnackbar("Copied ${selection.size} message(s)") }
                    selection = emptySet()
                })
                IconBtn(MIcon.Forward, {
                    forwardOf = all.filter { selection.contains(it.id) }
                })
                IconBtn(Icons.Rounded.Star, {
                    selection.forEach { vm.toggleStar(it) }
                    starredIds = vm.store.starred()
                    scope.launch { snackbar.showSnackbar("Starred") }
                    selection = emptySet()
                })
                IconBtn(Icons.Rounded.Share, {
                    val text = selection.mapNotNull { id -> all.firstOrNull { it.id == id }?.body }.joinToString("\n")
                    shareText(vm, text)
                    selection = emptySet()
                })
                IconBtn(Icons.Rounded.Delete, {
                    doDelete(all.filter { selection.contains(it.id) }, burstAt)
                }, tint = Color(0xFFFF6B6B))
            } else {
                IconBtn(Icons.Rounded.ArrowBack, onBack)
                Avatar(chat.name, 40.dp, seed = chat.address.hashCode())
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        chat.name, color = p.ink, fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 1
                    )
                    Text(chat.address, color = p.dim, fontSize = 11.sp, maxLines = 1)
                }
                IconBtn(Icons.Rounded.Search, onClick = {
                    scope.launch { snackbar.showSnackbar("Search inside chat is on the home screen") }
                })
                IconBtn(Icons.Rounded.MoreVert, onClick = {
                    if (all.isNotEmpty()) sheetFor = all.last()
                })
            }
        }

        // ---------------------------------------------------------- pinned strip
        val pinnedList = all.filter { pinnedIds.contains(it.id) }
        AnimatedVisibility(visible = pinnedList.isNotEmpty()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.glass)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(MIcon.Pin, null, tint = p.a1, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("PINNED", color = p.a1, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Text(
                    pinnedList.last().body, color = p.ink, fontSize = 12.sp, maxLines = 2,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // ---------------------------------------------------------- messages
        Box(Modifier.weight(1f)) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .onGloballyPositioned { overlayPos = it.positionInWindow() },
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 12.dp, end = 12.dp, top = 10.dp, bottom = 14.dp
                )
            ) {
                items(rows, key = { r ->
                    when (r) {
                        is RowItem.Day -> "d${r.t}"
                        is RowItem.Bubble -> "m${r.m.id}"
                    }
                }) { r ->
                    when (r) {
                        is RowItem.Day -> DayDivider(r.t)
                        is RowItem.Bubble -> {
                            val m = r.m
                            val focused = focusId == m.id
                            val blurred = focusId != null && !focused
                            val isSel = selection.contains(m.id)
                            androidx.compose.animation.AnimatedVisibility(
                                visible = !deleting.contains(m.id),
                                modifier = Modifier,
                                enter = fadeIn(tween(180)) + scaleIn(tween(180), initialScale = 0.9f),
                                exit = fadeOut(tween(180)) + shrinkVertically(tween(220))
                            ) {
                                BubbleRow(
                                    m = m,
                                    theme = theme,
                                    focused = focused,
                                    blurred = blurred,
                                    selected = isSel,
                                    selecting = selecting,
                                    starred = starredIds.contains(m.id),
                                    pinned = pinnedIds.contains(m.id),
                                    reaction = reactionMap[m.id],
                                    onLongPress = {
                                        if (theme.haptics.value) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        if (selecting) {
                                            selection = if (isSel) selection - m.id else selection + m.id
                                        } else {
                                            focusId = m.id
                                            sheetFor = m
                                        }
                                    },
                                    onTap = {
                                        if (selecting) {
                                            selection = if (isSel) selection - m.id else selection + m.id
                                        }
                                    },
                                    onDoubleTap = {
                                        vm.react(m.id, if (reactionMap[m.id] == "\u2764\uFE0F") null else "\u2764\uFE0F")
                                        reactionMap = vm.store.reactions()
                                        if (theme.haptics.value) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    },
                                    onSwipeReply = { replyTo = m },
                                    onPositioned = { win ->
                                        burstAt = Offset(
                                            win.x - overlayPos.x + 40f,
                                            win.y - overlayPos.y + 30f
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }

            ParticleBurst(
                trigger = burstTick,
                origin = burstAt,
                modifier = Modifier.matchParentSize()
            )

            SnackbarHost(
                hostState = snackbar,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(12.dp)
            )
        }

        // ---------------------------------------------------------- composer
        AnimatedVisibility(visible = replyTo != null) {
            val r = replyTo
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.glass)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .width(3.dp)
                        .height(28.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(p.brand)
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (r?.outgoing == true) "You" else chat.name,
                        color = p.a1, fontSize = 11.sp, fontWeight = FontWeight.Bold
                    )
                    Text(r?.body ?: "", color = p.dim, fontSize = 12.sp, maxLines = 1)
                }
                IconBtn(Icons.Rounded.Close, { replyTo = null }, size = 16.dp)
            }
        }

        val otp = remember(all.size) {
            all.lastOrNull { !it.outgoing }?.let { looksLikeOtp(it.body) }
        }
        AnimatedVisibility(visible = otp != null && input.isEmpty()) {
            Box(Modifier.padding(start = 14.dp, bottom = 6.dp)) {
                Pill("Copy OTP $otp", false) {
                    vm.copy(otp ?: "")
                    scope.launch { snackbar.showSnackbar("OTP copied") }
                }
            }
        }

        Composer(
            value = input,
            onValueChange = { input = it },
            onSend = {
                val text = if (replyTo != null) "\u21B3 ${replyTo!!.body.take(60)}\n$input" else input
                vm.send(text, chat)
                input = ""
                replyTo = null
                scope.launch {
                    kotlinx.coroutines.delay(120)
                    if (rows.isNotEmpty()) listState.animateScrollToItem((rows.size - 1).coerceAtLeast(0))
                }
            },
            haptics = theme.haptics.value
        )
    }

    // ---------------------------------------------------------- action sheet
    val target = sheetFor
    if (target != null) {
        ModalBottomSheet(
            onDismissRequest = { sheetFor = null; focusId = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = p.surf,
            scrimColor = if (focusId != null) Color.Transparent else Color.Black.copy(alpha = 0.4f)
        ) {
            MessageActions(
                m = target,
                isStarred = starredIds.contains(target.id),
                isPinned = pinnedIds.contains(target.id),
                reaction = reactionMap[target.id],
                onReact = { e ->
                    vm.react(target.id, if (reactionMap[target.id] == e) null else e)
                    reactionMap = vm.store.reactions()
                },
                onReply = { replyTo = target; sheetFor = null; focusId = null },
                onCopy = { vm.copy(target.body); scope.launch { snackbar.showSnackbar("Copied") } },
                onForward = { forwardOf = listOf(target) },
                onStar = {
                    vm.toggleStar(target.id); starredIds = vm.store.starred()
                    scope.launch { snackbar.showSnackbar(if (starredIds.contains(target.id)) "Starred" else "Unstarred") }
                },
                onPin = {
                    vm.togglePin(target.id); pinnedIds = vm.store.pinned()
                    scope.launch { snackbar.showSnackbar(if (pinnedIds.contains(target.id)) "Pinned" else "Unpinned") }
                },
                onSelect = { selection = setOf(target.id); sheetFor = null; focusId = null },
                onShare = { shareText(vm, target.body) },
                onInfo = { infoFor = target },
                onDelete = {
                    val origin = burstAt
                    sheetFor = null
                    focusId = null
                    doDelete(listOf(target), origin)
                },
                onDismiss = { sheetFor = null; focusId = null }
            )
        }
    }

    val fwd = forwardOf
    if (fwd.isNotEmpty()) {
        ForwardSheet(
            vm = vm,
            count = fwd.size,
            onPick = { c ->
                fwd.forEach { vm.forwardTo(it.body, c) }
                forwardOf = emptyList()
                selection = emptySet()
                scope.launch { snackbar.showSnackbar("Forwarded to ${c.name}") }
            },
            onDismiss = { forwardOf = emptyList() }
        )
    }

    val info = infoFor
    if (info != null) {
        ModalBottomSheet(
            onDismissRequest = { infoFor = null },
            containerColor = p.surf
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Message info", color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                InfoLine("From", if (info.outgoing) "You" else chat.name)
                InfoLine("Number", info.address.ifBlank { chat.address })
                InfoLine("Sent", fullStamp(info.date))
                InfoLine("Characters", "${info.body.length}")
                InfoLine("Parts", "${(info.body.length / 160) + 1}")
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

@Composable
private fun InfoLine(k: String, v: String) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(k, color = p.dim, fontSize = 13.sp, modifier = Modifier.width(110.dp))
        Text(v, color = p.ink, fontSize = 13.sp)
    }
}

@Composable
private fun DayDivider(t: Long) {
    val p = LocalPal.current
    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
        Text(
            dayLabel(t),
            color = p.dim,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(p.glass)
                .padding(horizontal = 12.dp, vertical = 5.dp)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BubbleRow(
    m: Msg,
    theme: ThemeState,
    focused: Boolean,
    blurred: Boolean,
    selected: Boolean,
    selecting: Boolean,
    starred: Boolean,
    pinned: Boolean,
    reaction: String?,
    onLongPress: () -> Unit,
    onTap: () -> Unit,
    onDoubleTap: () -> Unit,
    onSwipeReply: () -> Unit,
    onPositioned: (Offset) -> Unit
) {
    val p = LocalPal.current
    val dragScope = rememberCoroutineScope()
    var dragX by remember { mutableStateOf(0f) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.035f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow),
        label = "scale"
    )
    val alpha by animateFloatAsState(if (blurred) 0.35f else 1f, tween(220), label = "a")
    val blurDp by animateDpAsState(if (blurred && theme.focusBlur.value) 7.dp else 0.dp, tween(220), label = "b")
    val shape = when (theme.bubbleStyle.value) {
        1 -> RoundedCornerShape(18.dp)
        2 -> RoundedCornerShape(8.dp)
        else -> if (m.outgoing) RoundedCornerShape(22.dp, 22.dp, 6.dp, 22.dp)
        else RoundedCornerShape(22.dp, 22.dp, 22.dp, 6.dp)
    }
    val fs = theme.fontScale.value

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale; scaleY = scale
                this.alpha = alpha
                translationX = dragX
            }
            .then(if (blurDp > 0.dp) Modifier.blur(blurDp) else Modifier)
            .onGloballyPositioned { onPositioned(it.positionInWindow()) }
            .pointerInput(m.id) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        if (dragX > 130f && !m.outgoing) onSwipeReply()
                        val from = dragX
                        dragScope.launch {
                            androidx.compose.animation.core.animate(
                                0f, 1f, animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
                            ) { t, _ -> dragX = from * (1f - t) }
                            dragX = 0f
                        }
                    },
                    onDragCancel = {
                        val from = dragX
                        dragScope.launch {
                            androidx.compose.animation.core.animate(
                                0f, 1f, animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
                            ) { t, _ -> dragX = from * (1f - t) }
                            dragX = 0f
                        }
                    },
                    onHorizontalDrag = { change, amount ->
                        change.consume()
                        dragX = (dragX + amount).coerceIn(0f, 190f)
                    }
                )
            },
        horizontalArrangement = if (m.outgoing) Arrangement.End else Arrangement.Start
    ) {
        if (!m.outgoing) Spacer(Modifier.width(4.dp))
        Column(
            horizontalAlignment = if (m.outgoing) Alignment.End else Alignment.Start,
            modifier = Modifier.bubbleWidth()
        ) {
            Box(
                Modifier
                    .clip(shape)
                    .background(
                        if (m.outgoing) p.brand else Brush.linearGradient(listOf(p.surf2, p.surf2))
                    )
                    .border(
                        1.dp,
                        if (selected) p.a1 else if (m.outgoing) Color.Transparent else p.line.copy(alpha = 0.6f),
                        shape
                    )
                    .combinedClickable(
                        onLongClick = onLongPress,
                        onClick = onTap,
                        onDoubleClick = onDoubleTap
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Column {
                    if (starred) {
                        Icon(
                            Icons.Rounded.Star, null, tint = if (m.outgoing) Color.White else p.a3,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.height(2.dp))
                    }
                    Text(
                        text = m.body,
                        color = if (m.outgoing) Color.White else p.ink,
                        fontSize = (14.5f * fs).sp,
                        lineHeight = (20f * fs).sp
                    )
                    Spacer(Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (m.failed) "Failed" else if (m.pending) "Sending" else hm(m.date),
                            color = if (m.outgoing) Color.White.copy(alpha = 0.72f) else p.dim,
                            fontSize = 10.sp
                        )
                        if (m.outgoing && !m.pending && !m.failed) {
                            Spacer(Modifier.width(3.dp))
                            Icon(
                                Icons.Rounded.Check, null,
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(11.dp)
                            )
                        }
                        if (pinned) {
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                MIcon.Pin, null,
                                tint = if (m.outgoing) Color.White.copy(alpha = 0.8f) else p.a1,
                                modifier = Modifier.size(10.dp)
                            )
                        }
                    }
                }
            }
            AnimatedVisibility(visible = reaction != null, enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()) {
                Text(
                    reaction ?: "",
                    fontSize = 13.sp,
                    modifier = Modifier
                        .padding(top = 3.dp)
                        .clip(RoundedCornerShape(50))
                        .background(p.surf)
                        .border(1.dp, p.line, RoundedCornerShape(50))
                        .padding(horizontal = 7.dp, vertical = 1.dp)
                )
            }
            if (selecting) {
                AnimatedVisibility(visible = true, enter = scaleIn()) {
                    Row(
                        Modifier.padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (selected) MIcon.CheckBox else MIcon.CheckBoxBlank,
                            null,
                            tint = if (selected) p.a1 else p.dim,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            if (selected) "Selected" else "Tap to select",
                            color = if (selected) p.a1 else p.dim,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
        Spacer(Modifier.width(4.dp))
    }
}

private fun androidx.compose.ui.Modifier.bubbleWidth() = this.fillMaxWidth(0.82f)

@Composable
private fun Composer(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    haptics: Boolean
) {
    val p = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val active = value.isNotBlank()
    val sendScale by animateFloatAsState(if (active) 1f else 0.86f, spring(dampingRatio = 0.5f), label = "send")
    Row(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Row(
            Modifier
                .weight(1f)
                .clip(RoundedCornerShape(24.dp))
                .background(p.surf)
                .border(1.dp, p.line.copy(alpha = 0.8f), RoundedCornerShape(24.dp))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f)) {
                if (value.isEmpty()) {
                    Text("Message", color = p.dim, fontSize = 15.sp)
                }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = p.ink,
                        fontSize = 15.sp,
                        lineHeight = 20.sp
                    ),
                    cursorBrush = p.brand,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 20.dp, max = 140.dp)
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .size(48.dp)
                .graphicsLayer { scaleX = sendScale; scaleY = sendScale }
                .clip(CircleShape)
                .background(if (active) p.brand else Brush.linearGradient(listOf(p.surf2, p.surf2)))
                .clickable(enabled = active) {
                    if (haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onSend()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Send, null,
                tint = if (active) Color.White else p.dim,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun MessageActions(
    m: Msg,
    isStarred: Boolean,
    isPinned: Boolean,
    reaction: String?,
    onReact: (String) -> Unit,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onForward: () -> Unit,
    onStar: () -> Unit,
    onPin: () -> Unit,
    onSelect: () -> Unit,
    onShare: () -> Unit,
    onInfo: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPal.current
    Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("\u2764\uFE0F", "\uD83D\uDE02", "\uD83D\uDE2E", "\uD83D\uDE4F", "\uD83D\uDD25", "\uD83D\uDC4D").forEach { e ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clip(CircleShape)
                        .background(if (reaction == e) p.brand else Brush.linearGradient(listOf(p.glass, p.glass)))
                        .clickable { onReact(e) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(e, fontSize = 19.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            m.body, color = p.dim, fontSize = 12.sp, maxLines = 2,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
        Spacer(Modifier.height(10.dp))
        ActionRow(MIcon.Reply, "Reply", onReply)
        ActionRow(MIcon.Copy, "Copy", onCopy)
        ActionRow(MIcon.Forward, "Forward", onForward)
        ActionRow(if (isStarred) Icons.Rounded.Star else MIcon.StarBorder, if (isStarred) "Unstar" else "Star", onStar)
        ActionRow(MIcon.Pin, if (isPinned) "Unpin" else "Pin", onPin)
        ActionRow(MIcon.SelectAll, "Select", onSelect)
        ActionRow(Icons.Rounded.Share, "Share", onShare)
        ActionRow(Icons.Rounded.Info, "Message info", onInfo)
        ActionRow(Icons.Rounded.Delete, "Move to Recycle Bin", onDelete, danger = true)
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun ActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    danger: Boolean = false
) {
    val p = LocalPal.current
    val tint = if (danger) Color(0xFFFF6B6B) else p.ink
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ForwardSheet(
    vm: MessagesVM,
    count: Int,
    onPick: (Chat) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPal.current
    val convos by vm.convos.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    val list = remember(q, convos) {
        if (q.isBlank()) convos else convos.filter { it.name.contains(q, true) || it.address.contains(q) }
    }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = p.surf
    ) {
        Column(Modifier.navigationBarsPadding()) {
            Text(
                "Forward ${if (count > 1) "$count messages" else "message"}",
                color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, bottom = 10.dp)
            )
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(list, key = { it.threadId }) { c ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(Chat(c.threadId, c.address, c.name)) }
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(c.name, 40.dp, seed = c.address.hashCode())
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = p.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                            Text(c.address, color = p.dim, fontSize = 11.sp, maxLines = 1)
                        }
                        Icon(Icons.Rounded.Send, null, tint = p.a1, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

private fun shareText(vm: MessagesVM, text: String) {
    try {
        val ctx = vm.getApplication<android.app.Application>()
        val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, text)
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(android.content.Intent.createChooser(i, "Share message"))
    } catch (_: Exception) {
    }
}
