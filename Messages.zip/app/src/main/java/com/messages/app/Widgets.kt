package com.messages.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Soft animated backdrop. One cheap draw pass, no blur filters. */
@Composable
fun AuroraBackdrop(animate: Boolean, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    val transition = rememberInfiniteTransition(label = "aurora")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shift"
    )
    val phase = if (animate) t else 0.35f
    Canvas(modifier.fillMaxSize()) {
        drawRect(brush = Brush.verticalGradient(listOf(p.bg, p.bg, p.surf2.copy(alpha = 0.55f))))
        val r1 = size.minDimension * 0.95f
        val c1 = Offset(size.width * (0.18f + 0.12f * phase), size.height * (0.06f + 0.05f * phase))
        drawCircle(
            brush = Brush.radialGradient(
                listOf(p.a1.copy(alpha = if (p.dark) 0.30f else 0.20f), Color.Transparent),
                center = c1, radius = r1
            ),
            radius = r1, center = c1
        )
        val r2 = size.minDimension * 0.85f
        val c2 = Offset(size.width * (0.92f - 0.14f * phase), size.height * (0.24f + 0.10f * phase))
        drawCircle(
            brush = Brush.radialGradient(
                listOf(p.a2.copy(alpha = if (p.dark) 0.24f else 0.16f), Color.Transparent),
                center = c2, radius = r2
            ),
            radius = r2, center = c2
        )
        val r3 = size.minDimension * 0.7f
        val c3 = Offset(size.width * (0.5f + 0.2f * phase), size.height * 0.95f)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(p.a3.copy(alpha = if (p.dark) 0.18f else 0.12f), Color.Transparent),
                center = c3, radius = r3
            ),
            radius = r3, center = c3
        )
    }
}

@Composable
fun Avatar(name: String, size: Dp = 46.dp, seed: Int = name.hashCode(), dim: Boolean = false) {
    val p = LocalPal.current
    val accents = listOf(p.a1, p.a2, p.a3)
    val c1 = accents[(seed.let { if (it < 0) -it else it }) % 3]
    val c2 = accents[((seed.let { if (it < 0) -it else it }) + 1) % 3]
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(c1, c2)))
            .then(if (dim) Modifier else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initials(name),
            color = Color.White,
            fontSize = (size.value * 0.36f).sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun IconBtn(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color? = null,
    size: Dp = 20.dp,
    enabled: Boolean = true
) {
    val p = LocalPal.current
    Box(
        modifier = modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = (tint ?: p.ink).copy(alpha = if (enabled) 1f else 0.35f),
            modifier = Modifier.size(size)
        )
    }
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val p = LocalPal.current
    Box(
        modifier = modifier
            .height(50.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) p.brand else Brush.linearGradient(listOf(p.dim, p.dim)))
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
            modifier = Modifier.padding(horizontal = 22.dp)
        )
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) p.brand else Brush.linearGradient(listOf(p.glass, p.glass)))
            .border(1.dp, if (selected) Color.Transparent else p.line, RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = text,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = if (selected) Color.White else p.ink
        )
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, sub: String) {
    val p = LocalPal.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(p.a1.copy(alpha = 0.16f), p.a2.copy(alpha = 0.16f))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = p.a1, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(title, color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(sub, color = p.dim, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionLabel(text: String) {
    val p = LocalPal.current
    Text(
        text = text.uppercase(),
        color = p.dim,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 8.dp)
    )
}

// ------------------------------------------------------------- particles

private data class Particle(
    val vx: Float,
    val vy: Float,
    val r: Float,
    val color: Color
)

/**
 * Message-burst effect. 26 particles on a single analytic path, drawn once per
 * frame from one animated value - no per-particle animation objects.
 */
@Composable
fun ParticleBurst(
    trigger: Int,
    origin: Offset,
    modifier: Modifier = Modifier,
    onFinished: () -> Unit = {}
) {
    if (trigger == 0) return
    val p = LocalPal.current
    val palette = remember(trigger, p.id) {
        listOf(p.a1, p.a2, p.a3, p.ink.copy(alpha = 0.8f))
    }
    val parts = remember(trigger) {
        val rnd = Random(trigger)
        List(30) { i ->
            val ang = (i / 30f) * 6.28318f + rnd.nextFloat() * 0.35f
            val speed = 0.45f + rnd.nextFloat() * 1.15f
            Particle(
                vx = cos(ang) * speed,
                vy = sin(ang) * speed,
                r = 2.2f + rnd.nextFloat() * 5.5f,
                color = palette[i % palette.size]
            )
        }
    }
    val prog = remember(trigger) { Animatable(0f) }
    LaunchedEffect(trigger) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(720, easing = LinearEasing))
        onFinished()
    }
    Canvas(modifier.fillMaxSize()) {
        val t = prog.value
        if (t <= 0f || t >= 1f) return@Canvas
        val ease = 1f - (1f - t) * (1f - t)
        parts.forEach { part ->
            val x = origin.x + part.vx * ease * 190f
            val y = origin.y + part.vy * ease * 190f + 340f * t * t
            val a = (1f - t).coerceIn(0f, 1f)
            val rad = part.r * (1f - t * 0.55f)
            if (rad > 0.4f) {
                drawCircle(color = part.color.copy(alpha = a), radius = rad, center = Offset(x, y))
            }
        }
    }
}

/** Small helper for a thin divider that respects the theme. */
@Composable
fun HairLine(modifier: Modifier = Modifier) {
    val p = LocalPal.current
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(p.line.copy(alpha = 0.55f))
    )
}

@Composable
fun Dot(active: Boolean, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    Box(
        modifier
            .size(6.dp)
            .clip(CircleShape)
            .background(if (active) p.a1 else p.dim.copy(alpha = 0.35f))
    )
}
