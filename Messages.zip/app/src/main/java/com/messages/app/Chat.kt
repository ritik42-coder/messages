@file:OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.layout.ContentScale

fun Set<Long>.toggle(x: Long): Set<Long> = if (x in this) this - x else this + x

val URL_RE = Regex("(https?://|www\\.)\\S+", RegexOption.IGNORE_CASE)

// ---------- particle burst ----------
class Particle(val rx: Float, val ry: Float, val ang: Float, val speed: Float, val size: Float, val ci: Int)

val PARTS: List<Particle> = Random(7).let { r ->
    List(48) { Particle(r.nextFloat(), r.nextFloat(), r.nextFloat() * 6.2832f, r.nextFloat(), 3f + r.nextFloat() * 5f, r.nextInt(4)) }
}

fun Modifier.burstParticles(p: Animatable<Float, AnimationVector1D>): Modifier = drawWithContent {
    drawContent()
    val v = p.value
    if (v > 0f) {
        val cols = listOf(A1, A2, A3, Gold)
        val a = (1f - v).coerceIn(0f, 1f)
        for (pt in PARTS) {
            val r = v * (40f + pt.speed * 320f)
            val x = size.width * pt.rx + cos(pt.ang) * r
            val y = size.height * pt.ry + sin(pt.ang) * r + v * v * 240f
            drawCircle(cols[pt.ci].copy(alpha = a), radius = pt.size * density * (1f - 0.6f * v), center = Offset(x, y))
        }
    }
}

// ---------- bubbles ----------
@Composable
fun BubbleBody(m: Msg, reaction: String?, starred: Boolean, onTap: () -> Unit = {}, onLong: () -> Unit = {}, sender: String = "") {
    val scam = remember(m.body, sender) { if (!m.outgoing && m.media == null) Scam.check(m.body, sender) else null }
    val smart = remember(m.body) { if (!m.outgoing && m.media == null) Smart.find(m.body) else emptyList() }
    val shape = RoundedCornerShape(22.dp, 22.dp, if (m.outgoing) 6.dp else 22.dp, if (m.outgoing) 22.dp else 6.dp)
    val tc = if (m.outgoing) Color.White else Ink
    val isImg = m.media != null && m.mime?.startsWith("image") == true
    val isAud = m.media != null && m.mime?.startsWith("audio") == true
    val pad = if (isImg) 6.dp else 14.dp
    Column(horizontalAlignment = if (m.outgoing) Alignment.End else Alignment.Start) {
        Column(Modifier.widthIn(max = 290.dp).clip(shape).background(if (m.outgoing) Brand else SolidColor(Surf2), shape).padding(horizontal = pad, vertical = if (isImg) 6.dp else 10.dp)) {
            when {
                isImg -> {
                    ImageThumb(m.media!!)
                    if (m.body.isNotEmpty()) Text(m.body, color = tc.copy(alpha = 0.8f), fontSize = 12.sp, modifier = Modifier.padding(6.dp))
                }
                isAud -> VoiceBubble(m.media!!, m.outgoing)
                else -> LinkText(m.body, tc, if (m.outgoing) Color.White else A2, onTap, onLong, risky = scam?.risky == true)
            }
            if (m.code != null) { Spacer(Modifier.height(8.dp)); OtpPill(m.code) }
            if (scam != null && scam.warn) ScamBanner(scam)
            smart.forEach { SmartPill(it) }
            Row(Modifier.align(Alignment.End).padding(top = 3.dp, end = if (isImg) 6.dp else 0.dp), verticalAlignment = Alignment.CenterVertically) {
                if (starred) { Icon(Icons.Rounded.Star, null, tint = Gold, modifier = Modifier.size(13.dp)); Spacer(Modifier.width(4.dp)) }
                Text(if (m.failed) "Not sent" else hm(m.date), color = if (m.failed) A3 else tc.copy(alpha = 0.6f), fontSize = 11.sp)
                if (m.outgoing) {
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        when { m.failed -> Icons.Rounded.ErrorOutline; m.pending -> Icons.Rounded.Schedule; else -> Icons.Rounded.Done },
                        null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
        if (reaction != null) {
            Text(reaction, fontSize = 14.sp, modifier = Modifier.offset(y = (-6).dp).clip(CircleShape).background(Surf).padding(horizontal = 7.dp, vertical = 2.dp))
        }
    }
}

@Composable
fun SelDot(on: Boolean) {
    val s by animateFloatAsState(if (on) 1f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "dot")
    Box(
        Modifier.padding(end = 10.dp).size(26.dp).clip(CircleShape)
            .border(2.dp, if (on) A2 else Dim, CircleShape).background(if (on) A2 else Color.Transparent),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp).graphicsLayer { scaleX = s; scaleY = s }) }
}

@Composable
fun Bubble(
    m: Msg, showDay: Boolean, selMode: Boolean, sel: Boolean, burst: Boolean,
    reaction: String?, starred: Boolean, onTap: () -> Unit, onLong: () -> Unit, sender: String = ""
) {
    var shown by remember { mutableStateOf(System.currentTimeMillis() - m.date > 4000) }
    LaunchedEffect(Unit) { shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(300), label = "ba")
    val sc by animateFloatAsState(if (shown) 1f else 0.85f, spring(Spring.DampingRatioMediumBouncy), label = "bs")
    val prog = remember { Animatable(0f) }
    LaunchedEffect(burst) { if (burst) prog.animateTo(1f, tween(700, easing = LinearOutSlowInEasing)) }
    val hl by animateFloatAsState(if (sel) 1f else 0f, tween(200), label = "hl")
    Column(Modifier.fillMaxWidth()) {
        if (showDay) {
            Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                Text(dayLabel(m.date), color = Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Row(Modifier.fillMaxWidth().drawBehind { drawRect(A2.copy(alpha = 0.16f * hl)) }, verticalAlignment = Alignment.CenterVertically) {
            AnimatedVisibility(
                selMode,
                enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + expandHorizontally(),
                exit = scaleOut() + shrinkHorizontally()
            ) { SelDot(sel) }
            Box(Modifier.weight(1f), contentAlignment = if (m.outgoing) Alignment.CenterEnd else Alignment.CenterStart) {
                Box(Modifier.burstParticles(prog)) {
                    Box(
                        Modifier.graphicsLayer {
                            alpha = a * (1f - prog.value * 1.8f).coerceIn(0f, 1f)
                            val s = sc * (1f - 0.12f * prog.value)
                            scaleX = s; scaleY = s
                            transformOrigin = TransformOrigin(if (m.outgoing) 1f else 0f, 1f)
                        }.bounce(onClick = onTap, onLong = onLong)
                    ) { BubbleBody(m, reaction, starred, onTap, onLong, sender) }
                }
            }
        }
    }
}

@Composable
fun QuickChip(label: String, onClick: () -> Unit) {
    Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(Surf2).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(label, color = Ink, fontSize = 14.sp)
    }
}

// ---------- chat ----------
@Composable
fun ChatScreen(vm: MessagesVM, chat: Chat, onForward: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val msgs by vm.msgs.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    val starred by vm.starred.collectAsState()
    val reacts by vm.reactions.collectAsState()
    val blocked by vm.blocked.collectAsState()
    var tfv by remember { mutableStateOf(TextFieldValue("")) }
    val text = tfv.text
    fun setText(x: String) { tfv = TextFieldValue(x, TextRange(x.length)) }
    var viewer by remember { mutableStateOf<String?>(null) }
    var pendingImg by remember { mutableStateOf<android.net.Uri?>(null) }
    var emoji by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var secs by remember { mutableStateOf(0) }
    val recorder = remember { Recorder(ctx) }
    val kb = LocalSoftwareKeyboardController.current
    val fm = LocalFocusManager.current
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var focused by remember { mutableStateOf<Msg?>(null) }
    var keep by remember { mutableStateOf<Msg?>(null) }
    var bursting by remember { mutableStateOf(setOf<Long>()) }
    var undo by remember { mutableStateOf<List<Saved>?>(null) }
    var searching by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var dialogMsg by remember { mutableStateOf<Msg?>(null) }
    val state = rememberLazyListState()
    val shown = remember(msgs, q, searching) {
        (if (searching && q.isNotBlank()) msgs.filter { it.body.contains(q, true) } else msgs).asReversed()
    }
    val selMode = selected.isNotEmpty()
    val blurR by animateDpAsState(if (focused != null || menu) 14.dp else 0.dp, tween(250), label = "cb")
    SideEffect { if (focused != null) keep = focused }
    LaunchedEffect(Unit) { val d = vm.draft.value; if (d.isNotEmpty()) { setText(d); vm.draft.value = "" } }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty() && !searching) state.animateScrollToItem(0) }
    LaunchedEffect(undo) { if (undo != null) { delay(5000); undo = null } }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun textOf(ids: Set<Long>) = msgs.filter { it.id in ids }.joinToString("\n") { it.body }
    fun doDelete(ids: Set<Long>) {
        val pos = ids.filter { it > 0 }.toSet()
        val neg = ids.filter { it < 0 }.map { -it }
        if (pos.isNotEmpty() && !isDef) { toast("Set Messages as default SMS app to delete"); return }
        bursting = ids; selected = emptySet(); focused = null
        scope.launch {
            delay(720)
            val saved = if (pos.isNotEmpty()) vm.deleteMessages(chat, pos) else emptyList()
            if (neg.isNotEmpty()) vm.deleteMedia(neg)
            bursting = emptySet()
            if (saved.isNotEmpty()) undo = saved
        }
    }

    fun finishRec(send: Boolean) {
        recording = false
        if (send) {
            val f = recorder.stop()
            if (f != null && f.length() > 0) vm.sendVoice(chat, f) else toast("Recording too short")
        } else recorder.cancel()
    }
    fun startRec() { if (recorder.start()) { recording = true; secs = 0 } else toast("Can't start recording") }
    fun insertEmoji(e: String) {
        val sel = tfv.selection
        val t = tfv.text.replaceRange(sel.min, sel.max, e)
        tfv = TextFieldValue(t, TextRange(sel.min + e.length))
    }
    fun needDefault(): Boolean {
        if (!isDef) toast("Set Messages as default SMS app to send pictures & voice")
        return !isDef
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startRec() else toast("Microphone permission needed") }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) pendingImg = uri
    }
    LaunchedEffect(recording) {
        if (recording) { while (true) { delay(1000); secs++; if (secs >= 120) { finishRec(true); break } } }
    }
    DisposableEffect(Unit) { onDispose { recorder.cancel(); Player.stop() } }
    BackHandler(selMode || focused != null || menu || searching || viewer != null || emoji || recording) {
        when {
            viewer != null -> viewer = null
            focused != null -> focused = null
            menu -> menu = false
            recording -> finishRec(false)
            emoji -> emoji = false
            selMode -> selected = emptySet()
            else -> { searching = false; q = "" }
        }
    }

    Box(Modifier.fillMaxSize().background(Bg).blockTouches()) {
        Column(Modifier.fillMaxSize().blur(blurR).statusBarsPadding().navigationBarsPadding().imePadding()) {
            AnimatedContent(selMode, transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) }, label = "bar") { sm ->
                if (sm) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(Icons.Rounded.Close) { selected = emptySet() }
                        Text("${selected.size} selected", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        IconBtn(Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(textOf(selected))); toast("Copied"); selected = emptySet() }
                        IconBtn(Icons.Rounded.Forward) { onForward(textOf(selected)); selected = emptySet() }
                        IconBtn(Icons.Rounded.Star) {
                            msgs.filter { it.id in selected }.forEach { x -> if (starred.none { it.id == x.id }) vm.toggleStar(chat, x) }
                            selected = emptySet()
                        }
                        IconBtn(Icons.Rounded.Delete, A3) { doDelete(selected) }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(Icons.Rounded.ArrowBack) { onBack() }
                        Avatar(chat.name, 42.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(chat.name, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (chat.name != chat.address) Text(chat.address, color = Dim, fontSize = 12.sp)
                        }
                        SimChip(chat.address)
                        IconBtn(Icons.Rounded.Search) { searching = !searching; if (!searching) q = "" }
                        IconBtn(Icons.Rounded.Call) { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(chat.address)))) }
                        IconBtn(Icons.Rounded.MoreVert) { menu = true }
                    }
                }
            }
            AnimatedVisibility(searching) {
                Box(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) { SearchField(q, { q = it }, "Search in chat", autofocus = true) }
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = state, reverseLayout = true,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                itemsIndexed(shown, key = { _, m -> m.id }) { i, m ->
                    Box(Modifier.animateItemPlacement()) {
                        Bubble(
                            m, shown.getOrNull(i + 1).let { it == null || !sameDay(it.date, m.date) },
                            selMode, m.id in selected, m.id in bursting, reacts[m.id], starred.any { it.id == m.id },
                            onTap = { if (selMode) selected = selected.toggle(m.id) else if (m.mime?.startsWith("image") == true && m.media != null) viewer = m.media },
                            onLong = { if (selMode) selected = selected.toggle(m.id) else focused = m },
                            sender = chat.address
                        )
                    }
                }
            }
            if (!isDef) Text("Set Messages as default SMS app to keep sent messages in this chat", color = Dim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
            AnimatedVisibility(undo != null, enter = slideInVertically(tween(300)) { it } + fadeIn(), exit = slideOutVertically(tween(250)) { it } + fadeOut()) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf2).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Moved to Recycle bin", color = Ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Text("UNDO", color = A2, fontWeight = FontWeight.ExtraBold, modifier = Modifier.bounce(onClick = { undo?.let { vm.restore(it) }; undo = null }).padding(4.dp))
                }
            }
            val lastIn = msgs.lastOrNull()?.let { !it.outgoing } == true
            AnimatedVisibility(lastIn && text.isEmpty() && !selMode && !recording) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("\uD83D\uDC4D", "Okay", "Thanks!", "Call me", "On my way", "Busy, will text later").forEach { r -> QuickChip(r) { setText(r) } }
                }
            }
            val info = remember(text) { if (text.length > 60) android.telephony.SmsMessage.calculateLength(text, false) else null }
            if (info != null) Text("${text.length} chars  \u2022  ${info[0]} SMS", color = Dim, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(end = 22.dp))
            if (recording) {
                RecordBar(secs, onCancel = { finishRec(false) }, onSend = { finishRec(true) })
            } else {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Bottom) {
                    Box(Modifier.size(46.dp).bounce(onClick = { emoji = !emoji; if (emoji) { kb?.hide(); fm.clearFocus() } }), contentAlignment = Alignment.Center) {
                        Icon(if (emoji) Icons.Rounded.Keyboard else Icons.Rounded.EmojiEmotions, null, tint = Dim)
                    }
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(Surf).padding(horizontal = 18.dp, vertical = 14.dp)) {
                        if (text.isEmpty()) Text("Message", color = Dim, fontSize = 16.sp)
                        BasicTextField(
                            value = tfv, onValueChange = { tfv = it }, maxLines = 5,
                            textStyle = TextStyle(color = Ink, fontSize = 16.sp), cursorBrush = SolidColor(A2),
                            modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) emoji = false }
                        )
                    }
                    AnimatedVisibility(
                        text.isBlank(),
                        enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn() + expandHorizontally(),
                        exit = scaleOut() + fadeOut() + shrinkHorizontally()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).bounce(onClick = { pickImage.launch("image/*") }), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Image, null, tint = Dim)
                            }
                            Box(
                                Modifier.size(50.dp).bounce(onClick = {
                                    if (!needDefault()) {
                                        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec()
                                        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }).clip(CircleShape).background(Brand),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Rounded.Mic, null, tint = Color.White) }
                        }
                    }
                    AnimatedVisibility(
                        text.isNotBlank(),
                        enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn() + expandHorizontally(),
                        exit = scaleOut() + fadeOut() + shrinkHorizontally()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.padding(start = 4.dp).size(44.dp).bounce(onClick = { dialogMsg = null; dialog = "sched" }), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Schedule, null, tint = Dim)
                            }
                            Box(
                                Modifier.size(50.dp).bounce(onClick = {
                                    vm.send(chat, text.trim()); setText("")
                                    if (!isDef) toast("Sent. Set as default app to keep history")
                                }).clip(CircleShape).background(Brand),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Rounded.Send, null, tint = Color.White) }
                        }
                    }
                }
            }
            AnimatedVisibility(emoji) { EmojiPanel { e -> insertEmoji(e) } }
        }

        // hold-a-message overlay
        Scrim(focused != null, { focused = null }) {
            keep?.let { m ->
                val isStar = starred.any { it.id == m.id }
                Row(Modifier.shadow(12.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp)).background(Surf).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    listOf("👍", "❤️", "😂", "😮", "😢", "🙏").forEach { e ->
                        Text(e, fontSize = 26.sp, modifier = Modifier.bounce(onClick = { vm.react(m, e); focused = null }).padding(horizontal = 7.dp, vertical = 4.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.outgoing) Alignment.CenterEnd else Alignment.CenterStart) { BubbleBody(m, reacts[m.id], isStar) }
                Spacer(Modifier.height(14.dp))
                ActionCard(buildList {
                    m.code?.let { c -> add(Act(Icons.Rounded.ContentCopy, "Copy OTP $c") { clip.setText(AnnotatedString(c)); toast("OTP copied"); focused = null }) }
                    if (m.media == null) add(Act(Icons.Rounded.ContentCopy, "Copy text") { clip.setText(AnnotatedString(m.body)); toast("Copied"); focused = null })
                    if (m.media == null) add(Act(Icons.Rounded.Forward, "Forward") { onForward(m.body); focused = null })
                    add(Act(Icons.Rounded.CheckCircle, "Select") { selected = setOf(m.id); focused = null })
                    if (m.media == null) add(Act(if (isStar) Icons.Rounded.StarBorder else Icons.Rounded.Star, if (isStar) "Unstar" else "Star") { vm.toggleStar(chat, m); focused = null })
                    if (m.media == null) add(Act(Icons.Rounded.Alarm, "Remind me") { dialogMsg = m; dialog = "remind"; focused = null })
                    if (m.media == null) add(Act(Icons.Rounded.Share, "Share") {
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, m.body), null))
                        focused = null
                    })
                    add(Act(Icons.Rounded.Info, "Details") { dialogMsg = m; dialog = "info"; focused = null })
                    add(Act(Icons.Rounded.Delete, "Delete", true) { doDelete(setOf(m.id)) })
                })
            }
        }

        Scrim(menu, { menu = false }) {
            ActionCard(listOf(
                Act(Icons.Rounded.Share, "Export chat") {
                    val me = "Me"
                    val t = msgs.joinToString("\n") { "[${fullDate(it.date)}] ${if (it.outgoing) me else chat.name}: ${it.body}" }
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Export chat"))
                    menu = false
                },
                Act(Icons.Rounded.Block, if (nk(chat.address) in blocked) "Unblock number" else "Block number") { vm.toggleBlock(chat.address); menu = false }
            ))
        }

        AnimatedVisibility(viewer != null, enter = fadeIn(tween(200)), exit = fadeOut(tween(150))) {
            Box(
                Modifier.fillMaxSize().background(Color.Black)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { viewer = null }
            ) { viewer?.let { ImageThumb(it, full = true) } }
        }

        pendingImg?.let { u ->
            val est by produceState<Pair<Int, Int>?>(null, u) {
                value = withContext(Dispatchers.IO) {
                    val a = SmsPic.shrink(ctx, u, 1200)
                    val b = SmsPic.shrink(ctx, u, 3000)
                    if (a != null && b != null) SmsPic.count(a) to SmsPic.count(b) else null
                }
            }
            AlertDialog(
                onDismissRequest = { pendingImg = null }, containerColor = Surf2,
                title = { Text("Send picture", color = Ink) },
                text = {
                    Column {
                        Text("Works on any SIM and any phone network. The picture is shrunk and sent as small SMS messages (each one costs a normal SMS). Your friend needs Messages to see it.", color = Dim, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Tiny \u2022 about ${est?.first ?: "…"} SMS", color = Ink, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().bounce(onClick = { vm.sendImageSms(chat, u, 1200); pendingImg = null }).padding(vertical = 12.dp))
                        Text("Clearer \u2022 about ${est?.second ?: "…"} SMS", color = Ink, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().bounce(onClick = { vm.sendImageSms(chat, u, 3000); pendingImg = null }).padding(vertical = 12.dp))
                        Text("Full quality (MMS, needs carrier MMS)", color = A2, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().bounce(onClick = { if (!needDefault()) { vm.sendImage(chat, u, text.trim()); setText("") }; pendingImg = null }).padding(vertical = 12.dp))
                    }
                },
                confirmButton = { },
                dismissButton = { TextButton(onClick = { pendingImg = null }) { Text("Cancel", color = Dim) } }
            )
        }

        if (dialog == "remind" || dialog == "sched") {
            val isRemind = dialog == "remind"
            AlertDialog(
                onDismissRequest = { dialog = null }, containerColor = Surf2,
                title = { Text(if (isRemind) "Remind me" else "Send later", color = Ink) },
                text = {
                    Column {
                        timeOptions().forEach { (label, at) ->
                            Text(label, color = Ink, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().bounce(onClick = {
                                if (isRemind) { dialogMsg?.let { vm.schedule("remind", chat.address, it.body, at) }; toast("Reminder set for ${hm(at)}") }
                                else { vm.schedule("send", chat.address, text.trim(), at); setText(""); toast("Scheduled for ${hm(at)}") }
                                dialog = null
                            }).padding(vertical = 12.dp))
                        }
                    }
                },
                confirmButton = { },
                dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel", color = Dim) } }
            )
        }
        if (dialog == "info") {
            dialogMsg?.let { m ->
                AlertDialog(
                    onDismissRequest = { dialog = null }, containerColor = Surf2,
                    title = { Text("Message details", color = Ink) },
                    text = {
                        Text(
                            (if (m.outgoing) "To: ${chat.name}" else "From: ${chat.name}") + "\n${chat.address}\n\n" +
                                fullDate(m.date) + "\n${m.body.length} characters\nType: Text message (SMS)\n" +
                                (if (m.failed) "Status: Not sent" else if (m.pending) "Status: Sending" else "Status: OK"),
                            color = Dim
                        )
                    },
                    confirmButton = { TextButton(onClick = { dialog = null }) { Text("Close", color = A2) } }
                )
            }
        }
    }
}
