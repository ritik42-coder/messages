@file:OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.layout.ContentScale
import kotlin.math.roundToInt
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput

fun Set<Long>.toggle(x: Long): Set<Long> = if (x in this) this - x else this + x

val URL_RE = Regex("(https?://|www\\.)\\S+", RegexOption.IGNORE_CASE)

// ---------- particle burst ----------
class Particle(val rx: Float, val ry: Float, val ang: Float, val speed: Float, val size: Float, val ci: Int)

val PARTS: List<Particle> = Random(7).let { r ->
    List(48) { Particle(r.nextFloat(), r.nextFloat(), r.nextFloat() * 6.2832f, r.nextFloat(), 3f + r.nextFloat() * 5f, r.nextInt(4)) }
}

fun Modifier.burstParticles(p: Animatable<Float, AnimationVector1D>): Modifier = drawWithContent {
    drawContent()
    val v = p.value
    if (v > 0f) {
        val cols = listOf(A1, A2, A3, Gold)
        val a = (1f - v).coerceIn(0f, 1f)
        for (pt in PARTS) {
            val r = v * (40f + pt.speed * 320f)
            val x = size.width * pt.rx + cos(pt.ang) * r
            val y = size.height * pt.ry + sin(pt.ang) * r + v * v * 240f
            drawCircle(cols[pt.ci].copy(alpha = a), radius = pt.size * density * (1f - 0.6f * v), center = Offset(x, y))
        }
    }
}

// ---------- bubbles ----------
@Composable
fun BubbleBody(m: Msg, reaction: String?, starred: Boolean, onTap: () -> Unit = {}, onLong: () -> Unit = {}, sender: String = "") {
    val scam = remember(m.body, sender) { if (!m.outgoing && m.media == null) Scam.check(m.body, sender) else null }
    val smart = remember(m.body) { if (!m.outgoing && m.media == null) Smart.find(m.body) else emptyList() }
    val shape = RoundedCornerShape(22.dp, 22.dp, if (m.outgoing) 6.dp else 22.dp, if (m.outgoing) 22.dp else 6.dp)
    val tc = if (m.outgoing) Color.White else Ink
    val isImg = m.media != null && m.mime?.startsWith("image") == true
    val isAud = m.media != null && m.mime?.startsWith("audio") == true
    val pad = if (isImg) 6.dp else 14.dp
    Column(horizontalAlignment = if (m.outgoing) Alignment.End else Alignment.Start) {
        Column(Modifier.widthIn(max = 290.dp).clip(shape).background(if (m.outgoing) Brand else SolidColor(Surf2), shape).padding(horizontal = pad, vertical = if (isImg) 6.dp else 10.dp)) {
            when {
                isImg -> {
                    ImageThumb(m.media!!)
                    if (m.body.isNotEmpty()) Text(m.body, color = tc.copy(alpha = 0.8f), fontSize = 12.sp, modifier = Modifier.padding(6.dp))
                }
                isAud -> VoiceBubble(m.media!!, m.outgoing)
                else -> LinkText(m.body, tc, if (m.outgoing) Color.White else A2, onTap, onLong, risky = scam?.risky == true)
            }
            if (m.code != null) { Spacer(Modifier.height(8.dp)); OtpPill(m.code) }
            if (scam != null && scam.warn) ScamBanner(scam)
            smart.forEach { SmartPill(it) }
            if (m.media == null && m.body.isNotEmpty()) NumChips(m.body, m.outgoing)
            Row(Modifier.align(Alignment.End).padding(top = 3.dp, end = if (isImg) 6.dp else 0.dp), verticalAlignment = Alignment.CenterVertically) {
                if (starred) { Icon(Icons.Rounded.Star, null, tint = Gold, modifier = Modifier.size(13.dp)); Spacer(Modifier.width(4.dp)) }
                Text(if (m.failed) "Not sent" else hm(m.date), color = if (m.failed) A3 else tc.copy(alpha = 0.6f), fontSize = 11.sp)
                if (m.outgoing) {
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        when { m.failed -> Icons.Rounded.ErrorOutline; m.pending -> Icons.Rounded.Schedule; else -> Icons.Rounded.Done },
                        null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
        if (reaction != null) {
            Text(reaction, fontSize = 14.sp, modifier = Modifier.offset(y = (-6).dp).clip(CircleShape).background(Surf).padding(horizontal = 7.dp, vertical = 2.dp))
        }
    }
}

@Composable
fun NumChips(body: String, onBrand: Boolean) {
    val nums = remember(body) { Nums.find(body) }
    if (nums.isEmpty()) return
    val clip = LocalClipboardManager.current
    Column(Modifier.padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        nums.forEach { n ->
            var tick by remember(n) { mutableStateOf(false) }
            LaunchedEffect(tick) { if (tick) { delay(1400); tick = false } }
            Row(
                Modifier.bounce(onClick = { clip.setText(AnnotatedString(n)); tick = true })
                    .clip(RoundedCornerShape(50))
                    .background(if (onBrand) Color.White.copy(alpha = 0.18f) else Surf)
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (tick) Icons.Rounded.Check else Icons.Rounded.ContentCopy, null,
                    tint = if (onBrand) Color.White else A2, modifier = Modifier.size(13.dp)
                )
                Spacer(Modifier.width(5.dp))
                Text(
                    if (tick) "Copied" else Nums.pretty(n), color = if (onBrand) Color.White else Ink,
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp
                )
            }
        }
    }
}

/** Drag a bubble right to star it, left to delete it. */
@Composable
fun SwipeBubble(outgoing: Boolean, onStar: (() -> Unit)?, onDelete: (() -> Unit)?, content: @Composable () -> Unit) {
    val limit = with(LocalDensity.current) { 96.dp.toPx() }
    var dx by remember { mutableStateOf(0f) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var armed by remember { mutableStateOf(0) }
    Box(Modifier.fillMaxWidth()) {
        val v = dx
        if (v > 6f && onStar != null) {
            Icon(
                Icons.Rounded.Star, null, tint = Gold,
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp).size(20.dp)
                    .graphicsLayer { alpha = (v / limit).coerceIn(0f, 1f) }
            )
        } else if (v < -6f && onDelete != null) {
            Icon(
                Icons.Rounded.Delete, null, tint = A3,
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp).size(20.dp)
                    .graphicsLayer { alpha = (-v / limit).coerceIn(0f, 1f) }
            )
        }
        Box(
            Modifier.align(if (outgoing) Alignment.CenterEnd else Alignment.CenterStart)
                .offset { IntOffset(dx.roundToInt(), 0) }
                .pointerInput(onStar, onDelete) {
                    detectHorizontalDragGestures(
                        onDragStart = { armed = 0 },
                        onDragCancel = { scope.launch { animate(dx, 0f, animationSpec = tween(150)) { x, _ -> dx = x } } },
                        onDragEnd = {
                            val t = when {
                                dx > limit && onStar != null -> limit
                                dx < -limit && onDelete != null -> -limit
                                else -> 0f
                            }
                            scope.launch {
                                if (t != 0f) {
                                    animate(dx, t, animationSpec = tween(140)) { x, _ -> dx = x }
                                    if (t > 0) onStar?.invoke() else onDelete?.invoke()
                                }
                                animate(dx, 0f, animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { x, _ -> dx = x }
                            }
                        },
                        onHorizontalDrag = { _, drag ->
                            dx = (dx + drag).coerceIn(-limit * 1.3f, limit * 1.3f)
                            val a = when {
                                dx > limit -> 1
                                dx < -limit -> -1
                                else -> 0
                            }
                            if (a != armed && a != 0) {
                                armed = a
                                if (HapticsOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                            if (a == 0) armed = 0
                        }
                    )
                }
        ) { content() }
    }
}

@Composable
fun SelDot(on: Boolean) {
    val s by animateFloatAsState(if (on) 1f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "dot")
    Box(
        Modifier.padding(end = 10.dp).size(26.dp).clip(CircleShape)
            .border(2.dp, if (on) A2 else Dim, CircleShape).background(if (on) A2 else Color.Transparent),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp).graphicsLayer { scaleX = s; scaleY = s }) }
}

@Composable
fun Bubble(
    m: Msg, showDay: Boolean, selMode: Boolean, sel: Boolean, burst: Boolean,
    reaction: String?, starred: Boolean, onTap: () -> Unit, onLong: () -> Unit, sender: String = "",
    onStar: (() -> Unit)? = null, onDelete: (() -> Unit)? = null
) {
    var shown by remember { mutableStateOf(System.currentTimeMillis() - m.date > 4000) }
    LaunchedEffect(Unit) { shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(300), label = "ba")
    val sc by animateFloatAsState(if (shown) 1f else 0.85f, spring(Spring.DampingRatioMediumBouncy), label = "bs")
    val prog = remember { Animatable(0f) }
    LaunchedEffect(burst) { if (burst) prog.animateTo(1f, tween(700, easing = LinearOutSlowInEasing)) }
    val hl by animateFloatAsState(if (sel) 1f else 0f, tween(200), label = "hl")
    Column(Modifier.fillMaxWidth()) {
        if (showDay) {
            Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                Text(dayLabel(m.date), color = Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Row(Modifier.fillMaxWidth().drawBehind { drawRect(A2.copy(alpha = 0.16f * hl)) }, verticalAlignment = Alignment.CenterVertically) {
            AnimatedVisibility(
                selMode,
                enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + expandHorizontally(),
                exit = scaleOut() + shrinkHorizontally()
            ) { SelDot(sel) }
            Box(Modifier.weight(1f), contentAlignment = if (m.outgoing) Alignment.CenterEnd else Alignment.CenterStart) {
                SwipeBubble(m.outgoing, onStar, onDelete) {
                Box(Modifier.burstParticles(prog)) {
                    Box(
                        Modifier.graphicsLayer {
                            alpha = a * (1f - prog.value * 1.8f).coerceIn(0f, 1f)
                            val s = sc * (1f - 0.12f * prog.value)
                            scaleX = s; scaleY = s
                            transformOrigin = TransformOrigin(if (m.outgoing) 1f else 0f, 1f)
                        }.bounce(onClick = onTap, onLong = onLong)
                    ) { BubbleBody(m, reaction, starred, onTap, onLong, sender) }
                }
                }
            }
        }
    }
}

@Composable
fun QuickChip(label: String, onClick: () -> Unit) {
    Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(Surf2).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(label, color = Ink, fontSize = 14.sp)
    }
}

// ---------- chat ----------
@Composable
fun ChatScreen(vm: MessagesVM, chat: Chat, onForward: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val msgs by vm.msgs.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    val starred by vm.starred.collectAsState()
    val reacts by vm.reactions.collectAsState()
    val blocked by vm.blocked.collectAsState()
    var tfv by remember { mutableStateOf(TextFieldValue("")) }
    val text = tfv.text
    fun setText(x: String) { tfv = TextFieldValue(x, TextRange(x.length)) }
    var viewer by remember { mutableStateOf<String?>(null) }
    var pendingImg by remember { mutableStateOf<android.net.Uri?>(null) }
    var emoji by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var secs by remember { mutableStateOf(0) }
    val recorder = remember { Recorder(ctx) }
    val kb = LocalSoftwareKeyboardController.current
    val fm = LocalFocusManager.current
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var focused by remember { mutableStateOf<Msg?>(null) }
    var keep by remember { mutableStateOf<Msg?>(null) }
    var bursting by remember { mutableStateOf(setOf<Long>()) }
    var undo by remember { mutableStateOf<List<Saved>?>(null) }
    var searching by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var dialogMsg by remember { mutableStateOf<Msg?>(null) }
    var vaultMsg by remember { mutableStateOf<Msg?>(null) }
    var pending by remember { mutableStateOf<String?>(null) }
    var keepPending by remember { mutableStateOf("") }
    var trMsg by remember { mutableStateOf<Msg?>(null) }
    var voiceOpen by remember { mutableStateOf(false) }
    var voiceWant by remember { mutableStateOf(false) }
    SideEffect { pending?.let { keepPending = it } }
    val state = rememberLazyListState()
    val shown = remember(msgs, q, searching) {
        (if (searching && q.isNotBlank()) msgs.filter { it.body.contains(q, true) } else msgs).asReversed()
    }
    val selMode = selected.isNotEmpty()
    val blurR by animateDpAsState(if (focused != null || menu) 14.dp else 0.dp, tween(250), label = "cb")
    SideEffect { if (focused != null) keep = focused }
    LaunchedEffect(Unit) { val d = vm.draft.value; if (d.isNotEmpty()) { setText(d); vm.draft.value = "" } }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty() && !searching) state.animateScrollToItem(0) }
    LaunchedEffect(undo) { if (undo != null) { delay(5000); undo = null } }
    LaunchedEffect(pending) {
        val p = pending ?: return@LaunchedEffect
        delay(5000)
        if (pending == p) {
            vm.send(chat, p)
            pending = null
            if (!isDef) toast("Sent. Set as default app to keep history")
        }
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun reportSpam(m: Msg) {
        vm.draft.value = "SPAM " + chat.address + " " + m.body
        vm.startChat("1909")
        toast("Complaint drafted to 1909 \u2014 tap send")
    }
    fun textOf(ids: Set<Long>) = msgs.filter { it.id in ids }.joinToString("\n") { it.body }
    fun doDelete(ids: Set<Long>) {
        val pos = ids.filter { it > 0 }.toSet()
        val neg = ids.filter { it < 0 }.map { -it }
        if (pos.isNotEmpty() && !isDef) { toast("Set Messages as default SMS app to delete"); return }
        bursting = ids; selected = emptySet(); focused = null
        scope.launch {
            delay(720)
            val saved = if (pos.isNotEmpty()) vm.deleteMessages(chat, pos) else emptyList()
            if (neg.isNotEmpty()) vm.deleteMedia(neg)
            bursting = emptySet()
            if (saved.isNotEmpty()) undo = saved
        }
    }

    fun finishRec(send: Boolean) {
        recording = false
        if (send) {
            val f = recorder.stop()
            if (f != null && f.length() > 0) vm.sendVoice(chat, f) else toast("Recording too short")
        } else recorder.cancel()
    }
    fun startRec() { if (recorder.start()) { recording = true; secs = 0 } else toast("Can't start recording") }
    fun insertEmoji(e: String) {
        val sel = tfv.selection
        val t = tfv.text.replaceRange(sel.min, sel.max, e)
        tfv = TextFieldValue(t, TextRange(sel.min + e.length))
    }
    fun needDefault(): Boolean {
        if (!isDef) toast("Set Messages as default SMS app to send pictures & voice")
        return !isDef
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            if (voiceWant) { voiceWant = false; voiceOpen = true } else startRec()
        } else toast("Microphone permission needed")
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) pendingImg = uri
    }
    LaunchedEffect(recording) {
        if (recording) { while (true) { delay(1000); secs++; if (secs >= 120) { finishRec(true); break } } }
    }
    DisposableEffect(Unit) { onDispose { recorder.cancel(); Player.stop(); Voice.stop() } }
    BackHandler(selMode || focused != null || menu || searching || viewer != null || emoji || recording) {
        when {
            viewer != null -> viewer = null
            focused != null -> focused = null
            menu -> menu = false
            recording -> finishRec(false)
            emoji -> emoji = false
            selMode -> selected = emptySet()
            else -> { searching = false; q = "" }
        }
    }

    Box(Modifier.fillMaxSize().background(Bg).blockTouches()) {
        Column(Modifier.fillMaxSize().blur(blurR).statusBarsPadding().navigationBarsPadding().imePadding()) {
            AnimatedContent(selMode, transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) }, label = "bar") { sm ->
                if (sm) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(Icons.Rounded.Close) { selected = emptySet() }
                        Text("${selected.size} selected", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        IconBtn(Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(textOf(selected))); toast("Copied"); selected = emptySet() }
                        IconBtn(Icons.Rounded.Forward) { onForward(textOf(selected)); selected = emptySet() }
                        IconBtn(Icons.Rounded.Star) {
                            msgs.filter { it.id in selected }.forEach { x -> if (starred.none { it.id == x.id }) vm.toggleStar(chat, x) }
                            selected = emptySet()
                        }
                        IconBtn(Icons.Rounded.Delete, A3) { doDelete(selected) }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(Icons.Rounded.ArrowBack) { onBack() }
                        SenderAvatar(chat.address, chat.name, 42.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(chat.name, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val rep = remember(chat.address) { Reputation.of(chat.address) }
                            Text(rep ?: chat.address, color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        SimChip(chat.address)
                        IconBtn(Icons.Rounded.Search) { searching = !searching; if (!searching) q = "" }
                        IconBtn(Icons.Rounded.Call) { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(chat.address)))) }
                        IconBtn(Icons.Rounded.MoreVert) { menu = true }
                    }
                }
            }
            AnimatedVisibility(searching) {
                Box(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) { SearchField(q, { q = it }, "Search in chat", autofocus = true) }
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = state, reverseLayout = true,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                itemsIndexed(shown, key = { _, m -> m.id }) { i, m ->
                    Box(Modifier.animateItemPlacement()) {
                        Bubble(
                            m, shown.getOrNull(i + 1).let { it == null || !sameDay(it.date, m.date) },
                            selMode, m.id in selected, m.id in bursting, reacts[m.id], starred.any { it.id == m.id },
                            onTap = { if (selMode) selected = selected.toggle(m.id) else if (m.mime?.startsWith("image") == true && m.media != null) viewer = m.media },
                            onLong = { if (selMode) selected = selected.toggle(m.id) else focused = m },
                            sender = chat.address,
                            onStar = { vm.toggleStar(chat, m) },
                            onDelete = { doDelete(setOf(m.id)) }
                        )
                    }
                }
            }
            if (!isDef) Text("Set Messages as default SMS app to keep sent messages in this chat", color = Dim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
            AnimatedVisibility(undo != null, enter = slideInVertically(tween(300)) { it } + fadeIn(), exit = slideOutVertically(tween(250)) { it } + fadeOut()) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf2).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Moved to Recycle bin", color = Ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Text("UNDO", color = A2, fontWeight = FontWeight.ExtraBold, modifier = Modifier.bounce(onClick = { undo?.let { vm.restore(it) }; undo = null }).padding(4.dp))
                }
            }
            val lastIn = msgs.lastOrNull()?.let { !it.outgoing } == true
            AnimatedVisibility(lastIn && text.isEmpty() && !selMode && !recording) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("\uD83D\uDC4D", "Okay", "Thanks!", "Call me", "On my way", "Busy, will text later").forEach { r -> QuickChip(r) { setText(r) } }
                }
            }
            val info = remember(text) { if (text.length > 60) android.telephony.SmsMessage.calculateLength(text, false) else null }
            if (info != null) Text("${text.length} chars  \u2022  ${info[0]} SMS", color = Dim, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(end = 22.dp))
            AnimatedVisibility(
                pending != null,
                enter = slideInVertically(tween(260)) { it } + fadeIn(tween(180)),
                exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(150))
            ) {
                PendingBar(keepPending, onUndo = {
                    pending?.let { setText(it) }
                    pending = null
                    toast("Not sent")
                })
            }
            AnimatedVisibility(
                voiceOpen,
                enter = slideInVertically(tween(300)) { it } + fadeIn(tween(180)),
                exit = slideOutVertically(tween(240)) { it } + fadeOut(tween(150))
            ) {
                VoiceInputBar(
                    onDone = { t -> setText(if (text.isBlank()) t else text.trim() + " " + t); voiceOpen = false },
                    onCancel = { voiceOpen = false }
                )
            }
            if (recording) {
                RecordBar(secs, onCancel = { finishRec(false) }, onSend = { finishRec(true) })
            } else {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Bottom) {
                    Box(Modifier.size(46.dp).bounce(onClick = { emoji = !emoji; if (emoji) { kb?.hide(); fm.clearFocus() } }), contentAlignment = Alignment.Center) {
                        Icon(if (emoji) Icons.Rounded.Keyboard else Icons.Rounded.EmojiEmotions, null, tint = Dim)
                    }
                    Box(
                        Modifier.size(46.dp).bounce(onClick = {
                            kb?.hide(); fm.clearFocus()
                            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) voiceOpen = true
                            else { voiceWant = true; micPerm.launch(Manifest.permission.RECORD_AUDIO) }
                        }),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.GraphicEq, null, tint = if (voiceOpen) A2 else Dim) }
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(Surf).padding(horizontal = 18.dp, vertical = 14.dp)) {
                        if (text.isEmpty()) Text("Message", color = Dim, fontSize = 16.sp)
                        BasicTextField(
                            value = tfv, onValueChange = { tfv = it }, maxLines = 5,
                            textStyle = TextStyle(color = Ink, fontSize = 16.sp), cursorBrush = SolidColor(A2),
                            modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) emoji = false }
                        )
                    }
                    AnimatedVisibility(
                        text.isBlank(),
                        enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn() + expandHorizontally(),
                        exit = scaleOut() + fadeOut() + shrinkHorizontally()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).bounce(onClick = { pickImage.launch("image/*") }), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Image, null, tint = Dim)
                            }
                            Box(
                                Modifier.size(50.dp).bounce(onClick = {
                                    if (!needDefault()) {
                                        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec()
                                        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }).clip(CircleShape).background(Brand),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Rounded.Mic, null, tint = Color.White) }
                        }
                    }
                    AnimatedVisibility(
                        text.isNotBlank(),
                        enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn() + expandHorizontally(),
                        exit = scaleOut() + fadeOut() + shrinkHorizontally()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.padding(start = 4.dp).size(44.dp).bounce(onClick = { dialogMsg = null; dialog = "sched" }), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Schedule, null, tint = Dim)
                            }
                            Box(
                                Modifier.size(50.dp).bounce(onClick = {
                                    if (pending != null) { vm.send(chat, pending!!) }
                                    pending = text.trim()
                                    setText("")
                                }).clip(CircleShape).background(Brand),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Rounded.Send, null, tint = Color.White) }
                        }
                    }
                }
            }
            AnimatedVisibility(emoji) { EmojiPanel { e -> insertEmoji(e) } }
        }

        // hold-a-message overlay
        Scrim(focused != null, { focused = null }) {
            keep?.let { m ->
                val isStar = starred.any { it.id == m.id }
                Row(Modifier.shadow(12.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp)).background(Surf).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    listOf("👍", "❤️", "😂", "😮", "😢", "🙏").forEach { e ->
                        Text(e, fontSize = 26.sp, modifier = Modifier.bounce(onClick = { vm.react(m, e); focused = null }).padding(horizontal = 7.dp, vertical = 4.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.outgoing) Alignment.CenterEnd else Alignment.CenterStart) { BubbleBody(m, reacts[m.id], isStar) }
                Spacer(Modifier.height(14.dp))
                ActionCard(buildList {
                    m.code?.let { c -> add(Act(Icons.Rounded.ContentCopy, "Copy OTP $c") { clip.setText(AnnotatedString(c)); toast("OTP copied"); focused = null }) }
                    if (m.media == null) add(Act(Icons.Rounded.ContentCopy, "Copy text") { clip.setText(AnnotatedString(m.body)); toast("Copied"); focused = null })
                    if (m.media == null) Nums.find(m.body).forEach { n ->
                        add(Act(Icons.Rounded.ContentCopy, "Copy " + Nums.pretty(n)) { clip.setText(AnnotatedString(n)); toast("Number copied"); focused = null })
                    }
                    if (m.body.isNotBlank()) add(Act(Icons.Rounded.VolumeUp, "Read aloud") { Voice.speak(ctx, m.body); focused = null })
                    add(Act(Icons.Rounded.Bookmark, "Save to vault") { vaultMsg = m; focused = null })
                    if (m.body.isNotBlank()) add(Act(Icons.Rounded.Translate, "Translate") { trMsg = m; focused = null })
                    add(Act(Icons.Rounded.Report, "Report spam to 1909") { reportSpam(m); focused = null })
                    if (m.media == null) add(Act(Icons.Rounded.Forward, "Forward") { onForward(m.body); focused = null })
                    add(Act(Icons.Rounded.CheckCircle, "Select") { selected = setOf(m.id); focused = null })
                    if (m.media == null) add(Act(if (isStar) Icons.Rounded.StarBorder else Icons.Rounded.Star, if (isStar) "Unstar" else "Star") { vm.toggleStar(chat, m); focused = null })
                    if (m.media == null) add(Act(Icons.Rounded.Alarm, "Remind me") { dialogMsg = m; dialog = "remind"; focused = null })
                    if (m.media == null) add(Act(Icons.Rounded.Share, "Share") {
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, m.body), null))
                        focused = null
                    })
                    add(Act(Icons.Rounded.Info, "Details") { dialogMsg = m; dialog = "info"; focused = null })
                    add(Act(Icons.Rounded.Delete, "Delete", true) { doDelete(setOf(m.id)) })
                })
            }
        }

        Scrim(menu, { menu = false }) {
            ActionCard(listOf(
                Act(Icons.Rounded.VolumeUp, "Read chat aloud") {
                    val t = msgs.takeLast(8).joinToString(". ") {
                        if (it.outgoing) "You said: ${it.body}" else "${chat.name} said: ${it.body}"
                    }
                    Voice.speak(ctx, t)
                    menu = false
                },
                Act(Icons.Rounded.PictureAsPdf, "Export chat as PDF") {
                    val u = PdfExport.chat(ctx, chat.name, chat.address, msgs)
                    menu = false
                    if (u == null) toast("Couldn't create the PDF")
                    else try {
                        val i = Intent(Intent.ACTION_SEND).setType("application/pdf").putExtra(Intent.EXTRA_STREAM, u)
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        ctx.startActivity(Intent.createChooser(i, "Share chat PDF"))
                    } catch (_: Exception) { toast("Couldn't share the PDF") }
                },
                Act(Icons.Rounded.Report, "Report spam to 1909") {
                    val last = msgs.lastOrNull()
                    menu = false
                    if (last != null) reportSpam(last) else toast("Nothing to report")
                },
                Act(Icons.Rounded.Share, "Export chat") {
                    val me = "Me"
                    val t = msgs.joinToString("\n") { "[${fullDate(it.date)}] ${if (it.outgoing) me else chat.name}: ${it.body}" }
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Export chat"))
                    menu = false
                },
                Act(Icons.Rounded.Block, if (nk(chat.address) in blocked) "Unblock number" else "Block number") { vm.toggleBlock(chat.address); menu = false }
            ))
        }

        AnimatedVisibility(viewer != null, enter = fadeIn(tween(200)), exit = fadeOut(tween(150))) {
            Box(
                Modifier.fillMaxSize().background(Color.Black)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { viewer = null }
            ) { viewer?.let { ImageThumb(it, full = true) } }
        }

        pendingImg?.let { u ->
            val est by produceState<Pair<Int, Int>?>(null, u) {
                value = withContext(Dispatchers.IO) {
                    val a = SmsPic.shrink(ctx, u, 1200)
                    val b = SmsPic.shrink(ctx, u, 3000)
                    if (a != null && b != null) SmsPic.count(a) to SmsPic.count(b) else null
                }
            }
            AlertDialog(
                onDismissRequest = { pendingImg = null }, containerColor = Surf2,
                title = { Text("Send picture", color = Ink) },
                text = {
                    Column {
                        Text("Works on any SIM and any phone network. The picture is shrunk and sent as small SMS messages (each one costs a normal SMS). Your friend needs Messages to see it.", color = Dim, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Tiny \u2022 about ${est?.first ?: "…"} SMS", color = Ink, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().bounce(onClick = { vm.sendImageSms(chat, u, 1200); pendingImg = null }).padding(vertical = 12.dp))
                        Text("Clearer \u2022 about ${est?.second ?: "…"} SMS", color = Ink, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().bounce(onClick = { vm.sendImageSms(chat, u, 3000); pendingImg = null }).padding(vertical = 12.dp))
                        Text("Full quality (MMS, needs carrier MMS)", color = A2, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().bounce(onClick = { if (!needDefault()) { vm.sendImage(chat, u, text.trim()); setText("") }; pendingImg = null }).padding(vertical = 12.dp))
                    }
                },
                confirmButton = { },
                dismissButton = { TextButton(onClick = { pendingImg = null }) { Text("Cancel", color = Dim) } }
            )
        }

        if (dialog == "remind" || dialog == "sched") {
            val isRemind = dialog == "remind"
            SchedulePicker(
                if (isRemind) "Remind me" else "Send later",
                onCancel = { dialog = null },
                onPick = { at ->
                    if (isRemind) {
                        dialogMsg?.let { vm.schedule("remind", chat.address, it.body, at) }
                        toast("Reminder set for " + fullDate(at))
                    } else {
                        vm.schedule("send", chat.address, text.trim(), at)
                        setText("")
                        toast("Scheduled for " + fullDate(at))
                    }
                    dialog = null
                }
            )
        }
        trMsg?.let { m -> TranslateSheet(m.body) { trMsg = null } }
        vaultMsg?.let { m ->
            VaultSaveSheet(
                initial = m.body,
                onCancel = { vaultMsg = null },
                onSave = { label, value, kind -> vm.saveVault(label, value, kind); vaultMsg = null; toast("Saved to vault") }
            )
        }
        if (dialog == "info") {
            dialogMsg?.let { m ->
                AlertDialog(
                    onDismissRequest = { dialog = null }, containerColor = Surf2,
                    title = { Text("Message details", color = Ink) },
                    text = {
                        Text(
                            (if (m.outgoing) "To: ${chat.name}" else "From: ${chat.name}") + "\n${chat.address}\n\n" +
                                fullDate(m.date) + "\n${m.body.length} characters\nType: Text message (SMS)\n" +
                                (if (m.failed) "Status: Not sent" else if (m.pending) "Status: Sending" else "Status: OK"),
                            color = Dim
                        )
                    },
                    confirmButton = { TextButton(onClick = { dialog = null }) { Text("Close", color = A2) } }
                )
            }
        }
    }
}

// ---------- schedule with date & time ----------
@Composable
fun SchedulePicker(title: String, onCancel: () -> Unit, onPick: (Long) -> Unit) {
    val start = remember {
        Calendar.getInstance().apply {
            add(Calendar.HOUR_OF_DAY, 1); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
    }
    var day by remember { mutableStateOf(dayStart(start.timeInMillis)) }
    var hour by remember { mutableStateOf(start.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableStateOf(start.get(Calendar.MINUTE)) }
    var month by remember { mutableStateOf((start.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }) }
    val at = combine(day, hour, minute)
    AlertDialog(
        onDismissRequest = onCancel, containerColor = Surf2,
        title = { Text(title, color = Ink) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    timeOptions().forEach { pair ->
                        Box(
                            Modifier.bounce(onClick = { onPick(pair.second) })
                                .clip(RoundedCornerShape(50)).background(Surf)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) { Text(pair.first, color = Ink, fontSize = 13.sp) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(Icons.Rounded.ChevronLeft, Dim) {
                        month = (month.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
                    }
                    Text(
                        SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(month.timeInMillis)),
                        color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f), textAlign = TextAlign.Center
                    )
                    IconBtn(Icons.Rounded.ChevronRight, Dim) {
                        month = (month.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
                    }
                }
                Row(Modifier.fillMaxWidth()) {
                    listOf("S", "M", "T", "W", "T", "F", "S").forEach { d ->
                        Text(d, color = Dim, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    }
                }
                val first = (month.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
                val offset = first.get(Calendar.DAY_OF_WEEK) - 1
                val total = first.getActualMaximum(Calendar.DAY_OF_MONTH)
                val rowCount = (offset + total + 6) / 7
                for (r in 0 until rowCount) {
                    Row(Modifier.fillMaxWidth()) {
                        for (c in 0 until 7) {
                            val dnum = r * 7 + c - offset + 1
                            Box(Modifier.weight(1f).padding(1.dp), contentAlignment = Alignment.Center) {
                                if (dnum in 1..total) {
                                    val dms = dayStart((month.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, dnum) }.timeInMillis)
                                    val sel = dms == day
                                    val past = dms < dayStart(System.currentTimeMillis())
                                    Box(
                                        Modifier.size(34.dp).clip(CircleShape)
                                            .background(if (sel) A1 else Color.Transparent)
                                            .bounce(onClick = { if (!past) day = dms }),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            "$dnum",
                                            color = if (sel) Color.White else if (past) Dim.copy(alpha = 0.4f) else Ink,
                                            fontSize = 14.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                    TimeStep(if (hour % 12 == 0) 12 else hour % 12) { d -> hour = (hour + d + 24) % 24 }
                    Text(":", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                    TimeStep(minute) { d -> minute = (minute + d * 5 + 60) % 60 }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.bounce(onClick = { hour = (hour + 12) % 24 })
                            .clip(RoundedCornerShape(50)).background(Surf).padding(horizontal = 14.dp, vertical = 8.dp)
                    ) { Text(if (hour < 12) "AM" else "PM", color = A2, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(10.dp))
                Text(fullDate(at), color = Dim, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onPick(at) }) { Text("Set", color = A2, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Dim) } }
    )
}

@Composable
fun TimeStep(value: Int, onStep: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconBtn(Icons.Rounded.KeyboardArrowUp, Ink) { onStep(1) }
        Text(if (value < 10) "0$value" else "$value", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        IconBtn(Icons.Rounded.KeyboardArrowDown, Ink) { onStep(-1) }
    }
}

@Composable
fun VaultSaveSheet(initial: String, onCancel: () -> Unit, onSave: (String, String, String) -> Unit) {
    val firstNum = remember(initial) { Nums.find(initial).firstOrNull() ?: initial.trim().take(60) }
    var label by remember { mutableStateOf("") }
    var value by remember { mutableStateOf(firstNum) }
    var kind by remember { mutableStateOf(if (firstNum.count { it.isDigit() } == 10 && firstNum[0] in '6'..'9') "other" else "pnr") }
    AlertDialog(
        onDismissRequest = onCancel, containerColor = Surf2,
        title = { Text("Save to vault", color = Ink) },
        text = {
            Column {
                Text("Kept on this phone, behind your fingerprint.", color = Dim, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VAULT_KINDS.forEach { k ->
                        Box(
                            Modifier.bounce(onClick = { kind = k.id }).clip(RoundedCornerShape(50))
                                .background(if (kind == k.id) A1 else Surf).padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(k.label, color = if (kind == k.id) Color.White else Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                InputField(label, { label = it }, "Label — e.g. Indigo PNR")
                Spacer(Modifier.height(8.dp))
                InputField(value, { value = it }, "Number or text")
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (value.isNotBlank()) onSave(label.trim().ifBlank { vaultKind(kind).label }, value.trim(), kind)
            }) { Text("Save", color = A2, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Dim) } }
    )
}

// ---------- undo send bar ----------
@Composable
fun PendingBar(text: String, onUndo: () -> Unit) {
    val p = remember { Animatable(1f) }
    LaunchedEffect(text) {
        p.snapTo(1f)
        p.animateTo(0f, tween(5000, easing = LinearEasing))
    }
    Column(
        Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth()
            .clip(RoundedCornerShape(20.dp)).background(Surf).padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Schedule, null, tint = A2, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text("Sending in a moment…", color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text(
                "UNDO", color = A2, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.bounce(onClick = onUndo).padding(6.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(50)).background(Surf2)) {
            Box(Modifier.fillMaxWidth(p.value).height(3.dp).clip(RoundedCornerShape(50)).background(Brand))
        }
        Spacer(Modifier.height(8.dp))
        Text(text, color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ---------- premium voice typing bar ----------
@Composable
fun VoiceInputBar(onDone: (String) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    var heard by remember { mutableStateOf("") }
    var level by remember { mutableStateOf(0f) }
    var listening by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    val holder = remember { mutableStateOf<SpeechRecognizer?>(null) }
    val wave = rememberInfiniteTransition(label = "wave")
    val ph by wave.animateFloat(
        0f, 6.2832f,
        infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "ph"
    )

    fun begin() {
        val r = holder.value ?: return
        failed = false
        heard = ""
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        try {
            r.startListening(i)
            listening = true
        } catch (_: Exception) { failed = true }
    }

    DisposableEffect(Unit) {
        val r = try { SpeechRecognizer.createSpeechRecognizer(ctx) } catch (_: Exception) { null }
        holder.value = r
        if (r == null) {
            failed = true
        } else {
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() { }
                override fun onRmsChanged(rmsdB: Float) { level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { listening = false; level = 0f }
                override fun onError(error: Int) {
                    listening = false
                    level = 0f
                    if (heard.isBlank()) failed = true
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    level = 0f
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (t.isNotBlank()) heard = t
                    if (heard.isNotBlank()) onDone(heard) else failed = true
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (t.isNotBlank()) heard = t
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            begin()
        }
        onDispose {
            try { r?.stopListening(); r?.destroy() } catch (_: Exception) { }
            holder.value = null
        }
    }

    Column(
        Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth()
            .clip(RoundedCornerShape(26.dp)).background(Surf).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(if (listening) A3 else Dim))
            Spacer(Modifier.width(8.dp))
            Text(
                when {
                    listening -> "Listening…"
                    failed -> "Didn't catch that"
                    else -> "Say your message"
                },
                color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
            )
            Icon(Icons.Rounded.Close, null, tint = Dim, modifier = Modifier.size(20.dp).bounce(onClick = onCancel))
        }
        Spacer(Modifier.height(10.dp))
        Canvas(Modifier.fillMaxWidth().height(58.dp)) {
            val n = 26
            val gap = size.width / n
            for (i in 0 until n) {
                val wob = kotlin.math.sin(ph + i * 0.7f)
                val amp = if (listening) level else 0.12f
                val h = 5f + size.height * 0.62f * amp * (0.45f + 0.55f * kotlin.math.abs(wob))
                val x = i * gap + gap / 2f
                drawRoundRect(
                    color = if (listening) A2 else Dim.copy(alpha = 0.35f),
                    topLeft = Offset(x - gap * 0.18f, (size.height - h) / 2f),
                    size = Size(gap * 0.36f, h),
                    cornerRadius = CornerRadius(gap * 0.2f, gap * 0.2f)
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            if (heard.isBlank()) "Your words appear here as you speak." else heard,
            color = if (heard.isBlank()) Dim else Ink, fontSize = 16.sp, maxLines = 3, overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (failed) Text(
                "Try again", color = A2, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.bounce(onClick = { begin() }).padding(8.dp)
            )
            Spacer(Modifier.weight(1f))
            Text(
                if (heard.isBlank()) "Type instead" else "Use this",
                color = if (heard.isBlank()) Dim else A2, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.bounce(onClick = {
                    if (heard.isNotBlank()) onDone(heard) else onCancel()
                }).padding(8.dp)
            )
        }
    }
}

// ---------- translate a message ----------
@Composable
fun TranslateSheet(text: String, onClose: () -> Unit) {
    val clip = LocalClipboardManager.current
    val from = remember(text) { Translate.detect(text) }
    var target by remember { mutableStateOf(if (from == "en") "hi" else "en") }
    var out by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(true) }

    fun go(code: String) {
        target = code
        busy = true
        out = null
        Translate.run(text, code) { r ->
            out = r ?: ""
            busy = false
        }
    }

    LaunchedEffect(text) { go(target) }

    AlertDialog(
        onDismissRequest = onClose, containerColor = Surf2,
        title = { Text("Translate", color = Ink) },
        text = {
            Column {
                Text(
                    Translate.name(from) + "  \u2192  " + Translate.name(target),
                    color = Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("en", "hi", "ta", "bn", "te", "mr", "kn", "ml", "gu", "pa").forEach { c ->
                        Box(
                            Modifier.bounce(onClick = { go(c) }).clip(RoundedCornerShape(50))
                                .background(if (target == c) A1 else Surf).padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Text(
                                Translate.name(c), color = if (target == c) Color.White else Dim,
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(text, color = Dim, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                when {
                    busy -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = A2, strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Getting the language pack…", color = Dim, fontSize = 13.sp)
                    }
                    out.isNullOrEmpty() -> Text(
                        "Couldn't translate. Stay online for the first use of each language so the pack can download.",
                        color = A3, fontSize = 13.sp
                    )
                    else -> Text(out ?: "", color = Ink, fontSize = 16.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                out?.let { if (it.isNotEmpty()) clip.setText(AnnotatedString(it)) }
                onClose()
            }) { Text("Copy", color = A2, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Close", color = Dim) } }
    )
}
