package com.messages.app

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.CancellationSignal
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * The vault's second lock: a PIN that works when the fingerprint doesn't,
 * tied to a phone number, with an offline one-time code for recovery.
 * Nothing here talks to a server.
 */
object VaultSecurity {
    private const val P = "vaultsec"

    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    private fun hash(pin: String, salt: String): String = try {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val raw = f.generateSecret(PBEKeySpec(pin.toCharArray(), salt.toByteArray(), 60_000, 256)).encoded
        raw.joinToString("") { String.format("%02x", it) }
    } catch (_: Exception) { "" }

    fun hasPin(c: Context): Boolean = (sp(c).getString("hash", "") ?: "").isNotEmpty()

    fun setPin(c: Context, pin: String) {
        val salt = "s" + System.currentTimeMillis()
        sp(c).edit().putString("salt", salt).putString("hash", hash(pin, salt)).apply()
        SafeData.touch(c)
    }

    fun checkPin(c: Context, pin: String): Boolean {
        val s = sp(c).getString("salt", "") ?: return false
        val h = sp(c).getString("hash", "") ?: return false
        return h.isNotEmpty() && h == hash(pin, s)
    }

    fun phone(c: Context): String = sp(c).getString("phone", "") ?: ""
    fun setPhone(c: Context, v: String) {
        sp(c).edit().putString("phone", v.filter { it.isDigit() }).apply()
        SafeData.touch(c)
    }

    // ---------- decoy PIN: opens a fake vault ----------
    fun hasDecoy(c: Context): Boolean = (sp(c).getString("dhash", "") ?: "").isNotEmpty()

    fun setDecoy(c: Context, pin: String) {
        val salt = "d" + System.currentTimeMillis()
        sp(c).edit().putString("dsalt", salt).putString("dhash", hash(pin, salt)).apply()
        SafeData.touch(c)
    }

    fun clearDecoy(c: Context) {
        sp(c).edit().remove("dsalt").remove("dhash").apply()
        SafeData.touch(c)
    }

    fun checkDecoy(c: Context, pin: String): Boolean {
        val s = sp(c).getString("dsalt", "") ?: return false
        val h = sp(c).getString("dhash", "") ?: return false
        return h.isNotEmpty() && h == hash(pin, s)
    }

    fun misses(c: Context): Int = sp(c).getInt("misses", 0)

    // ---------- travels with the safe copy ----------
    fun exportSec(c: Context): org.json.JSONObject = org.json.JSONObject()
        .put("hash", sp(c).getString("hash", "") ?: "")
        .put("salt", sp(c).getString("salt", "") ?: "")
        .put("phone", sp(c).getString("phone", "") ?: "")
        .put("dhash", sp(c).getString("dhash", "") ?: "")
        .put("dsalt", sp(c).getString("dsalt", "") ?: "")
        .put("ion", sp(c).getBoolean("intruder", false))
        .put("intr", Intruder.rawLog(c))

    /** Only fills in what this install is missing, never replaces a PIN that was set here. */
    fun importSec(c: Context, o: org.json.JSONObject) {
        val e = sp(c).edit()
        if (!hasPin(c)) {
            val h = o.optString("hash", "")
            val sl = o.optString("salt", "")
            if (h.isNotEmpty() && sl.isNotEmpty()) e.putString("hash", h).putString("salt", sl)
        }
        if (!hasDecoy(c)) {
            val dh = o.optString("dhash", "")
            val ds = o.optString("dsalt", "")
            if (dh.isNotEmpty() && ds.isNotEmpty()) e.putString("dhash", dh).putString("dsalt", ds)
        }
        if (Intruder.log(c).isEmpty()) {
            val il = o.optString("intr", "")
            if (il.length > 2) e.putString("intr", il)
        }
        if (o.optBoolean("ion", false) && !sp(c).contains("intruder")) e.putBoolean("intruder", true)
        if (phone(c).isEmpty()) {
            val ph = o.optString("phone", "")
            if (ph.isNotEmpty()) e.putString("phone", ph)
        }
        e.apply()
    }

    // ---------- wrong-PIN lockout ----------
    /** Milliseconds left before another PIN try is allowed, 0 when free to try. */
    fun lockLeft(c: Context): Long = (sp(c).getLong("lockUntil", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    /** Counts a wrong PIN. From the 5th miss the wait doubles each time (30s, 1m, 2m ... up to 1h). */
    fun registerMiss(c: Context): Long {
        val n = sp(c).getInt("misses", 0) + 1
        var wait = 0L
        if (n >= 5) wait = (30_000L shl (n - 5).coerceAtMost(7)).coerceAtMost(3_600_000L)
        sp(c).edit().putInt("misses", n).putLong("lockUntil", if (wait > 0) System.currentTimeMillis() + wait else 0L).apply()
        return wait
    }

    fun clearMisses(c: Context) { sp(c).edit().putInt("misses", 0).putLong("lockUntil", 0L).apply() }

    fun phoneMatches(c: Context, entered: String): Boolean {
        val saved = phone(c)
        if (saved.length < 10) return true
        return saved.takeLast(10) == entered.filter { it.isDigit() }.takeLast(10)
    }

    /** The phone's own number, when the SIM is willing to tell us. */
    fun simNumber(c: Context): String {
        return try {
            if (c.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) "" else {
                val tm = c.getSystemService(TelephonyManager::class.java)
                (tm?.line1Number ?: "").filter { it.isDigit() }.takeLast(10)
            }
        } catch (_: Exception) { "" }
    }

    // ---------- offline one-time code ----------
    fun issueOtp(c: Context): String {
        val code = (100000..999999).random().toString()
        sp(c).edit()
            .putString("otp", code)
            .putLong("otpAt", System.currentTimeMillis())
            .apply()
        Notifier.vaultOtp(c, code)
        return code
    }

    fun checkOtp(c: Context, entered: String): Boolean {
        val code = sp(c).getString("otp", "") ?: return false
        val at = sp(c).getLong("otpAt", 0L)
        if (code.isEmpty() || System.currentTimeMillis() - at > 5 * 60_000L) return false
        return code == entered.trim()
    }

    fun clearOtp(c: Context) {
        sp(c).edit().remove("otp").remove("otpAt").apply()
    }

    fun forgetPin(c: Context) {
        sp(c).edit().remove("hash").remove("salt").apply()
        clearOtp(c)
        SafeData.touch(c)
    }

    // ---------- biometrics ----------
    fun biometric(c: Context, onOk: () -> Unit, onFail: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < 29) {
            onFail("No fingerprint sensor")
            return
        }
        try {
            val exec = ContextCompat.getMainExecutor(c)
            val cancel = CancellationSignal()
            val b = android.hardware.biometrics.BiometricPrompt.Builder(c)
                .setTitle("Unlock vault")
                .setSubtitle("Fingerprint, face or phone PIN")
            if (Build.VERSION.SDK_INT >= 30) {
                b.setAllowedAuthenticators(
                    android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK or
                        android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
            } else {
                @Suppress("DEPRECATION")
                b.setDeviceCredentialAllowed(true)
            }
            b.build().authenticate(
                cancel, exec,
                object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                        onOk()
                    }

                    override fun onAuthenticationError(code: Int, err: CharSequence?) {
                        onFail(err?.toString() ?: "Couldn't unlock")
                    }
                }
            )
        } catch (_: Exception) {
            onFail("Biometrics unavailable")
        }
    }

    fun keyguard(c: Context): android.content.Intent? = try {
        val km = c.getSystemService(android.app.KeyguardManager::class.java)
        if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("Vault", "Unlock to continue") else null
    } catch (_: Exception) { null }

    fun activity(c: Context): Activity? = c as? Activity
}
