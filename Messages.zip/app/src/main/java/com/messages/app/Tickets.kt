package com.messages.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** A ticket dug out of an IRCTC / airline SMS. */
class Ticket(
    val pnr: String, val trainNo: String, val trainName: String,
    val from: String, val to: String, val whenMs: Long,
    val cls: String, val coach: String, val berth: String,
    val body: String, val address: String, val at: Long
) {
    val title: String
        get() = listOf(trainNo, trainName).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Ticket" }

    val route: String
        get() = if (from.isBlank() && to.isBlank()) "" else from + " \u2192 " + to

    val seat: String
        get() = listOf(cls, coach, berth).filter { it.isNotBlank() }.joinToString(" ")

    val sub: String
        get() = listOf(route, if (whenMs > 0) Tickets.shortDate(whenMs) else "", seat)
            .filter { it.isNotBlank() }.joinToString(" \u00B7 ")
}

object Tickets {
    const val IRCTC = "https://www.indianrail.gov.in/enquiry/PNR/PnrEnquiry.html"

    private val pnrKeyed = Regex("(?i)\\bpnr\\s*(?:no\\.?|number)?\\s*[:\\-]?\\s*(\\d{10})\\b")
    private val pnrAny = Regex("\\b(\\d{10})\\b")
    private val trainRe = Regex("\\b(\\d{5})\\s*[/\\-]?\\s*([A-Z][A-Z0-9 ]{2,28})")
    private val classRe = Regex("\\b(1A|2A|3A|3E|SL|CC|EC|2S|FC)\\b")
    private val seatRe = Regex("\\b([A-Z]{1,2}\\d{1,2})\\s*[/\\-]\\s*(\\d{1,3})\\b")
    private val fromTo = Regex("(?i)\\bfrom\\s*[:\\-]?\\s*([A-Za-z]{2,18})\\s+(?:to|\\u2192)\\s*([A-Za-z]{2,18})")
    private val codes = Regex("\\b([A-Z]{3,5})\\s*(?:-|\\u2192|to)\\s*([A-Z]{3,5})\\b")
    private val dateRe = Regex("\\b(\\d{1,2})[-/. ](\\d{1,2}|[A-Za-z]{3,9})[-/. ](\\d{2,4})\\b")
    private val months = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

    fun shortDate(t: Long): String = SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))

    fun whenLabel(t: Long): String {
        if (t <= 0L) return ""
        val days = ((dayStart(t) - dayStart(System.currentTimeMillis())) / 86_400_000L).toInt()
        return when {
            days == 0 -> "Today"
            days == 1 -> "Tomorrow"
            days > 1 && days < 8 -> "In $days days"
            days < 0 -> shortDate(t)
            else -> shortDate(t)
        }
    }

    private fun parseDate(s: String): Long {
        val m = dateRe.find(s) ?: return 0L
        val day = m.groupValues[1].toIntOrNull() ?: return 0L
        val mid = m.groupValues[2]
        val mon = mid.toIntOrNull()?.minus(1) ?: months.indexOf(mid.lowercase().take(3))
        if (mon !in 0..11 || day !in 1..31) return 0L
        var year = m.groupValues[3].toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
        if (year < 100) year += 2000
        val cal = Calendar.getInstance()
        cal.set(year, mon, day, 6, 0, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (m.groupValues[3].length <= 2 && cal.timeInMillis < System.currentTimeMillis() - 30L * 86_400_000L) {
            cal.add(Calendar.YEAR, 1)
        }
        return cal.timeInMillis
    }

    /** Pulls the useful fields out of one message, or null if it isn't a ticket. */
    fun parse(body: String, address: String, at: Long): Ticket? {
        val looksRail = body.contains("PNR", true) || body.contains("IRCTC", true) ||
            body.contains("train", true) || body.contains("coach", true)
        if (!looksRail) return null
        val pnr = pnrKeyed.find(body)?.groupValues?.get(1)
            ?: pnrAny.find(body)?.groupValues?.get(1)
            ?: return null
        val train = trainRe.find(body)
        var trainNo = ""
        var trainName = ""
        if (train != null) {
            trainNo = train.groupValues[1]
            trainName = train.groupValues[2].trim().trimEnd('.', ',', '-').take(28)
            if (trainName.equals("train", true)) trainName = ""
        }
        val cls = classRe.find(body)?.value ?: ""
        val seat = seatRe.find(body)
        var coach = ""
        var berth = ""
        if (seat != null) {
            coach = seat.groupValues[1]
            berth = seat.groupValues[2]
        }
        var from = ""
        var to = ""
        fromTo.find(body)?.let {
            from = it.groupValues[1].uppercase()
            to = it.groupValues[2].uppercase()
        }
        if (from.isEmpty() && to.isEmpty()) {
            codes.find(body)?.let {
                from = it.groupValues[1]
                to = it.groupValues[2]
            }
        }
        val whenMs = parseDate(body)
        return Ticket(pnr, trainNo, trainName, from, to, whenMs, cls, coach, berth, body, address, at)
    }

    /** Looks through recent messages for tickets the user hasn't saved yet. */
    fun scan(ctx: Context, skip: Set<String> = emptySet()): List<Ticket> {
        val out = ArrayList<Ticket>()
        try {
            ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf("address", "body", "date"),
                "(body LIKE ? OR body LIKE ? OR body LIKE ?)",
                arrayOf("%PNR%", "%pnr%", "%IRCTC%"),
                "date DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 200) {
                    n++
                    val a = c.getString(0) ?: ""
                    val b = c.getString(1) ?: continue
                    val d = c.getLong(2)
                    val t = parse(b, a, d) ?: continue
                    if (t.pnr in skip) continue
                    if (out.any { it.pnr == t.pnr }) continue
                    out.add(t)
                }
            }
        } catch (_: Exception) { }
        return out
    }

    /** Reminder three hours before departure. */
    fun remind(c: Context, t: Ticket) {
        if (t.whenMs <= 0L) return
        val at = t.whenMs - 3L * 3_600_000L
        if (at <= System.currentTimeMillis() + 60_000L) return
        try {
            val am = c.getSystemService(AlarmManager::class.java) ?: return
            val pi = PendingIntent.getBroadcast(
                c, (t.pnr.hashCode() and 0x7FFFFFFF),
                Intent(c, TripReceiver::class.java)
                    .putExtra("title", t.title)
                    .putExtra("body", t.route + "  \u00B7  " + t.seat + "  \u00B7  PNR " + t.pnr),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.set(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Exception) { }
    }
}

class TripReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val title = i.getStringExtra("title") ?: "Your trip"
        val body = i.getStringExtra("body") ?: ""
        Notifier.trip(c, "Leaving in 3 hours \u00B7 " + title, body)
    }
}
