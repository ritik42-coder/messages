package com.messages.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private val StageBg = Color(0xFF06060B)

// =============================================================================================
// Entry: permissions, one-time model download, then the stage
// =============================================================================================
@Composable
fun HandShareScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val need = remember { nearbyPerms() + Manifest.permission.CAMERA }
    var granted by remember { mutableStateOf(need.all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = need.all { p -> ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED }
    }
    var modelReady by remember { mutableStateOf(HandModel.ready(ctx)) }
    var dl by remember { mutableStateOf(-1) }
    var dlFailed by remember { mutableStateOf(false) }
    BackHandler { onBack() }

    if (granted && modelReady) {
        HandStage(onBack)
        return
    }

    Box(Modifier.fillMaxSize().background(StageBg).statusBarsPadding().padding(24.dp)) {
        Icon(
            Icons.Rounded.ArrowBack, null, tint = Color.White,
            modifier = Modifier.align(Alignment.TopStart).bounce(onClick = onBack).padding(6.dp).size(26.dp)
        )
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(96.dp).clip(CircleShape).background(Brush.linearGradient(listOf(A1, A2, A3))),
                contentAlignment = Alignment.Center
            ) { Text("\u270B", fontSize = 44.sp) }
            Spacer(Modifier.height(20.dp))
            Text("Hand share", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Close your hand over a photo on one phone, open it over another phone, and the photo moves across. No internet needed.",
                color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))
            SetupStep(
                "1", "Allow camera and nearby phones", "So the app can see your hand and find the other phone.",
                done = granted
            ) { if (!granted) permLauncher.launch(need) }
            Spacer(Modifier.height(12.dp))
            SetupStep(
                "2",
                if (dl in 0..99) "Downloading hand recognition… $dl%" else "Download hand recognition",
                if (dlFailed) "That didn't work. Check your internet and tap to try again."
                else "About 8 MB, once. After this it works fully offline.",
                done = modelReady
            ) {
                if (!modelReady && dl < 0) {
                    dl = 0
                    dlFailed = false
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { HandModel.download(ctx) { p -> dl = p } }
                        if (ok) modelReady = true else dlFailed = true
                        dl = -1
                    }
                }
            }
            if (dl in 0..99) {
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { dl / 100f }, color = A2, trackColor = Color.White.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape)
                )
            }
        }
    }
}

@Composable
private fun SetupStep(n: String, title: String, sub: String, done: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().bounce(onClick = onClick).clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.07f)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(if (done) A2 else Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            if (done) Icon(Icons.Rounded.CheckCircle, null, tint = Color.White, modifier = Modifier.size(22.dp))
            else Text(n, color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }
    }
}

// =============================================================================================
// Camera: preview in a lens, frames go to the hand recogniser
// =============================================================================================
@Composable
private fun HandCamera(modifier: Modifier) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val vision by produceState<HandVision?>(null) {
        val v = withContext(Dispatchers.IO) { HandVision(ctx) }
        value = if (v.ok) v else null
        awaitDispose { v.close() }
    }
    val previewView = remember {
        PreviewView(ctx).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    DisposableEffect(vision, owner) {
        val v = vision
        val fut = ProcessCameraProvider.getInstance(ctx)
        var provider: ProcessCameraProvider? = null
        val exec = Executors.newSingleThreadExecutor()
        fut.addListener({
            try {
                val p = fut.get()
                provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val cases = ArrayList<UseCase>()
                cases.add(preview)
                if (v != null) {
                    val ia = ImageAnalysis.Builder()
                        .setTargetResolution(Size(480, 640))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                        .build()
                    ia.setAnalyzer(exec, v)
                    cases.add(ia)
                }
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, *cases.toTypedArray())
            } catch (_: Throwable) { }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            try { provider?.unbindAll() } catch (_: Throwable) { }
            exec.shutdown()
        }
    }
    AndroidView(factory = { previewView }, modifier = modifier)
}

// =============================================================================================
// The stage
// =============================================================================================
@Composable
private fun HandStage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val dens = LocalDensity.current

    val phase by HandShare.phase.collectAsState()
    val peers by HandShare.peers.collectAsState()
    val progress by HandShare.progress.collectAsState()
    val status by HandShare.status.collectAsState()
    val hand by HandShare.hand.collectAsState()
    val outgoing by HandShare.outgoing.collectAsState()
    val thumb by HandShare.incomingThumb.collectAsState()
    val fromName by HandShare.fromName.collectAsState()
    val gotPath by HandShare.received.collectAsState()

    DisposableEffect(Unit) {
        HandShare.begin(ctx)
        onDispose { HandShare.end() }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { HandShare.setPhoto(ctx, uri) }
            if (!ok) Toast.makeText(ctx, "Couldn't open that picture", Toast.LENGTH_SHORT).show()
        }
    }

    val gotBmp by produceState<ImageBitmap?>(null, gotPath) {
        value = gotPath?.let { p -> withContext(Dispatchers.IO) { Thumbs.get(p, 1800) } }
    }

    // sparkle burst on arrival and departure
    val burst = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        HandShare.events.collect { e ->
            haptic.performHapticFeedback(if (e == "arm" || e == "incoming") HapticFeedbackType.TextHandleMove else HapticFeedbackType.LongPress)
            if (e == "sent" || e == "got") {
                burst.snapTo(0f)
                burst.animateTo(1f, tween(1100))
            }
        }
    }
    LaunchedEffect(phase) {
        if (phase == HandPhase.SENT) {
            delay(2700)
            HandShare.dismissSent()
        }
    }

    // ---- geometry
    var stage by remember { mutableStateOf(IntSize.Zero) }
    val W = stage.width.toFloat()
    val H = stage.height.toFloat()
    val orbD = with(dens) { 150.dp.toPx() }
    val cardW = (W * 0.76f).coerceAtMost(H * 0.40f).coerceAtLeast(1f)
    val cardH = cardW * 1.28f

    val orbMode = phase == HandPhase.HOLDING || phase == HandPhase.SENDING || phase == HandPhase.SENT ||
        phase == HandPhase.INCOMING || phase == HandPhase.RECEIVING
    val morph by animateFloatAsState(if (orbMode) 1f else 0f, spring(dampingRatio = 0.66f, stiffness = 170f), label = "morph")
    val lift by animateFloatAsState(if (phase == HandPhase.ARMED) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 320f), label = "lift")
    val follow = phase == HandPhase.HOLDING || phase == HandPhase.INCOMING || phase == HandPhase.RECEIVING
    val hp = hand
    val tgtX = if (follow && hp != null) hp.x * W else W / 2f
    val tgtY = if (follow && hp != null) H * (0.16f + 0.44f * hp.y) else H * 0.38f
    val orbX by animateFloatAsState(tgtX, spring(dampingRatio = 0.82f, stiffness = 110f), label = "ox")
    val orbY by animateFloatAsState(tgtY, spring(dampingRatio = 0.82f, stiffness = 110f), label = "oy")
    val curX by animateFloatAsState(if (hp != null) hp.x * W else W / 2f, spring(dampingRatio = 0.9f, stiffness = 260f), label = "hx")
    val curY by animateFloatAsState(if (hp != null) hp.y * H else H / 2f, spring(dampingRatio = 0.9f, stiffness = 260f), label = "hy")
    val curA by animateFloatAsState(if (hp != null) 1f else 0f, tween(180), label = "ha")

    val inf = rememberInfiniteTransition(label = "inf")
    val wave by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "wave")
    val drift by inf.animateFloat(0f, 6.2831855f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Restart), label = "drift")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "pulse")

    val ring by animateFloatAsState(
        when (phase) {
            HandPhase.ARMED -> 1f
            HandPhase.HOLDING, HandPhase.SENDING, HandPhase.SENT -> 2f
            HandPhase.INCOMING, HandPhase.RECEIVING, HandPhase.RECEIVED -> 3f
            else -> 0f
        }, tween(300), label = "ring"
    )
    val ringColor = when {
        ring >= 2.5f -> A1
        ring >= 1.5f -> Gold
        ring >= 0.5f -> A2
        else -> Color.White.copy(alpha = 0.35f)
    }

    Box(Modifier.fillMaxSize().background(StageBg).onSizeChanged { stage = it }) {
        // ---------------- effects layer
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val hh = size.height
            // slow aurora
            drawCircle(
                Brush.radialGradient(listOf(A1.copy(alpha = 0.28f), Color.Transparent), Offset(w * (0.25f + 0.1f * cos(drift)), hh * (0.22f + 0.05f * sin(drift))), w * 0.7f),
                radius = w * 0.7f, center = Offset(w * (0.25f + 0.1f * cos(drift)), hh * (0.22f + 0.05f * sin(drift)))
            )
            drawCircle(
                Brush.radialGradient(listOf(A3.copy(alpha = 0.22f), Color.Transparent), Offset(w * (0.78f - 0.1f * sin(drift)), hh * (0.7f + 0.05f * cos(drift))), w * 0.75f),
                radius = w * 0.75f, center = Offset(w * (0.78f - 0.1f * sin(drift)), hh * (0.7f + 0.05f * cos(drift)))
            )

            val orbCx = lerp(w / 2f, orbX, morph)
            val orbCy = lerp(hh * 0.40f, orbY, morph)

            // radar waves while something is being held or is on its way
            if (phase == HandPhase.HOLDING || phase == HandPhase.INCOMING || phase == HandPhase.RECEIVING) {
                for (i in 0 until 3) {
                    val t = (wave + i / 3f) % 1f
                    val r = orbD * 0.5f + t * w * 0.62f
                    drawCircle(
                        ringColor.copy(alpha = (1f - t) * 0.42f), radius = r, center = Offset(orbCx, orbCy),
                        style = Stroke(width = 3.dp.toPx() * (1f - t * 0.6f))
                    )
                }
            }
            // glow behind the card
            val glow = (lift * 0.55f + morph * 0.45f)
            if (glow > 0.01f) {
                drawCircle(
                    Brush.radialGradient(listOf(ringColor.copy(alpha = 0.45f * glow * (0.8f + 0.2f * pulse)), Color.Transparent), Offset(orbCx, orbCy), orbD * 1.5f),
                    radius = orbD * 1.5f, center = Offset(orbCx, orbCy)
                )
            }
            // progress ring around the orb
            if (phase == HandPhase.SENDING || phase == HandPhase.RECEIVING) {
                val rr = orbD / 2f + 12.dp.toPx()
                drawCircle(Color.White.copy(alpha = 0.12f), radius = rr, center = Offset(orbCx, orbCy), style = Stroke(5.dp.toPx()))
                drawArc(
                    Brush.sweepGradient(listOf(A2, A1, A3, A2), Offset(orbCx, orbCy)),
                    startAngle = -90f, sweepAngle = 360f * progress / 100f, useCenter = false,
                    topLeft = Offset(orbCx - rr, orbCy - rr), size = androidx.compose.ui.geometry.Size(rr * 2, rr * 2),
                    style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            // incoming: glowing screen edge
            if (phase == HandPhase.INCOMING) {
                drawRoundRect(
                    Brush.linearGradient(listOf(A1, A2, A3, A1)),
                    topLeft = Offset(3.dp.toPx(), 3.dp.toPx()), size = androidx.compose.ui.geometry.Size(w - 6.dp.toPx(), hh - 6.dp.toPx()),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(36.dp.toPx()),
                    alpha = 0.35f + 0.5f * pulse, style = Stroke(6.dp.toPx())
                )
            }
            // your hand, as the phone sees it
            if (curA > 0.01f && hp != null) {
                val open = hp.gesture == "open"
                val fist = hp.gesture == "fist"
                val c = if (fist) Gold else if (open) A2 else Color.White
                drawCircle(
                    Brush.radialGradient(listOf(c.copy(alpha = 0.30f * curA), Color.Transparent), Offset(curX, curY), 64.dp.toPx()),
                    radius = 64.dp.toPx(), center = Offset(curX, curY)
                )
                drawCircle(
                    c.copy(alpha = 0.9f * curA), radius = if (fist) 12.dp.toPx() else 26.dp.toPx(), center = Offset(curX, curY),
                    style = if (fist) androidx.compose.ui.graphics.drawscope.Fill else Stroke(3.dp.toPx())
                )
            }
            // sparkles
            if (burst.value < 1f) {
                val p = burst.value
                val e = 1f - (1f - p) * (1f - p) * (1f - p)
                val pal = listOf(A1, A2, A3, Gold)
                for (i in 0 until 40) {
                    val ang = i * 2.3999631f
                    val spd = 0.5f + ((i * 37) % 10) / 10f * 0.75f
                    val d = e * spd * minOf(w, hh) * 0.46f
                    drawCircle(
                        pal[i % 4].copy(alpha = (1f - p).coerceIn(0f, 1f)), radius = (3 + i % 4).dp.toPx() * (1f - p * 0.6f),
                        center = Offset(orbCx + cos(ang) * d, orbCy + sin(ang) * d)
                    )
                }
            }
        }

        // ---------------- the photo: card, orb, or reveal
        val cardBmp: ImageBitmap? = when (phase) {
            HandPhase.RECEIVED -> gotBmp ?: thumb?.asImageBitmap()
            HandPhase.INCOMING, HandPhase.RECEIVING -> thumb?.asImageBitmap()
            else -> outgoing?.asImageBitmap()
        }
        if (W > 1f) {
            val sizeW = lerp(cardW, orbD, morph)
            val sizeH = lerp(cardH, orbD, morph)
            val cx = lerp(W / 2f, orbX, morph)
            val cy = lerp(H * 0.40f, orbY, morph)
            val radius = with(dens) { lerp(30.dp.toPx(), sizeW / 2f, morph).toDp() }
            val shape = RoundedCornerShape(radius)
            val fly = if (phase == HandPhase.SENDING) progress / 100f else if (phase == HandPhase.SENT) 1f else 0f
            Box(
                Modifier
                    .offset { IntOffset((cx - sizeW / 2f).roundToInt(), (cy - sizeH / 2f - fly * H * 0.22f).roundToInt()) }
                    .size(with(dens) { sizeW.toDp() }, with(dens) { sizeH.toDp() })
                    .graphicsLayer {
                        val s = (1f + 0.06f * lift) * (1f - 0.5f * fly)
                        scaleX = s
                        scaleY = s
                        alpha = if (phase == HandPhase.SENT) 0f else 1f - 0.75f * fly
                        cameraDistance = 12f * density
                        rotationX = -10f * lift
                    }
                    .shadow((8f + 26f * (lift + morph)).dp, shape, ambientColor = ringColor, spotColor = ringColor)
                    .clip(shape)
                    .background(Color(0xFF14141C))
                    .border(2.dp, Brush.linearGradient(listOf(ringColor, Color.White.copy(alpha = 0.25f))), shape)
                    .bounce(onClick = { if (phase == HandPhase.IDLE || phase == HandPhase.READY) pick.launch("image/*") }),
                contentAlignment = Alignment.Center
            ) {
                if (cardBmp != null) {
                    Image(
                        cardBmp, null, contentScale = ContentScale.Crop, filterQuality = FilterQuality.High,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (phase == HandPhase.IDLE) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.Add, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(44.dp))
                        Spacer(Modifier.height(6.dp))
                        Text("Choose a photo", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
                    }
                }
            }
            if (phase == HandPhase.SENT) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopStart) {
                    Column(
                        Modifier.offset { IntOffset((W / 2f - 90.dp.toPx()).roundToInt(), (H * 0.30f).roundToInt()) }.width(180.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Rounded.CheckCircle, null, tint = A2, modifier = Modifier.size(84.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Sent", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }

        // ---------------- top bar
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Rounded.ArrowBack, null, tint = Color.White,
                modifier = Modifier.bounce(onClick = onBack).padding(8.dp).size(26.dp)
            )
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) {
                Text("Hand share", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                if (status.isNotEmpty()) Text(status, color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp, maxLines = 1)
            }
            Box(
                Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.1f)).padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    if (peers == 0) "Searching…" else if (peers == 1) "1 phone nearby" else "$peers phones nearby",
                    color = if (peers > 0) A2 else Color.White.copy(alpha = 0.6f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
            }
        }

        // ---------------- bottom: words, buttons, lens
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Crossfade(phase, label = "msg") { p ->
                val headline = when (p) {
                    HandPhase.IDLE -> "Pick a photo to send, or wait for one to arrive"
                    HandPhase.READY -> "Open your hand"
                    HandPhase.ARMED -> "Now close it to grab the photo"
                    HandPhase.HOLDING -> "Got it. Take it to the other phone"
                    HandPhase.SENDING -> "Sending… $progress%"
                    HandPhase.SENT -> "Delivered"
                    HandPhase.INCOMING -> "$fromName is holding a photo"
                    HandPhase.RECEIVING -> "Receiving… $progress%"
                    HandPhase.RECEIVED -> "It's here"
                }
                val sub = when (p) {
                    HandPhase.IDLE -> "Both phones need Hand share open"
                    HandPhase.READY -> "Show your palm to the front camera"
                    HandPhase.ARMED -> "Make a fist, like picking it up"
                    HandPhase.HOLDING -> "Hold your open hand over the other phone. Open your hand here to put it back"
                    HandPhase.INCOMING -> "Open your hand over this phone to catch it"
                    HandPhase.RECEIVED -> "Saved to your gallery in Hand Share"
                    else -> ""
                }
                Column(Modifier.padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(headline, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    if (sub.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text(sub, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, textAlign = TextAlign.Center)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
                when (phase) {
                    HandPhase.IDLE -> Chip("Choose photo", true) { pick.launch("image/*") }
                    HandPhase.READY, HandPhase.ARMED -> {
                        Chip("Change photo", false) { pick.launch("image/*") }
                        Chip("Remove", false) { HandShare.clearPhoto() }
                    }
                    HandPhase.RECEIVED -> {
                        Chip("Done", true) { HandShare.dismissReceived() }
                        Chip("Open", false) { openReceived(ctx, gotPath) }
                        Chip("Share", false) { shareReceived(ctx, gotPath) }
                    }
                    else -> { }
                }
            }
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.size(118.dp).clip(CircleShape).border(3.dp, ringColor, CircleShape).background(Color.Black)
            ) { HandCamera(Modifier.fillMaxSize()) }
        }
    }
}

private fun openReceived(ctx: android.content.Context, path: String?) {
    if (path == null) return
    try {
        val uri = FileProvider.getUriForFile(ctx, "com.messages.app.vaultshare", File(path))
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/jpeg")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) { }
}

private fun shareReceived(ctx: android.content.Context, path: String?) {
    if (path == null) return
    try {
        val uri = FileProvider.getUriForFile(ctx, "com.messages.app.vaultshare", File(path))
        ctx.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) { }
}
