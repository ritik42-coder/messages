package com.messages.app

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.telephony.SmsManager
import java.io.ByteArrayOutputStream
import java.io.File

/** Minimal MMS (m-send-req / m-retrieve-conf) encoder + decoder. */
@Suppress("DEPRECATION")
object Mms {
    class Part(val name: String, val mime: String, val data: ByteArray)

    private const val AUTH = "com.messages.app.mmsfile"

    private fun sm(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun uintvar(o: ByteArrayOutputStream, v: Int) {
        var x = v
        val b = ArrayList<Int>()
        b.add(x and 0x7f); x = x shr 7
        while (x > 0) { b.add((x and 0x7f) or 0x80); x = x shr 7 }
        for (i in b.indices.reversed()) o.write(b[i])
    }

    private fun text(o: ByteArrayOutputStream, s: String) { o.write(s.toByteArray(Charsets.UTF_8)); o.write(0) }

    fun buildSendReq(to: String, parts: List<Part>): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(0x8C); o.write(0x80)                       // m-send-req
        o.write(0x98); text(o, "T" + System.currentTimeMillis())
        o.write(0x8D); o.write(0x90)                       // MMS 1.0
        o.write(0x89); o.write(0x01); o.write(0x81)        // From: insert-address-token
        o.write(0x97); text(o, to.filter { it.isDigit() || it == '+' } + "/TYPE=PLMN")
        o.write(0x86); o.write(0x81)                       // delivery report: no
        o.write(0x90); o.write(0x81)                       // read report: no
        o.write(0x84); o.write(0xA3)                       // multipart/mixed
        uintvar(o, parts.size)
        parts.forEachIndexed { i, p ->
            val h = ByteArrayOutputStream()
            when {
                p.mime == "text/plain" -> { h.write(0x03); h.write(0x83); h.write(0x81); h.write(0xEA) } // text/plain; charset=utf-8
                p.mime == "image/jpeg" -> h.write(0x9E)
                p.mime == "image/png" -> h.write(0xA0)
                p.mime == "image/gif" -> h.write(0x9D)
                else -> text(h, p.mime)
            }
            val n = "p${i}_" + p.name
            h.write(0x8E); text(h, n)                      // Content-Location
            h.write(0xC0); h.write(0x22); text(h, "<$n>")   // Content-ID
            val hb = h.toByteArray()
            uintvar(o, hb.size); uintvar(o, p.data.size)
            o.write(hb); o.write(p.data)
        }
        return o.toByteArray()
    }

    fun send(ctx: Context, to: String, parts: List<Part>, mid: Long) {
        try {
            val name = "send_$mid.dat"
            val dir = File(ctx.cacheDir, "mms").apply { mkdirs() }
            File(dir, name).writeBytes(buildSendReq(to, parts))
            val pi = PendingIntent.getBroadcast(
                ctx, mid.toInt(), Intent(ctx, MmsSentReceiver::class.java).putExtra("mid", mid).putExtra("name", name),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            sm(ctx).sendMultimediaMessage(ctx, Uri.parse("content://$AUTH/$name"), null, null, pi)
        } catch (_: Exception) {
            val st = Store(ctx)
            st.media = st.media.map { if (it.id == mid || it.id == mid + 1) it.copy(status = 2) else it }
            Bus.tick.value++
        }
    }

    fun download(ctx: Context, location: String, from: String) {
        try {
            val name = "recv_${System.currentTimeMillis()}.dat"
            File(ctx.cacheDir, "mms").mkdirs()
            val pi = PendingIntent.getBroadcast(
                ctx, name.hashCode(), Intent(ctx, MmsDownloadedReceiver::class.java).putExtra("name", name).putExtra("from", from),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            sm(ctx).downloadMultimediaMessage(ctx, location, Uri.parse("content://$AUTH/$name"), null, pi)
        } catch (_: Exception) { }
    }

    fun compressImage(ctx: Context, uri: Uri): ByteArray? {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 2000 || o.outHeight / s > 2000) s *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            } ?: return null
            val k = minOf(1f, 1024f / maxOf(bmp.width, bmp.height))
            val b = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
            var q = 80
            var out: ByteArray
            do {
                val bo = ByteArrayOutputStream()
                b.compress(Bitmap.CompressFormat.JPEG, q, bo)
                out = bo.toByteArray()
                q -= 10
            } while (out.size > 280_000 && q >= 30)
            return out
        } catch (_: Exception) { return null }
    }

    // ---------- decoding ----------
    private val WK = mapOf(
        0x83 to "text/plain", 0x84 to "text/html", 0x9D to "image/gif", 0x9E to "image/jpeg",
        0x9F to "image/tiff", 0xA0 to "image/png"
    )

    private fun uv(b: ByteArray, p: Int): Pair<Int, Int> {
        var v = 0; var i = p
        while (i < b.size) {
            val c = b[i].toInt() and 0xFF
            i++
            v = (v shl 7) or (c and 0x7F)
            if ((c and 0x80) == 0) break
        }
        return v to i
    }

    private fun readText(b: ByteArray, p: Int): String {
        var q = p
        while (q < b.size && b[q].toInt() != 0) q++
        return String(b, p, q - p, Charsets.UTF_8)
    }

    private fun skipVal(b: ByteArray, p: Int): Int {
        val c = b[p].toInt() and 0xFF
        return when {
            c < 31 -> p + 1 + c
            c == 31 -> { val (l, np) = uv(b, p + 1); np + l }
            c >= 128 -> p + 1
            else -> { var q = p; while (q < b.size && b[q].toInt() != 0) q++; q + 1 }
        }
    }

    fun parseNotification(b: ByteArray): Pair<String, String>? {
        val s = String(b, Charsets.ISO_8859_1)
        val i = s.indexOf("http")
        if (i < 0) return null
        val e = s.indexOf('\u0000', i)
        val loc = s.substring(i, if (e < 0) s.length else e)
        var from = "Unknown"
        val t = s.indexOf("/TYPE=")
        if (t > 0) {
            var a = t
            while (a > 0 && s[a - 1].code in 33..126) a--
            if (a < t) from = s.substring(a, t)
        }
        return loc to from
    }

    fun parseRetrieve(b: ByteArray): List<Part> {
        val out = ArrayList<Part>()
        try {
            var p = 0
            while (p < b.size) {
                val k = b[p].toInt() and 0xFF
                p++
                p = skipVal(b, p)
                if (k == 0x84) break
            }
            val (n, p1) = uv(b, p)
            p = p1
            repeat(n) {
                val (hl, a) = uv(b, p)
                val (dl, hs) = uv(b, a)
                var q = hs
                val c = b[q].toInt() and 0xFF
                var mime = "application/octet-stream"
                when {
                    c >= 128 -> { mime = WK[c] ?: mime; q++ }
                    c < 31 -> {
                        val inner = b[q + 1].toInt() and 0xFF
                        mime = if (inner >= 128) (WK[inner] ?: mime) else readText(b, q + 1)
                        q = q + 1 + c
                    }
                    else -> { mime = readText(b, q); q = skipVal(b, q) }
                }
                val he = hs + hl
                var name = "part"
                while (q < he) {
                    val key = b[q].toInt() and 0xFF
                    q++
                    if (key == 0x8E) name = readText(b, q)
                    q = skipVal(b, q)
                }
                out.add(Part(name, mime.substringBefore(';').lowercase(), b.copyOfRange(he, he + dl)))
                p = he + dl
            }
        } catch (_: Exception) { }
        return out
    }
}

class MmsFileProvider : ContentProvider() {
    override fun onCreate() = true
    override fun query(uri: Uri, projection: Array<String>?, selection: String?, selectionArgs: Array<String>?, sortOrder: String?): Cursor? = null
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<String>?): Int = 0
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val dir = File(context!!.cacheDir, "mms").apply { mkdirs() }
        val f = File(dir, uri.lastPathSegment ?: "x.dat")
        val m = if (mode.contains("w")) ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
        else ParcelFileDescriptor.MODE_READ_ONLY
        return ParcelFileDescriptor.open(f, m)
    }
}

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val data = i.getByteArrayExtra("data") ?: return
        val n = Mms.parseNotification(data) ?: return
        Mms.download(c, n.first, n.second)
    }
}

class MmsSentReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val mid = i.getLongExtra("mid", 0L)
        val ok = resultCode == Activity.RESULT_OK
        val st = Store(c)
        st.media = st.media.map { if (it.id == mid || it.id == mid + 1) it.copy(status = if (ok) 0 else 2) else it }
        Bus.tick.value++
        File(c.cacheDir, "mms/" + (i.getStringExtra("name") ?: "x")).delete()
    }
}

class MmsDownloadedReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val name = i.getStringExtra("name") ?: return
        val from = i.getStringExtra("from") ?: "Unknown"
        val f = File(c.cacheDir, "mms/$name")
        if (resultCode == Activity.RESULT_OK && f.exists()) {
            val dir = File(c.filesDir, "media").apply { mkdirs() }
            val now = System.currentTimeMillis()
            var k = 0L
            var summary = ""
            val list = ArrayList<Media>()
            for (p in Mms.parseRetrieve(f.readBytes())) {
                val id = now + k++
                when {
                    p.mime.startsWith("image/") -> {
                        val ext = if (p.mime.contains("png")) "png" else if (p.mime.contains("gif")) "gif" else "jpg"
                        val ff = File(dir, "in_$id.$ext"); ff.writeBytes(p.data)
                        list.add(Media(id, from, ff.path, p.mime, now, false, false, 0, ""))
                        summary = "\uD83D\uDCF7 Photo"
                    }
                    p.mime.startsWith("audio/") -> {
                        val ff = File(dir, "in_$id.amr"); ff.writeBytes(p.data)
                        list.add(Media(id, from, ff.path, "audio/amr", now, false, false, 0, ""))
                        summary = "\uD83C\uDFA4 Voice message"
                    }
                    p.mime == "text/plain" -> {
                        val t = String(p.data, Charsets.UTF_8)
                        list.add(Media(id, from, "", "text/plain", now, false, false, 0, t))
                        if (summary.isEmpty()) summary = t
                    }
                }
            }
            if (list.isNotEmpty()) {
                val st = Store(c)
                st.media = st.media + list
                Bus.tick.value++
                Notifier.show(c, from, summary)
            }
        }
        f.delete()
    }
}
