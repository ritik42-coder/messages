package com.messages.app

import android.Manifest
import android.app.KeyguardManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.util.JsonReader
import android.util.JsonWriter
import android.widget.RemoteViews
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val OTP_STRICT = Regex("(?i)\\b(otp|one[- ]?time (password|pin)|verification code|login code)\\b")

@Suppress("DEPRECATION")
fun authIntent(ctx: Context): Intent? = try {
    val km = ctx.getSystemService(KeyguardManager::class.java)
    if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("Messages", "Unlock to continue") else null
} catch (_: Exception) { null }

// ---------- smart categories ----------
object Cat {
    private val money = Regex("(?i)\\b(debited|credited|a/c|acct|upi|withdrawn|spent|paid|received|txn|transaction|balance|avl bal|neft|imps|rtgs|atm)\\b")
    private val bill = Regex("(?i)\\b(bill|due|emi|premium|recharge|outstanding|statement|invoice|renew|expires?)\\b")
    private val offer = Regex("(?i)(\\boffers?\\b|\\bsale\\b|\\bdiscount\\b|cashback|% ?off|\\bfree\\b|\\bwin\\b|\\bcoupon\\b|t&c|unsubscribe|limited time|\\bhurry\\b|\\bdeal\\b|\\bmega\\b)")

    /** 0 personal, 1 money, 2 bills, 3 offers, 4 other services */
    fun of(address: String, body: String): Int {
        if (address.none { it.isLetter() }) return 0
        return when {
            money.containsMatchIn(body) -> 1
            Otp.find(body) != null -> 4
            bill.containsMatchIn(body) -> 2
            offer.containsMatchIn(body) -> 3
            else -> 4
        }
    }
}

// ---------- scam shield ----------
class ScamResult(val score: Int, val reasons: List<String>) {
    val risky: Boolean get() = score >= 50
    val warn: Boolean get() = score >= 30
}

object Scam {
    private val url = Regex("(?i)(https?://|www\\.)[^\\s]+")
    private val badTld = Regex("(?i)\\.(xyz|top|click|club|icu|work|live|cfd|sbs|rest|buzz|monster|link|site|online|shop|vip|today|cyou)/")
    private val short = Regex("(?i)\\b(bit\\.ly|tinyurl\\.com|cutt\\.ly|is\\.gd|rb\\.gy|shorturl\\.at|t\\.ly|goo\\.gl|ow\\.ly|tiny\\.cc|rebrand\\.ly)")
    private val ip = Regex("^\\d{1,3}(\\.\\d{1,3}){3}")
    private val urgent = Regex("(?i)(account (will be |has been )?(blocked|suspended|closed)|\\bkyc\\b|pan (card )?(update|expire|suspend)|expires? today|verify (immediately|now)|click (here|below|the link)|you have won|lottery|\\bprize\\b|claim (your )?(reward|gift)|reward points (will )?expire|electricity (will be )?disconnect|last warning|immediate(ly)? action|refund)")
    private val brands = listOf("hdfc", "sbi", "icici", "axis", "kotak", "paytm", "phonepe", "jio", "airtel", "amazon", "flipkart", "irctc", "uidai", "aadhaar", "incometax", "epfo")

    fun check(body: String, addr: String): ScamResult {
        val urls = url.findAll(body).map { it.value }.toList()
        var s = 0
        val r = ArrayList<String>()
        for (u in urls) {
            val host = u.lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.").substringBefore('/').substringBefore('?')
            if (short.containsMatchIn(host)) { s += 25; r.add("shortened link hides the real website") }
            if (badTld.containsMatchIn("$host/")) { s += 30; r.add("unusual website ending") }
            if (ip.containsMatchIn(host)) { s += 35; r.add("link uses a raw IP address") }
            if (u.startsWith("http://", true)) { s += 10; r.add("not a secure (https) link") }
            if (host.count { it == '-' } >= 2) { s += 15; r.add("suspicious link name") }
            if (u.contains(".apk", true)) { s += 45; r.add("tries to make you install an app") }
            brands.firstOrNull { host.contains(it) }?.let { b ->
                if (host.contains('-') || host.any { it.isDigit() } || badTld.containsMatchIn("$host/")) { s += 35; r.add("looks like a fake $b website") }
            }
        }
        if (urgent.containsMatchIn(body)) { s += if (urls.isNotEmpty()) 30 else 15; r.add("pressure or urgent wording") }
        if (urls.isNotEmpty() && addr.isNotEmpty() && addr.none { it.isLetter() }) { s += 15; r.add("link from a personal number") }
        return ScamResult(s.coerceAtMost(100), r.distinct())
    }
}

// ---------- coupon / UPI / tracking helper ----------
class SmartAct(val label: String, val kind: String, val value: String)

object Smart {
    private val coupon = Regex("(?i:code|coupon|promo(?:code)?|voucher)\\W{0,6}([A-Z][A-Z0-9]{3,14})")
    private val upiLink = Regex("upi://[^\\s]+")
    private val upiId = Regex("(?i)\\b[\\w.\\-]{2,}@(?:ok\\w+|ybl|ibl|axl|paytm|upi|apl|sbi|hdfcbank|icici|axisbank)\\b")
    private val track = Regex("(?i:awb|tracking|consignment|docket)(?:\\W+(?:id|no\\.?|number|is)){0,3}\\W{0,6}([A-Z0-9]{8,20})")

    fun find(body: String): List<SmartAct> {
        val out = ArrayList<SmartAct>()
        coupon.find(body)?.let { out.add(SmartAct("Copy " + it.groupValues[1], "copy", it.groupValues[1])) }
        val ul = upiLink.find(body)
        if (ul != null) out.add(SmartAct("Pay with UPI", "view", ul.value))
        else upiId.find(body)?.let { out.add(SmartAct("Pay " + it.value, "view", "upi://pay?pa=" + it.value)) }
        track.find(body)?.let {
            val id = it.groupValues[1]
            if (id.any { ch -> ch.isDigit() }) out.add(SmartAct("Track $id", "web", "https://www.google.com/search?q=" + Uri.encode("$id tracking")))
        }
        return out
    }
}

// ---------- quick copy of any number ----------
object Nums {
    private val phone = Regex("(?<!\\d)(?:\\+91[\\s-]?)?([6-9]\\d{9})(?!\\d)")
    private val long = Regex("(?<![\\d/])(\\d{9,18})(?![\\d/])")

    /** Phone numbers and long account / PNR style numbers worth a one-tap copy. */
    fun find(body: String): List<String> {
        val out = ArrayList<String>()
        val otp = Otp.find(body)
        for (m in phone.findAll(body)) {
            val n = m.groupValues[1]
            if (n != otp && out.none { it == n }) out.add(n)
        }
        for (m in long.findAll(body)) {
            val n = m.groupValues[1]
            if (n == otp) continue
            if (out.any { it == n || n.contains(it) || it.contains(n) }) continue
            out.add(n)
        }
        return out.take(3)
    }

    fun pretty(n: String): String = when {
        n.length == 10 && n[0] in '6'..'9' -> "+91 " + n.substring(0, 5) + " " + n.substring(5)
        n.length > 8 -> n.chunked(4).joinToString(" ")
        else -> n
    }
}

// ---------- dual SIM ----------
class Sim(val subId: Int, val label: String)

@Suppress("DEPRECATION")
object Sims {
    fun list(ctx: Context): List<Sim> {
        if (ctx.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return emptyList()
        return try {
            val sm = ctx.getSystemService(SubscriptionManager::class.java)
            sm.activeSubscriptionInfoList?.map { Sim(it.subscriptionId, "SIM ${it.simSlotIndex + 1} \u2022 ${it.carrierName}") } ?: emptyList()
        } catch (_: Exception) { emptyList() }
    }

    fun manager(ctx: Context, address: String): SmsManager {
        val sub = Store(ctx).simFor(address)
        try {
            if (sub >= 0) return SmsManager.getSmsManagerForSubscriptionId(sub)
        } catch (_: Exception) { }
        return if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
    }
}

// ---------- backup / restore ----------
object Backup {
    fun create(ctx: Context): Pair<Uri, Int>? {
        try {
            val name = "Messages-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".json"
            val uri: Uri
            val os: OutputStream
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Messages/Backups")
                }
                uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
                os = ctx.contentResolver.openOutputStream(uri) ?: return null
            } else {
                val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Messages/Backups").apply { mkdirs() }
                val f = File(dir, name)
                uri = Uri.fromFile(f)
                os = FileOutputStream(f)
            }
            var n = 0
            JsonWriter(OutputStreamWriter(os, Charsets.UTF_8)).use { w ->
                w.beginObject()
                w.name("v").value(1L)
                w.name("sms").beginArray()
                ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "body", "date", "type"), null, null, "date ASC")?.use { c ->
                    while (c.moveToNext()) {
                        val t = c.getInt(3)
                        if (t != 1 && t != 2) continue
                        w.beginObject()
                        w.name("a").value(c.getString(0) ?: "")
                        w.name("b").value(c.getString(1) ?: "")
                        w.name("d").value(c.getLong(2))
                        w.name("t").value(t.toLong())
                        w.endObject()
                        n++
                    }
                }
                w.endArray()
                w.name("blocked").beginArray()
                Store(ctx).blocked.forEach { w.value(it) }
                w.endArray()
                w.endObject()
            }
            return uri to n
        } catch (_: Exception) { return null }
    }

    fun restore(ctx: Context, uri: Uri): Int {
        var n = 0
        try {
            val seen = HashSet<String>()
            ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "date"), null, null, null)?.use { c ->
                while (c.moveToNext()) seen.add("${c.getLong(1)}|${nk(c.getString(0) ?: "")}")
            }
            val ins = ctx.contentResolver.openInputStream(uri) ?: return 0
            JsonReader(InputStreamReader(ins, Charsets.UTF_8)).use { r ->
                r.beginObject()
                while (r.hasNext()) {
                    when (r.nextName()) {
                        "sms" -> {
                            r.beginArray()
                            while (r.hasNext()) {
                                var a = ""; var b = ""; var d = 0L; var t = 1
                                r.beginObject()
                                while (r.hasNext()) {
                                    when (r.nextName()) {
                                        "a" -> a = r.nextString()
                                        "b" -> b = r.nextString()
                                        "d" -> d = r.nextLong()
                                        "t" -> t = r.nextInt()
                                        else -> r.skipValue()
                                    }
                                }
                                r.endObject()
                                if (a.isNotEmpty() && seen.add("$d|${nk(a)}")) {
                                    ctx.contentResolver.insert(
                                        if (t == 2) Telephony.Sms.Sent.CONTENT_URI else Telephony.Sms.Inbox.CONTENT_URI,
                                        ContentValues().apply { put("address", a); put("body", b); put("date", d); put("read", 1) }
                                    )
                                    n++
                                }
                            }
                            r.endArray()
                        }
                        "blocked" -> {
                            val st = Store(ctx)
                            val set = st.blocked.toMutableSet()
                            r.beginArray()
                            while (r.hasNext()) set.add(r.nextString())
                            r.endArray()
                            st.blocked = set
                        }
                        else -> r.skipValue()
                    }
                }
                r.endObject()
            }
        } catch (_: Exception) { }
        return n
    }
}

// ---------- money & bills ----------
class Txn(val amount: Double, val debit: Boolean, val date: Long, val who: String, val body: String)
class Bill(val address: String, val who: String, val amount: Double?, val due: Long?, val date: Long, val body: String)
class MoneyData(val spent: Double, val received: Double, val txns: List<Txn>, val byWho: List<Pair<String, Double>>, val bills: List<Bill>)

object Money {
    private val amt = Regex("(?i)(?:rs\\.?|inr|\\u20B9)\\s*([\\d,]+(?:\\.\\d{1,2})?)")
    private val debit = Regex("(?i)\\b(debited|spent|withdrawn|paid|purchase|sent|payment of|dr)\\b")
    private val credit = Regex("(?i)\\b(credited|received|deposited|refund|cr)\\b")
    private val dueRe = Regex("(?i)due[^\\d]{0,25}(\\d{1,2})[-/. ]([a-z]{3,9}|\\d{1,2})[-/., ]*(\\d{2,4})?")
    private val months = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

    fun parseAmount(b: String): Double? = amt.find(b)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull()

    private fun parseDue(b: String): Long? {
        val m = dueRe.find(b) ?: return null
        val day = m.groupValues[1].toIntOrNull() ?: return null
        val ms = m.groupValues[2].lowercase()
        val mon = ms.toIntOrNull()?.minus(1) ?: (months.indexOf(ms.take(3)).takeIf { it >= 0 } ?: return null)
        if (mon !in 0..11 || day !in 1..31) return null
        val cal = Calendar.getInstance()
        var y = m.groupValues[3].toIntOrNull() ?: cal.get(Calendar.YEAR)
        if (y < 100) y += 2000
        cal.set(y, mon, day, 9, 0, 0)
        if (m.groupValues[3].isEmpty() && cal.timeInMillis < System.currentTimeMillis() - 20L * 86_400_000L) cal.add(Calendar.YEAR, 1)
        return cal.timeInMillis
    }

    fun compute(ctx: Context): MoneyData {
        val now = System.currentTimeMillis()
        val ms = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val since = minOf(ms, now - 45L * 86_400_000L)
        val txns = ArrayList<Txn>()
        val bills = LinkedHashMap<String, Bill>()
        try {
            ctx.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"), "date >= ?", arrayOf(since.toString()), "date DESC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n++ < 3000) {
                    val a = c.getString(0) ?: continue
                    val b = c.getString(1) ?: continue
                    val d = c.getLong(2)
                    val cat = Cat.of(a, b)
                    val who = a.substringAfter('-')
                    if (cat == 1) {
                        if (d < ms) continue
                        val x = parseAmount(b) ?: continue
                        val isDebit = debit.containsMatchIn(b)
                        if (!isDebit && !credit.containsMatchIn(b)) continue
                        txns.add(Txn(x, isDebit, d, who, b))
                    } else if (cat == 2 && !bills.containsKey(who)) {
                        bills[who] = Bill(a, who, parseAmount(b), parseDue(b), d, b)
                    }
                }
            }
        } catch (_: Exception) { }
        val spent = txns.filter { it.debit }.sumOf { it.amount }
        val received = txns.filter { !it.debit }.sumOf { it.amount }
        val by = txns.filter { it.debit }.groupBy { it.who }.map { e -> e.key to e.value.sumOf { it.amount } }.sortedByDescending { it.second }.take(5)
        val bl = bills.values.sortedWith(compareBy({ it.due == null }, { it.due ?: 0L }))
        return MoneyData(spent, received, txns, by, bl)
    }
}

// ---------- home-screen OTP widget ----------
class OtpWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, views(c))
    }

    companion object {
        fun views(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget_otp)
            val o = Store(c).lastOtp()
            if (o != null && System.currentTimeMillis() - o.third < 10 * 60_000L) {
                rv.setTextViewText(R.id.otp_code, o.first)
                rv.setTextViewText(R.id.otp_from, "${o.second} \u2022 tap to copy")
                val pi = PendingIntent.getBroadcast(
                    c, 77, Intent(c, CopyReceiver::class.java).putExtra("code", o.first).putExtra("nid", 0),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                rv.setOnClickPendingIntent(R.id.widget_root, pi)
            } else {
                rv.setTextViewText(R.id.otp_code, "\u2014 \u2014 \u2014")
                rv.setTextViewText(R.id.otp_from, "No recent OTP")
                val pi = PendingIntent.getActivity(c, 78, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                rv.setOnClickPendingIntent(R.id.widget_root, pi)
            }
            return rv
        }

        fun refresh(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, OtpWidget::class.java))
                for (id in ids) m.updateAppWidget(id, views(c))
            } catch (_: Exception) { }
        }
    }
}
