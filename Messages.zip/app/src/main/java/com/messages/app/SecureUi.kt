package com.messages.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val inviteLook = Regex("SC1:[A-Za-z0-9_-]{86,88}")

/** Pure text check, used by the SMS thread to show a Connect button. Nothing online happens here. */
fun looksLikeInvite(body: String): Boolean = inviteLook.containsMatchIn(body)

private fun scSize(b: Long): String = when {
    b >= 1_000_000L -> String.format(Locale.US, "%.1f MB", b / 1_000_000.0)
    b >= 1_000L -> (b / 1_000L).toString() + " KB"
    else -> "$b B"
}

private fun scOpen(ctx: Context, path: String, mime: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "com.messages.app.vaultshare", File(path))
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
        Toast.makeText(ctx, "No app on this phone can open that file", Toast.LENGTH_SHORT).show()
    }
}

/** The button shown under an invite inside a normal SMS conversation. */
@Composable
fun SecureInviteChip(address: String, body: String) {
    val ctx = LocalContext.current
    var done by remember { mutableStateOf(false) }
    var askBack by remember { mutableStateOf(false) }
    Row(
        Modifier.padding(top = 8.dp)
            .bounce(onClick = {
                if (!done) {
                    val err = SecureCore.acceptInvite(ctx, address, body)
                    if (err != null) Toast.makeText(ctx, err, Toast.LENGTH_SHORT).show()
                    else {
                        done = true
                        askBack = true
                    }
                }
            })
            .clip(RoundedCornerShape(50)).background(A2.copy(alpha = 0.2f)).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Lock, null, tint = A2, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(if (done) "Connected securely" else "Connect securely", color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
    if (askBack) {
        AlertDialog(
            onDismissRequest = { askBack = false }, containerColor = Surf2,
            title = { Text("Send your key back?", color = Ink) },
            text = {
                Text(
                    "They get one normal text so they can connect to you too. Nothing goes online for this step.",
                    color = Dim, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    SecureCore.sendInvite(ctx, address)
                    askBack = false
                    Toast.makeText(ctx, "Sent. Open Secure chat in Settings to start.", Toast.LENGTH_LONG).show()
                }) { Text("Send", color = A2, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { askBack = false }) { Text("Not now", color = Dim) } }
        )
    }
}

// ===================================================================================== home
@Composable
fun SecureHomeScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t by SecureCore.tick.collectAsState()
    val status by SecureCore.status.collectAsState()
    var open by remember { mutableStateOf<String?>(null) }
    var invite by remember { mutableStateOf(false) }
    var number by remember { mutableStateOf("") }
    var ghost by remember { mutableStateOf(SecureCore.ghost(ctx)) }
    var instant by remember { mutableStateOf(SecureCore.instant(ctx)) }
    LaunchedEffect(Unit) { SecureCore.start(ctx) }
    val store = remember { SecureDb.get(ctx) }
    val contacts = remember(t) { store.contacts() }

    val cid = open
    if (cid != null) {
        BackHandler { open = null }
        SecureChatScreen(cid) { open = null }
        return
    }

    Page("Secure chat", onBack, actions = { IconBtn(Icons.Rounded.Add, A2) { invite = true } }) {
        LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Shield, null, tint = A2, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            status.ifEmpty { "Starting…" }, color = Ink, fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                        )
                    }
                    Text(
                        "Your SMS stays offline and separate. Only people you invite can write here, and Firebase never sees a phone number.",
                        color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                    )
                    if (!SecureConfig.storageReady()) {
                        Text(
                            "Photos, videos and files need the Supabase details in SecureConfig.kt. Text chat works without them.",
                            color = Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
            if (contacts.isEmpty()) {
                item { EmptyState(Icons.Rounded.Lock, "No secure chats yet", "Tap + to invite someone by text message") }
            }
            itemsIndexed(contacts, key = { _, c -> c.id }) { _, c ->
                val last = remember(t, c.id) { store.lastMsg(c.id) }
                val unread = remember(t, c.id) { store.unread(c.id) }
                Row(
                    Modifier.fillMaxWidth().bounce(onClick = { open = c.id })
                        .clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(A2.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                        Text(c.name.take(1).uppercase().ifEmpty { "?" }, color = A2, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name.ifEmpty { c.phone }, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            when {
                                last == null -> "Say hello"
                                last.kind == "image" -> "Photo"
                                last.kind == "video" -> "Video"
                                last.kind == "file" -> last.fname
                                else -> last.body
                            },
                            color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (unread > 0) {
                        Box(Modifier.clip(CircleShape).background(A2).padding(horizontal = 8.dp, vertical = 3.dp)) {
                            Text(unread.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(6.dp)) }
            item {
                SettingRow("Ghost mode", "Don't tell people when you've read their messages", ghost) {
                    ghost = it
                    SecureCore.setGhost(ctx, it)
                }
            }
            item {
                SettingRow("Instant mode", "Keep listening in the background so messages arrive right away. Uses a little more battery.", instant) { on ->
                    instant = on
                    SecureCore.setInstant(ctx, on)
                    try {
                        if (on) ContextCompat.startForegroundService(ctx, Intent(ctx, SecureService::class.java))
                        else ctx.stopService(Intent(ctx, SecureService::class.java))
                    } catch (_: Exception) { }
                }
            }
        }
    }

    if (invite) {
        AlertDialog(
            onDismissRequest = { invite = false }, containerColor = Surf2,
            title = { Text("Invite by text", color = Ink) },
            text = {
                Column {
                    Text(
                        "We send one normal text with your public key. The number stays on this phone. When they tap Connect in their Messages app, you're linked.",
                        color = Dim, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    InputField(number, { number = it.filter { ch -> ch.isDigit() || ch == '+' } }, "Phone number", single = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (number.length >= 6) {
                        SecureCore.sendInvite(ctx, number)
                        Toast.makeText(ctx, "Invite sent by SMS", Toast.LENGTH_SHORT).show()
                        number = ""
                        invite = false
                    }
                }) { Text("Send invite", color = A2, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { invite = false }) { Text("Cancel", color = Dim) } }
        )
    }
}

// ===================================================================================== chat
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SecureChatScreen(cid: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t by SecureCore.tick.collectAsState()
    val prog by SecureCore.progress.collectAsState()
    val store = remember { SecureDb.get(ctx) }
    val contact = remember(t) { store.contact(cid) }
    val msgs = remember(t) { store.msgs(cid) }
    var text by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<ScMsg?>(null) }
    var timerDlg by remember { mutableStateOf(false) }
    var burnDlg by remember { mutableStateOf(false) }
    var codeDlg by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<String?>(null) }
    val seen = remember(cid) { HashSet<Any>() }
    val state = rememberLazyListState()
    val silk = rememberSilkFling()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) SecureCore.sendFile(ctx, cid, uri)
    }
    DisposableEffect(cid) {
        SecureCore.openChat(ctx, cid)
        onDispose { SecureCore.closeChat() }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) state.animateScrollToItem(0) }
    BackHandler(viewer != null) { viewer = null }

    Box(Modifier.fillMaxSize()) {
        Page(
            (contact?.name ?: "").ifEmpty { contact?.phone ?: "Secure chat" }, onBack,
            actions = {
                IconBtn(Icons.Rounded.Shield) { codeDlg = true }
                IconBtn(Icons.Rounded.Timer, if ((contact?.ttl ?: 0) > 0) A2 else Ink) { timerDlg = true }
                IconBtn(Icons.Rounded.Delete, A3) { burnDlg = true }
            }
        ) {
            val rev = remember(msgs) { msgs.asReversed() }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = state, reverseLayout = true, flingBehavior = silk,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(rev, key = { _, m -> m.row }) { _, m ->
                    Box(
                        Modifier.fillMaxWidth().animateItemPlacement().edgeFx(state, m.row).entrance(
                            seen, m.row, play = System.currentTimeMillis() - m.ts < 3000L, dir = if (m.out) 1f else -1f
                        ),
                        contentAlignment = if (m.out) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        ScBubble(
                            m, prog[m.row],
                            onTap = {
                                val ready = m.path.isNotEmpty() && (m.out || m.state == 2)
                                when {
                                    m.kind == "image" && ready -> viewer = m.path
                                    m.kind != "text" && ready -> scOpen(ctx, m.path, m.mime)
                                    m.state == 9 || (!m.out && m.state == 0) -> SecureCore.retry(ctx, m.row)
                                }
                            },
                            onLong = { menuFor = m }
                        )
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().imePadding().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn(Icons.Rounded.AttachFile, A2) { picker.launch(arrayOf("*/*")) }
                Box(Modifier.weight(1f)) { InputField(text, { text = it }, "Message", single = false) }
                IconBtn(Icons.Rounded.Send, A2) {
                    if (text.isNotBlank()) {
                        SecureCore.sendText(ctx, cid, text)
                        text = ""
                    }
                }
            }
        }
        viewer?.let { p -> ImageOverlay(p) { viewer = null } }
    }

    menuFor?.let { m ->
        AlertDialog(
            onDismissRequest = { menuFor = null }, containerColor = Surf2,
            title = { Text("Message", color = Ink) },
            text = {
                Column {
                    if (m.out) {
                        Text(
                            "Unsend for everyone", color = A3, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.fillMaxWidth().bounce(onClick = { SecureCore.unsend(ctx, m.row); menuFor = null }).padding(vertical = 12.dp)
                        )
                    }
                    Text(
                        "Delete for me", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth().bounce(onClick = { SecureCore.deleteForMe(ctx, m.row); menuFor = null }).padding(vertical = 12.dp)
                    )
                    if (m.state == 9 || (!m.out && m.state != 2 && m.kind != "text")) {
                        Text(
                            "Try again", color = A2, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.fillMaxWidth().bounce(onClick = { SecureCore.retry(ctx, m.row); menuFor = null }).padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Close", color = Dim) } }
        )
    }

    if (timerDlg) {
        val options = listOf("Off" to 0, "1 hour" to 3600, "1 day" to 86_400, "7 days" to 604_800)
        AlertDialog(
            onDismissRequest = { timerDlg = false }, containerColor = Surf2,
            title = { Text("Disappearing messages", color = Ink) },
            text = {
                Column {
                    Text("New messages and files in this chat disappear from both phones after this time.", color = Dim, fontSize = 12.sp)
                    options.forEach { (label, secs) ->
                        val on = (contact?.ttl ?: 0) == secs
                        Text(
                            label, color = if (on) A2 else Ink, fontSize = 15.sp,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().bounce(onClick = { SecureCore.setTimer(ctx, cid, secs); timerDlg = false }).padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { timerDlg = false }) { Text("Close", color = Dim) } }
        )
    }

    if (burnDlg) {
        AlertDialog(
            onDismissRequest = { burnDlg = false }, containerColor = Surf2,
            title = { Text("Burn this chat?", color = Ink) },
            text = { Text("Every message and file in this chat is erased from this phone and from theirs. This can't be undone.", color = Dim, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { SecureCore.burn(ctx, cid); burnDlg = false }) { Text("Burn", color = A3, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { burnDlg = false }) { Text("Cancel", color = Dim) } }
        )
    }

    if (codeDlg && contact != null) {
        AlertDialog(
            onDismissRequest = { codeDlg = false }, containerColor = Surf2,
            title = { Text("Safety code", color = Ink) },
            text = {
                Column {
                    Text(SecureCore.safetyCode(ctx, contact), color = A2, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Read this out on a phone call. If both phones show the same numbers, nobody is listening in between.",
                        color = Dim, fontSize = 12.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { codeDlg = false }) { Text("Done", color = A2, fontWeight = FontWeight.Bold) } }
        )
    }
}

@Composable
private fun ScBubble(m: ScMsg, pct: Int?, onTap: () -> Unit, onLong: () -> Unit) {
    val out = m.out
    val shape = RoundedCornerShape(18.dp, 18.dp, if (out) 4.dp else 18.dp, if (out) 18.dp else 4.dp)
    val fg = if (out) Color.White else Ink
    val ready = m.path.isNotEmpty() && (out || m.state == 2)
    Column(
        Modifier.widthIn(max = 280.dp).clip(shape).background(if (out) A1 else Surf)
            .bounce(onClick = onTap, onLong = onLong).padding(if (m.kind == "image" && ready) 4.dp else 12.dp)
    ) {
        when (m.kind) {
            "text" -> Text(m.body, color = fg, fontSize = 15.sp)
            "image" -> {
                val bmp by produceState<ImageBitmap?>(null, m.path, ready) {
                    value = if (ready) withContext(Dispatchers.IO) { Thumbs.get(m.path, 700) } else null
                }
                val b = bmp
                if (b != null) {
                    Image(
                        b, null, contentScale = ContentScale.Crop,
                        modifier = Modifier.widthIn(max = 260.dp).height(200.dp).clip(RoundedCornerShape(14.dp))
                    )
                } else {
                    Box(Modifier.size(width = 200.dp, height = 120.dp), contentAlignment = Alignment.Center) {
                        Text(transferText(m, pct), color = fg, fontSize = 13.sp)
                    }
                }
            }
            else -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (m.kind == "video") Icons.Rounded.PlayArrow else fileIcon(m.mime), null, tint = fg, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(m.fname, color = fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (ready) scSize(m.size) + (if (m.kind == "video") " \u00B7 tap to play" else "") else transferText(m, pct),
                            color = fg.copy(alpha = 0.75f), fontSize = 12.sp
                        )
                    }
                }
            }
        }
        Row(Modifier.align(Alignment.End).padding(top = 3.dp, end = if (m.kind == "image" && ready) 6.dp else 0.dp), verticalAlignment = Alignment.CenterVertically) {
            if (m.exp > 0L) {
                Icon(Icons.Rounded.Timer, null, tint = fg.copy(alpha = 0.7f), modifier = Modifier.size(11.dp))
                Spacer(Modifier.width(3.dp))
            }
            Text(
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.ts)) + if (out) "  " + ticks(m.state) else "",
                color = fg.copy(alpha = 0.7f), fontSize = 10.sp
            )
        }
    }
}

private fun ticks(state: Int): String = when (state) {
    0 -> "\u2026"
    1 -> "\u2713"
    2 -> "\u2713\u2713"
    3 -> "\u2713\u2713 seen"
    else -> "failed, tap to retry"
}

private fun transferText(m: ScMsg, pct: Int?): String = when {
    pct != null -> (if (m.out) "Sending " else "Downloading ") + pct + "%"
    m.state == 9 -> "Failed. Tap to retry"
    m.out -> "Waiting to send…"
    m.state == 1 -> "Downloading…"
    else -> "Tap to download"
}
