package com.messages.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import java.io.File
import java.util.Locale

private val inviteLook = Regex("SC1:[A-Za-z0-9_-]{86,88}")

/** Pure text check, used by the SMS thread to show a Connect button. Nothing online happens here. */
fun looksLikeInvite(body: String): Boolean = inviteLook.containsMatchIn(body)

internal fun scSize(b: Long): String = when {
    b >= 1_000_000L -> String.format(Locale.US, "%.1f MB", b / 1_000_000.0)
    b >= 1_000L -> (b / 1_000L).toString() + " KB"
    else -> "$b B"
}

internal fun scOpen(ctx: Context, path: String, mime: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "com.messages.app.vaultshare", File(path))
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
        Toast.makeText(ctx, "No app on this phone can open that file", Toast.LENGTH_SHORT).show()
    }
}

/** The button shown under an invite inside a normal SMS conversation. */
@Composable
fun SecureInviteChip(address: String, body: String) {
    val ctx = LocalContext.current
    var done by remember { mutableStateOf(false) }
    var askBack by remember { mutableStateOf(false) }
    Row(
        Modifier.padding(top = 8.dp)
            .bounce(onClick = {
                if (!done) {
                    val err = SecureCore.acceptInvite(ctx, address, body)
                    if (err != null) Toast.makeText(ctx, err, Toast.LENGTH_SHORT).show()
                    else {
                        done = true
                        askBack = true
                    }
                }
            })
            .clip(RoundedCornerShape(50)).background(A2.copy(alpha = 0.2f)).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Lock, null, tint = A2, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(if (done) "Connected securely" else "Connect securely", color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
    if (askBack) {
        AlertDialog(
            onDismissRequest = { askBack = false }, containerColor = Surf2,
            title = { Text("Send your key back?", color = Ink) },
            text = {
                Text(
                    "They get one normal text so they can connect to you too. Nothing goes online for this step.",
                    color = Dim, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    SecureCore.sendInvite(ctx, address)
                    askBack = false
                    Toast.makeText(ctx, "Sent. Open Secure chat in Settings to start.", Toast.LENGTH_LONG).show()
                }) { Text("Send", color = A2, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { askBack = false }) { Text("Not now", color = Dim) } }
        )
    }
}

// ===================================================================================== home
@Composable
fun SecureHomeScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t by SecureCore.tick.collectAsState()
    val status by SecureCore.status.collectAsState()
    var open by remember { mutableStateOf<String?>(null) }
    var invite by remember { mutableStateOf(false) }
    var ghost by remember { mutableStateOf(SecureCore.ghost(ctx)) }
    var instant by remember { mutableStateOf(SecureCore.instant(ctx)) }
    var pname by remember { mutableStateOf(SecureCore.profileName(ctx)) }
    var nameDlg by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { SecureCore.start(ctx) }
    val store = remember { SecureDb.get(ctx) }
    val contacts = remember(t) { store.contacts() }

    val cid = open
    if (cid != null) {
        BackHandler { open = null }
        SecureChatScreen(cid) { open = null }
        return
    }

    Page("Secure chat", onBack, actions = { IconBtn(Icons.Rounded.Add, A2) { invite = true } }) {
        LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Shield, null, tint = A2, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            status.ifEmpty { "Starting…" }, color = Ink, fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                        )
                    }
                    Text(
                        "Works over any internet, no SMS or recharge needed. Your SMS stays offline and separate, and no phone number is stored online.",
                        color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                    )
                    if (!SecureConfig.storageReady()) {
                        Text(
                            "Photos, videos and voice notes need the Supabase details in SecureConfig.kt. Text chat works without them.",
                            color = Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
            if (contacts.isEmpty()) {
                item { EmptyState(Icons.Rounded.Lock, "No secure chats yet", "Tap + to connect with a code, a QR or an SMS") }
            }
            itemsIndexed(contacts, key = { _, c -> c.id }) { _, c ->
                val last = remember(t, c.id) { store.lastMsg(c.id) }
                val unread = remember(t, c.id) { store.unread(c.id) }
                Row(
                    Modifier.fillMaxWidth().bounce(onClick = { open = c.id })
                        .clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(A2.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                        Text(c.name.take(1).uppercase().ifEmpty { "?" }, color = A2, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name.ifEmpty { c.phone }, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            when {
                                last == null -> "Say hello"
                                last.kind == "image" -> "Photo"
                                last.kind == "video" -> "Video"
                                last.kind == "voice" -> "Voice message"
                                last.kind == "file" -> last.fname
                                (last.flags and 1) != 0 -> "View-once message"
                                (last.flags and 2) != 0 && !last.out -> "Whisper message"
                                else -> last.body
                            },
                            color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (unread > 0) {
                        Box(Modifier.clip(CircleShape).background(A2).padding(horizontal = 8.dp, vertical = 3.dp)) {
                            Text(unread.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(6.dp)) }
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Your name", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("Shown to people when they connect with your code: $pname", color = Dim, fontSize = 12.sp)
                    }
                    Chip("Change", false) { nameDlg = true }
                }
            }
            item {
                SettingRow("Ghost mode", "Don't tell people when you've read their messages", ghost) {
                    ghost = it
                    SecureCore.setGhost(ctx, it)
                }
            }
            item {
                SettingRow("Instant mode", "Keep listening in the background so messages arrive right away. Uses a little more battery.", instant) { on ->
                    instant = on
                    SecureCore.setInstant(ctx, on)
                    try {
                        if (on) ContextCompat.startForegroundService(ctx, Intent(ctx, SecureService::class.java))
                        else ctx.stopService(Intent(ctx, SecureService::class.java))
                    } catch (_: Exception) { }
                }
            }
        }
    }

    if (invite) InviteDialog { invite = false }

    if (nameDlg) {
        var nm by remember { mutableStateOf(pname) }
        AlertDialog(
            onDismissRequest = { nameDlg = false }, containerColor = Surf2,
            title = { Text("Your name", color = Ink) },
            text = { InputField(nm, { nm = it.take(20) }, "Name", single = true) },
            confirmButton = {
                TextButton(onClick = {
                    if (nm.isNotBlank()) {
                        SecureCore.setProfileName(ctx, nm)
                        pname = SecureCore.profileName(ctx)
                    }
                    nameDlg = false
                }) { Text("Save", color = A2, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { nameDlg = false }) { Text("Cancel", color = Dim) } }
        )
    }
}

// ===================================================================================== invite
@Composable
private fun InviteDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var code by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var entered by remember { mutableStateOf("") }
    var nameIn by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }

    fun redeem(raw: String) {
        if (busy) return
        busy = true
        SecureCore.redeemInvite(ctx, raw, nameIn) { err ->
            busy = false
            if (err == null) {
                Toast.makeText(ctx, "Connected. Say hello!", Toast.LENGTH_SHORT).show()
                onClose()
            } else Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
        }
    }

    fun scan() {
        val o = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        GmsBarcodeScanning.getClient(ctx, o).startScan()
            .addOnSuccessListener { b ->
                val c = SecureCore.extractCode(b.rawValue ?: "")
                if (c != null) {
                    entered = SecureCore.prettyCode(c)
                    redeem(c)
                } else Toast.makeText(ctx, "That isn't a Secure chat QR code", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { Toast.makeText(ctx, "Scanner unavailable (needs Google Play services)", Toast.LENGTH_LONG).show() }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.padding(16.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Surf2).padding(20.dp)
        ) {
            Text("Connect with someone", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            Text("Over any internet. No SMS, no recharge, no phone number.", color = Dim, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("My code", tab == 0) { tab = 0 }
                Chip("Enter code", tab == 1) { tab = 1 }
                Chip("By SMS", tab == 2) { tab = 2 }
            }
            Spacer(Modifier.height(14.dp))
            when (tab) {
                0 -> {
                    val c = code
                    if (c == null) {
                        Text(
                            "Make a one-time code and send it to your friend on WhatsApp, Telegram, email or anything. When they enter it, you are connected. It works for one person and lasts 48 hours.",
                            color = Dim, fontSize = 13.sp
                        )
                        Spacer(Modifier.height(14.dp))
                        GradientButton(if (busy) "Making your code…" else "Create my code") {
                            if (!busy) {
                                busy = true
                                SecureCore.createInvite(ctx) { made ->
                                    busy = false
                                    if (made != null) code = made
                                    else Toast.makeText(ctx, "Couldn't make a code. Check your internet and try again in a moment.", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    } else {
                        Text(
                            SecureCore.prettyCode(c), color = A2, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Image(
                                qrBitmap("SC2:$c", 520), null,
                                modifier = Modifier.size(190.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(10.dp)
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("Copy", false) { ctx.copyText(SecureCore.prettyCode(c), "Code copied") }
                            Chip("Share", true) {
                                try {
                                    ctx.startActivity(
                                        Intent.createChooser(
                                            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, SecureCore.inviteShareText(c)), "Share your code"
                                        )
                                    )
                                } catch (_: Exception) { }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("One person, 48 hours. They can also scan the QR code.", color = Dim, fontSize = 12.sp)
                    }
                }
                1 -> {
                    InputField(entered, { entered = it.take(40) }, "Their code, like 7K3M-Q9XA-4D", single = true)
                    Spacer(Modifier.height(8.dp))
                    InputField(nameIn, { nameIn = it.take(30) }, "Name for this contact (optional)", single = true)
                    Spacer(Modifier.height(14.dp))
                    GradientButton(if (busy) "Connecting…" else "Connect") {
                        val c = SecureCore.extractCode(entered)
                        if (c == null) Toast.makeText(ctx, "That code doesn't look right", Toast.LENGTH_SHORT).show()
                        else redeem(c)
                    }
                    Spacer(Modifier.height(10.dp))
                    Chip("Scan their QR code", false) { scan() }
                }
                else -> {
                    Text(
                        "Sends one normal text with your public key. Needs SMS credit. The number stays on this phone.",
                        color = Dim, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    InputField(number, { number = it.filter { ch -> ch.isDigit() || ch == '+' } }, "Phone number", single = true)
                    Spacer(Modifier.height(14.dp))
                    GradientButton("Send invite by SMS") {
                        if (number.length >= 6) {
                            SecureCore.sendInvite(ctx, number)
                            Toast.makeText(ctx, "Invite sent by SMS", Toast.LENGTH_SHORT).show()
                            number = ""
                            onClose()
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Close", color = Dim, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.CenterHorizontally).bounce(onClick = onClose).padding(10.dp)
            )
        }
    }
}
