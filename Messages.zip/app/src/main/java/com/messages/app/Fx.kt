package com.messages.app

import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollScope
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

fun Context.findActivity(): android.app.Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is android.app.Activity) return c
        c = c.baseContext
    }
    return null
}

// ---------------------------------------------------------------------------------------------
// Scrolling
// ---------------------------------------------------------------------------------------------

/**
 * Rows ease out as they travel under the top edge: a gentle shrink, fade and 3D tilt, like a drum.
 * Everything is read at draw time, so scrolling never recomposes anything.
 */
fun Modifier.edgeFx(state: LazyListState, key: Any): Modifier = this.graphicsLayer {
    val li = state.layoutInfo
    val item = li.visibleItemsInfo.firstOrNull { it.key == key } ?: return@graphicsLayer
    val mid = item.offset + item.size / 2f
    val distTop = if (li.reverseLayout) li.viewportEndOffset - mid else mid - li.viewportStartOffset
    val zone = 150.dp.toPx()
    val t = (distTop / zone).coerceIn(0f, 1f)
    val e = t * t * (3f - 2f * t)
    val s = 0.88f + 0.12f * e
    scaleX = s
    scaleY = s
    alpha = 0.25f + 0.75f * e
    cameraDistance = 14f * density
    rotationX = (1f - e) * (if (li.reverseLayout) -22f else 22f)
}

/**
 * New rows spring into place once: slide, scale and fade, from the side they belong to.
 * [seen] remembers which keys already played, so scrolling back never replays them.
 */
@Composable
fun Modifier.entrance(
    seen: MutableSet<Any>, key: Any, play: Boolean, dir: Float = 0f, delayMs: Int = 0
): Modifier {
    val first = remember { seen.add(key) }
    val animate = play && first
    val p = remember { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (animate) {
            if (delayMs > 0) kotlinx.coroutines.delay(delayMs.toLong())
            p.animateTo(1f, spring(dampingRatio = 0.64f, stiffness = 240f))
        }
    }
    return this.graphicsLayer {
        val v = p.value
        if (v < 1f) {
            alpha = v.coerceIn(0f, 1f)
            translationX = (1f - v) * 72.dp.toPx() * dir
            translationY = (1f - v) * 30.dp.toPx()
            val sc = 0.80f + 0.20f * v
            scaleX = sc
            scaleY = sc
        }
    }
}

/** A longer, silkier glide after a flick than the stock fling. */
@Composable
fun rememberSilkFling(): FlingBehavior = remember {
    object : FlingBehavior {
        override suspend fun ScrollScope.performFling(initialVelocity: Float): Float {
            var last = 0f
            var left = initialVelocity
            if (abs(initialVelocity) < 1f) return initialVelocity
            AnimationState(initialValue = 0f, initialVelocity = initialVelocity)
                .animateDecay(exponentialDecay<Float>(frictionMultiplier = 0.62f, absVelocityThreshold = 1.2f)) {
                    val delta = value - last
                    val consumed = scrollBy(delta)
                    last = value
                    left = velocity
                    if (abs(delta - consumed) > 0.5f) cancelAnimation()
                }
            return left
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Zoomable image: pinch, pan, double-tap, swipe down to dismiss
// ---------------------------------------------------------------------------------------------

/**
 * [onFade] reports 0..1 how far the image has been dragged away, so the backdrop can fade with it.
 * [onDismiss] is called after the image has flown off screen.
 */
@Composable
fun ZoomImage(
    bitmap: ImageBitmap, description: String?, onDismiss: () -> Unit, onFade: (Float) -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    var scale by remember { mutableFloatStateOf(1f) }
    var offX by remember { mutableFloatStateOf(0f) }
    var offY by remember { mutableFloatStateOf(0f) }
    var boxW by remember { mutableFloatStateOf(1f) }
    var boxH by remember { mutableFloatStateOf(1f) }
    var busy by remember { mutableStateOf(false) }

    fun settle(toScale: Float, toX: Float, toY: Float) {
        val s0 = scale
        val x0 = offX
        val y0 = offY
        scope.launch {
            busy = true
            animate(0f, 1f, animationSpec = spring(dampingRatio = 0.8f, stiffness = 300f)) { f, _ ->
                scale = s0 + (toScale - s0) * f
                offX = x0 + (toX - x0) * f
                offY = y0 + (toY - y0) * f
                onFade(if (scale <= 1.01f) (abs(offY) / (boxH * 0.5f)).coerceIn(0f, 1f) else 0f)
            }
            busy = false
        }
    }

    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { boxW = it.width.toFloat(); boxH = it.height.toFloat() }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { p ->
                    if (scale > 1.05f) settle(1f, 0f, 0f)
                    else {
                        val target = 2.8f
                        val qx = p.x - boxW / 2f
                        val qy = p.y - boxH / 2f
                        val maxX = boxW * (target - 1f) / 2f
                        val maxY = boxH * (target - 1f) / 2f
                        settle(
                            target,
                            (-qx * (target - 1f)).coerceIn(-maxX, maxX),
                            (-qy * (target - 1f)).coerceIn(-maxY, maxY)
                        )
                    }
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var moved = false
                    var fingers = 1
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Main)
                        fingers = ev.changes.count { it.pressed }
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        val c = ev.calculateCentroid(useCurrent = false)
                        if (fingers >= 2 || scale > 1.01f) {
                            val ns = (scale * zoom).coerceIn(0.85f, 6f)
                            val q = if (c == Offset.Unspecified) Offset.Zero else c - Offset(boxW / 2f, boxH / 2f)
                            val z = ns / scale
                            val maxX = boxW * (ns - 1f).coerceAtLeast(0f) / 2f
                            val maxY = boxH * (ns - 1f).coerceAtLeast(0f) / 2f
                            offX = (offX * z + q.x * (1f - z) + pan.x).coerceIn(-maxX, maxX)
                            offY = (offY * z + q.y * (1f - z) + pan.y).coerceIn(-maxY, maxY)
                            scale = ns
                            moved = true
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        } else if (fingers == 1 && abs(pan.y) > 0f && (moved || abs(offY) > 0f || abs(pan.y) > abs(pan.x))) {
                            // one finger, not zoomed: drag the image away to dismiss
                            offY += pan.y
                            offX += pan.x * 0.35f
                            moved = true
                            onFade((abs(offY) / (boxH * 0.5f)).coerceIn(0f, 1f))
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                    // finger lifted
                    if (scale < 1.02f) {
                        if (abs(offY) > boxH * 0.16f) {
                            val dir = if (offY > 0) 1f else -1f
                            val y0 = offY
                            val x0 = offX
                            val s0 = scale
                            scope.launch {
                                animate(0f, 1f, animationSpec = tween(220)) { f, _ ->
                                    offY = y0 + (dir * boxH - y0) * f
                                    offX = x0 * (1f - f)
                                    scale = s0 * (1f - 0.25f * f)
                                    onFade(1f)
                                }
                                onDismiss()
                            }
                        } else settle(1f, 0f, 0f)
                    }
                }
            }
    ) {
        Image(
            bitmap = bitmap, contentDescription = description, contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offX
                translationY = offY
            }
        )
    }
}

/**
 * Full-screen image overlay for chat pictures: springs open, zooms, and flies away when dragged down.
 */
@Composable
fun ImageOverlay(path: String, onClose: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { Thumbs.get(path, 2000) }
    }
    var fade by remember { mutableFloatStateOf(0f) }
    val open = remember { Animatable(0f) }
    LaunchedEffect(Unit) { open.animateTo(1f, spring(dampingRatio = 0.82f, stiffness = 320f)) }
    BackHandler { onClose() }
    Box(
        Modifier.fillMaxSize()
            .background(Color.Black.copy(alpha = (0.96f * open.value * (1f - fade)).coerceIn(0f, 1f)))
    ) {
        val b = bmp
        if (b != null) {
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val o = open.value
                    scaleX = 0.88f + 0.12f * o
                    scaleY = 0.88f + 0.12f * o
                    alpha = o.coerceIn(0f, 1f)
                }
            ) { ZoomImage(b, null, onDismiss = onClose, onFade = { fade = it }) }
        }
    }
}
