package com.messages.app

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.database.ContentObserver
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: MessagesVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        val st = Store(this)
        val sysDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        CurTheme = resolveTheme(st.theme, st.system, sysDark)
        HapticsOn = st.haptics
        Mesh.init(this)
        handle(intent)
        setContent { App(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        Mesh.foreground = true
        vm.refresh()
    }

    override fun onPause() {
        super.onPause()
        Mesh.foreground = false
    }

    private fun handle(i: Intent?) {
        if (i?.getBooleanExtra("mesh", false) == true) {
            vm.goto.value = "nearby"
            i?.getStringExtra("conv")?.let { Mesh.openConv.value = it }
            return
        }
        val data = i?.data
        val addr = i?.getStringExtra("address")
            ?: if (data != null && data.scheme in listOf("sms", "smsto", "mms", "mmsto"))
                Uri.decode(data.schemeSpecificPart).substringBefore('?') else null
        if (!addr.isNullOrBlank()) vm.startChat(addr)
    }
}

data class Settings(val theme: Int, val system: Boolean, val haptics: Boolean)

class MessagesVM(app: Application) : AndroidViewModel(app) {
    val repo = SmsRepo(app)
    val store = Store(app)
    val convos = MutableStateFlow<List<Convo>>(emptyList())
    val msgs = MutableStateFlow<List<Msg>>(emptyList())
    val open = MutableStateFlow<Chat?>(null)
    val isDefault = MutableStateFlow(false)
    val loaded = MutableStateFlow(false)
    val draft = MutableStateFlow("")
    val goto = MutableStateFlow<String?>(null)
    val settings = MutableStateFlow(Settings(store.theme, store.system, store.haptics))
    val pinned = MutableStateFlow(store.pinned)
    val blocked = MutableStateFlow(store.blocked)
    val starred = MutableStateFlow(store.starred)
    val trash = MutableStateFlow<List<Saved>>(emptyList())
    val reactions = MutableStateFlow(store.reactions)
    val sched = MutableStateFlow(store.sched)
    private var job: Job? = null
    private var watching = false
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { refresh() }
    }

    init {
        viewModelScope.launch { Bus.tick.collect { reload(); refresh() } }
        val cutoff = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
        store.trash = store.trash.filter { it.at > cutoff }
        reload()
    }

    fun reload() {
        pinned.value = store.pinned; blocked.value = store.blocked; starred.value = store.starred
        trash.value = store.trash; reactions.value = store.reactions; sched.value = store.sched
    }

    fun refresh() {
        val app = getApplication<Application>()
        if (app.checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return
        if (!watching) {
            try {
                app.contentResolver.registerContentObserver(Uri.parse("content://mms-sms/"), true, obs)
                watching = true
            } catch (_: Exception) { }
        }
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            delay(120)
            isDefault.value = repo.isDefault()
            val list = mergeMedia(repo.conversations())
            convos.value = list
            val o = open.value
            if (o != null) {
                val real = if (o.threadId <= 0) list.firstOrNull { nk(it.address) == nk(o.address) } else null
                val cur = if (real != null) o.copy(threadId = real.threadId).also { open.value = it } else o
                val extra = store.media.filter { nk(it.address) == nk(cur.address) }
                msgs.value = (repo.messages(cur.threadId, cur.address) + extra.map { it.toMsg() }).sortedBy { it.date }
                if (extra.any { !it.read }) {
                    store.media = store.media.map { if (nk(it.address) == nk(cur.address)) it.copy(read = true) else it }
                    reload()
                }
                if (list.any { it.threadId == cur.threadId && it.unread > 0 }) {
                    repo.markRead(cur.threadId)
                    NotificationManagerCompat.from(app).cancel(Notifier.nid(cur.address))
                }
            }
            loaded.value = true
        }
    }

    private fun mergeMedia(sms: List<Convo>): List<Convo> {
        val out = ArrayList(sms)
        for ((k, ms) in store.media.groupBy { nk(it.address) }) {
            val last = ms.maxByOrNull { it.date } ?: continue
            val snip = when {
                last.mime.startsWith("image") -> "\uD83D\uDCF7 Photo"
                last.mime.startsWith("audio") -> "\uD83C\uDFA4 Voice message"
                else -> last.text
            }
            val un = ms.count { !it.read && !it.outgoing }
            val idx = out.indexOfFirst { nk(it.address) == k }
            if (idx >= 0) {
                val c = out[idx]
                out[idx] = if (last.date > c.date) c.copy(snippet = snip, date = last.date, outgoing = last.outgoing, unread = c.unread + un, code = null)
                else c.copy(unread = c.unread + un)
            } else {
                out.add(Convo(-((k.hashCode().toLong() and 0x7fffffffL) + 1L), last.address, repo.name(last.address), snip, last.date, un, null, last.outgoing))
            }
        }
        return out.sortedByDescending { it.date }
    }

    fun sendImage(chat: Chat, uri: android.net.Uri, caption: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val bytes = Mms.compressImage(ctx, uri) ?: return@launch
            val id = System.currentTimeMillis()
            val f = File(File(ctx.filesDir, "media").apply { mkdirs() }, "img_$id.jpg")
            f.writeBytes(bytes)
            val parts = arrayListOf(Mms.Part("image.jpg", "image/jpeg", bytes))
            val recs = arrayListOf(Media(id, chat.address, f.path, "image/jpeg", id, true, true, 1, ""))
            if (caption.isNotBlank()) {
                parts.add(Mms.Part("text.txt", "text/plain", caption.toByteArray()))
                recs.add(Media(id + 1, chat.address, "", "text/plain", id + 1, true, true, 1, caption))
            }
            store.media = store.media + recs
            reload(); refresh()
            Mms.send(ctx, chat.address, parts, id)
        }
    }

    fun sendVoice(chat: Chat, file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val bytes = file.readBytes()
            val id = System.currentTimeMillis()
            val f = File(File(ctx.filesDir, "media").apply { mkdirs() }, "voice_$id.amr")
            f.writeBytes(bytes)
            file.delete()
            store.media = store.media + Media(id, chat.address, f.path, "audio/amr", id, true, true, 1, "")
            reload(); refresh()
            Mms.send(ctx, chat.address, listOf(Mms.Part("voice.amr", "audio/amr", bytes)), id)
        }
    }

    fun deleteMedia(ids: List<Long>) {
        viewModelScope.launch(Dispatchers.IO) {
            store.media.filter { it.id in ids }.forEach { if (it.path.isNotEmpty()) File(it.path).delete() }
            store.media = store.media.filter { it.id !in ids }
            reload(); refresh()
        }
    }

    fun openChat(c: Chat) {
        msgs.value = emptyList()
        open.value = c
        refresh()
        NotificationManagerCompat.from(getApplication<Application>()).cancel(Notifier.nid(c.address))
    }

    fun close() { open.value = null }

    fun startChat(address: String, name: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val a = address.trim()
            openChat(Chat(repo.threadFor(a), a, name ?: repo.name(a)))
        }
    }

    fun send(chat: Chat, text: String) {
        viewModelScope.launch(Dispatchers.IO) { repo.send(chat.address, text); refresh() }
    }

    // ---- settings ----
    fun setTheme(i: Int) { store.theme = i; settings.value = settings.value.copy(theme = i) }
    fun setSystem(b: Boolean) { store.system = b; settings.value = settings.value.copy(system = b) }
    fun setHaptics(b: Boolean) { store.haptics = b; settings.value = settings.value.copy(haptics = b) }

    // ---- conversation actions ----
    fun togglePin(c: Convo) { store.pinned = store.pinned.let { if (c.threadId in it) it - c.threadId else it + c.threadId }; reload() }
    fun toggleBlock(address: String) { val k = nk(address); store.blocked = store.blocked.let { if (k in it) it - k else it + k }; reload() }
    fun markReadConvo(c: Convo) { viewModelScope.launch(Dispatchers.IO) { repo.markRead(c.threadId); refresh() } }

    fun deleteThread(c: Convo) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val items = repo.messages(c.threadId, c.address).map { Saved(it.id, c.address, it.body, it.date, it.outgoing, now) }
            repo.deleteThread(c.threadId)
            store.media.filter { nk(it.address) == nk(c.address) }.forEach { if (it.path.isNotEmpty()) File(it.path).delete() }
            store.media = store.media.filter { nk(it.address) != nk(c.address) }
            store.trash = store.trash + items
            reload(); refresh()
        }
    }

    // ---- message actions ----
    suspend fun deleteMessages(chat: Chat, ids: Set<Long>): List<Saved> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val ok = msgs.value.filter { it.id in ids }
            .map { Saved(it.id, chat.address, it.body, it.date, it.outgoing, now) }
            .filter { repo.deleteMessage(it.id) > 0 }
        if (ok.isNotEmpty()) { store.trash = store.trash + ok; reload() }
        refresh()
        ok
    }

    fun restore(list: List<Saved>) {
        viewModelScope.launch(Dispatchers.IO) {
            list.forEach { repo.insertSaved(it) }
            store.trash = store.trash.filter { t -> list.none { it.id == t.id && it.at == t.at } }
            reload(); refresh()
        }
    }

    fun purge(s: Saved) { store.trash = store.trash.filter { !(it.id == s.id && it.at == s.at) }; reload() }
    fun emptyTrash() { store.trash = emptyList(); reload() }

    fun toggleStar(chat: Chat, m: Msg) {
        store.starred = if (store.starred.any { it.id == m.id }) store.starred.filter { it.id != m.id }
        else store.starred + Saved(m.id, chat.address, m.body, m.date, m.outgoing)
        reload()
    }
    fun unstar(s: Saved) { store.starred = store.starred.filter { it.id != s.id }; reload() }

    fun react(m: Msg, emoji: String) {
        val r = store.reactions.toMutableMap()
        if (r[m.id] == emoji) r.remove(m.id) else r[m.id] = emoji
        store.reactions = r
        reload()
    }

    fun schedule(kind: String, address: String, body: String, at: Long) {
        val s = Sched(System.currentTimeMillis(), kind, address, body, at)
        store.sched = store.sched + s
        Alarms.set(getApplication(), s)
        reload()
    }

    fun cancelSched(s: Sched) {
        Alarms.cancel(getApplication(), s.id)
        store.sched = store.sched.filter { it.id != s.id }
        reload()
    }

    override fun onCleared() {
        try { getApplication<Application>().contentResolver.unregisterContentObserver(obs) } catch (_: Exception) { }
    }
}
