package com.messages.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.provider.Telephony
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {

    private val vm: MessagesVM by viewModels()

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val theme = ThemeState(this)
        setContent {
            Root(vm, theme)
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }
}

// ------------------------------------------------------------------ notifications

object Notifier {

    const val CHANNEL = "messages_v2"

    private fun channel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Messages", NotificationManager.IMPORTANCE_HIGH)
                )
            }
        }
    }

    fun show(ctx: Context, from: String, body: String) {
        try {
            channel(ctx)
            val id = from.hashCode()
            val open = Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(
                ctx, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val replyIntent = Intent(ctx, ReplyReceiver::class.java).putExtra("addr", from)
            val replyPi = PendingIntent.getBroadcast(
                ctx, id + 1, replyIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val remote = RemoteInput.Builder("reply").setLabel("Reply").build()
            val action = Notification.Action.Builder(
                Icon.createWithResource(ctx, R.drawable.ic_stat), "Reply", replyPi
            ).addRemoteInput(remote).build()

            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(ctx, CHANNEL)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(ctx)
            }
            builder
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(from)
                .setContentText(body)
                .setStyle(Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .addAction(action)

            ctx.getSystemService(NotificationManager::class.java)?.notify(id, builder.build())
        } catch (_: Exception) {
        }
    }

    fun clear(ctx: Context, from: String) {
        try {
            ctx.getSystemService(NotificationManager::class.java)?.cancel(from.hashCode())
        } catch (_: Exception) {
        }
    }
}

class SmsReceivedReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try {
            val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
            if (parts.isEmpty()) return
            val from = parts[0].displayOriginatingAddress ?: "Unknown"
            val body = parts.joinToString("") { it.displayMessageBody ?: "" }
            Notifier.show(ctx, from, body)
        } catch (_: Exception) {
        }
    }
}

class ReplyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try {
            val text = RemoteInput.getResultsFromIntent(intent)?.getCharSequence("reply")?.toString()
            val addr = intent.getStringExtra("addr")
            if (!text.isNullOrBlank() && !addr.isNullOrBlank()) {
                SmsRepo(ctx).send(addr, text)
                Notifier.clear(ctx, addr)
            }
        } catch (_: Exception) {
        }
    }
}
