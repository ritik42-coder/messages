package com.messages.app

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MessagesVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        handle(intent)
        setContent { App(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }

    private fun handle(i: Intent?) {
        val data = i?.data
        val addr = i?.getStringExtra("address")
            ?: if (data != null && data.scheme in listOf("sms", "smsto", "mms", "mmsto"))
                Uri.decode(data.schemeSpecificPart).substringBefore('?') else null
        if (!addr.isNullOrBlank()) vm.startChat(addr)
    }
}

class MessagesVM(app: Application) : AndroidViewModel(app) {
    val repo = SmsRepo(app)
    val convos = MutableStateFlow<List<Convo>>(emptyList())
    val msgs = MutableStateFlow<List<Msg>>(emptyList())
    val open = MutableStateFlow<Chat?>(null)
    val isDefault = MutableStateFlow(false)
    val loaded = MutableStateFlow(false)
    private var job: Job? = null
    private var watching = false
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { refresh() }
    }

    fun refresh() {
        val app = getApplication<Application>()
        if (app.checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return
        if (!watching) {
            try {
                app.contentResolver.registerContentObserver(Uri.parse("content://mms-sms/"), true, obs)
                watching = true
            } catch (_: Exception) { }
        }
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            delay(100)
            isDefault.value = repo.isDefault()
            val list = repo.conversations()
            convos.value = list
            val o = open.value
            if (o != null) {
                val real = if (o.threadId <= 0) list.firstOrNull { nk(it.address) == nk(o.address) } else null
                val cur = if (real != null) o.copy(threadId = real.threadId).also { open.value = it } else o
                msgs.value = repo.messages(cur.threadId, cur.address)
                if (list.any { it.threadId == cur.threadId && it.unread > 0 }) {
                    repo.markRead(cur.threadId)
                    NotificationManagerCompat.from(app).cancel(Notifier.nid(cur.address))
                }
            }
            loaded.value = true
        }
    }

    fun openChat(c: Chat) {
        msgs.value = emptyList()
        open.value = c
        refresh()
        NotificationManagerCompat.from(getApplication<Application>()).cancel(Notifier.nid(c.address))
    }

    fun close() { open.value = null }

    fun startChat(address: String, name: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val a = address.trim()
            openChat(Chat(repo.threadFor(a), a, name ?: repo.name(a)))
        }
    }

    fun send(chat: Chat, text: String) {
        viewModelScope.launch(Dispatchers.IO) { repo.send(chat.address, text); refresh() }
    }

    fun delete(c: Convo) {
        viewModelScope.launch(Dispatchers.IO) { repo.deleteThread(c.threadId); refresh() }
    }

    override fun onCleared() {
        try { getApplication<Application>().contentResolver.unregisterContentObserver(obs) } catch (_: Exception) { }
    }
}
