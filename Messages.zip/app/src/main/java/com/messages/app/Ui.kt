@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.roundToInt
import kotlin.random.Random
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.input.pointer.pointerInput
import android.view.WindowManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

// ---------- themes ----------
class AppTheme(
    val name: String, val dark: Boolean,
    val bg: Color, val surf: Color, val surf2: Color, val ink: Color, val dim: Color,
    val a1: Color, val a2: Color, val a3: Color
) {
    val brand: Brush = Brush.linearGradient(listOf(a1, a2, a3))
}

private fun th(n: String, d: Boolean, bg: Long, s: Long, s2: Long, ink: Long, dim: Long, a1: Long, a2: Long, a3: Long) =
    AppTheme(n, d, Color(bg), Color(s), Color(s2), Color(ink), Color(dim), Color(a1), Color(a2), Color(a3))

val THEMES = listOf(
    th("Midnight", true, 0xFF07070D, 0xFF14141F, 0xFF1E1E2E, 0xFFF4F4FB, 0xFF9A9AB5, 0xFF6D5BFF, 0xFFB04BFF, 0xFFFF5CA8),
    th("AMOLED", true, 0xFF000000, 0xFF101012, 0xFF1B1B1F, 0xFFFFFFFF, 0xFF8E8E93, 0xFF00E0FF, 0xFF4D7CFF, 0xFF9B5CFF),
    th("Daylight", false, 0xFFF6F5FF, 0xFFFFFFFF, 0xFFECEAFB, 0xFF14142B, 0xFF6B6B88, 0xFF6D5BFF, 0xFFB04BFF, 0xFFFF5CA8),
    th("Rose Quartz", false, 0xFFFFF5F8, 0xFFFFFFFF, 0xFFFFE6EE, 0xFF2B1620, 0xFF8A6577, 0xFFFF5C8A, 0xFFFF7A59, 0xFFFFB36B),
    th("Ocean", true, 0xFF06111A, 0xFF0D1E2B, 0xFF143044, 0xFFEAF6FF, 0xFF86A5BA, 0xFF00B3FF, 0xFF00D4C0, 0xFF5CFFB1),
    th("Sunset", true, 0xFF120A0C, 0xFF211215, 0xFF2E1A1E, 0xFFFFF1EC, 0xFFB89A95, 0xFFFF7A18, 0xFFFF4D6D, 0xFFC13BFF),
    th("Mint", false, 0xFFF1FBF7, 0xFFFFFFFF, 0xFFDDF5EA, 0xFF0F2A21, 0xFF5E8577, 0xFF00B894, 0xFF00A3C4, 0xFF6C5CE7),
    th("Emerald", true, 0xFF050E0A, 0xFF0C1C15, 0xFF142B21, 0xFFE9FFF4, 0xFF84AD9A, 0xFF1ED760, 0xFF00C2A8, 0xFF8BE04E),
    th("Indigo Night", true, 0xFF05070F, 0xFF0D1120, 0xFF161C30, 0xFFEAF0FF, 0xFF8894B5, 0xFF3D5AFE, 0xFF7C4DFF, 0xFF00E5FF),
    th("Neon", true, 0xFF06060A, 0xFF101018, 0xFF171722, 0xFFF0F0F8, 0xFF8A8AA0, 0xFF00FFC2, 0xFF00A3FF, 0xFFC400FF),
    th("Sakura", false, 0xFFFFF7FA, 0xFFFFFFFF, 0xFFFFE9F1, 0xFF2A1620, 0xFF8B6A78, 0xFFFF6FA5, 0xFFFF9E6D, 0xFFC86DD7),
    th("Copper", true, 0xFF0E0A08, 0xFF1A1310, 0xFF261A14, 0xFFFFF3EA, 0xFFB39A8A, 0xFFE07A3F, 0xFFC2410C, 0xFFF59E0B),
    th("Chhath", true, 0xFF140805, 0xFF231009, 0xFF331A0E, 0xFFFFF3E0, 0xFFC9A98F, 0xFFFFB300, 0xFFFF6D00, 0xFF00B8D4),
    th("Monsoon", true, 0xFF07101A, 0xFF0E1B28, 0xFF16283A, 0xFFE6F1FA, 0xFF8FA6BA, 0xFF4FC3F7, 0xFF00897B, 0xFF7C4DFF),
    th("Peacock", true, 0xFF04120F, 0xFF0A1F1A, 0xFF123029, 0xFFE8FFF8, 0xFF7FB0A2, 0xFF00BFA5, 0xFF1565C0, 0xFFFFC107),
    th("Lagoon", false, 0xFFF0FBFB, 0xFFFFFFFF, 0xFFDDF3F3, 0xFF0C2B2B, 0xFF5F8484, 0xFF00ACC1, 0xFF00897B, 0xFF26C6DA),
    th("Desert", false, 0xFFFBF3E6, 0xFFFFFDF8, 0xFFF3E4CC, 0xFF3A2A18, 0xFF9A8467, 0xFFD97706, 0xFFB45309, 0xFF8D6E63),
    th("Ivory", false, 0xFFFFFDF6, 0xFFFFFFFF, 0xFFF6F0E2, 0xFF241F17, 0xFF8C8271, 0xFFB08D57, 0xFF7A5C2E, 0xFFD4AF37),
    th("Cyber", true, 0xFF050510, 0xFF0E0E1E, 0xFF171730, 0xFFEAF6FF, 0xFF7C86A8, 0xFF00E5FF, 0xFFFF00A0, 0xFF7CFF00),
    th("Maroon", true, 0xFF120608, 0xFF1E0C10, 0xFF2C1218, 0xFFFFF0F2, 0xFFB48A93, 0xFFB71C1C, 0xFF7B1FA2, 0xFFFFB300),
    th("Galaxy", true, 0xFF06030F, 0xFF100A1E, 0xFF1A1130, 0xFFF2ECFF, 0xFF9B8FBF, 0xFF7C4DFF, 0xFF00D4FF, 0xFFFF5CE1),
    th("Lava", true, 0xFF0C0403, 0xFF1A0A06, 0xFF2A110A, 0xFFFFF0E8, 0xFFC09A88, 0xFFFF3D00, 0xFFFFA000, 0xFFD50000),
    th("Sky", false, 0xFFEFF7FF, 0xFFFFFFFF, 0xFFDDEBFA, 0xFF10233A, 0xFF6A819B, 0xFF2196F3, 0xFF03A9F4, 0xFF7C4DFF),
    th("Coral", false, 0xFFFFF4F0, 0xFFFFFFFF, 0xFFFFE2D6, 0xFF3A1F17, 0xFF9A7365, 0xFFFF7043, 0xFFFF5252, 0xFFFFB300),
    th("Tide", true, 0xFF04121A, 0xFF0A2130, 0xFF123246, 0xFFE8F6FF, 0xFF86A6BC, 0xFF00B4D8, 0xFF0077B6, 0xFF90E0EF),
    th("Cosmos", true, 0xFF05030D, 0xFF0E0A1C, 0xFF18122E, 0xFFF0EAFF, 0xFF9A8FC0, 0xFF9D4EDD, 0xFF5A189A, 0xFFFFB703),
    th("Fireflies", true, 0xFF06110A, 0xFF0D1F14, 0xFF15301F, 0xFFF2FFE9, 0xFF8FAF93, 0xFFFFD166, 0xFF06D6A0, 0xFFEF476F),
    th("Festival", true, 0xFF100A18, 0xFF1C1228, 0xFF2A1A3A, 0xFFFFF3E0, 0xFFBFA8C9, 0xFFFFB703, 0xFFFB8500, 0xFFFFD60A),
    th("Prism", false, 0xFFF7F8FF, 0xFFFFFFFF, 0xFFEAECFB, 0xFF16182B, 0xFF6F7590, 0xFF7C4DFF, 0xFF00C2FF, 0xFFFF4D8D),
    th("Snow", false, 0xFFF2F8FF, 0xFFFFFFFF, 0xFFE1EDFA, 0xFF14263A, 0xFF6E879C, 0xFF6FA8DC, 0xFF3D85C6, 0xFFA9C7E8),
    th("Beats", true, 0xFF07060C, 0xFF12101C, 0xFF1C1930, 0xFFF5F0FF, 0xFF8F88A8, 0xFF00F5D4, 0xFFF15BB5, 0xFFFEE440)
)

fun resolveTheme(sel: Int, system: Boolean, sysDark: Boolean): AppTheme {
    val t = THEMES[sel.coerceIn(0, THEMES.lastIndex)]
    if (!system || t.dark == sysDark) return t
    return if (sysDark) THEMES[0] else THEMES[2]
}

var CurTheme by mutableStateOf(THEMES[0])
var HapticsOn = true
var MotionOn by mutableStateOf(true)

/** Everything the user can reshape, kept as live state so changes show instantly. */
object Look {
    var hue by mutableStateOf(-1)
    var radius by mutableStateOf(22)
    var glass by mutableStateOf(false)
    var pattern by mutableStateOf(0)
    var font by mutableStateOf(0)
    var density by mutableStateOf(1)
    var avatar by mutableStateOf(0)

    fun load(s: Store) {
        h24 = s.clock24
        bubbleWidth = s.bubbleWidth
        patternAlpha = s.patternAlpha
        hue = s.accentHue
        radius = s.bubbleRadius
        glass = s.bubbleGlass
        pattern = s.chatPattern
        font = s.fontFamily
        density = s.density
        avatar = s.avatarShape
    }

    val family: FontFamily get() = when (font) {
        1 -> FontFamily.Serif
        2 -> FontFamily.Monospace
        else -> FontFamily.Default
    }

    var h24 by mutableStateOf(false)
    var bubbleWidth by mutableStateOf(290)
    var patternAlpha by mutableStateOf(1f)

    val rowGap: Dp get() = when (density) {
        0 -> 1.dp
        2 -> 6.dp
        else -> 3.dp
    }

    val bubbleShape: RoundedCornerShape get() = RoundedCornerShape(radius.dp)
}

// The live palette. Every screen reads these, so when you pick a new theme the whole
// app blends across instead of snapping.
private val cBg = mutableStateOf(THEMES[0].bg)
private val cSurf = mutableStateOf(THEMES[0].surf)
private val cSurf2 = mutableStateOf(THEMES[0].surf2)
private val cInk = mutableStateOf(THEMES[0].ink)
private val cDim = mutableStateOf(THEMES[0].dim)
private val cA1 = mutableStateOf(THEMES[0].a1)
private val cA2 = mutableStateOf(THEMES[0].a2)
private val cA3 = mutableStateOf(THEMES[0].a3)

val Bg: Color get() = cBg.value
val Surf: Color get() = cSurf.value
val Surf2: Color get() = cSurf2.value
val Ink: Color get() = cInk.value
val Dim: Color get() = cDim.value
val A1: Color get() = cA1.value
val A2: Color get() = cA2.value
val A3: Color get() = cA3.value
val Brand: Brush get() = Brush.linearGradient(listOf(cA1.value, cA2.value, cA3.value))
val Gold = Color(0xFFFFC857)

val PERMS: Array<String> = buildList {
    add(Manifest.permission.READ_SMS); add(Manifest.permission.SEND_SMS)
    add(Manifest.permission.RECEIVE_SMS); add(Manifest.permission.READ_CONTACTS)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

fun hasPerm(c: Context) = c.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

fun defaultSmsIntent(c: Context): Intent =
    if (Build.VERSION.SDK_INT >= 29) c.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
    else Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, c.packageName)

// ---------- helpers ----------
fun hm(t: Long): String =
    SimpleDateFormat(if (Look.h24) "HH:mm" else "h:mm a", Locale.getDefault()).format(Date(t))
fun fullDate(t: Long): String = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(t))

fun fmt(t: Long): String = when {
    DateUtils.isToday(t) -> hm(t)
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    System.currentTimeMillis() - t < 6 * DateUtils.DAY_IN_MILLIS -> SimpleDateFormat("EEE", Locale.getDefault()).format(Date(t))
    else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))
}

fun dayLabel(t: Long): String = when {
    DateUtils.isToday(t) -> "Today"
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    else -> SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(t))
}

fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

fun dayStart(t: Long): Long = Calendar.getInstance().apply {
    timeInMillis = t
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun combine(day: Long, hour: Int, minute: Int): Long = Calendar.getInstance().apply {
    timeInMillis = day
    set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun timeOptions(): List<Pair<String, Long>> {
    val now = System.currentTimeMillis()
    val out = ArrayList<Pair<String, Long>>()
    out.add("In 1 hour" to now + 3_600_000L)
    val ev = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 18); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
    if (ev.timeInMillis > now + 600_000L) out.add("This evening, 6 PM" to ev.timeInMillis)
    val tm = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
    out.add("Tomorrow, 9 AM" to tm.timeInMillis)
    return out
}

// ---------- animation building blocks ----------
object Seen { val set = HashSet<String>() }

fun Modifier.bounce(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.95f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "bounce"
    )
    val h = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            onLongClick = onLong?.let { f -> { if (HapticsOn) h.performHapticFeedback(HapticFeedbackType.LongPress); f() } },
            onClick = { if (HapticsOn) h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
        )
}

// ---------- global look switches ----------
var ElderMode by mutableStateOf(false)

fun Context.copyText(t: String, msg: String = "Copied") {
    try {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Messages", t))
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    } catch (_: Exception) { }
}

/** Swipe a row right for [rightLabel], left for [leftLabel]. Snaps back by itself. */
@Composable
fun SwipeRow(
    rightIcon: ImageVector, rightLabel: String, rightColor: Color, onRight: (() -> Unit)? = null,
    leftIcon: ImageVector, leftLabel: String, leftColor: Color, onLeft: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val limit = with(LocalDensity.current) { 86.dp.toPx() }
    var dx by remember { mutableStateOf(0f) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var armed by remember { mutableStateOf(0) }
    Box(modifier.fillMaxWidth()) {
        val v = dx
        if (v > 4f) {
            Row(Modifier.matchParentSize().padding(start = 26.dp), verticalAlignment = Alignment.CenterVertically) {
                val k = (v / limit).coerceIn(0f, 1f)
                Icon(
                    rightIcon, null, tint = rightColor,
                    modifier = Modifier.size(22.dp).graphicsLayer { alpha = k; scaleX = 0.55f + 0.45f * k; scaleY = 0.55f + 0.45f * k }
                )
                if (k > 0.62f) {
                    Spacer(Modifier.width(8.dp))
                    Text(rightLabel, color = rightColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else if (v < -4f) {
            Row(Modifier.matchParentSize().padding(end = 26.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                val k = (-v / limit).coerceIn(0f, 1f)
                if (k > 0.62f) {
                    Text(leftLabel, color = leftColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                }
                Icon(
                    leftIcon, null, tint = leftColor,
                    modifier = Modifier.size(22.dp).graphicsLayer { alpha = k; scaleX = 0.55f + 0.45f * k; scaleY = 0.55f + 0.45f * k }
                )
            }
        }
        Box(
            Modifier.offset { IntOffset(dx.roundToInt(), 0) }.pointerInput(onLeft, onRight) {
                detectHorizontalDragGestures(
                    onDragStart = { armed = 0 },
                    onDragCancel = { scope.launch { animate(dx, 0f, animationSpec = tween(150)) { x, _ -> dx = x } } },
                    onDragEnd = {
                        val target = when {
                            dx > limit && onRight != null -> limit
                            dx < -limit && onLeft != null -> -limit
                            else -> 0f
                        }
                        scope.launch {
                            if (target != 0f) {
                                animate(dx, target, animationSpec = tween(140)) { x, _ -> dx = x }
                                if (target > 0) onRight?.invoke() else onLeft?.invoke()
                            }
                            animate(dx, 0f, animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { x, _ -> dx = x }
                        }
                    },
                    onHorizontalDrag = { _, drag ->
                        dx = (dx + drag).coerceIn(-limit * 1.25f, limit * 1.25f)
                        val a = when {
                            dx > limit -> 1
                            dx < -limit -> -1
                            else -> 0
                        }
                        if (a != armed && a != 0) {
                            armed = a
                            if (HapticsOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                        if (a == 0) armed = 0
                    }
                )
            }
        ) { content() }
    }
}

/** Wipes a row away with a bright edge sweep (used for bulk delete instead of particles). */
fun Modifier.wipeAway(p: Float): Modifier = this
    .graphicsLayer {
        alpha = (1f - p * 0.92f).coerceIn(0f, 1f)
        scaleY = 1f - 0.3f * p * p
    }
    .drawWithContent {
        if (p <= 0.001f) {
            drawContent()
        } else {
            val keep = size.width * (1f - p)
            clipRect(0f, 0f, keep, size.height) { this@drawWithContent.drawContent() }
            val edge = size.width * 0.16f
            drawRect(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, A2, Color.Transparent)),
                topLeft = Offset(keep - edge / 2f, 0f),
                size = Size(edge, size.height)
            )
        }
    }

@Composable
fun WipeRow(active: Boolean, content: @Composable () -> Unit) {
    val p by animateFloatAsState(if (active) 1f else 0f, tween(460, easing = FastOutSlowInEasing), label = "wipe")
    Box(Modifier.wipeAway(p)) { content() }
}

// swallows touches so screens stacked underneath never receive them
fun Modifier.blockTouches(): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
}

@Composable
fun Appear(i: Int, key: String? = null, content: @Composable () -> Unit) {
    val already = key != null && key in Seen.set
    val p = remember { Animatable(if (already) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!already) {
            if (i < 10) delay(i * 40L)
            p.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
            key?.let { Seen.set.add(it) }
        }
    }
    Box(Modifier.graphicsLayer { alpha = p.value; translationY = (1f - p.value) * 60f }) { content() }
}

// ---------- animated theme scenes ----------
/** Themes whose background actually moves, not just changes colour. */
val LIVE_THEMES = setOf(
    "Chhath", "Monsoon", "Sakura", "Neon", "Cyber", "Ocean", "Lagoon", "Mint",
    "Peacock", "Galaxy", "Lava", "Sky", "Coral",
    "Tide", "Cosmos", "Fireflies", "Festival", "Prism", "Snow", "Beats"
)

fun scenePeriod(name: String): Int = when (name) {
    "Monsoon" -> 5200
    "Sakura" -> 9000
    "Lava" -> 6000
    "Neon", "Cyber" -> 7000
    "Galaxy" -> 8000
    "Tide" -> 11000
    "Cosmos" -> 14000
    "Fireflies" -> 9000
    "Festival" -> 7000
    "Prism" -> 6500
    "Snow" -> 15000
    "Beats" -> 4200
    else -> 12000
}

private fun DrawScope.blobScene(c1: Color, c2: Color, c3: Color, dark: Boolean, q: Float, p: Float) {
    val k = if (dark) 1f else 0.55f
    val w = size.width
    val h = size.height
    val a = Offset(w * (0.06f + 0.58f * q), h * (0.04f + 0.20f * p))
    val b = Offset(w * (0.98f - 0.55f * p), h * (0.20f + 0.20f * q))
    val c = Offset(w * (0.28f + 0.42f * q), h * (0.40f + 0.14f * p))
    val r1 = w * 0.80f
    val r2 = w * 0.62f
    val r3 = w * 0.46f
    drawCircle(Brush.radialGradient(listOf(c1.copy(alpha = 0.55f * k), Color.Transparent), center = a, radius = r1), radius = r1, center = a)
    drawCircle(Brush.radialGradient(listOf(c3.copy(alpha = 0.40f * k), Color.Transparent), center = b, radius = r2), radius = r2, center = b)
    drawCircle(Brush.radialGradient(listOf(c2.copy(alpha = 0.30f * k), Color.Transparent), center = c, radius = r3), radius = r3, center = c)
}

/** Chhath: the setting sun over a river, rays breathing, water catching the light. */
private fun DrawScope.sunScene(gold: Color, orange: Color, river: Color, q: Float) {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * (0.34f + 0.03f * q)
    val r = w * 0.15f
    for (i in 0 until 26) {
        val a = (i / 26f) * 6.2832f
        val len = r * (1.30f + 0.22f * kotlin.math.sin(q * 6.2832f + i * 0.9f))
        drawLine(
            color = gold.copy(alpha = 0.22f),
            start = Offset(cx + kotlin.math.cos(a) * r * 1.15f, cy + kotlin.math.sin(a) * r * 1.15f),
            end = Offset(cx + kotlin.math.cos(a) * len, cy + kotlin.math.sin(a) * len),
            strokeWidth = 3.5f
        )
    }
    drawCircle(
        Brush.radialGradient(
            listOf(gold.copy(alpha = 0.55f), orange.copy(alpha = 0.18f), Color.Transparent),
            center = Offset(cx, cy), radius = r * 2.8f
        ),
        radius = r * 2.8f, center = Offset(cx, cy)
    )
    drawCircle(gold, radius = r, center = Offset(cx, cy))
    drawCircle(Color.White.copy(alpha = 0.45f), radius = r * 0.55f, center = Offset(cx, cy))
    val wy = h * 0.66f
    for (i in 0 until 8) {
        val yy = wy + i * h * 0.032f
        val shift = kotlin.math.sin(q * 6.2832f + i * 0.8f) * w * 0.05f
        drawRect(
            color = river.copy(alpha = 0.20f * (1f - i / 8f)),
            topLeft = Offset(w * 0.12f + shift, yy),
            size = Size(w * 0.76f, h * 0.010f)
        )
    }
}

private fun DrawScope.rainScene(c1: Color, c2: Color, c3: Color, dark: Boolean, p: Float) {
    val w = size.width
    val h = size.height
    val k = if (dark) 1f else 0.6f
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.42f * k), Color.Transparent), center = Offset(w * 0.2f, -h * 0.1f), radius = w * 0.85f),
        radius = w * 0.85f, center = Offset(w * 0.2f, -h * 0.1f)
    )
    drawCircle(
        Brush.radialGradient(listOf(c3.copy(alpha = 0.30f * k), Color.Transparent), center = Offset(w * 0.85f, h * 0.06f), radius = w * 0.6f),
        radius = w * 0.6f, center = Offset(w * 0.85f, h * 0.06f)
    )
    for (i in 0 until 44) {
        val seed = ((i * 37) % 97) / 97f
        val x = w * ((seed + i * 0.031f) % 1f)
        val len = h * (0.05f + 0.06f * ((i * 13 % 7) / 7f))
        val y = ((p * 1.35f + seed) % 1f) * (h + len) - len
        drawLine(c2.copy(alpha = 0.26f * k), Offset(x, y), Offset(x - len * 0.22f, y + len), strokeWidth = 2f)
    }
}

private fun DrawScope.petalScene(c1: Color, c2: Color, c3: Color, p: Float, q: Float) {
    val w = size.width
    val h = size.height
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.35f), Color.Transparent), center = Offset(w * 0.75f, h * 0.1f), radius = w * 0.7f),
        radius = w * 0.7f, center = Offset(w * 0.75f, h * 0.1f)
    )
    for (i in 0 until 20) {
        val seed = ((i * 41) % 97) / 97f
        val x = w * ((seed + q * 0.22f) % 1f)
        val y = ((p + seed) % 1f) * (h * 1.25f) - h * 0.12f
        val r = 3f + 4f * seed
        rotate(p * 360f + i * 26f, pivot = Offset(x, y)) {
            drawOval(
                color = (if (i % 3 == 0) c2 else c3).copy(alpha = 0.5f),
                topLeft = Offset(x - r, y - r * 0.55f),
                size = Size(r * 2f, r * 1.1f)
            )
        }
    }
}

private fun DrawScope.gridScene(c1: Color, c2: Color, c3: Color, p: Float, q: Float) {
    val w = size.width
    val h = size.height
    val horizon = h * 0.52f
    drawCircle(
        Brush.radialGradient(listOf(c2.copy(alpha = 0.45f), Color.Transparent), center = Offset(w * 0.5f, horizon), radius = w * 0.6f),
        radius = w * 0.6f, center = Offset(w * 0.5f, horizon)
    )
    for (i in 0..10) {
        val t = i / 10f
        val y = horizon + (h - horizon) * (t * t)
        drawLine(c1.copy(alpha = 0.34f * (1f - t * 0.35f)), Offset(0f, y), Offset(w, y), strokeWidth = 1.6f)
    }
    for (i in -7..7) {
        drawLine(
            c1.copy(alpha = 0.26f),
            Offset(w * 0.5f, horizon),
            Offset(w * 0.5f + i * w * 0.20f, h),
            strokeWidth = 1.6f
        )
    }
    val sy = horizon + (h - horizon) * q
    drawLine(c3.copy(alpha = 0.45f), Offset(0f, sy), Offset(w, sy), strokeWidth = 2.5f)
}

private fun DrawScope.bubbleScene(c1: Color, c2: Color, c3: Color, p: Float) {
    val w = size.width
    val h = size.height
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.32f), Color.Transparent), center = Offset(w * 0.3f, h * 0.9f), radius = w * 0.8f),
        radius = w * 0.8f, center = Offset(w * 0.3f, h * 0.9f)
    )
    for (i in 0 until 16) {
        val seed = ((i * 29) % 89) / 89f
        val x = w * seed
        val y = h * (1f - ((p + seed) % 1f))
        val r = 3f + 9f * seed
        drawCircle((if (i % 2 == 0) c2 else c3).copy(alpha = 0.20f + 0.25f * seed), radius = r, center = Offset(x, y))
    }
}

private fun DrawScope.ringScene(c1: Color, c2: Color, c3: Color, q: Float) {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.45f
    for (i in 0 until 7) {
        val t = (i / 7f + q) % 1f
        val r = w * (0.08f + 0.55f * t)
        drawCircle(
            color = (if (i % 2 == 0) c1 else c3).copy(alpha = 0.30f * (1f - t)),
            radius = r, center = Offset(cx, cy), style = Stroke(width = 2.5f)
        )
    }
    drawCircle(
        Brush.radialGradient(listOf(c2.copy(alpha = 0.35f), Color.Transparent), center = Offset(cx, cy), radius = w * 0.5f),
        radius = w * 0.5f, center = Offset(cx, cy)
    )
}

private fun DrawScope.starScene(c1: Color, c2: Color, c3: Color, p: Float, q: Float) {
    val w = size.width
    val h = size.height
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.38f), Color.Transparent), center = Offset(w * 0.25f, h * 0.25f), radius = w * 0.75f),
        radius = w * 0.75f, center = Offset(w * 0.25f, h * 0.25f)
    )
    for (i in 0 until 46) {
        val sx = ((i * 53) % 101) / 101f
        val sy = ((i * 31) % 97) / 97f
        val tw = 0.35f + 0.65f * kotlin.math.abs(kotlin.math.sin(p * 6.2832f + i))
        val r = 0.8f + 1.6f * tw
        drawCircle(
            (if (i % 4 == 0) c3 else c2).copy(alpha = 0.75f * tw),
            radius = r, center = Offset(w * sx, h * sy * (0.9f + 0.1f * q))
        )
    }
}

private fun DrawScope.emberScene(c1: Color, c2: Color, c3: Color, p: Float) {
    val w = size.width
    val h = size.height
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.45f), Color.Transparent), center = Offset(w * 0.5f, h * 1.05f), radius = w * 0.9f),
        radius = w * 0.9f, center = Offset(w * 0.5f, h * 1.05f)
    )
    for (i in 0 until 22) {
        val seed = ((i * 43) % 91) / 91f
        val x = w * (0.1f + 0.8f * seed + 0.04f * kotlin.math.sin(p * 6.2832f + i))
        val y = h * (1f - ((p * 1.2f + seed) % 1f))
        val r = 1.5f + 3f * seed
        drawCircle((if (i % 3 == 0) c2 else c3).copy(alpha = 0.25f + 0.4f * seed), radius = r, center = Offset(x, y))
    }
}

private fun DrawScope.cloudScene(c1: Color, c2: Color, c3: Color, dark: Boolean, q: Float) {
    val w = size.width
    val h = size.height
    val k = if (dark) 1f else 0.7f
    for (i in 0 until 5) {
        val seed = i / 5f
        val x = w * ((seed + q * 0.35f) % 1f)
        val y = h * (0.12f + 0.14f * i)
        val r = w * (0.22f + 0.10f * seed)
        drawCircle(
            Brush.radialGradient(
                listOf((if (i % 2 == 0) c1 else c3).copy(alpha = 0.30f * k), Color.Transparent),
                center = Offset(x, y), radius = r
            ),
            radius = r, center = Offset(x, y)
        )
    }
}

private fun DrawScope.waveScene(c1: Color, c2: Color, c3: Color, dark: Boolean, p: Float) {
    val w = size.width
    val h = size.height
    val k = if (dark) 1f else 0.65f
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.32f * k), Color.Transparent), center = Offset(w * 0.5f, h * 0.12f), radius = w * 0.85f),
        radius = w * 0.85f, center = Offset(w * 0.5f, h * 0.12f)
    )
    for (i in 0 until 3) {
        val path = Path()
        val base = h * (0.60f + 0.10f * i)
        val amp = h * (0.030f + 0.014f * i)
        val phase = p * 6.2832f + i * 1.4f
        path.moveTo(0f, base)
        var x = 0f
        val step = w / 36f
        while (x <= w) {
            path.lineTo(x, base + amp * kotlin.math.sin(x / w * 9.8f + phase))
            x += step
        }
        path.lineTo(w, h)
        path.lineTo(0f, h)
        path.close()
        drawPath(path, color = (if (i == 0) c2 else c3).copy(alpha = (0.32f - 0.07f * i) * k))
    }
}

private fun DrawScope.orbitScene(c1: Color, c2: Color, c3: Color, p: Float) {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.5f
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.40f), Color.Transparent), center = Offset(cx, cy), radius = w * 0.5f),
        radius = w * 0.5f, center = Offset(cx, cy)
    )
    for (ring in 0 until 3) {
        val r = w * (0.17f + 0.14f * ring)
        drawCircle(c2.copy(alpha = 0.16f), radius = r, center = Offset(cx, cy), style = Stroke(width = 1.5f))
        val speed = 0.55f + ring * 0.35f
        for (dot in 0 until 2) {
            val a = p * 6.2832f * speed + dot * 3.1416f + ring
            drawCircle(
                if (dot == 0) c3 else c1,
                radius = 3.4f,
                center = Offset(cx + kotlin.math.cos(a) * r, cy + kotlin.math.sin(a) * r)
            )
        }
    }
}

private fun DrawScope.flyScene(c1: Color, c2: Color, c3: Color, p: Float, q: Float) {
    val w = size.width
    val h = size.height
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.28f), Color.Transparent), center = Offset(w * 0.5f, h * 0.8f), radius = w * 0.85f),
        radius = w * 0.85f, center = Offset(w * 0.5f, h * 0.8f)
    )
    for (i in 0 until 14) {
        val seed = ((i * 47) % 89) / 89f
        val a = p * 6.2832f + i
        val x = w * (0.12f + 0.76f * seed) + kotlin.math.sin(a) * w * 0.05f
        val y = h * (0.22f + 0.62f * ((seed + q) % 1f)) + kotlin.math.cos(a * 1.3f) * h * 0.04f
        val glow = 0.35f + 0.45f * kotlin.math.abs(kotlin.math.sin(a * 2f))
        drawCircle(c2.copy(alpha = 0.16f * glow), radius = 9f, center = Offset(x, y))
        drawCircle(c3.copy(alpha = glow), radius = 2.6f, center = Offset(x, y))
    }
}

private fun DrawScope.diyaScene(c1: Color, c2: Color, c3: Color, p: Float) {
    val w = size.width
    val h = size.height
    drawCircle(
        Brush.radialGradient(listOf(c2.copy(alpha = 0.30f), Color.Transparent), center = Offset(w * 0.5f, h * 0.98f), radius = w * 0.9f),
        radius = w * 0.9f, center = Offset(w * 0.5f, h * 0.98f)
    )
    for (i in 0 until 9) {
        val seed = ((i * 53) % 97) / 97f
        val x = w * (0.08f + 0.84f * seed)
        val y = h * (0.95f - 0.70f * ((p + seed) % 1f))
        val flick = 0.6f + 0.4f * kotlin.math.abs(kotlin.math.sin(p * 12f + i))
        drawCircle(c3.copy(alpha = 0.10f * flick), radius = 12f, center = Offset(x, y))
        drawCircle(c1.copy(alpha = 0.85f * flick), radius = 2.4f, center = Offset(x, y))
    }
    for (i in 0 until 18) {
        val sx = ((i * 71) % 103) / 103f
        val sy = ((i * 37) % 101) / 101f
        val tw = kotlin.math.abs(kotlin.math.sin(p * 6.2832f + i * 1.7f))
        drawCircle(c3.copy(alpha = 0.55f * tw), radius = 1.3f, center = Offset(w * sx, h * sy))
    }
}

private fun DrawScope.sweepScene(c1: Color, c2: Color, c3: Color, p: Float) {
    val w = size.width
    val h = size.height
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.25f), Color.Transparent), center = Offset(w * 0.5f, h * 0.5f), radius = w * 0.75f),
        radius = w * 0.75f, center = Offset(w * 0.5f, h * 0.5f)
    )
    for (i in 0 until 4) {
        val shift = (p + i * 0.25f) % 1f
        val x = -w * 0.5f + shift * (w * 2f)
        val col = when (i % 4) {
            0 -> c1
            1 -> c2
            2 -> c3
            else -> c1
        }
        drawRect(
            brush = Brush.linearGradient(
                listOf(Color.Transparent, col.copy(alpha = 0.30f), Color.Transparent),
                start = Offset(x, 0f), end = Offset(x + w * 0.5f, h)
            ),
            topLeft = Offset(0f, 0f), size = Size(w, h)
        )
    }
}

private fun DrawScope.snowScene(c1: Color, c2: Color, c3: Color, dark: Boolean, p: Float) {
    val w = size.width
    val h = size.height
    val k = if (dark) 1f else 0.8f
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.30f * k), Color.Transparent), center = Offset(w * 0.3f, h * 0.08f), radius = w * 0.85f),
        radius = w * 0.85f, center = Offset(w * 0.3f, h * 0.08f)
    )
    for (i in 0 until 34) {
        val seed = ((i * 61) % 97) / 97f
        val x = w * ((seed + 0.05f * kotlin.math.sin(p * 6.2832f + i)) % 1f)
        val y = ((p * 0.7f + seed) % 1f) * h
        drawCircle(c3.copy(alpha = 0.30f + 0.45f * seed), radius = 1.2f + 2.2f * seed, center = Offset(x, y))
    }
}

private fun DrawScope.barScene(c1: Color, c2: Color, c3: Color, p: Float) {
    val w = size.width
    val h = size.height
    val n = 18
    val gap = w / n
    for (i in 0 until n) {
        val amp = 0.22f + 0.58f * kotlin.math.abs(kotlin.math.sin(p * 6.2832f + i * 0.7f))
        val bh = h * amp
        drawRoundRect(
            color = (if (i % 2 == 0) c1 else c3).copy(alpha = 0.28f),
            topLeft = Offset(i * gap + gap * 0.22f, h - bh),
            size = Size(gap * 0.56f, bh),
            cornerRadius = CornerRadius(gap * 0.2f, gap * 0.2f)
        )
    }
}

private fun DrawScope.paintScene(name: String, c1: Color, c2: Color, c3: Color, dark: Boolean, p: Float, q: Float) {
    when (name) {
        "Chhath" -> sunScene(c1, c2, c3, q)
        "Monsoon" -> rainScene(c1, c2, c3, dark, p)
        "Sakura" -> petalScene(c1, c2, c3, p, q)
        "Neon", "Cyber" -> gridScene(c1, c2, c3, p, q)
        "Ocean", "Lagoon", "Mint" -> bubbleScene(c1, c2, c3, p)
        "Peacock" -> ringScene(c1, c2, c3, q)
        "Galaxy" -> starScene(c1, c2, c3, p, q)
        "Lava" -> emberScene(c1, c2, c3, p)
        "Sky", "Coral" -> cloudScene(c1, c2, c3, dark, q)
        "Tide" -> waveScene(c1, c2, c3, dark, p)
        "Cosmos" -> orbitScene(c1, c2, c3, p)
        "Fireflies" -> flyScene(c1, c2, c3, p, q)
        "Festival" -> diyaScene(c1, c2, c3, p)
        "Prism" -> sweepScene(c1, c2, c3, p)
        "Snow" -> snowScene(c1, c2, c3, dark, p)
        "Beats" -> barScene(c1, c2, c3, p)
        else -> blobScene(c1, c2, c3, dark, q, p)
    }
}

/** One animated background, used by the home screen, the splash and every theme card. */
@Composable
fun SceneBackground(
    name: String, c1: Color, c2: Color, c3: Color, dark: Boolean,
    modifier: Modifier, still: Boolean = false
) {
    if (still) {
        Canvas(modifier) { paintScene(name, c1, c2, c3, dark, 0.45f, 0.6f) }
        return
    }
    val t = rememberInfiniteTransition(label = "scene")
    val period = scenePeriod(name)
    val p by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(period, easing = LinearEasing), RepeatMode.Restart), label = "p"
    )
    val q by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween((period * 1.6f).toInt(), easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "q"
    )
    Canvas(modifier) { paintScene(name, c1, c2, c3, dark, p, q) }
}

@Composable
fun Aurora(modifier: Modifier) {
    SceneBackground(CurTheme.name, A1, A2, A3, CurTheme.dark, modifier, still = !MotionOn)
}

@Composable
fun GradText(t: String, size: Int, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "grad")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart), label = "gp")
    val sweep = if (MotionOn) p else 0.3f
    val brush = Brush.linearGradient(
        colors = listOf(A1, A2, A3, A1),
        start = Offset(sweep * 900f, 0f),
        end = Offset(sweep * 900f + 520f, 300f)
    )
    BasicText(t, modifier, style = TextStyle(brush = brush, fontSize = size.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp))
}

@Composable
fun Logo(size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(Brand), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.Sms, null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
    }
}

@Composable
fun Avatar(name: String, size: Dp) {
    val h = ((name.hashCode() and 0x7fffffff) % 360).toFloat()
    val brush = remember(name) { Brush.linearGradient(listOf(Color.hsv(h, 0.55f, 0.95f), Color.hsv((h + 40f) % 360f, 0.75f, 0.72f))) }
    val shape = if (Look.avatar == 1) RoundedCornerShape(size * 0.34f) else CircleShape
    Box(Modifier.size(size).clip(shape).background(brush), contentAlignment = Alignment.Center) {
        val ch = name.firstOrNull { it.isLetter() }?.uppercase() ?: "#"
        Text(ch, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.4f).sp)
    }
}

@Composable
fun IconBtn(icon: ImageVector, tint: Color = Ink, onClick: () -> Unit) {
    Box(Modifier.size(if (ElderMode) 50.dp else 44.dp).bounce(onClick = onClick), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint) }
}

@Composable
fun OtpPill(code: String) {
    val clip = LocalClipboardManager.current
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(done) { if (done) { delay(1600); done = false } }
    Row(
        Modifier.bounce(onClick = { clip.setText(AnnotatedString(code)); done = true })
            .clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (done) Icons.Rounded.Check else Icons.Rounded.ContentCopy, null, tint = Color.White, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(if (done) "Copied" else code, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
fun Chip(label: String, sel: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (sel) A1 else Surf, label = "chip")
    Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 18.dp, vertical = 9.dp)) {
        Text(label, color = if (sel) Color.White else Dim, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun SearchField(q: String, onQ: (String) -> Unit, hint: String, autofocus: Boolean = false) {
    var focus by remember { mutableStateOf(false) }
    val glow by animateFloatAsState(if (focus) 1f else 0f, tween(300), label = "glow")
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (autofocus) { delay(450); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Surf)
            .border(1.5.dp, Brush.linearGradient(listOf(A1.copy(alpha = glow), A3.copy(alpha = glow))), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = if (focus) A2 else Dim)
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = q, onValueChange = onQ, singleLine = true,
            textStyle = TextStyle(color = Ink, fontSize = 16.sp), cursorBrush = SolidColor(A2),
            modifier = Modifier.weight(1f).focusRequester(fr).onFocusChanged { focus = it.isFocused },
            decorationBox = { inner -> Box { if (q.isEmpty()) Text(hint, color = Dim, fontSize = 16.sp); inner() } }
        )
        AnimatedVisibility(q.isNotEmpty()) {
            Icon(Icons.Rounded.Close, null, tint = Dim, modifier = Modifier.size(22.dp).bounce(onClick = { onQ("") }))
        }
    }
}

@Composable
fun GradientButton(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier.fillMaxWidth().bounce(onClick = onClick)
            .shadow(16.dp, shape, ambientColor = A2, spotColor = A2).clip(shape).background(Brand).padding(vertical = 17.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

class Act(val icon: ImageVector, val label: String, val danger: Boolean = false, val onClick: () -> Unit)

@Composable
fun ActionCard(items: List<Act>) {
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.widthIn(min = 240.dp, max = 320.dp).shadow(24.dp, shape).clip(shape).background(Surf).padding(vertical = 6.dp)) {
        items.forEach { a ->
            Row(Modifier.fillMaxWidth().bounce(onClick = a.onClick).padding(horizontal = 20.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(a.icon, null, tint = if (a.danger) A3 else Ink, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(16.dp))
                Text(a.label, color = if (a.danger) A3 else Ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

/** A quiet backdrop for the chat: dots, a grid or soft waves. */
@Composable
fun ChatPattern(kind: Int, modifier: Modifier) {
    if (kind == 0) return
    val c = Dim
    Canvas(modifier) {
        when (kind) {
            1 -> {
                val step = 26.dp.toPx()
                var y = step / 2f
                while (y < size.height) {
                    var x = step / 2f
                    while (x < size.width) {
                        drawCircle(c.copy(alpha = 0.08f * Look.patternAlpha), radius = 1.6f, center = Offset(x, y))
                        x += step
                    }
                    y += step
                }
            }
            2 -> {
                val step = 34.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(c.copy(alpha = 0.05f * Look.patternAlpha), Offset(x, 0f), Offset(x, size.height), 1f)
                    x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(c.copy(alpha = 0.05f * Look.patternAlpha), Offset(0f, y), Offset(size.width, y), 1f)
                    y += step
                }
            }
            else -> {
                val step = 48.dp.toPx()
                val amp = 5.dp.toPx()
                var y = step
                while (y < size.height) {
                    val path = Path()
                    path.moveTo(0f, y)
                    var x = 0f
                    while (x <= size.width) {
                        path.lineTo(x, y + amp * sin(x / 62f))
                        x += 10f
                    }
                    drawPath(path, c.copy(alpha = 0.07f * Look.patternAlpha), style = Stroke(1.4f))
                    y += step
                }
            }
        }
    }
}

/** Compact icon + label tiles, four to a row. Keeps long menus short. */
@Composable
fun ActionGrid(items: List<Act>, columns: Int = 4) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.widthIn(max = 330.dp).shadow(24.dp, shape).clip(shape).background(Surf).padding(8.dp)
    ) {
        items.chunked(columns).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { a ->
                    Column(
                        Modifier.weight(1f).bounce(onClick = a.onClick).clip(RoundedCornerShape(16.dp))
                            .padding(vertical = 10.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape)
                                .background(if (a.danger) A3.copy(alpha = 0.16f) else Surf2),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                a.icon, null, tint = if (a.danger) A3 else A2,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(
                            a.label, color = if (a.danger) A3 else Ink, fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 2, textAlign = TextAlign.Center,
                            lineHeight = 12.sp
                        )
                    }
                }
                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun RowScope.QuickTile(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).bounce(onClick = onClick).clip(RoundedCornerShape(18.dp)).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(Brand),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(21.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Ink, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun RowScope.MiniRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.weight(1f).bounce(onClick = onClick).clip(RoundedCornerShape(14.dp))
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Dim, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Ink, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** The whole top menu: eight quick tiles, then two tidy groups. */
@Composable
fun HomeMenu(
    unread: Int, tickets: Int, vault: Int,
    onGo: (String) -> Unit, onSelect: () -> Unit, onMarkRead: () -> Unit,
    onClose: () -> Unit
) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier.widthIn(max = 340.dp).shadow(28.dp, shape).clip(shape).background(Surf).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Logo(30.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Messages", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    (if (unread > 0) unread.toString() + " unread" else "All caught up") +
                        (if (tickets > 0) "  \u00B7  " + tickets + " ticket" + (if (tickets == 1) "" else "s") else "") +
                        (if (vault > 0) "  \u00B7  " + vault + " saved" else ""),
                    color = Dim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                Icons.Rounded.Close, null, tint = Dim,
                modifier = Modifier.size(20.dp).bounce(onClick = onClose)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            QuickTile(Icons.Rounded.NearMe, "Nearby") { onGo("nearby") }
            QuickTile(Icons.Rounded.AccountBalanceWallet, "Money") { onGo("money") }
            QuickTile(Icons.Rounded.LocalShipping, "Parcels") { onGo("parcels") }
            QuickTile(Icons.Rounded.Description, "Bills") { onGo("bills") }
        }
        Row(Modifier.fillMaxWidth()) {
            QuickTile(Icons.Rounded.Checklist, "Rules") { onGo("rules") }
            QuickTile(Icons.Rounded.Fingerprint, "Vault") { onGo("vault") }
            QuickTile(Icons.Rounded.LaptopMac, "Laptop") { onGo("companion") }
            QuickTile(Icons.Rounded.Warning, "SOS") { onGo("sos") }
        }
        Row(Modifier.fillMaxWidth()) {
            QuickTile(Icons.Rounded.Forum, "Ask") { onGo("ask") }
            QuickTile(Icons.Rounded.Search, "Search") { onGo("search") }
            QuickTile(Icons.Rounded.Groups, "Broadcast") { onGo("broadcast") }
            QuickTile(Icons.Rounded.Palette, "Look") { onGo("personalise") }
        }
        Spacer(Modifier.height(6.dp))
        Text("ORGANISE", color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 8.dp, bottom = 2.dp))
        Row(Modifier.fillMaxWidth()) {
            MiniRow(Icons.Rounded.ConfirmationNumber, "Tickets") { onGo("vault") }
            MiniRow(Icons.Rounded.Lock, "OTP history") { onGo("otps") }
        }
        Row(Modifier.fillMaxWidth()) {
            MiniRow(Icons.Rounded.Star, "Starred") { onGo("starred") }
            MiniRow(Icons.Rounded.Schedule, "Scheduled") { onGo("sched") }
        }
        Row(Modifier.fillMaxWidth()) {
            MiniRow(Icons.Rounded.Delete, "Recycle bin") { onGo("bin") }
            MiniRow(Icons.Rounded.Block, "Blocked") { onGo("blocked") }
        }
        Spacer(Modifier.height(6.dp))
        Text("APP", color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 8.dp, bottom = 2.dp))
        Row(Modifier.fillMaxWidth()) {
            MiniRow(Icons.Rounded.Palette, "Themes") { onGo("themes") }
            MiniRow(Icons.Rounded.Backup, "Backup") { onGo("backup") }
        }
        Row(Modifier.fillMaxWidth()) {
            MiniRow(Icons.Rounded.Checklist, "Select chats") { onSelect() }
            MiniRow(Icons.Rounded.MarkEmailRead, "Mark all read") { onMarkRead() }
        }
        Row(Modifier.fillMaxWidth()) {
            MiniRow(Icons.Rounded.Lock, "Private chats") { onGo("private") }
            MiniRow(Icons.Rounded.Palette, "Settings") { onGo("settings") }
        }
        Spacer(Modifier.height(2.dp))
    }
}

@Composable
fun Scrim(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(tween(180)), exit = fadeOut(tween(150))) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            val p = remember { Animatable(0.88f) }
            LaunchedEffect(Unit) { p.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) }
            Column(
                Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())
                    .padding(24.dp).graphicsLayer { scaleX = p.value; scaleY = p.value },
                horizontalAlignment = Alignment.CenterHorizontally, content = content
            )
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, sub: String = "") {
    val t = rememberInfiniteTransition(label = "empty")
    val y by t.animateFloat(-12f, 12f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y")
    Column(Modifier.fillMaxWidth().padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = A2, modifier = Modifier.size(84.dp).graphicsLayer { translationY = y })
        Spacer(Modifier.height(12.dp))
        Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = Dim, fontSize = 14.sp)
    }
}

// ---------- app shell ----------
@Composable
fun App(vm: MessagesVM) {
    val st by vm.settings.collectAsState()
    val theme = resolveTheme(st.theme, st.system, isSystemInDarkTheme())
    val blend = tween<Color>(420, easing = FastOutSlowInEasing)
    val bgT by animateColorAsState(theme.bg, blend, label = "cbg")
    val surfT by animateColorAsState(theme.surf, blend, label = "csurf")
    val surf2T by animateColorAsState(theme.surf2, blend, label = "csurf2")
    val inkT by animateColorAsState(theme.ink, blend, label = "cink")
    val dimT by animateColorAsState(theme.dim, blend, label = "cdim")
    val hue = Look.hue
    val a1T by animateColorAsState(
        if (hue >= 0) Color.hsv(hue.toFloat(), 0.66f, 0.98f) else theme.a1, blend, label = "ca1"
    )
    val a2T by animateColorAsState(
        if (hue >= 0) Color.hsv(((hue + 26) % 360).toFloat(), 0.80f, 0.86f) else theme.a2, blend, label = "ca2"
    )
    val a3T by animateColorAsState(
        if (hue >= 0) Color.hsv(((hue + 58) % 360).toFloat(), 0.72f, 0.95f) else theme.a3, blend, label = "ca3"
    )
    SideEffect {
        CurTheme = theme
        HapticsOn = st.haptics
        ElderMode = st.elder
        MotionOn = st.motion
        if (cBg.value != bgT) cBg.value = bgT
        if (cSurf.value != surfT) cSurf.value = surfT
        if (cSurf2.value != surf2T) cSurf2.value = surf2T
        if (cInk.value != inkT) cInk.value = inkT
        if (cDim.value != dimT) cDim.value = dimT
        if (cA1.value != a1T) cA1.value = a1T
        if (cA2.value != a2T) cA2.value = a2T
        if (cA3.value != a3T) cA3.value = a3T
    }
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = !theme.dark
                isAppearanceLightNavigationBars = !theme.dark
            }
            w.setBackgroundDrawable(ColorDrawable(theme.bg.toArgb()))
            if (st.lock) w.addFlags(WindowManager.LayoutParams.FLAG_SECURE) else w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    val baseDensity = LocalDensity.current
    val scaled = (baseDensity.fontScale * st.textScale).coerceIn(0.7f, 2.6f)
    CompositionLocalProvider(
        LocalDensity provides Density(baseDensity.density, scaled),
        LocalTextStyle provides TextStyle(fontFamily = Look.family)
    ) {
    MaterialTheme(colorScheme = if (theme.dark) darkColorScheme() else lightColorScheme()) {
        val ctx = LocalContext.current
        var ok by remember { mutableStateOf(hasPerm(ctx)) }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            ok = hasPerm(ctx); vm.refresh()
        }
        var splash by remember { mutableStateOf(true) }
        var locked by remember { mutableStateOf(st.lock) }
        val lifeOwner = LocalLifecycleOwner.current
        DisposableEffect(lifeOwner, st.lock) {
            var stopped = 0L
            val obs = LifecycleEventObserver { _, e ->
                if (e == Lifecycle.Event.ON_STOP) stopped = System.currentTimeMillis()
                else if (e == Lifecycle.Event.ON_START && st.lock && stopped > 0L && System.currentTimeMillis() - stopped > 15_000L) locked = true
            }
            lifeOwner.lifecycle.addObserver(obs)
            onDispose { lifeOwner.lifecycle.removeObserver(obs) }
        }
        var composing by remember { mutableStateOf(false) }
        var fwd by remember { mutableStateOf<String?>(null) }
        var screen by remember { mutableStateOf<String?>(null) }
        var lastScreen by remember { mutableStateOf("") }
        val open by vm.open.collectAsState()
        val meshConv by Mesh.openConv.collectAsState()
        val gotoTarget by vm.goto.collectAsState()
        var last by remember { mutableStateOf<Chat?>(null) }
        val shownChat = open ?: last
        SideEffect { if (open != null) last = open }
        LaunchedEffect(Unit) { delay(1100); splash = false }
        BackHandler(composing || open != null || screen != null || meshConv != null) {
            when {
                composing -> { composing = false; fwd = null }
                meshConv != null -> Mesh.openConv.value = null
                open != null -> vm.close()
                else -> screen = null
            }
        }
        val go = { s: String -> lastScreen = s; screen = s }
        LaunchedEffect(gotoTarget) {
            val t = gotoTarget
            if (t != null) {
                if (t == "compose") composing = true else go(t)
                vm.goto.value = null
            }
        }
        var lastMesh by remember { mutableStateOf("zone") }
        SideEffect { meshConv?.let { lastMesh = it } }

        Box(Modifier.fillMaxSize().background(Bg)) {
            if (!ok) {
                Onboarding { launcher.launch(PERMS) }
            } else {
                HomeScreen(vm, go) { composing = true }
                AnimatedVisibility(
                    screen != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) {
                    val back = { screen = null }
                    when (lastScreen) {
                        "nearby" -> NearbyScreen(vm, back)
                        "money" -> MoneyScreen(vm, back)
                        "private" -> PrivateScreen(vm, back)
                        "backup" -> BackupScreen(vm, back)
                        "settings" -> SettingsScreen(vm, back, onVault = { vm.goto.value = "vault" })
                        "bin" -> BinScreen(vm, back)
                        "starred" -> StarredScreen(vm, back)
                        "sched" -> ScheduledScreen(vm, back)
                        "vault" -> VaultScreen(vm, back)
                        "companion" -> CompanionScreen(vm, back)
                        "search" -> SearchScreen(vm, back) { addr -> vm.startChat(addr) }
                        "themes" -> ThemeGalleryScreen(vm, back)
                        "rules" -> RulesScreen(vm, back)
                        "parcels" -> ParcelsScreen(vm, back)
                        "bills" -> BillsScreen(vm, back)
                        "broadcast" -> BroadcastScreen(vm, back)
                        "otps" -> OtpHistoryScreen(vm, back)
                        "sos" -> SosScreen(vm, back)
                        "ask" -> AskScreen(vm, back) { s -> vm.goto.value = s }
                        "personalise" -> PersonaliseScreen(vm, back)
                        else -> BlockedScreen(vm, back)
                    }
                }
                AnimatedVisibility(
                    open != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) {
                    shownChat?.let { c ->
                        key(c.address) { ChatScreen(vm, c, onForward = { t -> fwd = t; composing = true }, onBack = { vm.close() }) }
                    }
                }
                AnimatedVisibility(
                    meshConv != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) { MeshChatScreen(meshConv ?: lastMesh) { Mesh.openConv.value = null } }
                AnimatedVisibility(
                    composing,
                    enter = slideInVertically(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(),
                    exit = slideOutVertically(tween(300)) { it } + fadeOut()
                ) {
                    NewChatScreen(vm, if (fwd != null) "Forward to…" else "New message", { composing = false; fwd = null }) { a, n ->
                        composing = false
                        fwd?.let { vm.draft.value = it }
                        fwd = null
                        vm.startChat(a, n)
                    }
                }
            }
            AnimatedVisibility(locked && st.lock, enter = fadeIn(tween(150)), exit = fadeOut(tween(300))) { LockScreen { locked = false } }
            AnimatedVisibility(splash, exit = fadeOut(tween(450)) + scaleOut(tween(450), targetScale = 1.12f)) { Splash() }
        }
    }
    }
}

@Composable
fun Splash() {
    val sc = remember { Animatable(0.2f) }
    LaunchedEffect(Unit) { sc.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Aurora(Modifier.fillMaxSize())
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { scaleX = sc.value; scaleY = sc.value; alpha = sc.value.coerceIn(0f, 1f) }
        ) {
            Logo(112.dp)
            Spacer(Modifier.height(20.dp))
            GradText("Messages", 36)
        }
    }
}

@Composable
fun Onboarding(onGo: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg)) {
        Aurora(Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Appear(0) { Logo(100.dp) }
            Spacer(Modifier.height(22.dp))
            Appear(1) { GradText("Messages", 42) }
            Spacer(Modifier.height(8.dp))
            Appear(2) { Text("Beautiful SMS with smart one-tap OTP copy.", color = Dim, fontSize = 16.sp, textAlign = TextAlign.Center) }
            Spacer(Modifier.height(32.dp))
            listOf(
                Icons.Rounded.Sms to "Send and receive real SMS through your SIM",
                Icons.Rounded.ContentCopy to "OTP codes pop up with one-tap copy",
                Icons.Rounded.Notifications to "Instant notifications with quick reply"
            ).forEachIndexed { i, (ic, t) ->
                Appear(i + 3) {
                    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) { Icon(ic, null, tint = A2) }
                        Spacer(Modifier.width(14.dp))
                        Text(t, color = Ink, fontSize = 15.sp)
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
            Appear(6) { GradientButton("Get started", onGo) }
        }
    }
}

// ---------- home ----------
@Composable
fun HomeScreen(vm: MessagesVM, onGo: (String) -> Unit, onNew: () -> Unit) {
    val ctx = LocalContext.current
    val convos by vm.convos.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val pinned by vm.pinned.collectAsState()
    val blocked by vm.blocked.collectAsState()
    val priv by vm.privateSet.collectAsState()
    val trash by vm.trash.collectAsState()
    val sched by vm.sched.collectAsState()
    val tickets by vm.ticketCount.collectAsState()
    val arch by vm.archived.collectAsState()
    val vaultCount by vm.vault.collectAsState()
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    var menu by remember { mutableStateOf<Convo?>(null) }
    var keepMenu by remember { mutableStateOf<Convo?>(null) }
    var topMenu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<Convo?>(null) }
    var selMode by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(setOf<Long>()) }
    var wiping by remember { mutableStateOf(setOf<Long>()) }
    var bulkConfirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    SideEffect { if (menu != null) keepMenu = menu }
    val state = rememberLazyListState()
    val expanded by remember { derivedStateOf { state.firstVisibleItemIndex == 0 } }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.refresh() }
    val blurR by animateDpAsState(if (menu != null || topMenu) 14.dp else 0.dp, tween(250), label = "hb")
    val list = remember(convos, q, filter, blocked, pinned, priv, arch) {
        convos.filter { c ->
            val isArch = nk(c.address) in arch
            val visible = if (filter == 7) isArch else !isArch && nk(c.address) !in blocked && nk(c.address) !in priv
            visible && when (filter) {
                1 -> c.unread > 0
                2 -> Cat.of(c.address, c.snippet) == 0
                3 -> Cat.of(c.address, c.snippet) == 1
                4 -> Cat.of(c.address, c.snippet) == 2
                5 -> Cat.of(c.address, c.snippet) == 3
                6 -> c.code != null
                else -> true
            } && (q.isBlank() || c.name.contains(q, true) || c.snippet.contains(q, true) || c.address.contains(q))
        }.sortedByDescending { it.threadId in pinned }
    }
    val unreadTotal = convos.sumOf { it.unread }
    BackHandler(selMode) { selMode = false; sel = emptySet() }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Bg).blur(blurR)) {
            val shift by remember { derivedStateOf { (state.firstVisibleItemIndex * 140 + state.firstVisibleItemScrollOffset) * 0.3f } }
            Aurora(
                Modifier.fillMaxWidth().height(380.dp)
                    .graphicsLayer { translationY = -shift; scaleY = 1f + (shift / 3800f).coerceIn(0f, 0.15f) }
            )
            LazyColumn(state = state, modifier = Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 150.dp)) {
                item { OtpCard(vm) }
                item {
                    Appear(0, "hdr") {
                        val hs = (1f - shift / 560f).coerceIn(0.80f, 1f)
                        Column(
                            Modifier.padding(horizontal = 22.dp).padding(top = 14.dp, bottom = 8.dp)
                                .graphicsLayer {
                                    scaleX = hs
                                    scaleY = hs
                                    alpha = (0.25f + 0.75f * hs).coerceIn(0f, 1f)
                                    transformOrigin = TransformOrigin(0f, 0f)
                                }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    GradText("Messages", 40)
                                    Text(if (unreadTotal > 0) "$unreadTotal unread" else "You're all caught up", color = Dim, fontSize = 15.sp)
                                }
                                IconBtn(Icons.Rounded.MoreVert) { topMenu = true }
                            }
                            Spacer(Modifier.height(16.dp))
                            SearchField(q, { q = it }, "Search messages")
                        }
                    }
                }
                item {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val counts = remember(convos, arch) {
                            val live = convos.filter { nk(it.address) !in arch }
                            listOf(
                                live.size,
                                live.sumOf { it.unread },
                                live.count { Cat.of(it.address, it.snippet) == 0 },
                                live.count { Cat.of(it.address, it.snippet) == 1 },
                                live.count { Cat.of(it.address, it.snippet) == 2 },
                                live.count { Cat.of(it.address, it.snippet) == 3 },
                                live.count { it.code != null },
                                convos.count { nk(it.address) in arch }
                            )
                        }
                        listOf("All", "Unread", "Personal", "Money", "Bills", "Offers", "OTP", "Archived").forEachIndexed { i, s ->
                            val n = counts.getOrElse(i) { 0 }
                            Chip(if (n > 0) s + " " + n else s, filter == i) { filter = i }
                        }
                    }
                }
                if (!isDef && loaded) item { DefaultBanner { roleLauncher.launch(defaultSmsIntent(ctx)) } }
                if (tickets > 0 && loaded) item { TicketBanner(tickets) { onGo("vault") } }
                itemsIndexed(list, key = { _, c -> c.threadId }) { i, c ->
                    Box(Modifier.animateItemPlacement()) {
                        Appear(i, "c${c.threadId}") {
                            WipeRow(c.threadId in wiping) {
                                SwipeRow(
                                    rightIcon = Icons.Rounded.PushPin,
                                    rightLabel = if (c.threadId in pinned) "Unpin" else "Pin",
                                    rightColor = A2,
                                    onRight = { vm.togglePin(c) },
                                    leftIcon = Icons.Rounded.DeleteOutline,
                                    leftLabel = "Delete",
                                    leftColor = A3,
                                    onLeft = { confirm = c }
                                ) {
                                    ConvoRow(
                                        c, c.threadId in pinned,
                                        onClick = { if (selMode) sel = sel.toggle(c.threadId) else vm.openChat(Chat(c.threadId, c.address, c.name)) },
                                        onLong = { if (selMode) sel = sel.toggle(c.threadId) else menu = c },
                                        selMode = selMode, selected = c.threadId in sel
                                    )
                                }
                            }
                        }
                    }
                }
                if (!loaded) items(7) { SkeletonRow() }
                if (list.isEmpty() && loaded) item { EmptyState(Icons.Rounded.Sms, "No messages here", "Tap New chat to start") }
            }
            Fab(expanded, onNew, Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(22.dp))
        }

        Scrim(topMenu, { topMenu = false }) {
            HomeMenu(
                unread = unreadTotal,
                tickets = tickets,
                vault = vaultCount.size,
                onGo = { topMenu = false; onGo(it) },
                onSelect = { topMenu = false; sel = emptySet(); selMode = true },
                onMarkRead = { topMenu = false; vm.markAllRead() },
                onClose = { topMenu = false }
            )
        }
        Scrim(menu != null, { menu = null }) {
            keepMenu?.let { c ->
                Row(Modifier.padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name, 46.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(c.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                ActionCard(buildList {
                    add(Act(Icons.Rounded.PushPin, if (c.threadId in pinned) "Unpin" else "Pin to top") { vm.togglePin(c); menu = null })
                    if (c.unread > 0) add(Act(Icons.Rounded.MarkEmailRead, "Mark as read") { vm.markReadConvo(c); menu = null })
                    add(Act(Icons.Rounded.Block, if (nk(c.address) in blocked) "Unblock" else "Block") { vm.toggleBlock(c.address); menu = null })
                    add(Act(Icons.Rounded.Lock, "Move to private") { vm.togglePrivate(c.address); menu = null })
                    add(Act(Icons.Rounded.Folder, if (nk(c.address) in arch) "Unarchive" else "Archive") { vm.toggleArchive(c); menu = null })
                    add(Act(Icons.Rounded.CheckCircle, "Select") { sel = setOf(c.threadId); selMode = true; menu = null })
                    add(Act(Icons.Rounded.Delete, "Delete", true) { menu = null; confirm = c })
                })
            }
        }
        confirm?.let { c ->
            AlertDialog(
                onDismissRequest = { confirm = null }, containerColor = Surf2,
                title = { Text("Delete conversation?", color = Ink) },
                text = { Text("Messages with ${c.name} move to the Recycle bin for 30 days.", color = Dim) },
                confirmButton = {
                    TextButton(onClick = {
                        if (isDef) vm.deleteThread(c) else Toast.makeText(ctx, "Set Messages as default SMS app to delete", Toast.LENGTH_LONG).show()
                        confirm = null
                    }) { Text("Delete", color = A3) }
                },
                dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel", color = Dim) } }
            )
        }
        if (bulkConfirm) {
            AlertDialog(
                onDismissRequest = { bulkConfirm = false }, containerColor = Surf2,
                title = { Text(if (sel.size == 1) "Delete 1 conversation?" else "Delete ${sel.size} conversations?", color = Ink) },
                text = { Text("They move to the Recycle bin for 30 days, so you can restore them any time.", color = Dim) },
                confirmButton = {
                    TextButton(onClick = {
                        bulkConfirm = false
                        if (!isDef) {
                            Toast.makeText(ctx, "Set Messages as default SMS app to delete", Toast.LENGTH_LONG).show()
                        } else {
                            val targets = list.filter { it.threadId in sel }
                            wiping = sel
                            scope.launch {
                                delay(500)
                                vm.deleteThreads(targets)
                                wiping = emptySet(); sel = emptySet(); selMode = false
                            }
                        }
                    }) { Text("Delete", color = A3) }
                },
                dismissButton = { TextButton(onClick = { bulkConfirm = false }) { Text("Cancel", color = Dim) } }
            )
        }
        AnimatedVisibility(
            selMode,
            enter = slideInVertically(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { -it } + fadeIn(tween(180)),
            exit = slideOutVertically(tween(220)) { -it } + fadeOut(tween(140)),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Column(
                Modifier.fillMaxWidth().background(Bg).statusBarsPadding()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(Icons.Rounded.Close) { selMode = false; sel = emptySet() }
                    Column(Modifier.weight(1f)) {
                        Text("${sel.size} selected", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            when {
                                sel.isEmpty() -> "Tap any chat to select"
                                sel.size == list.size -> "Every conversation selected"
                                else -> "Tap more chats to add them"
                            },
                            color = Dim, fontSize = 12.sp
                        )
                    }
                    Box(
                        Modifier.bounce(onClick = {
                            sel = if (sel.size == list.size && list.isNotEmpty()) emptySet() else list.map { it.threadId }.toSet()
                        }).clip(RoundedCornerShape(50)).background(Surf2).padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Text(
                            if (sel.size == list.size && list.isNotEmpty()) "None" else "Select all",
                            color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Row(
                        Modifier.bounce(onClick = { if (sel.isNotEmpty()) bulkConfirm = true })
                            .clip(RoundedCornerShape(50))
                            .background(if (sel.isEmpty()) Surf2 else A3)
                            .padding(horizontal = 14.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Delete, null, tint = if (sel.isEmpty()) Dim else Color.White, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Delete", color = if (sel.isEmpty()) Dim else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TicketBanner(n: Int, onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 22.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(A2.copy(alpha = 0.30f), A1.copy(alpha = 0.22f))))
            .bounce(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.ConfirmationNumber, null, tint = A2)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (n == 1) "1 ticket found in your messages" else "$n tickets found in your messages",
                color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
            Text("Save it with PNR, train and seat", color = Dim, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text("Save", color = A2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun DefaultBanner(onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 22.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(A1.copy(alpha = 0.35f), A3.copy(alpha = 0.3f)))).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Make Messages your default", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Needed to receive, save and delete SMS", color = Dim, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 18.dp, vertical = 9.dp)) {
            Text("Set", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Fab(expanded: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier.bounce(onClick = onClick).shadow(20.dp, shape, ambientColor = A2, spotColor = A2)
            .clip(shape).background(Brand).padding(horizontal = 20.dp, vertical = 16.dp).animateContentSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Edit, null, tint = Color.White)
        AnimatedVisibility(expanded) { Text("  New chat", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    }
}

@Composable
fun Badge(n: Int) {
    val t = rememberInfiniteTransition(label = "badge")
    val s by t.animateFloat(1f, 1.15f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bs")
    Box(
        Modifier.graphicsLayer { scaleX = s; scaleY = s }.defaultMinSize(24.dp, 24.dp).clip(CircleShape)
            .background(Brand).padding(horizontal = 7.dp),
        contentAlignment = Alignment.Center
    ) { Text(if (n > 99) "99+" else "$n", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

private fun shimmerBrush(p: Float, base: Color): Brush = Brush.linearGradient(
    colors = listOf(base, base.copy(alpha = 0.35f), base),
    start = Offset(-320f + 1000f * p, 0f),
    end = Offset(120f + 1000f * p, 320f)
)

@Composable
fun SkeletonRow() {
    val t = rememberInfiniteTransition(label = "sk")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart), label = "sp")
    Row(
        Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(54.dp).clip(CircleShape).background(Surf2))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Box(Modifier.fillMaxWidth(0.42f).height(13.dp).clip(RoundedCornerShape(7.dp)).background(shimmerBrush(p, Surf2)))
            Spacer(Modifier.height(9.dp))
            Box(Modifier.fillMaxWidth(0.72f).height(11.dp).clip(RoundedCornerShape(7.dp)).background(shimmerBrush(p, Surf2)))
        }
        Spacer(Modifier.width(10.dp))
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(shimmerBrush(p, Surf2)))
    }
}

@Composable
fun ConvoRow(
    c: Convo, pinned: Boolean, onClick: () -> Unit, onLong: () -> Unit,
    selMode: Boolean = false, selected: Boolean = false
) {
    val unread = c.unread > 0
    Row(
        Modifier.fillMaxWidth().bounce(onClick = onClick, onLong = onLong)
            .padding(horizontal = 12.dp, vertical = Look.rowGap).clip(RoundedCornerShape(24.dp))
            .background(
                when {
                    selected -> A2.copy(alpha = 0.16f)
                    unread -> Surf2
                    else -> Color.Transparent
                }
            ).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AnimatedVisibility(
            selMode,
            enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + expandHorizontally(),
            exit = scaleOut() + shrinkHorizontally()
        ) { SelDot(selected) }
        SenderAvatar(c.address, c.name, if (ElderMode) 60.dp else 54.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c.name, color = Ink, fontSize = 17.sp, fontWeight = if (unread) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (pinned) { Spacer(Modifier.width(6.dp)); Icon(Icons.Rounded.PushPin, null, tint = A2, modifier = Modifier.size(15.dp)) }
            }
            Text((if (c.outgoing) "You: " else "") + c.snippet, color = if (unread) Ink else Dim, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            val scam = remember(c.snippet) { if (!c.outgoing) Scam.check(c.snippet, c.address) else null }
            if (scam != null && scam.warn) Text("\u26A0 Possible scam", color = if (scam.risky) Color(0xFFFF3B30) else Color(0xFFFFB020), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (c.code != null && System.currentTimeMillis() - c.date < 3_600_000) {
                Spacer(Modifier.height(6.dp))
                OtpPill(c.code)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(fmt(c.date), color = if (unread) A2 else Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (unread) { Spacer(Modifier.height(6.dp)); Badge(c.unread) }
        }
    }
}
