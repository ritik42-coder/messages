@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import android.view.WindowManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

// ---------- themes ----------
class AppTheme(
    val name: String, val dark: Boolean,
    val bg: Color, val surf: Color, val surf2: Color, val ink: Color, val dim: Color,
    val a1: Color, val a2: Color, val a3: Color
) {
    val brand: Brush = Brush.linearGradient(listOf(a1, a2, a3))
}

private fun th(n: String, d: Boolean, bg: Long, s: Long, s2: Long, ink: Long, dim: Long, a1: Long, a2: Long, a3: Long) =
    AppTheme(n, d, Color(bg), Color(s), Color(s2), Color(ink), Color(dim), Color(a1), Color(a2), Color(a3))

val THEMES = listOf(
    th("Midnight", true, 0xFF07070D, 0xFF14141F, 0xFF1E1E2E, 0xFFF4F4FB, 0xFF9A9AB5, 0xFF6D5BFF, 0xFFB04BFF, 0xFFFF5CA8),
    th("AMOLED", true, 0xFF000000, 0xFF101012, 0xFF1B1B1F, 0xFFFFFFFF, 0xFF8E8E93, 0xFF00E0FF, 0xFF4D7CFF, 0xFF9B5CFF),
    th("Daylight", false, 0xFFF6F5FF, 0xFFFFFFFF, 0xFFECEAFB, 0xFF14142B, 0xFF6B6B88, 0xFF6D5BFF, 0xFFB04BFF, 0xFFFF5CA8),
    th("Rose Quartz", false, 0xFFFFF5F8, 0xFFFFFFFF, 0xFFFFE6EE, 0xFF2B1620, 0xFF8A6577, 0xFFFF5C8A, 0xFFFF7A59, 0xFFFFB36B),
    th("Ocean", true, 0xFF06111A, 0xFF0D1E2B, 0xFF143044, 0xFFEAF6FF, 0xFF86A5BA, 0xFF00B3FF, 0xFF00D4C0, 0xFF5CFFB1),
    th("Sunset", true, 0xFF120A0C, 0xFF211215, 0xFF2E1A1E, 0xFFFFF1EC, 0xFFB89A95, 0xFFFF7A18, 0xFFFF4D6D, 0xFFC13BFF),
    th("Mint", false, 0xFFF1FBF7, 0xFFFFFFFF, 0xFFDDF5EA, 0xFF0F2A21, 0xFF5E8577, 0xFF00B894, 0xFF00A3C4, 0xFF6C5CE7),
    th("Emerald", true, 0xFF050E0A, 0xFF0C1C15, 0xFF142B21, 0xFFE9FFF4, 0xFF84AD9A, 0xFF1ED760, 0xFF00C2A8, 0xFF8BE04E)
)

fun resolveTheme(sel: Int, system: Boolean, sysDark: Boolean): AppTheme {
    val t = THEMES[sel.coerceIn(0, THEMES.lastIndex)]
    if (!system || t.dark == sysDark) return t
    return if (sysDark) THEMES[0] else THEMES[2]
}

var CurTheme by mutableStateOf(THEMES[0])
var HapticsOn = true
val Bg: Color get() = CurTheme.bg
val Surf: Color get() = CurTheme.surf
val Surf2: Color get() = CurTheme.surf2
val Ink: Color get() = CurTheme.ink
val Dim: Color get() = CurTheme.dim
val A1: Color get() = CurTheme.a1
val A2: Color get() = CurTheme.a2
val A3: Color get() = CurTheme.a3
val Brand: Brush get() = CurTheme.brand
val Gold = Color(0xFFFFC857)

val PERMS: Array<String> = buildList {
    add(Manifest.permission.READ_SMS); add(Manifest.permission.SEND_SMS)
    add(Manifest.permission.RECEIVE_SMS); add(Manifest.permission.READ_CONTACTS)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

fun hasPerm(c: Context) = c.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

fun defaultSmsIntent(c: Context): Intent =
    if (Build.VERSION.SDK_INT >= 29) c.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
    else Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, c.packageName)

// ---------- helpers ----------
fun hm(t: Long): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(t))
fun fullDate(t: Long): String = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(t))

fun fmt(t: Long): String = when {
    DateUtils.isToday(t) -> hm(t)
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    System.currentTimeMillis() - t < 6 * DateUtils.DAY_IN_MILLIS -> SimpleDateFormat("EEE", Locale.getDefault()).format(Date(t))
    else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))
}

fun dayLabel(t: Long): String = when {
    DateUtils.isToday(t) -> "Today"
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    else -> SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(t))
}

fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

fun timeOptions(): List<Pair<String, Long>> {
    val now = System.currentTimeMillis()
    val out = ArrayList<Pair<String, Long>>()
    out.add("In 1 hour" to now + 3_600_000L)
    val ev = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 18); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
    if (ev.timeInMillis > now + 600_000L) out.add("This evening, 6 PM" to ev.timeInMillis)
    val tm = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
    out.add("Tomorrow, 9 AM" to tm.timeInMillis)
    return out
}

// ---------- animation building blocks ----------
object Seen { val set = HashSet<String>() }

fun Modifier.bounce(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.95f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "bounce"
    )
    val h = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            onLongClick = onLong?.let { f -> { if (HapticsOn) h.performHapticFeedback(HapticFeedbackType.LongPress); f() } },
            onClick = { if (HapticsOn) h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
        )
}

// swallows touches so screens stacked underneath never receive them
fun Modifier.blockTouches(): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
}

@Composable
fun Appear(i: Int, key: String? = null, content: @Composable () -> Unit) {
    val already = key != null && key in Seen.set
    val p = remember { Animatable(if (already) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!already) {
            if (i < 10) delay(i * 40L)
            p.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
            key?.let { Seen.set.add(it) }
        }
    }
    Box(Modifier.graphicsLayer { alpha = p.value; translationY = (1f - p.value) * 60f }) { content() }
}

@Composable
fun Aurora(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(10000, easing = LinearEasing), RepeatMode.Reverse), label = "p")
    Canvas(modifier) {
        val k = if (CurTheme.dark) 1f else 0.55f
        val w = size.width; val h = size.height
        val c1 = Offset(w * (0.1f + 0.6f * p), h * 0.12f)
        val c2 = Offset(w * (0.9f - 0.6f * p), h * 0.35f)
        drawCircle(Brush.radialGradient(listOf(A1.copy(alpha = 0.5f * k), Color.Transparent), center = c1, radius = w * 0.75f), radius = w * 0.75f, center = c1)
        drawCircle(Brush.radialGradient(listOf(A3.copy(alpha = 0.32f * k), Color.Transparent), center = c2, radius = w * 0.6f), radius = w * 0.6f, center = c2)
    }
}

@Composable
fun GradText(t: String, size: Int, modifier: Modifier = Modifier) {
    BasicText(t, modifier, style = TextStyle(brush = Brand, fontSize = size.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp))
}

@Composable
fun Logo(size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(Brand), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.Sms, null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
    }
}

@Composable
fun Avatar(name: String, size: Dp) {
    val h = ((name.hashCode() and 0x7fffffff) % 360).toFloat()
    val brush = remember(name) { Brush.linearGradient(listOf(Color.hsv(h, 0.55f, 0.95f), Color.hsv((h + 40f) % 360f, 0.75f, 0.72f))) }
    Box(Modifier.size(size).clip(CircleShape).background(brush), contentAlignment = Alignment.Center) {
        val ch = name.firstOrNull { it.isLetter() }?.uppercase() ?: "#"
        Text(ch, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.4f).sp)
    }
}

@Composable
fun IconBtn(icon: ImageVector, tint: Color = Ink, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).bounce(onClick = onClick), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint) }
}

@Composable
fun OtpPill(code: String) {
    val clip = LocalClipboardManager.current
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(done) { if (done) { delay(1600); done = false } }
    Row(
        Modifier.bounce(onClick = { clip.setText(AnnotatedString(code)); done = true })
            .clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (done) Icons.Rounded.Check else Icons.Rounded.ContentCopy, null, tint = Color.White, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(if (done) "Copied" else code, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
fun Chip(label: String, sel: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (sel) A1 else Surf, label = "chip")
    Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 18.dp, vertical = 9.dp)) {
        Text(label, color = if (sel) Color.White else Dim, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun SearchField(q: String, onQ: (String) -> Unit, hint: String, autofocus: Boolean = false) {
    var focus by remember { mutableStateOf(false) }
    val glow by animateFloatAsState(if (focus) 1f else 0f, tween(300), label = "glow")
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (autofocus) { delay(450); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Surf)
            .border(1.5.dp, Brush.linearGradient(listOf(A1.copy(alpha = glow), A3.copy(alpha = glow))), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = if (focus) A2 else Dim)
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = q, onValueChange = onQ, singleLine = true,
            textStyle = TextStyle(color = Ink, fontSize = 16.sp), cursorBrush = SolidColor(A2),
            modifier = Modifier.weight(1f).focusRequester(fr).onFocusChanged { focus = it.isFocused },
            decorationBox = { inner -> Box { if (q.isEmpty()) Text(hint, color = Dim, fontSize = 16.sp); inner() } }
        )
        AnimatedVisibility(q.isNotEmpty()) {
            Icon(Icons.Rounded.Close, null, tint = Dim, modifier = Modifier.size(22.dp).bounce(onClick = { onQ("") }))
        }
    }
}

@Composable
fun GradientButton(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier.fillMaxWidth().bounce(onClick = onClick)
            .shadow(16.dp, shape, ambientColor = A2, spotColor = A2).clip(shape).background(Brand).padding(vertical = 17.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

class Act(val icon: ImageVector, val label: String, val danger: Boolean = false, val onClick: () -> Unit)

@Composable
fun ActionCard(items: List<Act>) {
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.widthIn(min = 240.dp, max = 320.dp).shadow(24.dp, shape).clip(shape).background(Surf).padding(vertical = 6.dp)) {
        items.forEach { a ->
            Row(Modifier.fillMaxWidth().bounce(onClick = a.onClick).padding(horizontal = 20.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(a.icon, null, tint = if (a.danger) A3 else Ink, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(16.dp))
                Text(a.label, color = if (a.danger) A3 else Ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun Scrim(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(tween(180)), exit = fadeOut(tween(150))) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            val p = remember { Animatable(0.88f) }
            LaunchedEffect(Unit) { p.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) }
            Column(
                Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())
                    .padding(24.dp).graphicsLayer { scaleX = p.value; scaleY = p.value },
                horizontalAlignment = Alignment.CenterHorizontally, content = content
            )
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, sub: String = "") {
    val t = rememberInfiniteTransition(label = "empty")
    val y by t.animateFloat(-12f, 12f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y")
    Column(Modifier.fillMaxWidth().padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = A2, modifier = Modifier.size(84.dp).graphicsLayer { translationY = y })
        Spacer(Modifier.height(12.dp))
        Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = Dim, fontSize = 14.sp)
    }
}

// ---------- app shell ----------
@Composable
fun App(vm: MessagesVM) {
    val st by vm.settings.collectAsState()
    val theme = resolveTheme(st.theme, st.system, isSystemInDarkTheme())
    SideEffect { CurTheme = theme; HapticsOn = st.haptics }
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = !theme.dark
                isAppearanceLightNavigationBars = !theme.dark
            }
            w.setBackgroundDrawable(ColorDrawable(theme.bg.toArgb()))
            if (st.lock) w.addFlags(WindowManager.LayoutParams.FLAG_SECURE) else w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    MaterialTheme(colorScheme = if (theme.dark) darkColorScheme() else lightColorScheme()) {
        val ctx = LocalContext.current
        var ok by remember { mutableStateOf(hasPerm(ctx)) }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            ok = hasPerm(ctx); vm.refresh()
        }
        var splash by remember { mutableStateOf(true) }
        var locked by remember { mutableStateOf(st.lock) }
        val lifeOwner = LocalLifecycleOwner.current
        DisposableEffect(lifeOwner, st.lock) {
            var stopped = 0L
            val obs = LifecycleEventObserver { _, e ->
                if (e == Lifecycle.Event.ON_STOP) stopped = System.currentTimeMillis()
                else if (e == Lifecycle.Event.ON_START && st.lock && stopped > 0L && System.currentTimeMillis() - stopped > 15_000L) locked = true
            }
            lifeOwner.lifecycle.addObserver(obs)
            onDispose { lifeOwner.lifecycle.removeObserver(obs) }
        }
        var composing by remember { mutableStateOf(false) }
        var fwd by remember { mutableStateOf<String?>(null) }
        var screen by remember { mutableStateOf<String?>(null) }
        var lastScreen by remember { mutableStateOf("") }
        val open by vm.open.collectAsState()
        val meshConv by Mesh.openConv.collectAsState()
        val gotoTarget by vm.goto.collectAsState()
        var last by remember { mutableStateOf<Chat?>(null) }
        val shownChat = open ?: last
        SideEffect { if (open != null) last = open }
        LaunchedEffect(Unit) { delay(1100); splash = false }
        BackHandler(composing || open != null || screen != null || meshConv != null) {
            when {
                composing -> { composing = false; fwd = null }
                meshConv != null -> Mesh.openConv.value = null
                open != null -> vm.close()
                else -> screen = null
            }
        }
        val go = { s: String -> lastScreen = s; screen = s }
        LaunchedEffect(gotoTarget) { if (gotoTarget != null) { go(gotoTarget!!); vm.goto.value = null } }
        var lastMesh by remember { mutableStateOf("zone") }
        SideEffect { meshConv?.let { lastMesh = it } }

        Box(Modifier.fillMaxSize().background(Bg)) {
            if (!ok) {
                Onboarding { launcher.launch(PERMS) }
            } else {
                HomeScreen(vm, go) { composing = true }
                AnimatedVisibility(
                    screen != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) {
                    val back = { screen = null }
                    when (lastScreen) {
                        "nearby" -> NearbyScreen(vm, back)
                        "money" -> MoneyScreen(vm, back)
                        "private" -> PrivateScreen(vm, back)
                        "backup" -> BackupScreen(vm, back)
                        "settings" -> SettingsScreen(vm, back)
                        "bin" -> BinScreen(vm, back)
                        "starred" -> StarredScreen(vm, back)
                        "sched" -> ScheduledScreen(vm, back)
                        else -> BlockedScreen(vm, back)
                    }
                }
                AnimatedVisibility(
                    open != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) {
                    shownChat?.let { c ->
                        key(c.address) { ChatScreen(vm, c, onForward = { t -> fwd = t; composing = true }, onBack = { vm.close() }) }
                    }
                }
                AnimatedVisibility(
                    meshConv != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) { MeshChatScreen(meshConv ?: lastMesh) { Mesh.openConv.value = null } }
                AnimatedVisibility(
                    composing,
                    enter = slideInVertically(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(),
                    exit = slideOutVertically(tween(300)) { it } + fadeOut()
                ) {
                    NewChatScreen(vm, if (fwd != null) "Forward to…" else "New message", { composing = false; fwd = null }) { a, n ->
                        composing = false
                        fwd?.let { vm.draft.value = it }
                        fwd = null
                        vm.startChat(a, n)
                    }
                }
            }
            AnimatedVisibility(locked && st.lock, enter = fadeIn(tween(150)), exit = fadeOut(tween(300))) { LockScreen { locked = false } }
            AnimatedVisibility(splash, exit = fadeOut(tween(450)) + scaleOut(tween(450), targetScale = 1.12f)) { Splash() }
        }
    }
}

@Composable
fun Splash() {
    val sc = remember { Animatable(0.2f) }
    LaunchedEffect(Unit) { sc.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Aurora(Modifier.fillMaxSize())
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { scaleX = sc.value; scaleY = sc.value; alpha = sc.value.coerceIn(0f, 1f) }
        ) {
            Logo(112.dp)
            Spacer(Modifier.height(20.dp))
            GradText("Messages", 36)
        }
    }
}

@Composable
fun Onboarding(onGo: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg)) {
        Aurora(Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Appear(0) { Logo(100.dp) }
            Spacer(Modifier.height(22.dp))
            Appear(1) { GradText("Messages", 42) }
            Spacer(Modifier.height(8.dp))
            Appear(2) { Text("Beautiful SMS with smart one-tap OTP copy.", color = Dim, fontSize = 16.sp, textAlign = TextAlign.Center) }
            Spacer(Modifier.height(32.dp))
            listOf(
                Icons.Rounded.Sms to "Send and receive real SMS through your SIM",
                Icons.Rounded.ContentCopy to "OTP codes pop up with one-tap copy",
                Icons.Rounded.Notifications to "Instant notifications with quick reply"
            ).forEachIndexed { i, (ic, t) ->
                Appear(i + 3) {
                    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) { Icon(ic, null, tint = A2) }
                        Spacer(Modifier.width(14.dp))
                        Text(t, color = Ink, fontSize = 15.sp)
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
            Appear(6) { GradientButton("Get started", onGo) }
        }
    }
}

// ---------- home ----------
@Composable
fun HomeScreen(vm: MessagesVM, onGo: (String) -> Unit, onNew: () -> Unit) {
    val ctx = LocalContext.current
    val convos by vm.convos.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val pinned by vm.pinned.collectAsState()
    val blocked by vm.blocked.collectAsState()
    val priv by vm.privateSet.collectAsState()
    val trash by vm.trash.collectAsState()
    val sched by vm.sched.collectAsState()
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    var menu by remember { mutableStateOf<Convo?>(null) }
    var keepMenu by remember { mutableStateOf<Convo?>(null) }
    var topMenu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<Convo?>(null) }
    SideEffect { if (menu != null) keepMenu = menu }
    val state = rememberLazyListState()
    val expanded by remember { derivedStateOf { state.firstVisibleItemIndex == 0 } }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.refresh() }
    val blurR by animateDpAsState(if (menu != null || topMenu) 14.dp else 0.dp, tween(250), label = "hb")
    val list = remember(convos, q, filter, blocked, pinned, priv) {
        convos.filter { c ->
            nk(c.address) !in blocked && nk(c.address) !in priv && when (filter) {
                1 -> c.unread > 0
                2 -> Cat.of(c.address, c.snippet) == 0
                3 -> Cat.of(c.address, c.snippet) == 1
                4 -> Cat.of(c.address, c.snippet) == 2
                5 -> Cat.of(c.address, c.snippet) == 3
                6 -> c.code != null
                else -> true
            } && (q.isBlank() || c.name.contains(q, true) || c.snippet.contains(q, true) || c.address.contains(q))
        }.sortedByDescending { it.threadId in pinned }
    }
    val unreadTotal = convos.sumOf { it.unread }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Bg).blur(blurR)) {
            Aurora(Modifier.fillMaxWidth().height(380.dp))
            LazyColumn(state = state, modifier = Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 150.dp)) {
                item { OtpCard(vm) }
                item {
                    Appear(0, "hdr") {
                        Column(Modifier.padding(horizontal = 22.dp).padding(top = 14.dp, bottom = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    GradText("Messages", 40)
                                    Text(if (unreadTotal > 0) "$unreadTotal unread" else "You're all caught up", color = Dim, fontSize = 15.sp)
                                }
                                IconBtn(Icons.Rounded.MoreVert) { topMenu = true }
                            }
                            Spacer(Modifier.height(16.dp))
                            SearchField(q, { q = it }, "Search messages")
                        }
                    }
                }
                item {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("All", "Unread", "Personal", "Money", "Bills", "Offers", "OTP").forEachIndexed { i, s -> Chip(s, filter == i) { filter = i } }
                    }
                }
                if (!isDef && loaded) item { DefaultBanner { roleLauncher.launch(defaultSmsIntent(ctx)) } }
                itemsIndexed(list, key = { _, c -> c.threadId }) { i, c ->
                    Box(Modifier.animateItemPlacement()) {
                        Appear(i, "c${c.threadId}") {
                            ConvoRow(c, c.threadId in pinned, { vm.openChat(Chat(c.threadId, c.address, c.name)) }, { menu = c })
                        }
                    }
                }
                if (list.isEmpty() && loaded) item { EmptyState(Icons.Rounded.Sms, "No messages here", "Tap New chat to start") }
            }
            Fab(expanded, onNew, Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(22.dp))
        }

        Scrim(topMenu, { topMenu = false }) {
            ActionCard(listOf(
                Act(Icons.Rounded.NearMe, "Nearby & offline mesh") { topMenu = false; onGo("nearby") },
                Act(Icons.Rounded.AccountBalanceWallet, "Money & bills") { topMenu = false; onGo("money") },
                Act(Icons.Rounded.Lock, "Private chats") { topMenu = false; onGo("private") },
                Act(Icons.Rounded.Backup, "Backup & phone switch") { topMenu = false; onGo("backup") },
                Act(Icons.Rounded.Star, "Starred messages") { topMenu = false; onGo("starred") },
                Act(Icons.Rounded.Delete, "Recycle bin" + if (trash.isNotEmpty()) " (${trash.size})" else "") { topMenu = false; onGo("bin") },
                Act(Icons.Rounded.Schedule, "Scheduled" + if (sched.isNotEmpty()) " (${sched.size})" else "") { topMenu = false; onGo("sched") },
                Act(Icons.Rounded.Block, "Blocked numbers") { topMenu = false; onGo("blocked") },
                Act(Icons.Rounded.Palette, "Themes & settings") { topMenu = false; onGo("settings") }
            ))
        }
        Scrim(menu != null, { menu = null }) {
            keepMenu?.let { c ->
                Row(Modifier.padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name, 46.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(c.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                ActionCard(buildList {
                    add(Act(Icons.Rounded.PushPin, if (c.threadId in pinned) "Unpin" else "Pin to top") { vm.togglePin(c); menu = null })
                    if (c.unread > 0) add(Act(Icons.Rounded.MarkEmailRead, "Mark as read") { vm.markReadConvo(c); menu = null })
                    add(Act(Icons.Rounded.Block, if (nk(c.address) in blocked) "Unblock" else "Block") { vm.toggleBlock(c.address); menu = null })
                    add(Act(Icons.Rounded.Lock, "Move to private") { vm.togglePrivate(c.address); menu = null })
                    add(Act(Icons.Rounded.Delete, "Delete", true) { menu = null; confirm = c })
                })
            }
        }
        confirm?.let { c ->
            AlertDialog(
                onDismissRequest = { confirm = null }, containerColor = Surf2,
                title = { Text("Delete conversation?", color = Ink) },
                text = { Text("Messages with ${c.name} move to the Recycle bin for 30 days.", color = Dim) },
                confirmButton = {
                    TextButton(onClick = {
                        if (isDef) vm.deleteThread(c) else Toast.makeText(ctx, "Set Messages as default SMS app to delete", Toast.LENGTH_LONG).show()
                        confirm = null
                    }) { Text("Delete", color = A3) }
                },
                dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel", color = Dim) } }
            )
        }
    }
}

@Composable
fun DefaultBanner(onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 22.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(A1.copy(alpha = 0.35f), A3.copy(alpha = 0.3f)))).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Make Messages your default", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Needed to receive, save and delete SMS", color = Dim, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 18.dp, vertical = 9.dp)) {
            Text("Set", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Fab(expanded: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier.bounce(onClick = onClick).shadow(20.dp, shape, ambientColor = A2, spotColor = A2)
            .clip(shape).background(Brand).padding(horizontal = 20.dp, vertical = 16.dp).animateContentSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Edit, null, tint = Color.White)
        AnimatedVisibility(expanded) { Text("  New chat", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    }
}

@Composable
fun Badge(n: Int) {
    val t = rememberInfiniteTransition(label = "badge")
    val s by t.animateFloat(1f, 1.15f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bs")
    Box(
        Modifier.graphicsLayer { scaleX = s; scaleY = s }.defaultMinSize(24.dp, 24.dp).clip(CircleShape)
            .background(Brand).padding(horizontal = 7.dp),
        contentAlignment = Alignment.Center
    ) { Text(if (n > 99) "99+" else "$n", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun ConvoRow(c: Convo, pinned: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val unread = c.unread > 0
    Row(
        Modifier.fillMaxWidth().bounce(onClick = onClick, onLong = onLong)
            .padding(horizontal = 12.dp, vertical = 3.dp).clip(RoundedCornerShape(24.dp))
            .background(if (unread) Surf2 else Color.Transparent).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(c.name, 54.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c.name, color = Ink, fontSize = 17.sp, fontWeight = if (unread) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (pinned) { Spacer(Modifier.width(6.dp)); Icon(Icons.Rounded.PushPin, null, tint = A2, modifier = Modifier.size(15.dp)) }
            }
            Text((if (c.outgoing) "You: " else "") + c.snippet, color = if (unread) Ink else Dim, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            val scam = remember(c.snippet) { if (!c.outgoing) Scam.check(c.snippet, c.address) else null }
            if (scam != null && scam.warn) Text("\u26A0 Possible scam", color = if (scam.risky) Color(0xFFFF3B30) else Color(0xFFFFB020), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (c.code != null && System.currentTimeMillis() - c.date < 3_600_000) {
                Spacer(Modifier.height(6.dp))
                OtpPill(c.code)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(fmt(c.date), color = if (unread) A2 else Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (unread) { Spacer(Modifier.height(6.dp)); Badge(c.unread) }
        }
    }
}
