@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- theme ----------
val Bg = Color(0xFF07070D)
val Surf = Color(0xFF14141F)
val Surf2 = Color(0xFF1E1E2E)
val Ink = Color(0xFFF4F4FB)
val Dim = Color(0xFF9A9AB5)
val A1 = Color(0xFF6D5BFF)
val A2 = Color(0xFFB04BFF)
val A3 = Color(0xFFFF5CA8)
val Brand: Brush = Brush.linearGradient(listOf(A1, A2, A3))

val PERMS: Array<String> = buildList {
    add(Manifest.permission.READ_SMS); add(Manifest.permission.SEND_SMS)
    add(Manifest.permission.RECEIVE_SMS); add(Manifest.permission.READ_CONTACTS)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

fun hasPerm(c: Context) = c.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

fun defaultSmsIntent(c: Context): Intent =
    if (Build.VERSION.SDK_INT >= 29) c.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
    else Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, c.packageName)

// ---------- helpers ----------
fun hm(t: Long): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(t))

fun fmt(t: Long): String = when {
    DateUtils.isToday(t) -> hm(t)
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    System.currentTimeMillis() - t < 6 * DateUtils.DAY_IN_MILLIS -> SimpleDateFormat("EEE", Locale.getDefault()).format(Date(t))
    else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))
}

fun dayLabel(t: Long): String = when {
    DateUtils.isToday(t) -> "Today"
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    else -> SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(t))
}

fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

// ---------- animation building blocks ----------
fun Modifier.bounce(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.94f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "bounce"
    )
    val h = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            onLongClick = onLong?.let { f -> { h.performHapticFeedback(HapticFeedbackType.LongPress); f() } },
            onClick = { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
        )
}

@Composable
fun Appear(i: Int, content: @Composable () -> Unit) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (i < 10) delay(i * 45L)
        p.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
    }
    Box(Modifier.graphicsLayer { alpha = p.value; translationY = (1f - p.value) * 70f }) { content() }
}

@Composable
fun Aurora(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "p")
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val c1 = Offset(w * (0.1f + 0.6f * p), h * 0.12f)
        val c2 = Offset(w * (0.9f - 0.6f * p), h * 0.35f)
        drawCircle(Brush.radialGradient(listOf(A1.copy(alpha = 0.5f), Color.Transparent), center = c1, radius = w * 0.75f), radius = w * 0.75f, center = c1)
        drawCircle(Brush.radialGradient(listOf(A3.copy(alpha = 0.32f), Color.Transparent), center = c2, radius = w * 0.6f), radius = w * 0.6f, center = c2)
    }
}

@Composable
fun GradText(t: String, size: Int, modifier: Modifier = Modifier) {
    BasicText(t, modifier, style = TextStyle(brush = Brand, fontSize = size.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp))
}

@Composable
fun Logo(size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(Brand), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.Sms, null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
    }
}

@Composable
fun Avatar(name: String, size: Dp) {
    val h = ((name.hashCode() and 0x7fffffff) % 360).toFloat()
    val brush = Brush.linearGradient(listOf(Color.hsv(h, 0.55f, 0.95f), Color.hsv((h + 40f) % 360f, 0.75f, 0.72f)))
    Box(Modifier.size(size).clip(CircleShape).background(brush), contentAlignment = Alignment.Center) {
        val ch = name.firstOrNull { it.isLetter() }?.uppercase() ?: "#"
        Text(ch, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.4f).sp)
    }
}

@Composable
fun IconBtn(icon: ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).bounce(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Ink)
    }
}

@Composable
fun OtpPill(code: String) {
    val clip = LocalClipboardManager.current
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(done) { if (done) { delay(1600); done = false } }
    Row(
        Modifier.bounce(onClick = { clip.setText(AnnotatedString(code)); done = true })
            .clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (done) Icons.Rounded.Check else Icons.Rounded.ContentCopy, null, tint = Color.White, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(if (done) "Copied" else code, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
fun Chip(label: String, sel: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (sel) A1 else Surf, label = "chip")
    Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 18.dp, vertical = 9.dp)) {
        Text(label, color = if (sel) Color.White else Dim, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun SearchField(q: String, onQ: (String) -> Unit, hint: String, autofocus: Boolean = false) {
    var focus by remember { mutableStateOf(false) }
    val glow by animateFloatAsState(if (focus) 1f else 0f, tween(300), label = "glow")
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (autofocus) { delay(450); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Surf)
            .border(1.5.dp, Brush.linearGradient(listOf(A1.copy(alpha = glow), A3.copy(alpha = glow))), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = if (focus) A2 else Dim)
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = q, onValueChange = onQ, singleLine = true,
            textStyle = TextStyle(color = Ink, fontSize = 16.sp), cursorBrush = SolidColor(A2),
            modifier = Modifier.weight(1f).focusRequester(fr).onFocusChanged { focus = it.isFocused },
            decorationBox = { inner -> Box { if (q.isEmpty()) Text(hint, color = Dim, fontSize = 16.sp); inner() } }
        )
        AnimatedVisibility(q.isNotEmpty()) {
            Icon(Icons.Rounded.Close, null, tint = Dim, modifier = Modifier.size(22.dp).bounce(onClick = { onQ("") }))
        }
    }
}

@Composable
fun GradientButton(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier.fillMaxWidth().bounce(onClick = onClick)
            .shadow(16.dp, shape, ambientColor = A2, spotColor = A2).clip(shape).background(Brand).padding(vertical = 17.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

// ---------- screens ----------
@Composable
fun App(vm: MessagesVM) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        val ctx = LocalContext.current
        var ok by remember { mutableStateOf(hasPerm(ctx)) }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            ok = hasPerm(ctx); vm.refresh()
        }
        var splash by remember { mutableStateOf(true) }
        var composing by remember { mutableStateOf(false) }
        val open by vm.open.collectAsState()
        var last by remember { mutableStateOf<Chat?>(null) }
        LaunchedEffect(Unit) { delay(1200); splash = false }
        LaunchedEffect(open) { if (open != null) last = open }
        BackHandler(composing || open != null) { if (composing) composing = false else vm.close() }

        Box(Modifier.fillMaxSize().background(Bg)) {
            if (!ok) {
                Onboarding { launcher.launch(PERMS) }
            } else {
                HomeScreen(vm) { composing = true }
                AnimatedVisibility(
                    composing,
                    enter = slideInVertically(tween(420, easing = FastOutSlowInEasing)) { it } + fadeIn(),
                    exit = slideOutVertically(tween(320)) { it } + fadeOut()
                ) {
                    NewChatScreen(vm, { composing = false }) { a, n -> composing = false; vm.startChat(a, n) }
                }
                AnimatedVisibility(
                    open != null,
                    enter = slideInHorizontally(tween(420, easing = FastOutSlowInEasing)) { it } + fadeIn(),
                    exit = slideOutHorizontally(tween(320)) { it } + fadeOut()
                ) {
                    last?.let { ChatScreen(vm, it) { vm.close() } }
                }
            }
            AnimatedVisibility(splash, exit = fadeOut(tween(450)) + scaleOut(tween(450), targetScale = 1.12f)) { Splash() }
        }
    }
}

@Composable
fun Splash() {
    val sc = remember { Animatable(0.2f) }
    LaunchedEffect(Unit) { sc.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Aurora(Modifier.fillMaxSize())
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { scaleX = sc.value; scaleY = sc.value; alpha = sc.value.coerceIn(0f, 1f) }
        ) {
            Logo(112.dp)
            Spacer(Modifier.height(20.dp))
            GradText("Messages", 36)
        }
    }
}

@Composable
fun Onboarding(onGo: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg)) {
        Aurora(Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Appear(0) { Logo(100.dp) }
            Spacer(Modifier.height(22.dp))
            Appear(1) { GradText("Messages", 42) }
            Spacer(Modifier.height(8.dp))
            Appear(2) { Text("Beautiful SMS with smart one-tap OTP copy.", color = Dim, fontSize = 16.sp, textAlign = TextAlign.Center) }
            Spacer(Modifier.height(32.dp))
            listOf(
                Icons.Rounded.Sms to "Send and receive real SMS through your SIM",
                Icons.Rounded.ContentCopy to "OTP codes pop up with one-tap copy",
                Icons.Rounded.Notifications to "Instant notifications with quick reply"
            ).forEachIndexed { i, (ic, t) ->
                Appear(i + 3) {
                    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) {
                            Icon(ic, null, tint = A2)
                        }
                        Spacer(Modifier.width(14.dp))
                        Text(t, color = Ink, fontSize = 15.sp)
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
            Appear(6) { GradientButton("Get started", onGo) }
        }
    }
}

@Composable
fun HomeScreen(vm: MessagesVM, onNew: () -> Unit) {
    val ctx = LocalContext.current
    val convos by vm.convos.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    val loaded by vm.loaded.collectAsState()
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    var del by remember { mutableStateOf<Convo?>(null) }
    val state = rememberLazyListState()
    val expanded by remember { derivedStateOf { state.firstVisibleItemIndex == 0 } }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.refresh() }
    val list = remember(convos, q, filter) {
        convos.filter { c ->
            (filter == 0 || (filter == 1 && c.unread > 0) || (filter == 2 && c.code != null)) &&
                (q.isBlank() || c.name.contains(q, true) || c.snippet.contains(q, true) || c.address.contains(q))
        }
    }
    val unreadTotal = convos.sumOf { it.unread }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Aurora(Modifier.fillMaxWidth().height(380.dp))
        LazyColumn(state = state, modifier = Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 150.dp)) {
            item {
                Appear(0) {
                    Column(Modifier.padding(horizontal = 22.dp).padding(top = 22.dp, bottom = 8.dp)) {
                        GradText("Messages", 40)
                        Text(if (unreadTotal > 0) "$unreadTotal unread" else "You're all caught up", color = Dim, fontSize = 15.sp)
                        Spacer(Modifier.height(16.dp))
                        SearchField(q, { q = it }, "Search messages")
                    }
                }
            }
            item {
                Row(Modifier.padding(horizontal = 22.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("All", "Unread", "OTP").forEachIndexed { i, s -> Chip(s, filter == i) { filter = i } }
                }
            }
            if (!isDef && loaded) item { DefaultBanner { roleLauncher.launch(defaultSmsIntent(ctx)) } }
            itemsIndexed(list, key = { _, c -> c.threadId }) { i, c ->
                Box(Modifier.animateItemPlacement()) {
                    Appear(i) { ConvoRow(c, { vm.openChat(Chat(c.threadId, c.address, c.name)) }, { del = c }) }
                }
            }
            if (list.isEmpty() && loaded) item { Empty() }
        }
        Fab(expanded, onNew, Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(22.dp))

        del?.let { c ->
            AlertDialog(
                onDismissRequest = { del = null },
                containerColor = Surf2,
                title = { Text("Delete conversation?", color = Ink) },
                text = { Text("All messages with ${c.name} will be removed.", color = Dim) },
                confirmButton = {
                    TextButton(onClick = {
                        if (isDef) vm.delete(c) else Toast.makeText(ctx, "Set Messages as default SMS app to delete", Toast.LENGTH_LONG).show()
                        del = null
                    }) { Text("Delete", color = A3) }
                },
                dismissButton = { TextButton(onClick = { del = null }) { Text("Cancel", color = Dim) } }
            )
        }
    }
}

@Composable
fun DefaultBanner(onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 22.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(A1.copy(alpha = 0.35f), A3.copy(alpha = 0.3f)))).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Make Messages your default", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Needed to receive, save and delete SMS", color = Dim, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(Color.White).padding(horizontal = 18.dp, vertical = 9.dp)) {
            Text("Set", color = Bg, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Empty() {
    val t = rememberInfiniteTransition(label = "empty")
    val y by t.animateFloat(-12f, 12f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y")
    Column(Modifier.fillMaxWidth().padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.Sms, null, tint = A2, modifier = Modifier.size(84.dp).graphicsLayer { translationY = y })
        Spacer(Modifier.height(12.dp))
        Text("No messages here", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Tap New chat to start", color = Dim, fontSize = 14.sp)
    }
}

@Composable
fun Fab(expanded: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier.bounce(onClick = onClick).shadow(20.dp, shape, ambientColor = A2, spotColor = A2)
            .clip(shape).background(Brand).padding(horizontal = 20.dp, vertical = 16.dp).animateContentSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Edit, null, tint = Color.White)
        AnimatedVisibility(expanded) { Text("  New chat", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    }
}

@Composable
fun Badge(n: Int) {
    val t = rememberInfiniteTransition(label = "badge")
    val s by t.animateFloat(1f, 1.2f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bs")
    Box(
        Modifier.graphicsLayer { scaleX = s; scaleY = s }.defaultMinSize(24.dp, 24.dp).clip(CircleShape)
            .background(Brand).padding(horizontal = 7.dp),
        contentAlignment = Alignment.Center
    ) { Text(if (n > 99) "99+" else "$n", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun ConvoRow(c: Convo, onClick: () -> Unit, onLong: () -> Unit) {
    val unread = c.unread > 0
    Row(
        Modifier.fillMaxWidth().bounce(onClick = onClick, onLong = onLong)
            .padding(horizontal = 12.dp, vertical = 3.dp).clip(RoundedCornerShape(24.dp))
            .background(if (unread) Surf2 else Color.Transparent).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(c.name, 54.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(c.name, color = Ink, fontSize = 17.sp, fontWeight = if (unread) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text((if (c.outgoing) "You: " else "") + c.snippet, color = if (unread) Ink else Dim, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            if (c.code != null && System.currentTimeMillis() - c.date < 3_600_000) {
                Spacer(Modifier.height(6.dp))
                OtpPill(c.code)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(fmt(c.date), color = if (unread) A2 else Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (unread) { Spacer(Modifier.height(6.dp)); Badge(c.unread) }
        }
    }
}

@Composable
fun ChatScreen(vm: MessagesVM, chat: Chat, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val msgs by vm.msgs.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    var text by remember { mutableStateOf("") }
    val state = rememberLazyListState()
    val rev = remember(msgs) { msgs.asReversed() }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) state.animateScrollToItem(0) }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.ArrowBack) { onBack() }
            Avatar(chat.name, 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(chat.name, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (chat.name != chat.address) Text(chat.address, color = Dim, fontSize = 12.sp)
            }
            IconBtn(Icons.Rounded.Call) { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(chat.address)))) }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = state, reverseLayout = true,
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            itemsIndexed(rev, key = { _, m -> m.id }) { i, m ->
                Bubble(m, rev.getOrNull(i + 1).let { it == null || !sameDay(it.date, m.date) })
            }
        }
        if (!isDef) Text("Set Messages as default SMS app to keep sent messages in this chat", color = Dim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Bottom) {
            Box(Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(Surf).padding(horizontal = 18.dp, vertical = 14.dp)) {
                if (text.isEmpty()) Text("Message", color = Dim, fontSize = 16.sp)
                BasicTextField(
                    value = text, onValueChange = { text = it }, maxLines = 5,
                    textStyle = TextStyle(color = Ink, fontSize = 16.sp), cursorBrush = SolidColor(A2),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            AnimatedVisibility(
                text.isNotBlank(),
                enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn() + expandHorizontally(),
                exit = scaleOut() + fadeOut() + shrinkHorizontally()
            ) {
                Box(
                    Modifier.padding(start = 8.dp).size(50.dp).bounce(onClick = {
                        vm.send(chat, text.trim()); text = ""
                        if (!isDef) Toast.makeText(ctx, "Sent. Set as default app to keep history", Toast.LENGTH_SHORT).show()
                    }).clip(CircleShape).background(Brand),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Send, null, tint = Color.White) }
            }
        }
    }
}

@Composable
fun Bubble(m: Msg, showDay: Boolean) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(350), label = "ba")
    val sc by animateFloatAsState(if (shown) 1f else 0.85f, spring(Spring.DampingRatioMediumBouncy), label = "bs")
    val shape = RoundedCornerShape(22.dp, 22.dp, if (m.outgoing) 6.dp else 22.dp, if (m.outgoing) 22.dp else 6.dp)
    Column(
        Modifier.fillMaxWidth().graphicsLayer {
            alpha = a; scaleX = sc; scaleY = sc
            transformOrigin = TransformOrigin(if (m.outgoing) 1f else 0f, 1f)
        },
        horizontalAlignment = if (m.outgoing) Alignment.End else Alignment.Start
    ) {
        if (showDay) {
            Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                Text(dayLabel(m.date), color = Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Column(Modifier.widthIn(max = 300.dp).clip(shape).background(if (m.outgoing) Brand else SolidColor(Surf2), shape).padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(m.body, color = Color.White, fontSize = 16.sp)
            if (m.code != null) { Spacer(Modifier.height(8.dp)); OtpPill(m.code) }
            Row(Modifier.align(Alignment.End).padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (m.failed) "Not sent" else hm(m.date), color = if (m.failed) A3 else Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                if (m.outgoing) {
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        when { m.failed -> Icons.Rounded.ErrorOutline; m.pending -> Icons.Rounded.Schedule; else -> Icons.Rounded.Done },
                        null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun NewChatScreen(vm: MessagesVM, onClose: () -> Unit, onPick: (String, String) -> Unit) {
    var q by remember { mutableStateOf("") }
    var res by remember { mutableStateOf(emptyList<Contact>()) }
    LaunchedEffect(q) { delay(120); res = withContext(Dispatchers.IO) { vm.repo.contacts(q.trim()) } }
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 18.dp)) {
        Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.Close) { onClose() }
            Text("New message", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        SearchField(q, { q = it }, "Type a name or number", autofocus = true)
        Spacer(Modifier.height(12.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            if (q.count { it.isDigit() } >= 3) {
                item {
                    Row(Modifier.fillMaxWidth().bounce(onClick = { onPick(q.trim(), q.trim()) }).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Send, null, tint = Color.White)
                        }
                        Spacer(Modifier.width(14.dp))
                        Text("Send to ${q.trim()}", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            itemsIndexed(res) { i, c ->
                Appear(i) {
                    Row(Modifier.fillMaxWidth().bounce(onClick = { onPick(c.number, c.name) }).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.name, 46.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(c.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text(c.number, color = Dim, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
