@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.roundToInt
import kotlin.random.Random
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import android.view.WindowManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

// ---------- themes ----------
class AppTheme(
    val name: String, val dark: Boolean,
    val bg: Color, val surf: Color, val surf2: Color, val ink: Color, val dim: Color,
    val a1: Color, val a2: Color, val a3: Color
) {
    val brand: Brush = Brush.linearGradient(listOf(a1, a2, a3))
}

private fun th(n: String, d: Boolean, bg: Long, s: Long, s2: Long, ink: Long, dim: Long, a1: Long, a2: Long, a3: Long) =
    AppTheme(n, d, Color(bg), Color(s), Color(s2), Color(ink), Color(dim), Color(a1), Color(a2), Color(a3))

val THEMES = listOf(
    th("Midnight", true, 0xFF07070D, 0xFF14141F, 0xFF1E1E2E, 0xFFF4F4FB, 0xFF9A9AB5, 0xFF6D5BFF, 0xFFB04BFF, 0xFFFF5CA8),
    th("AMOLED", true, 0xFF000000, 0xFF101012, 0xFF1B1B1F, 0xFFFFFFFF, 0xFF8E8E93, 0xFF00E0FF, 0xFF4D7CFF, 0xFF9B5CFF),
    th("Daylight", false, 0xFFF6F5FF, 0xFFFFFFFF, 0xFFECEAFB, 0xFF14142B, 0xFF6B6B88, 0xFF6D5BFF, 0xFFB04BFF, 0xFFFF5CA8),
    th("Rose Quartz", false, 0xFFFFF5F8, 0xFFFFFFFF, 0xFFFFE6EE, 0xFF2B1620, 0xFF8A6577, 0xFFFF5C8A, 0xFFFF7A59, 0xFFFFB36B),
    th("Ocean", true, 0xFF06111A, 0xFF0D1E2B, 0xFF143044, 0xFFEAF6FF, 0xFF86A5BA, 0xFF00B3FF, 0xFF00D4C0, 0xFF5CFFB1),
    th("Sunset", true, 0xFF120A0C, 0xFF211215, 0xFF2E1A1E, 0xFFFFF1EC, 0xFFB89A95, 0xFFFF7A18, 0xFFFF4D6D, 0xFFC13BFF),
    th("Mint", false, 0xFFF1FBF7, 0xFFFFFFFF, 0xFFDDF5EA, 0xFF0F2A21, 0xFF5E8577, 0xFF00B894, 0xFF00A3C4, 0xFF6C5CE7),
    th("Emerald", true, 0xFF050E0A, 0xFF0C1C15, 0xFF142B21, 0xFFE9FFF4, 0xFF84AD9A, 0xFF1ED760, 0xFF00C2A8, 0xFF8BE04E),
    th("Indigo Night", true, 0xFF05070F, 0xFF0D1120, 0xFF161C30, 0xFFEAF0FF, 0xFF8894B5, 0xFF3D5AFE, 0xFF7C4DFF, 0xFF00E5FF),
    th("Neon", true, 0xFF06060A, 0xFF101018, 0xFF171722, 0xFFF0F0F8, 0xFF8A8AA0, 0xFF00FFC2, 0xFF00A3FF, 0xFFC400FF),
    th("Sakura", false, 0xFFFFF7FA, 0xFFFFFFFF, 0xFFFFE9F1, 0xFF2A1620, 0xFF8B6A78, 0xFFFF6FA5, 0xFFFF9E6D, 0xFFC86DD7),
    th("Copper", true, 0xFF0E0A08, 0xFF1A1310, 0xFF261A14, 0xFFFFF3EA, 0xFFB39A8A, 0xFFE07A3F, 0xFFC2410C, 0xFFF59E0B),
    th("Chhath", true, 0xFF140805, 0xFF231009, 0xFF331A0E, 0xFFFFF3E0, 0xFFC9A98F, 0xFFFFB300, 0xFFFF6D00, 0xFF00B8D4),
    th("Monsoon", true, 0xFF07101A, 0xFF0E1B28, 0xFF16283A, 0xFFE6F1FA, 0xFF8FA6BA, 0xFF4FC3F7, 0xFF00897B, 0xFF7C4DFF),
    th("Peacock", true, 0xFF04120F, 0xFF0A1F1A, 0xFF123029, 0xFFE8FFF8, 0xFF7FB0A2, 0xFF00BFA5, 0xFF1565C0, 0xFFFFC107),
    th("Lagoon", false, 0xFFF0FBFB, 0xFFFFFFFF, 0xFFDDF3F3, 0xFF0C2B2B, 0xFF5F8484, 0xFF00ACC1, 0xFF00897B, 0xFF26C6DA),
    th("Desert", false, 0xFFFBF3E6, 0xFFFFFDF8, 0xFFF3E4CC, 0xFF3A2A18, 0xFF9A8467, 0xFFD97706, 0xFFB45309, 0xFF8D6E63),
    th("Ivory", false, 0xFFFFFDF6, 0xFFFFFFFF, 0xFFF6F0E2, 0xFF241F17, 0xFF8C8271, 0xFFB08D57, 0xFF7A5C2E, 0xFFD4AF37),
    th("Cyber", true, 0xFF050510, 0xFF0E0E1E, 0xFF171730, 0xFFEAF6FF, 0xFF7C86A8, 0xFF00E5FF, 0xFFFF00A0, 0xFF7CFF00),
    th("Maroon", true, 0xFF120608, 0xFF1E0C10, 0xFF2C1218, 0xFFFFF0F2, 0xFFB48A93, 0xFFB71C1C, 0xFF7B1FA2, 0xFFFFB300)
)

fun resolveTheme(sel: Int, system: Boolean, sysDark: Boolean): AppTheme {
    val t = THEMES[sel.coerceIn(0, THEMES.lastIndex)]
    if (!system || t.dark == sysDark) return t
    return if (sysDark) THEMES[0] else THEMES[2]
}

var CurTheme by mutableStateOf(THEMES[0])
var HapticsOn = true
var MotionOn by mutableStateOf(true)

// The live palette. Every screen reads these, so when you pick a new theme the whole
// app blends across instead of snapping.
private val cBg = mutableStateOf(THEMES[0].bg)
private val cSurf = mutableStateOf(THEMES[0].surf)
private val cSurf2 = mutableStateOf(THEMES[0].surf2)
private val cInk = mutableStateOf(THEMES[0].ink)
private val cDim = mutableStateOf(THEMES[0].dim)
private val cA1 = mutableStateOf(THEMES[0].a1)
private val cA2 = mutableStateOf(THEMES[0].a2)
private val cA3 = mutableStateOf(THEMES[0].a3)

val Bg: Color get() = cBg.value
val Surf: Color get() = cSurf.value
val Surf2: Color get() = cSurf2.value
val Ink: Color get() = cInk.value
val Dim: Color get() = cDim.value
val A1: Color get() = cA1.value
val A2: Color get() = cA2.value
val A3: Color get() = cA3.value
val Brand: Brush get() = Brush.linearGradient(listOf(cA1.value, cA2.value, cA3.value))
val Gold = Color(0xFFFFC857)

val PERMS: Array<String> = buildList {
    add(Manifest.permission.READ_SMS); add(Manifest.permission.SEND_SMS)
    add(Manifest.permission.RECEIVE_SMS); add(Manifest.permission.READ_CONTACTS)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

fun hasPerm(c: Context) = c.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

fun defaultSmsIntent(c: Context): Intent =
    if (Build.VERSION.SDK_INT >= 29) c.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
    else Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, c.packageName)

// ---------- helpers ----------
fun hm(t: Long): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(t))
fun fullDate(t: Long): String = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(t))

fun fmt(t: Long): String = when {
    DateUtils.isToday(t) -> hm(t)
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    System.currentTimeMillis() - t < 6 * DateUtils.DAY_IN_MILLIS -> SimpleDateFormat("EEE", Locale.getDefault()).format(Date(t))
    else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))
}

fun dayLabel(t: Long): String = when {
    DateUtils.isToday(t) -> "Today"
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    else -> SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(t))
}

fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

fun dayStart(t: Long): Long = Calendar.getInstance().apply {
    timeInMillis = t
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun combine(day: Long, hour: Int, minute: Int): Long = Calendar.getInstance().apply {
    timeInMillis = day
    set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun timeOptions(): List<Pair<String, Long>> {
    val now = System.currentTimeMillis()
    val out = ArrayList<Pair<String, Long>>()
    out.add("In 1 hour" to now + 3_600_000L)
    val ev = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 18); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
    if (ev.timeInMillis > now + 600_000L) out.add("This evening, 6 PM" to ev.timeInMillis)
    val tm = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
    out.add("Tomorrow, 9 AM" to tm.timeInMillis)
    return out
}

// ---------- animation building blocks ----------
object Seen { val set = HashSet<String>() }

fun Modifier.bounce(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.95f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "bounce"
    )
    val h = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            onLongClick = onLong?.let { f -> { if (HapticsOn) h.performHapticFeedback(HapticFeedbackType.LongPress); f() } },
            onClick = { if (HapticsOn) h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
        )
}

// ---------- global look switches ----------
var ElderMode by mutableStateOf(false)

fun Context.copyText(t: String, msg: String = "Copied") {
    try {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Messages", t))
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    } catch (_: Exception) { }
}

/** Swipe a row right for [rightLabel], left for [leftLabel]. Snaps back by itself. */
@Composable
fun SwipeRow(
    rightIcon: ImageVector, rightLabel: String, rightColor: Color, onRight: (() -> Unit)? = null,
    leftIcon: ImageVector, leftLabel: String, leftColor: Color, onLeft: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val limit = with(LocalDensity.current) { 86.dp.toPx() }
    var dx by remember { mutableStateOf(0f) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var armed by remember { mutableStateOf(0) }
    Box(modifier.fillMaxWidth()) {
        val v = dx
        if (v > 4f) {
            Row(Modifier.matchParentSize().padding(start = 26.dp), verticalAlignment = Alignment.CenterVertically) {
                val k = (v / limit).coerceIn(0f, 1f)
                Icon(
                    rightIcon, null, tint = rightColor,
                    modifier = Modifier.size(22.dp).graphicsLayer { alpha = k; scaleX = 0.55f + 0.45f * k; scaleY = 0.55f + 0.45f * k }
                )
                if (k > 0.62f) {
                    Spacer(Modifier.width(8.dp))
                    Text(rightLabel, color = rightColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else if (v < -4f) {
            Row(Modifier.matchParentSize().padding(end = 26.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                val k = (-v / limit).coerceIn(0f, 1f)
                if (k > 0.62f) {
                    Text(leftLabel, color = leftColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                }
                Icon(
                    leftIcon, null, tint = leftColor,
                    modifier = Modifier.size(22.dp).graphicsLayer { alpha = k; scaleX = 0.55f + 0.45f * k; scaleY = 0.55f + 0.45f * k }
                )
            }
        }
        Box(
            Modifier.offset { IntOffset(dx.roundToInt(), 0) }.pointerInput(onLeft, onRight) {
                detectHorizontalDragGestures(
                    onDragStart = { armed = 0 },
                    onDragCancel = { scope.launch { animate(dx, 0f, animationSpec = tween(150)) { x, _ -> dx = x } } },
                    onDragEnd = {
                        val target = when {
                            dx > limit && onRight != null -> limit
                            dx < -limit && onLeft != null -> -limit
                            else -> 0f
                        }
                        scope.launch {
                            if (target != 0f) {
                                animate(dx, target, animationSpec = tween(140)) { x, _ -> dx = x }
                                if (target > 0) onRight?.invoke() else onLeft?.invoke()
                            }
                            animate(dx, 0f, animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { x, _ -> dx = x }
                        }
                    },
                    onHorizontalDrag = { _, drag ->
                        dx = (dx + drag).coerceIn(-limit * 1.25f, limit * 1.25f)
                        val a = when {
                            dx > limit -> 1
                            dx < -limit -> -1
                            else -> 0
                        }
                        if (a != armed && a != 0) {
                            armed = a
                            if (HapticsOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                        if (a == 0) armed = 0
                    }
                )
            }
        ) { content() }
    }
}

/** Wipes a row away with a bright edge sweep (used for bulk delete instead of particles). */
fun Modifier.wipeAway(p: Float): Modifier = this
    .graphicsLayer {
        alpha = (1f - p * 0.92f).coerceIn(0f, 1f)
        scaleY = 1f - 0.3f * p * p
    }
    .drawWithContent {
        if (p <= 0.001f) {
            drawContent()
        } else {
            val keep = size.width * (1f - p)
            clipRect(0f, 0f, keep, size.height) { this@drawWithContent.drawContent() }
            val edge = size.width * 0.16f
            drawRect(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, A2, Color.Transparent)),
                topLeft = Offset(keep - edge / 2f, 0f),
                size = Size(edge, size.height)
            )
        }
    }

@Composable
fun WipeRow(active: Boolean, content: @Composable () -> Unit) {
    val p by animateFloatAsState(if (active) 1f else 0f, tween(460, easing = FastOutSlowInEasing), label = "wipe")
    Box(Modifier.wipeAway(p)) { content() }
}

// swallows touches so screens stacked underneath never receive them
fun Modifier.blockTouches(): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
}

@Composable
fun Appear(i: Int, key: String? = null, content: @Composable () -> Unit) {
    val already = key != null && key in Seen.set
    val p = remember { Animatable(if (already) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!already) {
            if (i < 10) delay(i * 40L)
            p.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
            key?.let { Seen.set.add(it) }
        }
    }
    Box(Modifier.graphicsLayer { alpha = p.value; translationY = (1f - p.value) * 60f }) { content() }
}

private fun DrawScope.auroraBlobs(p1: Float, p2: Float, p3: Float, breathe: Float, dark: Boolean) {
    val k = if (dark) 1f else 0.55f
    val w = size.width
    val h = size.height
    val c1 = Offset(w * (0.06f + 0.58f * p1), h * (0.04f + 0.20f * p2))
    val c2 = Offset(w * (0.98f - 0.55f * p2), h * (0.20f + 0.20f * p3))
    val c3 = Offset(w * (0.28f + 0.42f * p3), h * (0.40f + 0.14f * p1))
    val r1 = w * 0.80f * breathe
    val r2 = w * 0.62f * (1.95f - breathe)
    val r3 = w * 0.46f * breathe
    drawCircle(
        Brush.radialGradient(listOf(A1.copy(alpha = 0.55f * k), Color.Transparent), center = c1, radius = r1),
        radius = r1, center = c1
    )
    drawCircle(
        Brush.radialGradient(listOf(A3.copy(alpha = 0.40f * k), Color.Transparent), center = c2, radius = r2),
        radius = r2, center = c2
    )
    drawCircle(
        Brush.radialGradient(listOf(A2.copy(alpha = 0.30f * k), Color.Transparent), center = c3, radius = r3),
        radius = r3, center = c3
    )
}

/** Chhath: the setting sun over a river, rays breathing, water catching the light. */
private fun DrawScope.chhathSun(p: Float) {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * (0.34f + 0.03f * p)
    val r = w * 0.15f
    for (i in 0 until 26) {
        val a = (i / 26f) * 6.2832f
        val len = r * (1.30f + 0.22f * kotlin.math.sin(p * 6.2832f + i * 0.9f))
        drawLine(
            color = Color(0xFFFFB300).copy(alpha = 0.22f),
            start = Offset(cx + kotlin.math.cos(a) * r * 1.15f, cy + kotlin.math.sin(a) * r * 1.15f),
            end = Offset(cx + kotlin.math.cos(a) * len, cy + kotlin.math.sin(a) * len),
            strokeWidth = 3.5f
        )
    }
    drawCircle(
        Brush.radialGradient(
            listOf(Color(0xFFFFC107).copy(alpha = 0.55f), Color(0xFFFF6D00).copy(alpha = 0.18f), Color.Transparent),
            center = Offset(cx, cy), radius = r * 2.8f
        ),
        radius = r * 2.8f, center = Offset(cx, cy)
    )
    drawCircle(Color(0xFFFFD54F), radius = r, center = Offset(cx, cy))
    drawCircle(Color(0xFFFFE082).copy(alpha = 0.55f), radius = r * 0.55f, center = Offset(cx, cy))
    val wy = h * 0.66f
    for (i in 0 until 8) {
        val yy = wy + i * h * 0.032f
        val shift = kotlin.math.sin(p * 6.2832f + i * 0.8f) * w * 0.05f
        drawRect(
            color = Color(0xFF00B8D4).copy(alpha = 0.20f * (1f - i / 8f)),
            topLeft = Offset(w * 0.12f + shift, yy),
            size = Size(w * 0.76f, h * 0.010f)
        )
    }
}

@Composable
fun Aurora(modifier: Modifier) {
    val dark = CurTheme.dark
    if (!MotionOn) {
        Canvas(modifier) { auroraBlobs(0.5f, 0.5f, 0.5f, 1f, dark) }
        return
    }
    if (CurTheme.name == "Chhath") {
        val sun = rememberInfiniteTransition(label = "sun")
        val sp by sun.animateFloat(0f, 1f, infiniteRepeatable(tween(11000, easing = LinearEasing), RepeatMode.Reverse), label = "sp")
        Canvas(modifier) { chhathSun(if (MotionOn) sp else 0.4f) }
        return
    }
    val t = rememberInfiniteTransition(label = "aurora")
    val p1 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "p1")
    val p2 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(13000, easing = LinearEasing), RepeatMode.Reverse), label = "p2")
    val p3 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(17000, easing = LinearEasing), RepeatMode.Reverse), label = "p3")
    val br by t.animateFloat(0.85f, 1.18f, infiniteRepeatable(tween(6500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "br")
    Canvas(modifier) { auroraBlobs(p1, p2, p3, br, dark) }
}

@Composable
fun GradText(t: String, size: Int, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "grad")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart), label = "gp")
    val sweep = if (MotionOn) p else 0.3f
    val brush = Brush.linearGradient(
        colors = listOf(A1, A2, A3, A1),
        start = Offset(sweep * 900f, 0f),
        end = Offset(sweep * 900f + 520f, 300f)
    )
    BasicText(t, modifier, style = TextStyle(brush = brush, fontSize = size.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp))
}

@Composable
fun Logo(size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(Brand), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.Sms, null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
    }
}

@Composable
fun Avatar(name: String, size: Dp) {
    val h = ((name.hashCode() and 0x7fffffff) % 360).toFloat()
    val brush = remember(name) { Brush.linearGradient(listOf(Color.hsv(h, 0.55f, 0.95f), Color.hsv((h + 40f) % 360f, 0.75f, 0.72f))) }
    Box(Modifier.size(size).clip(CircleShape).background(brush), contentAlignment = Alignment.Center) {
        val ch = name.firstOrNull { it.isLetter() }?.uppercase() ?: "#"
        Text(ch, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.4f).sp)
    }
}

@Composable
fun IconBtn(icon: ImageVector, tint: Color = Ink, onClick: () -> Unit) {
    Box(Modifier.size(if (ElderMode) 50.dp else 44.dp).bounce(onClick = onClick), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint) }
}

@Composable
fun OtpPill(code: String) {
    val clip = LocalClipboardManager.current
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(done) { if (done) { delay(1600); done = false } }
    Row(
        Modifier.bounce(onClick = { clip.setText(AnnotatedString(code)); done = true })
            .clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (done) Icons.Rounded.Check else Icons.Rounded.ContentCopy, null, tint = Color.White, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(if (done) "Copied" else code, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
fun Chip(label: String, sel: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (sel) A1 else Surf, label = "chip")
    Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 18.dp, vertical = 9.dp)) {
        Text(label, color = if (sel) Color.White else Dim, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun SearchField(q: String, onQ: (String) -> Unit, hint: String, autofocus: Boolean = false) {
    var focus by remember { mutableStateOf(false) }
    val glow by animateFloatAsState(if (focus) 1f else 0f, tween(300), label = "glow")
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (autofocus) { delay(450); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Surf)
            .border(1.5.dp, Brush.linearGradient(listOf(A1.copy(alpha = glow), A3.copy(alpha = glow))), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = if (focus) A2 else Dim)
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = q, onValueChange = onQ, singleLine = true,
            textStyle = TextStyle(color = Ink, fontSize = 16.sp), cursorBrush = SolidColor(A2),
            modifier = Modifier.weight(1f).focusRequester(fr).onFocusChanged { focus = it.isFocused },
            decorationBox = { inner -> Box { if (q.isEmpty()) Text(hint, color = Dim, fontSize = 16.sp); inner() } }
        )
        AnimatedVisibility(q.isNotEmpty()) {
            Icon(Icons.Rounded.Close, null, tint = Dim, modifier = Modifier.size(22.dp).bounce(onClick = { onQ("") }))
        }
    }
}

@Composable
fun GradientButton(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier.fillMaxWidth().bounce(onClick = onClick)
            .shadow(16.dp, shape, ambientColor = A2, spotColor = A2).clip(shape).background(Brand).padding(vertical = 17.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

class Act(val icon: ImageVector, val label: String, val danger: Boolean = false, val onClick: () -> Unit)

@Composable
fun ActionCard(items: List<Act>) {
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.widthIn(min = 240.dp, max = 320.dp).shadow(24.dp, shape).clip(shape).background(Surf).padding(vertical = 6.dp)) {
        items.forEach { a ->
            Row(Modifier.fillMaxWidth().bounce(onClick = a.onClick).padding(horizontal = 20.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(a.icon, null, tint = if (a.danger) A3 else Ink, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(16.dp))
                Text(a.label, color = if (a.danger) A3 else Ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun Scrim(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(tween(180)), exit = fadeOut(tween(150))) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            val p = remember { Animatable(0.88f) }
            LaunchedEffect(Unit) { p.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) }
            Column(
                Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())
                    .padding(24.dp).graphicsLayer { scaleX = p.value; scaleY = p.value },
                horizontalAlignment = Alignment.CenterHorizontally, content = content
            )
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, sub: String = "") {
    val t = rememberInfiniteTransition(label = "empty")
    val y by t.animateFloat(-12f, 12f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y")
    Column(Modifier.fillMaxWidth().padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = A2, modifier = Modifier.size(84.dp).graphicsLayer { translationY = y })
        Spacer(Modifier.height(12.dp))
        Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = Dim, fontSize = 14.sp)
    }
}

// ---------- app shell ----------
@Composable
fun App(vm: MessagesVM) {
    val st by vm.settings.collectAsState()
    val theme = resolveTheme(st.theme, st.system, isSystemInDarkTheme())
    val blend = tween<Color>(420, easing = FastOutSlowInEasing)
    val bgT by animateColorAsState(theme.bg, blend, label = "cbg")
    val surfT by animateColorAsState(theme.surf, blend, label = "csurf")
    val surf2T by animateColorAsState(theme.surf2, blend, label = "csurf2")
    val inkT by animateColorAsState(theme.ink, blend, label = "cink")
    val dimT by animateColorAsState(theme.dim, blend, label = "cdim")
    val a1T by animateColorAsState(theme.a1, blend, label = "ca1")
    val a2T by animateColorAsState(theme.a2, blend, label = "ca2")
    val a3T by animateColorAsState(theme.a3, blend, label = "ca3")
    SideEffect {
        CurTheme = theme
        HapticsOn = st.haptics
        ElderMode = st.elder
        MotionOn = st.motion
        if (cBg.value != bgT) cBg.value = bgT
        if (cSurf.value != surfT) cSurf.value = surfT
        if (cSurf2.value != surf2T) cSurf2.value = surf2T
        if (cInk.value != inkT) cInk.value = inkT
        if (cDim.value != dimT) cDim.value = dimT
        if (cA1.value != a1T) cA1.value = a1T
        if (cA2.value != a2T) cA2.value = a2T
        if (cA3.value != a3T) cA3.value = a3T
    }
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = !theme.dark
                isAppearanceLightNavigationBars = !theme.dark
            }
            w.setBackgroundDrawable(ColorDrawable(theme.bg.toArgb()))
            if (st.lock) w.addFlags(WindowManager.LayoutParams.FLAG_SECURE) else w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    val baseDensity = LocalDensity.current
    val scaled = (baseDensity.fontScale * st.textScale).coerceIn(0.7f, 2.6f)
    CompositionLocalProvider(LocalDensity provides Density(baseDensity.density, scaled)) {
    MaterialTheme(colorScheme = if (theme.dark) darkColorScheme() else lightColorScheme()) {
        val ctx = LocalContext.current
        var ok by remember { mutableStateOf(hasPerm(ctx)) }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            ok = hasPerm(ctx); vm.refresh()
        }
        var splash by remember { mutableStateOf(true) }
        var locked by remember { mutableStateOf(st.lock) }
        val lifeOwner = LocalLifecycleOwner.current
        DisposableEffect(lifeOwner, st.lock) {
            var stopped = 0L
            val obs = LifecycleEventObserver { _, e ->
                if (e == Lifecycle.Event.ON_STOP) stopped = System.currentTimeMillis()
                else if (e == Lifecycle.Event.ON_START && st.lock && stopped > 0L && System.currentTimeMillis() - stopped > 15_000L) locked = true
            }
            lifeOwner.lifecycle.addObserver(obs)
            onDispose { lifeOwner.lifecycle.removeObserver(obs) }
        }
        var composing by remember { mutableStateOf(false) }
        var fwd by remember { mutableStateOf<String?>(null) }
        var screen by remember { mutableStateOf<String?>(null) }
        var lastScreen by remember { mutableStateOf("") }
        val open by vm.open.collectAsState()
        val meshConv by Mesh.openConv.collectAsState()
        val gotoTarget by vm.goto.collectAsState()
        var last by remember { mutableStateOf<Chat?>(null) }
        val shownChat = open ?: last
        SideEffect { if (open != null) last = open }
        LaunchedEffect(Unit) { delay(1100); splash = false }
        BackHandler(composing || open != null || screen != null || meshConv != null) {
            when {
                composing -> { composing = false; fwd = null }
                meshConv != null -> Mesh.openConv.value = null
                open != null -> vm.close()
                else -> screen = null
            }
        }
        val go = { s: String -> lastScreen = s; screen = s }
        LaunchedEffect(gotoTarget) {
            val t = gotoTarget
            if (t != null) {
                if (t == "compose") composing = true else go(t)
                vm.goto.value = null
            }
        }
        var lastMesh by remember { mutableStateOf("zone") }
        SideEffect { meshConv?.let { lastMesh = it } }

        Box(Modifier.fillMaxSize().background(Bg)) {
            if (!ok) {
                Onboarding { launcher.launch(PERMS) }
            } else {
                HomeScreen(vm, go) { composing = true }
                AnimatedVisibility(
                    screen != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) {
                    val back = { screen = null }
                    when (lastScreen) {
                        "nearby" -> NearbyScreen(vm, back)
                        "money" -> MoneyScreen(vm, back)
                        "private" -> PrivateScreen(vm, back)
                        "backup" -> BackupScreen(vm, back)
                        "settings" -> SettingsScreen(vm, back, onVault = { vm.goto.value = "vault" })
                        "bin" -> BinScreen(vm, back)
                        "starred" -> StarredScreen(vm, back)
                        "sched" -> ScheduledScreen(vm, back)
                        "vault" -> VaultScreen(vm, back)
                        "companion" -> CompanionScreen(vm, back)
                        "search" -> SearchScreen(vm, back) { addr -> vm.startChat(addr) }
                        else -> BlockedScreen(vm, back)
                    }
                }
                AnimatedVisibility(
                    open != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) {
                    shownChat?.let { c ->
                        key(c.address) { ChatScreen(vm, c, onForward = { t -> fwd = t; composing = true }, onBack = { vm.close() }) }
                    }
                }
                AnimatedVisibility(
                    meshConv != null,
                    enter = slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(250)),
                    exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200))
                ) { MeshChatScreen(meshConv ?: lastMesh) { Mesh.openConv.value = null } }
                AnimatedVisibility(
                    composing,
                    enter = slideInVertically(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(),
                    exit = slideOutVertically(tween(300)) { it } + fadeOut()
                ) {
                    NewChatScreen(vm, if (fwd != null) "Forward to…" else "New message", { composing = false; fwd = null }) { a, n ->
                        composing = false
                        fwd?.let { vm.draft.value = it }
                        fwd = null
                        vm.startChat(a, n)
                    }
                }
            }
            AnimatedVisibility(locked && st.lock, enter = fadeIn(tween(150)), exit = fadeOut(tween(300))) { LockScreen { locked = false } }
            AnimatedVisibility(splash, exit = fadeOut(tween(450)) + scaleOut(tween(450), targetScale = 1.12f)) { Splash() }
        }
    }
    }
}

@Composable
fun Splash() {
    val sc = remember { Animatable(0.2f) }
    LaunchedEffect(Unit) { sc.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Aurora(Modifier.fillMaxSize())
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { scaleX = sc.value; scaleY = sc.value; alpha = sc.value.coerceIn(0f, 1f) }
        ) {
            Logo(112.dp)
            Spacer(Modifier.height(20.dp))
            GradText("Messages", 36)
        }
    }
}

@Composable
fun Onboarding(onGo: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg)) {
        Aurora(Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Appear(0) { Logo(100.dp) }
            Spacer(Modifier.height(22.dp))
            Appear(1) { GradText("Messages", 42) }
            Spacer(Modifier.height(8.dp))
            Appear(2) { Text("Beautiful SMS with smart one-tap OTP copy.", color = Dim, fontSize = 16.sp, textAlign = TextAlign.Center) }
            Spacer(Modifier.height(32.dp))
            listOf(
                Icons.Rounded.Sms to "Send and receive real SMS through your SIM",
                Icons.Rounded.ContentCopy to "OTP codes pop up with one-tap copy",
                Icons.Rounded.Notifications to "Instant notifications with quick reply"
            ).forEachIndexed { i, (ic, t) ->
                Appear(i + 3) {
                    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) { Icon(ic, null, tint = A2) }
                        Spacer(Modifier.width(14.dp))
                        Text(t, color = Ink, fontSize = 15.sp)
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
            Appear(6) { GradientButton("Get started", onGo) }
        }
    }
}

// ---------- home ----------
@Composable
fun HomeScreen(vm: MessagesVM, onGo: (String) -> Unit, onNew: () -> Unit) {
    val ctx = LocalContext.current
    val convos by vm.convos.collectAsState()
    val isDef by vm.isDefault.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val pinned by vm.pinned.collectAsState()
    val blocked by vm.blocked.collectAsState()
    val priv by vm.privateSet.collectAsState()
    val trash by vm.trash.collectAsState()
    val sched by vm.sched.collectAsState()
    val tickets by vm.ticketCount.collectAsState()
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    var menu by remember { mutableStateOf<Convo?>(null) }
    var keepMenu by remember { mutableStateOf<Convo?>(null) }
    var topMenu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<Convo?>(null) }
    var selMode by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(setOf<Long>()) }
    var wiping by remember { mutableStateOf(setOf<Long>()) }
    var bulkConfirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    SideEffect { if (menu != null) keepMenu = menu }
    val state = rememberLazyListState()
    val expanded by remember { derivedStateOf { state.firstVisibleItemIndex == 0 } }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.refresh() }
    val blurR by animateDpAsState(if (menu != null || topMenu) 14.dp else 0.dp, tween(250), label = "hb")
    val list = remember(convos, q, filter, blocked, pinned, priv) {
        convos.filter { c ->
            nk(c.address) !in blocked && nk(c.address) !in priv && when (filter) {
                1 -> c.unread > 0
                2 -> Cat.of(c.address, c.snippet) == 0
                3 -> Cat.of(c.address, c.snippet) == 1
                4 -> Cat.of(c.address, c.snippet) == 2
                5 -> Cat.of(c.address, c.snippet) == 3
                6 -> c.code != null
                else -> true
            } && (q.isBlank() || c.name.contains(q, true) || c.snippet.contains(q, true) || c.address.contains(q))
        }.sortedByDescending { it.threadId in pinned }
    }
    val unreadTotal = convos.sumOf { it.unread }
    BackHandler(selMode) { selMode = false; sel = emptySet() }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Bg).blur(blurR)) {
            val shift by remember { derivedStateOf { (state.firstVisibleItemIndex * 140 + state.firstVisibleItemScrollOffset) * 0.3f } }
            Aurora(
                Modifier.fillMaxWidth().height(380.dp)
                    .graphicsLayer { translationY = -shift; scaleY = 1f + (shift / 3800f).coerceIn(0f, 0.15f) }
            )
            LazyColumn(state = state, modifier = Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 150.dp)) {
                item { OtpCard(vm) }
                item {
                    Appear(0, "hdr") {
                        val hs = (1f - shift / 560f).coerceIn(0.80f, 1f)
                        Column(
                            Modifier.padding(horizontal = 22.dp).padding(top = 14.dp, bottom = 8.dp)
                                .graphicsLayer {
                                    scaleX = hs
                                    scaleY = hs
                                    alpha = (0.25f + 0.75f * hs).coerceIn(0f, 1f)
                                    transformOrigin = TransformOrigin(0f, 0f)
                                }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    GradText("Messages", 40)
                                    Text(if (unreadTotal > 0) "$unreadTotal unread" else "You're all caught up", color = Dim, fontSize = 15.sp)
                                }
                                IconBtn(Icons.Rounded.MoreVert) { topMenu = true }
                            }
                            Spacer(Modifier.height(16.dp))
                            SearchField(q, { q = it }, "Search messages")
                        }
                    }
                }
                item {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("All", "Unread", "Personal", "Money", "Bills", "Offers", "OTP").forEachIndexed { i, s -> Chip(s, filter == i) { filter = i } }
                    }
                }
                if (!isDef && loaded) item { DefaultBanner { roleLauncher.launch(defaultSmsIntent(ctx)) } }
                if (tickets > 0 && loaded) item { TicketBanner(tickets) { onGo("vault") } }
                itemsIndexed(list, key = { _, c -> c.threadId }) { i, c ->
                    Box(Modifier.animateItemPlacement()) {
                        Appear(i, "c${c.threadId}") {
                            WipeRow(c.threadId in wiping) {
                                SwipeRow(
                                    rightIcon = Icons.Rounded.PushPin,
                                    rightLabel = if (c.threadId in pinned) "Unpin" else "Pin",
                                    rightColor = A2,
                                    onRight = { vm.togglePin(c) },
                                    leftIcon = Icons.Rounded.DeleteOutline,
                                    leftLabel = "Delete",
                                    leftColor = A3,
                                    onLeft = { confirm = c }
                                ) {
                                    ConvoRow(
                                        c, c.threadId in pinned,
                                        onClick = { if (selMode) sel = sel.toggle(c.threadId) else vm.openChat(Chat(c.threadId, c.address, c.name)) },
                                        onLong = { if (selMode) sel = sel.toggle(c.threadId) else menu = c },
                                        selMode = selMode, selected = c.threadId in sel
                                    )
                                }
                            }
                        }
                    }
                }
                if (!loaded) items(7) { SkeletonRow() }
                if (list.isEmpty() && loaded) item { EmptyState(Icons.Rounded.Sms, "No messages here", "Tap New chat to start") }
            }
            Fab(expanded, onNew, Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(22.dp))
        }

        Scrim(topMenu, { topMenu = false }) {
            ActionCard(listOf(
                Act(Icons.Rounded.NearMe, "Nearby & offline mesh") { topMenu = false; onGo("nearby") },
                Act(Icons.Rounded.AccountBalanceWallet, "Money & bills") { topMenu = false; onGo("money") },
                Act(Icons.Rounded.Lock, "Private chats") { topMenu = false; onGo("private") },
                Act(Icons.Rounded.Backup, "Backup & phone switch") { topMenu = false; onGo("backup") },
                Act(Icons.Rounded.Star, "Starred messages") { topMenu = false; onGo("starred") },
                Act(Icons.Rounded.Delete, "Recycle bin" + if (trash.isNotEmpty()) " (${trash.size})" else "") { topMenu = false; onGo("bin") },
                Act(Icons.Rounded.Schedule, "Scheduled" + if (sched.isNotEmpty()) " (${sched.size})" else "") { topMenu = false; onGo("sched") },
                Act(Icons.Rounded.Search, "Search all messages") { topMenu = false; onGo("search") },
                Act(Icons.Rounded.ConfirmationNumber, "Find tickets in messages") { topMenu = false; onGo("vault") },
                Act(Icons.Rounded.Block, "Blocked numbers") { topMenu = false; onGo("blocked") },
                Act(Icons.Rounded.Fingerprint, "Saved info vault") { topMenu = false; onGo("vault") },
                Act(Icons.Rounded.LaptopMac, "Use from laptop") { topMenu = false; onGo("companion") },
                Act(Icons.Rounded.Checklist, "Select chats") { topMenu = false; sel = emptySet(); selMode = true },
                Act(Icons.Rounded.MarkEmailRead, "Mark all as read") { topMenu = false; vm.markAllRead() },
                Act(Icons.Rounded.Palette, "Themes & settings") { topMenu = false; onGo("settings") }
            ))
        }
        Scrim(menu != null, { menu = null }) {
            keepMenu?.let { c ->
                Row(Modifier.padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name, 46.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(c.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                ActionCard(buildList {
                    add(Act(Icons.Rounded.PushPin, if (c.threadId in pinned) "Unpin" else "Pin to top") { vm.togglePin(c); menu = null })
                    if (c.unread > 0) add(Act(Icons.Rounded.MarkEmailRead, "Mark as read") { vm.markReadConvo(c); menu = null })
                    add(Act(Icons.Rounded.Block, if (nk(c.address) in blocked) "Unblock" else "Block") { vm.toggleBlock(c.address); menu = null })
                    add(Act(Icons.Rounded.Lock, "Move to private") { vm.togglePrivate(c.address); menu = null })
                    add(Act(Icons.Rounded.CheckCircle, "Select") { sel = setOf(c.threadId); selMode = true; menu = null })
                    add(Act(Icons.Rounded.Delete, "Delete", true) { menu = null; confirm = c })
                })
            }
        }
        confirm?.let { c ->
            AlertDialog(
                onDismissRequest = { confirm = null }, containerColor = Surf2,
                title = { Text("Delete conversation?", color = Ink) },
                text = { Text("Messages with ${c.name} move to the Recycle bin for 30 days.", color = Dim) },
                confirmButton = {
                    TextButton(onClick = {
                        if (isDef) vm.deleteThread(c) else Toast.makeText(ctx, "Set Messages as default SMS app to delete", Toast.LENGTH_LONG).show()
                        confirm = null
                    }) { Text("Delete", color = A3) }
                },
                dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel", color = Dim) } }
            )
        }
        if (bulkConfirm) {
            AlertDialog(
                onDismissRequest = { bulkConfirm = false }, containerColor = Surf2,
                title = { Text(if (sel.size == 1) "Delete 1 conversation?" else "Delete ${sel.size} conversations?", color = Ink) },
                text = { Text("They move to the Recycle bin for 30 days, so you can restore them any time.", color = Dim) },
                confirmButton = {
                    TextButton(onClick = {
                        bulkConfirm = false
                        if (!isDef) {
                            Toast.makeText(ctx, "Set Messages as default SMS app to delete", Toast.LENGTH_LONG).show()
                        } else {
                            val targets = list.filter { it.threadId in sel }
                            wiping = sel
                            scope.launch {
                                delay(500)
                                vm.deleteThreads(targets)
                                wiping = emptySet(); sel = emptySet(); selMode = false
                            }
                        }
                    }) { Text("Delete", color = A3) }
                },
                dismissButton = { TextButton(onClick = { bulkConfirm = false }) { Text("Cancel", color = Dim) } }
            )
        }
        AnimatedVisibility(
            selMode,
            enter = slideInVertically(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { -it } + fadeIn(tween(180)),
            exit = slideOutVertically(tween(220)) { -it } + fadeOut(tween(140)),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Column(
                Modifier.fillMaxWidth().background(Bg).statusBarsPadding()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(Icons.Rounded.Close) { selMode = false; sel = emptySet() }
                    Column(Modifier.weight(1f)) {
                        Text("${sel.size} selected", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            when {
                                sel.isEmpty() -> "Tap any chat to select"
                                sel.size == list.size -> "Every conversation selected"
                                else -> "Tap more chats to add them"
                            },
                            color = Dim, fontSize = 12.sp
                        )
                    }
                    Box(
                        Modifier.bounce(onClick = {
                            sel = if (sel.size == list.size && list.isNotEmpty()) emptySet() else list.map { it.threadId }.toSet()
                        }).clip(RoundedCornerShape(50)).background(Surf2).padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Text(
                            if (sel.size == list.size && list.isNotEmpty()) "None" else "Select all",
                            color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Row(
                        Modifier.bounce(onClick = { if (sel.isNotEmpty()) bulkConfirm = true })
                            .clip(RoundedCornerShape(50))
                            .background(if (sel.isEmpty()) Surf2 else A3)
                            .padding(horizontal = 14.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Delete, null, tint = if (sel.isEmpty()) Dim else Color.White, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Delete", color = if (sel.isEmpty()) Dim else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TicketBanner(n: Int, onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 22.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(A2.copy(alpha = 0.30f), A1.copy(alpha = 0.22f))))
            .bounce(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.ConfirmationNumber, null, tint = A2)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (n == 1) "1 ticket found in your messages" else "$n tickets found in your messages",
                color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
            Text("Save it with PNR, train and seat", color = Dim, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text("Save", color = A2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun DefaultBanner(onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 22.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(A1.copy(alpha = 0.35f), A3.copy(alpha = 0.3f)))).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Make Messages your default", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Needed to receive, save and delete SMS", color = Dim, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Box(Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(50)).background(Brand).padding(horizontal = 18.dp, vertical = 9.dp)) {
            Text("Set", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Fab(expanded: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier.bounce(onClick = onClick).shadow(20.dp, shape, ambientColor = A2, spotColor = A2)
            .clip(shape).background(Brand).padding(horizontal = 20.dp, vertical = 16.dp).animateContentSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Edit, null, tint = Color.White)
        AnimatedVisibility(expanded) { Text("  New chat", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    }
}

@Composable
fun Badge(n: Int) {
    val t = rememberInfiniteTransition(label = "badge")
    val s by t.animateFloat(1f, 1.15f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bs")
    Box(
        Modifier.graphicsLayer { scaleX = s; scaleY = s }.defaultMinSize(24.dp, 24.dp).clip(CircleShape)
            .background(Brand).padding(horizontal = 7.dp),
        contentAlignment = Alignment.Center
    ) { Text(if (n > 99) "99+" else "$n", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

private fun shimmerBrush(p: Float, base: Color): Brush = Brush.linearGradient(
    colors = listOf(base, base.copy(alpha = 0.35f), base),
    start = Offset(-320f + 1000f * p, 0f),
    end = Offset(120f + 1000f * p, 320f)
)

@Composable
fun SkeletonRow() {
    val t = rememberInfiniteTransition(label = "sk")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart), label = "sp")
    Row(
        Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(54.dp).clip(CircleShape).background(Surf2))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Box(Modifier.fillMaxWidth(0.42f).height(13.dp).clip(RoundedCornerShape(7.dp)).background(shimmerBrush(p, Surf2)))
            Spacer(Modifier.height(9.dp))
            Box(Modifier.fillMaxWidth(0.72f).height(11.dp).clip(RoundedCornerShape(7.dp)).background(shimmerBrush(p, Surf2)))
        }
        Spacer(Modifier.width(10.dp))
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(shimmerBrush(p, Surf2)))
    }
}

@Composable
fun ConvoRow(
    c: Convo, pinned: Boolean, onClick: () -> Unit, onLong: () -> Unit,
    selMode: Boolean = false, selected: Boolean = false
) {
    val unread = c.unread > 0
    Row(
        Modifier.fillMaxWidth().bounce(onClick = onClick, onLong = onLong)
            .padding(horizontal = 12.dp, vertical = 3.dp).clip(RoundedCornerShape(24.dp))
            .background(
                when {
                    selected -> A2.copy(alpha = 0.16f)
                    unread -> Surf2
                    else -> Color.Transparent
                }
            ).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AnimatedVisibility(
            selMode,
            enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + expandHorizontally(),
            exit = scaleOut() + shrinkHorizontally()
        ) { SelDot(selected) }
        SenderAvatar(c.address, c.name, if (ElderMode) 60.dp else 54.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c.name, color = Ink, fontSize = 17.sp, fontWeight = if (unread) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (pinned) { Spacer(Modifier.width(6.dp)); Icon(Icons.Rounded.PushPin, null, tint = A2, modifier = Modifier.size(15.dp)) }
            }
            Text((if (c.outgoing) "You: " else "") + c.snippet, color = if (unread) Ink else Dim, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            val scam = remember(c.snippet) { if (!c.outgoing) Scam.check(c.snippet, c.address) else null }
            if (scam != null && scam.warn) Text("\u26A0 Possible scam", color = if (scam.risky) Color(0xFFFF3B30) else Color(0xFFFFB020), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (c.code != null && System.currentTimeMillis() - c.date < 3_600_000) {
                Spacer(Modifier.height(6.dp))
                OtpPill(c.code)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(fmt(c.date), color = if (unread) A2 else Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (unread) { Spacer(Modifier.height(6.dp)); Badge(c.unread) }
        }
    }
}
