package com.messages.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Reply
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MenuTarget(val m: ScMsg, val rect: Rect)

private class MAct(val key: String, val label: String, val icon: ImageVector, val danger: Boolean = false)

private val LANGS = listOf("en", "hi", "bn", "ta", "te", "kn", "ml", "gu", "mr", "pa", "ur")

private fun quoteOf(m: ScMsg, name: String): String {
    val what = when (m.kind) {
        "text" -> m.body
        "image" -> "Photo"
        "video" -> "Video"
        "voice" -> "Voice message"
        else -> m.fname
    }
    return ((if (m.out) "You" else name) + ": " + what).take(110)
}

private fun fmtDur(ms: Long): String {
    val s = (ms / 1000).toInt()
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

private fun xferText(m: ScMsg, pct: Int?): String = when {
    pct != null -> (if (m.out) "Sending " else "Downloading ") + pct + "%"
    m.state == 9 -> "Failed. Tap to retry"
    m.out -> "Waiting to send…"
    m.state == 1 -> "Downloading…"
    else -> "Tap to download"
}

private fun ticksOf(state: Int): String = when (state) {
    0 -> "\u2026"
    1 -> "\u2713"
    2 -> "\u2713\u2713"
    3 -> "\u2713\u2713 seen"
    else -> "failed"
}

/** Blocks screenshots and screen recording while something private is on screen. */
@Composable
private fun SecureWindow(active: Boolean) {
    val ctx = LocalContext.current
    DisposableEffect(active) {
        val w = ctx.findActivity()?.window
        if (active) w?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { if (active) w?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE) }
    }
}

// =============================================================================================
// the chat
// =============================================================================================
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SecureChatScreen(cid: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val keyboard = LocalSoftwareKeyboardController.current
    val t by SecureCore.tick.collectAsState()
    val prog by SecureCore.progress.collectAsState()
    val store = remember { SecureDb.get(ctx) }
    val contact = remember(t) { store.contact(cid) }
    val msgs = remember(t) { store.msgs(cid) }
    val cname = (contact?.name ?: "").ifEmpty { "Contact" }

    var text by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<ScMsg?>(null) }
    var lastReply by remember { mutableStateOf<ScMsg?>(null) }
    if (replyTo != null) lastReply = replyTo
    var showEmoji by remember { mutableStateOf(false) }
    var showOpts by remember { mutableStateOf(false) }
    var onceOn by remember { mutableStateOf(false) }
    var whisperOn by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf<MenuTarget?>(null) }
    var timerDlg by remember { mutableStateOf(false) }
    var burnDlg by remember { mutableStateOf(false) }
    var codeDlg by remember { mutableStateOf(false) }
    var renameDlg by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<String?>(null) }
    var viewerOnce by remember { mutableStateOf(-1L) }
    var onceText by remember { mutableStateOf<ScMsg?>(null) }
    val dying = remember { mutableStateMapOf<Long, Boolean>() }
    val translated = remember { mutableStateMapOf<Long, String>() }
    var rootPos by remember { mutableStateOf(Offset.Zero) }
    var rootSize by remember { mutableStateOf(IntSize.Zero) }

    // voice recording
    var recording by remember { mutableStateOf(false) }
    var recMs by remember { mutableStateOf(0L) }
    var slide by remember { mutableFloatStateOf(0f) }
    var levels by remember { mutableStateOf(listOf<Float>()) }

    val seen = remember(cid) { HashSet<Any>() }
    val state = rememberLazyListState()
    val silk = rememberSilkFling()

    DisposableEffect(cid) {
        SecureCore.openChat(ctx, cid)
        onDispose {
            SecureCore.closeChat()
            VoicePlay.stop()
            VoiceRec.cancel()
        }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty() && state.firstVisibleItemIndex <= 2) state.animateScrollToItem(0) }

    // the list leans a little in the direction you scroll, then springs back
    var velTarget by remember { mutableFloatStateOf(0f) }
    val vel by animateFloatAsState(velTarget, spring(dampingRatio = 0.55f, stiffness = 200f), label = "vel")
    LaunchedEffect(state) {
        var last = 0
        snapshotFlow { state.firstVisibleItemIndex * 4000 + state.firstVisibleItemScrollOffset }.collectLatest { cur ->
            velTarget = (cur - last).toFloat().coerceIn(-90f, 90f)
            last = cur
            delay(70)
            velTarget = 0f
        }
    }

    // ---- launchers
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            SecureCore.sendFile(ctx, cid, uri, if (onceOn) 1 else 0)
            onceOn = false
        }
    }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val list = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!list.isNullOrEmpty()) text = (text + " " + list[0]).trim()
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) Toast.makeText(ctx, "Allow the microphone to send voice messages", Toast.LENGTH_SHORT).show()
    }

    fun dictate() {
        try {
            speech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your message")
            )
        } catch (_: Exception) {
            Toast.makeText(ctx, "Voice typing isn't available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendNow() {
        if (text.isBlank()) return
        val fl = (if (onceOn) 1 else 0) or (if (whisperOn) 2 else 0)
        SecureCore.sendText(ctx, cid, text, replyTo?.let { quoteOf(it, cname) } ?: "", fl)
        text = ""
        replyTo = null
        onceOn = false
        whisperOn = false
    }

    fun removeWithStyle(m: ScMsg, everyone: Boolean) {
        dying[m.row] = true
        scope.launch {
            delay(560)
            if (everyone) SecureCore.unsend(ctx, m.row) else SecureCore.deleteForMe(ctx, m.row)
            delay(200)
            dying.remove(m.row)
        }
    }

    fun translate(m: ScMsg, code: String) {
        Toast.makeText(ctx, "Translating to " + Translate.name(code) + "…", Toast.LENGTH_SHORT).show()
        Translate.run(m.body, code) { r ->
            if (r != null) translated[m.row] = r
            else Toast.makeText(ctx, "Couldn't translate. Check your internet for the first use.", Toast.LENGTH_LONG).show()
        }
    }

    fun act(key: String, m: ScMsg) {
        when (key) {
            "reply" -> replyTo = m
            "copy" -> ctx.copyText(m.body)
            "listen" -> Voice.speak(ctx, m.body)
            "star" -> SecureCore.toggleStar(ctx, m.row)
            "info" -> Toast.makeText(
                ctx,
                (if (m.out) "Sent " else "Received ") + SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(m.ts)) +
                    (if (m.out) " \u00B7 " + ticksOf(m.state) else ""), Toast.LENGTH_LONG
            ).show()
            "delete" -> removeWithStyle(m, false)
            "unsend" -> removeWithStyle(m, true)
        }
    }

    fun onTapMsg(m: ScMsg) {
        val ready = m.path.isNotEmpty() && (m.out || m.state == 2)
        val once = (m.flags and 1) != 0 && !m.out
        when {
            m.kind == "text" && once -> onceText = m
            m.kind == "image" && ready -> {
                viewer = m.path
                viewerOnce = if (once) m.row else -1L
            }
            (m.kind == "video" || m.kind == "file") && ready -> scOpen(ctx, m.path, m.mime)
            m.kind != "text" && !ready && (m.state == 9 || (!m.out && m.state == 0)) -> SecureCore.retry(ctx, m.row)
            m.state == 9 && m.out -> SecureCore.retry(ctx, m.row)
        }
    }

    Box(
        Modifier.fillMaxSize().onGloballyPositioned { rootPos = it.positionInWindow(); rootSize = it.size }
    ) {
        Page(
            cname, onBack,
            actions = {
                IconBtn(Icons.Rounded.Edit) { renameDlg = true }
                IconBtn(Icons.Rounded.Shield) { codeDlg = true }
                IconBtn(Icons.Rounded.Timer, if ((contact?.ttl ?: 0) > 0) A2 else Ink) { timerDlg = true }
                IconBtn(Icons.Rounded.Delete, A3) { burnDlg = true }
            }
        ) {
            val rev = remember(msgs) { msgs.asReversed() }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = state, reverseLayout = true, flingBehavior = silk,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(rev, key = { _, m -> m.row }) { _, m ->
                    val dir = if (m.out) 1f else -1f
                    val d by animateFloatAsState(if (dying[m.row] == true) 1f else 0f, tween(560, easing = FastOutLinearInEasing), label = "die")
                    Box(
                        Modifier.fillMaxWidth().animateItemPlacement().edgeFx(state, m.row).entrance(
                            seen, m.row, play = System.currentTimeMillis() - m.ts < 3000L, dir = dir
                        ).graphicsLayer {
                            translationX = vel * 0.5f * dir
                            rotationZ = vel * 0.05f * dir
                        },
                        contentAlignment = if (m.out) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Box {
                            Box(
                                Modifier.graphicsLayer {
                                    alpha = (1f - d * 1.7f).coerceIn(0f, 1f)
                                    translationX = dir * d * 70.dp.toPx()
                                    rotationZ = dir * d * 7f
                                    val s = 1f - 0.18f * d
                                    scaleX = s
                                    scaleY = s
                                }
                            ) {
                                Bubble(
                                    m, cname, prog[m.row], translated[m.row], false,
                                    onTap = { onTapMsg(m) },
                                    onLong = { r -> menu = MenuTarget(m, r.translate(-rootPos.x, -rootPos.y)) }
                                )
                            }
                            if (d > 0.01f) Dissolve(d, if (m.out) A1 else Surf, Modifier.matchParentSize())
                        }
                    }
                }
            }

            // ---------------- composer
            Column(Modifier.fillMaxWidth().imePadding()) {
                AnimatedVisibility(
                    replyTo != null,
                    enter = expandVertically(spring(0.8f, 420f)) + fadeIn(), exit = shrinkVertically() + fadeOut()
                ) {
                    val r = lastReply
                    if (r != null) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                                .background(Surf).height(IntrinsicSize.Min),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.width(4.dp).fillMaxHeight().background(A2))
                            Column(Modifier.weight(1f).padding(10.dp)) {
                                Text("Replying to " + (if (r.out) "yourself" else cname), color = A2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(quoteOf(r, cname).substringAfter(": "), color = Dim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Icon(
                                Icons.Rounded.Close, null, tint = Dim,
                                modifier = Modifier.bounce(onClick = { replyTo = null }).padding(10.dp).size(22.dp)
                            )
                        }
                    }
                }
                AnimatedVisibility(showOpts, enter = expandVertically(spring(0.8f, 420f)) + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Chip("Photo or file", false) { picker.launch(arrayOf("*/*")); showOpts = false }
                        Chip("View once", onceOn) { onceOn = !onceOn }
                        Chip("Whisper", whisperOn) { whisperOn = !whisperOn }
                        Chip("Voice typing", false) { dictate() }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    if (recording) {
                        RecordingStrip(recMs, levels, slide, Modifier.weight(1f).padding(end = 8.dp, start = 4.dp))
                    } else {
                        val plus by animateFloatAsState(if (showOpts) 45f else 0f, spring(0.6f, 400f), label = "plus")
                        Box(Modifier.graphicsLayer { rotationZ = plus }) {
                            IconBtn(Icons.Rounded.Add, if (onceOn || whisperOn) A2 else Ink) { showOpts = !showOpts }
                        }
                        IconBtn(Icons.Rounded.EmojiEmotions, if (showEmoji) A2 else Ink) {
                            showEmoji = !showEmoji
                            if (showEmoji) keyboard?.hide()
                        }
                        Box(Modifier.weight(1f)) {
                            InputField(
                                text, { text = it },
                                if (whisperOn) "Whisper message" else if (onceOn) "View-once message" else "Message", single = false
                            )
                        }
                    }
                    if (text.isNotBlank() && !recording) {
                        IconBtn(Icons.Rounded.Send, A2) { sendNow() }
                    } else {
                        MicButton(
                            recording, slide,
                            onStart = {
                                if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                    micPerm.launch(Manifest.permission.RECORD_AUDIO)
                                    false
                                } else if (VoiceRec.start(ctx)) {
                                    VoicePlay.stop()
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    levels = emptyList()
                                    recMs = 0L
                                    slide = 0f
                                    recording = true
                                    true
                                } else false
                            },
                            onMove = { slide = it },
                            onEnd = { cancelled ->
                                recording = false
                                slide = 0f
                                if (cancelled) VoiceRec.cancel()
                                else {
                                    val n = VoiceRec.stop()
                                    if (n != null) SecureCore.sendVoice(ctx, cid, n.file, n.durMs, n.wf)
                                    else Toast.makeText(ctx, "Hold the mic and speak", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                }
                AnimatedVisibility(showEmoji, enter = expandVertically(spring(0.85f, 380f)) + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                    ScEmojiPanel { e -> text += e }
                }
            }
        }

        // recording tick: loudness, timer, hard stop at three minutes
        LaunchedEffect(recording) {
            while (recording) {
                levels = (levels + VoiceRec.level()).takeLast(34)
                recMs = VoiceRec.elapsed()
                if (recMs > 180_000L) {
                    recording = false
                    val n = VoiceRec.stop()
                    if (n != null) SecureCore.sendVoice(ctx, cid, n.file, n.durMs, n.wf)
                }
                delay(50)
            }
        }

        // jump to the newest message
        val away by remember { androidx.compose.runtime.derivedStateOf { state.firstVisibleItemIndex > 4 } }
        AnimatedVisibility(
            away, enter = scaleIn(spring(0.6f, 400f)) + fadeIn(), exit = scaleOut() + fadeOut(),
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 96.dp)
        ) {
            Box(
                Modifier.size(44.dp).shadow(10.dp, CircleShape).clip(CircleShape).background(Surf2)
                    .bounce(onClick = { scope.launch { state.animateScrollToItem(0) } }),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.ArrowDownward, null, tint = A2, modifier = Modifier.size(22.dp)) }
        }

        // ---------------- touch and hold menu
        menu?.let { tg ->
            MessageMenu(
                tg, cname, rootSize.width.toFloat(), rootSize.height.toFloat(),
                onDismiss = { menu = null },
                onReact = { e -> SecureCore.react(ctx, tg.m.row, e) },
                onAction = { k -> act(k, tg.m) },
                onTranslate = { code -> translate(tg.m, code) }
            )
        }

        // ---------------- full screen viewers
        SecureWindow(viewer != null && viewerOnce >= 0L)
        viewer?.let { p ->
            ImageOverlay(p) {
                viewer = null
                if (viewerOnce >= 0L) {
                    SecureCore.deleteForMe(ctx, viewerOnce)
                    viewerOnce = -1L
                }
            }
        }
        onceText?.let { m -> OnceReader(m.body) { onceText = null; SecureCore.deleteForMe(ctx, m.row) } }
    }

    // ---------------- dialogs
    if (renameDlg) {
        var nm by remember { mutableStateOf(cname) }
        AlertDialog(
            onDismissRequest = { renameDlg = false }, containerColor = Surf2,
            title = { Text("Rename contact", color = Ink) },
            text = { InputField(nm, { nm = it.take(30) }, "Name", single = true) },
            confirmButton = {
                TextButton(onClick = { SecureCore.renameContact(ctx, cid, nm); renameDlg = false }) {
                    Text("Save", color = A2, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { renameDlg = false }) { Text("Cancel", color = Dim) } }
        )
    }
    if (timerDlg) {
        val options = listOf("Off" to 0, "1 hour" to 3600, "1 day" to 86_400, "7 days" to 604_800)
        AlertDialog(
            onDismissRequest = { timerDlg = false }, containerColor = Surf2,
            title = { Text("Disappearing messages", color = Ink) },
            text = {
                Column {
                    Text("New messages, voice notes and files in this chat disappear from both phones after this time.", color = Dim, fontSize = 12.sp)
                    options.forEach { (label, secs) ->
                        val on = (contact?.ttl ?: 0) == secs
                        Text(
                            label, color = if (on) A2 else Ink, fontSize = 15.sp,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().bounce(onClick = { SecureCore.setTimer(ctx, cid, secs); timerDlg = false }).padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { timerDlg = false }) { Text("Close", color = Dim) } }
        )
    }
    if (burnDlg) {
        AlertDialog(
            onDismissRequest = { burnDlg = false }, containerColor = Surf2,
            title = { Text("Burn this chat?", color = Ink) },
            text = { Text("Every message, voice note and file in this chat is erased from this phone and from theirs. This can't be undone.", color = Dim, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { SecureCore.burn(ctx, cid); burnDlg = false }) { Text("Burn", color = A3, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { burnDlg = false }) { Text("Cancel", color = Dim) } }
        )
    }
    if (codeDlg && contact != null) {
        AlertDialog(
            onDismissRequest = { codeDlg = false }, containerColor = Surf2,
            title = { Text("Safety code", color = Ink) },
            text = {
                Column {
                    Text(SecureCore.safetyCode(ctx, contact), color = A2, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Read this out on a call. If both phones show the same numbers, nobody is listening in between.", color = Dim, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { codeDlg = false }) { Text("Done", color = A2, fontWeight = FontWeight.Bold) } }
        )
    }
}

// =============================================================================================
// one-time text reader
// =============================================================================================
@Composable
private fun OnceReader(body: String, onClose: () -> Unit) {
    val left = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        left.animateTo(0f, tween(9000))
        onClose()
    }
    SecureWindow(true)
    BackHandler { onClose() }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.88f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(28.dp).clip(RoundedCornerShape(26.dp)).background(Surf2).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Rounded.Visibility, null, tint = A2, modifier = Modifier.size(26.dp))
            Spacer(Modifier.height(10.dp))
            Text(body, color = Ink, fontSize = 18.sp)
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Ink.copy(alpha = 0.12f))) {
                Box(Modifier.fillMaxWidth(left.value).fillMaxHeight().background(A2))
            }
            Spacer(Modifier.height(8.dp))
            Text("This message disappears when you close it", color = Dim, fontSize = 12.sp)
        }
    }
}

// =============================================================================================
// delete: the bubble turns to dust
// =============================================================================================
@Composable
private fun Dissolve(p: Float, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val cols = 12
        val rows = 5
        val cw = size.width / cols
        val ch = size.height / rows
        for (ix in 0 until cols) {
            for (iy in 0 until rows) {
                val delayF = (ix.toFloat() / cols) * 0.45f
                val q = ((p - delayF) / 0.55f).coerceIn(0f, 1f)
                if (q >= 1f) continue
                val h1 = ((ix * 31 + iy * 17) % 7) / 7f
                val h2 = ((ix * 13 + iy * 29) % 5) / 5f
                val dx = q * (30f + 110f * h1).dp.toPx()
                val dy = -q * (10f + 100f * h2).dp.toPx() + q * q * 40.dp.toPx()
                val k = 1f - 0.55f * q
                drawRect(
                    color.copy(alpha = (1f - q) * 0.92f), topLeft = Offset(ix * cw + dx, iy * ch + dy),
                    size = Size(cw * k, ch * k)
                )
            }
        }
    }
}

// =============================================================================================
// one message
// =============================================================================================
@Composable
private fun Bubble(
    m: ScMsg, cname: String, pct: Int?, translation: String?, preview: Boolean,
    onTap: () -> Unit, onLong: (Rect) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val tapNow by rememberUpdatedState(onTap)
    val longNow by rememberUpdatedState(onLong)
    var coords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(if (pressed && !preview) 0.955f else 1f, spring(dampingRatio = 0.45f, stiffness = 520f), label = "press")
    val out = m.out
    val once = (m.flags and 1) != 0
    val whisper = (m.flags and 2) != 0 && !out
    val starred = (m.flags and 4) != 0
    val ready = m.path.isNotEmpty() && (out || m.state == 2)
    val fg = if (out) Color.White else Ink
    val jumbo = m.kind == "text" && !once && !whisper && m.reply.isEmpty() && EmojiData.isJumbo(m.body)
    val shape = RoundedCornerShape(20.dp, 20.dp, if (out) 5.dp else 20.dp, if (out) 20.dp else 5.dp)
    val fill = if (out) Brush.verticalGradient(listOf(A1, A1.copy(alpha = 0.88f))) else Brush.verticalGradient(listOf(Surf, Surf))

    Column(
        Modifier
            .onGloballyPositioned { coords = it }
            .graphicsLayer { scaleX = press; scaleY = press }
            .widthIn(max = 290.dp)
            .then(if (jumbo) Modifier else Modifier.clip(shape).background(fill))
            .pointerInput(preview) {
                if (!preview) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = { tapNow() },
                        onLongPress = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            coords?.let { longNow(it.boundsInWindow()) }
                        }
                    )
                }
            }
            .padding(if (jumbo) 2.dp else if (m.kind == "image" && ready && !(once && !out)) 4.dp else 12.dp)
    ) {
        if (m.reply.isNotEmpty()) {
            Row(
                Modifier.padding(bottom = 6.dp).clip(RoundedCornerShape(10.dp)).background(fg.copy(alpha = 0.13f)).height(IntrinsicSize.Min)
            ) {
                Box(Modifier.width(3.dp).fillMaxHeight().background(if (out) Color.White else A2))
                Text(m.reply, color = fg.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(8.dp))
            }
        }
        when (m.kind) {
            "text" -> when {
                once && !out -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Visibility, null, tint = A2, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Tap to read once", color = fg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
                whisper -> {
                    val show = pressed && !preview
                    Crossfade(show, label = "whisper") { s ->
                        if (s) Text(m.body, color = fg, fontSize = 15.sp)
                        else Column {
                            Text("\u2022".repeat(m.body.length.coerceIn(4, 28)), color = fg, fontSize = 15.sp, letterSpacing = 3.sp)
                            Text("Hold to read", color = fg.copy(alpha = 0.6f), fontSize = 11.sp)
                        }
                    }
                }
                jumbo -> Text(m.body, fontSize = 46.sp)
                else -> Text(m.body, color = fg, fontSize = 15.sp)
            }
            "image" -> {
                if (once && !out) {
                    Box(Modifier.size(width = 190.dp, height = 110.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.Visibility, null, tint = A2, modifier = Modifier.size(28.dp))
                            Text(if (ready) "Photo \u00B7 tap to view once" else xferText(m, pct), color = fg, fontSize = 13.sp)
                        }
                    }
                } else {
                    val bmp by produceState<ImageBitmap?>(null, m.path, ready) {
                        value = if (ready) withContext(Dispatchers.IO) { Thumbs.get(m.path, 700) } else null
                    }
                    val b = bmp
                    if (b != null) {
                        Image(
                            b, null, contentScale = ContentScale.Crop,
                            modifier = Modifier.widthIn(max = 260.dp).height(200.dp).clip(RoundedCornerShape(15.dp))
                        )
                    } else {
                        Box(Modifier.size(width = 200.dp, height = 120.dp), contentAlignment = Alignment.Center) {
                            Text(xferText(m, pct), color = fg, fontSize = 13.sp)
                        }
                    }
                }
            }
            "voice" -> VoiceRow(m, fg, ready, pct)
            else -> Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (m.kind == "video") Icons.Rounded.PlayArrow else fileIcon(m.mime), null, tint = fg, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(m.fname, color = fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (ready) scSize(m.size) + (if (m.kind == "video") " \u00B7 tap to play" else "") else xferText(m, pct),
                        color = fg.copy(alpha = 0.75f), fontSize = 12.sp
                    )
                }
            }
        }
        if (translation != null) {
            Box(Modifier.padding(vertical = 6.dp).fillMaxWidth().height(1.dp).background(fg.copy(alpha = 0.2f)))
            Text(translation, color = fg.copy(alpha = 0.92f), fontSize = 14.sp)
        }
        Row(
            Modifier.align(Alignment.End).padding(top = 3.dp, end = if (m.kind == "image" && ready) 6.dp else 0.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (once) {
                Icon(Icons.Rounded.Visibility, null, tint = fg.copy(alpha = 0.7f), modifier = Modifier.size(11.dp))
                Spacer(Modifier.width(3.dp))
            }
            if (m.exp > 0L) {
                Icon(Icons.Rounded.Timer, null, tint = fg.copy(alpha = 0.7f), modifier = Modifier.size(11.dp))
                Spacer(Modifier.width(3.dp))
            }
            if (starred) {
                Icon(Icons.Rounded.Star, null, tint = Gold, modifier = Modifier.size(12.dp))
                Spacer(Modifier.width(3.dp))
            }
            Text(
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.ts)) + if (out) "  " + ticksOf(m.state) else "",
                color = if (jumbo) Dim else fg.copy(alpha = 0.7f), fontSize = 10.sp
            )
        }
        if (m.mine.isNotEmpty() || m.theirs.isNotEmpty()) {
            Row(Modifier.padding(top = 4.dp)) {
                if (m.mine.isNotEmpty()) ReactChip(m.mine, true)
                if (m.theirs.isNotEmpty()) ReactChip(m.theirs, false)
            }
        }
    }
}

@Composable
private fun ReactChip(e: String, mine: Boolean) {
    val s = remember(e) { Animatable(0f) }
    LaunchedEffect(e) { s.animateTo(1f, spring(0.36f, 420f)) }
    Box(
        Modifier.padding(end = 4.dp).graphicsLayer { scaleX = s.value; scaleY = s.value }.clip(CircleShape)
            .background(if (mine) A2.copy(alpha = 0.4f) else Color.Black.copy(alpha = 0.28f)).padding(horizontal = 8.dp, vertical = 2.dp)
    ) { Text(e, fontSize = 14.sp) }
}

@Composable
private fun VoiceRow(m: ScMsg, fg: Color, ready: Boolean, pct: Int?) {
    val playing by VoicePlay.playingRow.collectAsState()
    val prog by VoicePlay.progress.collectAsState()
    val speed by VoicePlay.speed.collectAsState()
    val parts = remember(m.body) { m.body.split("|") }
    val dur = parts.getOrNull(0)?.toLongOrNull() ?: 0L
    val bars = remember(m.body) { VoiceRec.bars(parts.getOrNull(1) ?: "") }
    val on = playing == m.row
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(fg.copy(alpha = 0.2f))
                .bounce(onClick = { if (ready) VoicePlay.toggle(m.path, m.row) }),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (on) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = fg, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Canvas(Modifier.width(150.dp).height(30.dp)) {
                val n = bars.size
                val bw = size.width / n
                for (i in 0 until n) {
                    val h = bars[i].coerceIn(0.1f, 1f) * size.height
                    val played = on && i.toFloat() / n < prog
                    drawRoundRect(
                        fg.copy(alpha = if (played) 1f else 0.42f),
                        topLeft = Offset(i * bw + bw * 0.18f, (size.height - h) / 2f),
                        size = Size(bw * 0.64f, h), cornerRadius = CornerRadius(bw * 0.3f)
                    )
                }
            }
            Text(
                if (!ready) xferText(m, pct) else fmtDur(if (on) (dur * prog).toLong() else dur),
                color = fg.copy(alpha = 0.7f), fontSize = 11.sp
            )
        }
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.clip(CircleShape).background(fg.copy(alpha = 0.18f)).bounce(onClick = { VoicePlay.cycleSpeed() })
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(if (speed == 1f) "1x" else if (speed == 1.5f) "1.5x" else "2x", color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// =============================================================================================
// voice recording controls
// =============================================================================================
@Composable
private fun RecordingStrip(ms: Long, levels: List<Float>, slide: Float, modifier: Modifier) {
    val blink by rememberInfiniteTransition(label = "rec").animateFloat(
        1f, 0.2f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "blink"
    )
    val cancelling = slide < -110f
    Row(
        modifier.clip(RoundedCornerShape(28.dp)).background(Surf).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFFF4B4B).copy(alpha = blink)))
        Spacer(Modifier.width(8.dp))
        Text(fmtDur(ms), color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        Canvas(Modifier.weight(1f).height(26.dp)) {
            val n = 34
            val bw = size.width / n
            val pad = n - levels.size
            for (i in 0 until n) {
                val lv = if (i < pad) 0.05f else levels[i - pad]
                val h = (0.12f + 0.88f * lv) * size.height
                drawRoundRect(
                    (if (cancelling) A3 else A2).copy(alpha = 0.9f),
                    topLeft = Offset(i * bw + bw * 0.2f, (size.height - h) / 2f), size = Size(bw * 0.6f, h),
                    cornerRadius = CornerRadius(bw * 0.3f)
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(
            if (cancelling) "Release to cancel" else "\u2039 Slide to cancel",
            color = if (cancelling) A3 else Dim, fontSize = 12.sp,
            modifier = Modifier.graphicsLayer {
                translationX = slide.coerceAtMost(0f) * 0.35f
                alpha = 1f - (-slide / 320f).coerceIn(0f, 0.75f)
            }
        )
    }
}

@Composable
private fun MicButton(
    recording: Boolean, slide: Float, onStart: () -> Boolean, onMove: (Float) -> Unit, onEnd: (Boolean) -> Unit
) {
    val startNow by rememberUpdatedState(onStart)
    val moveNow by rememberUpdatedState(onMove)
    val endNow by rememberUpdatedState(onEnd)
    val scale by animateFloatAsState(if (recording) 1.55f else 1f, spring(0.5f, 380f), label = "mic")
    val ring by rememberInfiniteTransition(label = "micring").animateFloat(
        1f, 1.9f, infiniteRepeatable(tween(900), RepeatMode.Restart), label = "ring"
    )
    Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
        if (recording) {
            Box(
                Modifier.size(44.dp).graphicsLayer {
                    scaleX = ring
                    scaleY = ring
                    alpha = (1.9f - ring).coerceIn(0f, 0.6f)
                    translationX = slide.coerceAtMost(0f) * 0.5f
                }.clip(CircleShape).background(A2)
            )
        }
        Box(
            Modifier.size(44.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = slide.coerceAtMost(0f) * 0.5f
                }
                .clip(CircleShape).background(if (slide < -110f) A3 else A2)
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        if (!startNow()) {
                            waitForUpOrCancellation()
                            return@awaitEachGesture
                        }
                        val limit = 110.dp.toPx()
                        var dx = 0f
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull() ?: break
                            dx = ch.position.x - down.position.x
                            moveNow(dx)
                            ch.consume()
                            if (!ch.pressed) break
                        }
                        endNow(dx < -limit)
                    }
                },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Mic, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
    }
}

// =============================================================================================
// touch and hold: the message lifts, reactions pop, actions slide up
// =============================================================================================
@Composable
private fun Stagger(i: Int, content: @Composable () -> Unit) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(70L + i * 40L)
        p.animateTo(1f, spring(0.7f, 360f))
    }
    Box(
        Modifier.graphicsLayer {
            alpha = p.value.coerceIn(0f, 1f)
            translationY = (1f - p.value) * 26.dp.toPx()
        }
    ) { content() }
}

@Composable
private fun MessageMenu(
    target: MenuTarget, cname: String, boxW: Float, boxH: Float,
    onDismiss: () -> Unit, onReact: (String) -> Unit, onAction: (String) -> Unit, onTranslate: (String) -> Unit
) {
    val m = target.m
    val r = target.rect
    val dens = LocalDensity.current
    val scope = rememberCoroutineScope()
    val enter = remember { Animatable(0f) }
    var closing by remember { mutableStateOf(false) }
    var pickLang by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { enter.animateTo(1f, spring(dampingRatio = 0.74f, stiffness = 280f)) }

    fun close(after: () -> Unit = {}) {
        if (closing) return
        closing = true
        scope.launch {
            enter.animateTo(0f, tween(190))
            onDismiss()
            after()
        }
    }
    BackHandler { close() }

    val starred = (m.flags and 4) != 0
    val acts = remember(m.row, starred) {
        val l = ArrayList<MAct>()
        l.add(MAct("reply", "Reply", Icons.Rounded.Reply))
        if (m.kind == "text") {
            l.add(MAct("copy", "Copy", Icons.Rounded.ContentCopy))
            l.add(MAct("translate", "Translate", Icons.Rounded.Translate))
            l.add(MAct("listen", "Listen", Icons.Rounded.VolumeUp))
        }
        l.add(MAct("star", if (starred) "Remove star" else "Star", if (starred) Icons.Rounded.StarBorder else Icons.Rounded.Star))
        l.add(MAct("info", "Info", Icons.Rounded.Info))
        l.add(MAct("delete", "Delete for me", Icons.Rounded.Delete, true))
        if (m.out) l.add(MAct("unsend", "Unsend for everyone", Icons.Rounded.DeleteForever, true))
        l
    }

    val reactH = with(dens) { 56.dp.toPx() }
    val gap = with(dens) { 12.dp.toPx() }
    val rowH = with(dens) { 46.dp.toPx() }
    val rows = if (pickLang) (LANGS.size + 2) / 3 else acts.size
    val actH = rowH * rows + with(dens) { 16.dp.toPx() }
    val minTop = reactH + gap + with(dens) { 76.dp.toPx() }
    val maxBottom = boxH - with(dens) { 18.dp.toPx() }
    var top = r.top
    if (top < minTop) top = minTop
    if (top + r.height + gap + actH > maxBottom) top = (maxBottom - actH - gap - r.height).coerceAtLeast(minTop)
    val menuW = with(dens) { 244.dp.toPx() }
    val barW = with(dens) { 332.dp.toPx() }
    val margin = with(dens) { 12.dp.toPx() }
    fun xFor(width: Float): Float {
        val x = if (m.out) r.right - width else r.left
        return x.coerceIn(margin, (boxW - width - margin).coerceAtLeast(margin))
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.66f * enter.value))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { close() }
    ) {
        // the lifted message, floating just where it was
        val shownTop = lerp(r.top, top, enter.value)
        Box(
            Modifier
                .offset { IntOffset(r.left.roundToInt(), shownTop.roundToInt()) }
                .width(with(dens) { r.width.toDp() })
                .graphicsLayer {
                    val s = 1f + 0.05f * enter.value
                    scaleX = s
                    scaleY = s
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(if (m.out) 1f else 0f, 0.5f)
                }
        ) {
            Bubble(m, cname, null, null, true, onTap = { }, onLong = { })
        }

        // reaction bar
        Row(
            Modifier
                .offset { IntOffset(xFor(barW).roundToInt(), (shownTop - reactH - gap * 0.7f).roundToInt()) }
                .graphicsLayer {
                    scaleX = enter.value
                    scaleY = enter.value
                    alpha = enter.value.coerceIn(0f, 1f)
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(if (m.out) 1f else 0f, 1f)
                }
                .shadow(14.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp)).background(Surf2)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            EmojiData.quick.forEachIndexed { i, e ->
                val pop = remember { Animatable(0f) }
                LaunchedEffect(Unit) {
                    delay(90L + i * 38L)
                    pop.animateTo(1f, spring(0.38f, 420f))
                }
                val sel = chosen == e
                val big by animateFloatAsState(if (sel) 2.1f else 1f, spring(0.4f, 500f), label = "big")
                Box(
                    Modifier.size(44.dp).graphicsLayer {
                        scaleX = pop.value * big
                        scaleY = pop.value * big
                        translationY = if (sel) -18.dp.toPx() else 0f
                    }.bounce(onClick = {
                        if (chosen.isEmpty()) {
                            chosen = e
                            onReact(e)
                            scope.launch {
                                delay(330)
                                close()
                            }
                        }
                    }),
                    contentAlignment = Alignment.Center
                ) { Text(e, fontSize = 26.sp) }
            }
        }

        // actions, or the language list
        Column(
            Modifier
                .offset { IntOffset(xFor(menuW).roundToInt(), (shownTop + r.height + gap).roundToInt()) }
                .width(with(dens) { menuW.toDp() })
                .graphicsLayer {
                    alpha = enter.value.coerceIn(0f, 1f)
                    translationY = (1f - enter.value) * -30.dp.toPx()
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(if (m.out) 1f else 0f, 0f)
                    val s = 0.85f + 0.15f * enter.value
                    scaleX = s
                    scaleY = s
                }
                .shadow(16.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(Surf2)
                .padding(vertical = 8.dp)
        ) {
            if (pickLang) {
                LANGS.chunked(3).forEachIndexed { i, row ->
                    Stagger(i) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).height(46.dp), verticalAlignment = Alignment.CenterVertically) {
                            row.forEach { code ->
                                Box(
                                    Modifier.weight(1f).padding(horizontal = 3.dp).clip(CircleShape).background(A2.copy(alpha = 0.16f))
                                        .bounce(onClick = { onTranslate(code); close() }).padding(vertical = 9.dp),
                                    contentAlignment = Alignment.Center
                                ) { Text(Translate.name(code), color = Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
                            }
                        }
                    }
                }
            } else {
                acts.forEachIndexed { i, a ->
                    Stagger(i) {
                        Row(
                            Modifier.fillMaxWidth().height(46.dp).bounce(onClick = {
                                if (a.key == "translate") pickLang = true
                                else close { onAction(a.key) }
                            }).padding(horizontal = 18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(a.icon, null, tint = if (a.danger) A3 else A2, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(14.dp))
                            Text(a.label, color = if (a.danger) A3 else Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}
