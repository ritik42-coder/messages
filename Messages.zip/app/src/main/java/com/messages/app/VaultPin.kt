@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val PIN_LEN = 6

@Composable
fun PinDots(value: String, error: Boolean) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        repeat(PIN_LEN) { i ->
            val filled = i < value.length
            Box(
                Modifier.size(14.dp).clip(CircleShape)
                    .background(
                        when {
                            error -> A3
                            filled -> A2
                            else -> Dim.copy(alpha = 0.35f)
                        }
                    )
            )
        }
    }
}

@Composable
fun NumPad(onDigit: (Char) -> Unit, onBack: () -> Unit, onFinger: (() -> Unit)? = null) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        listOf("123", "456", "789").forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                row.forEach { ch ->
                    Box(
                        Modifier.size(70.dp).clip(CircleShape).background(Surf)
                            .bounce(onClick = { onDigit(ch) }),
                        contentAlignment = Alignment.Center
                    ) { Text(ch.toString(), color = Ink, fontSize = 24.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(
                Modifier.size(70.dp).clip(CircleShape)
                    .then(if (onFinger != null) Modifier.background(Surf2).bounce(onClick = onFinger) else Modifier),
                contentAlignment = Alignment.Center
            ) {
                if (onFinger != null) Icon(Icons.Rounded.Fingerprint, null, tint = A2, modifier = Modifier.size(26.dp))
            }
            Box(
                Modifier.size(70.dp).clip(CircleShape).background(Surf).bounce(onClick = { onDigit('0') }),
                contentAlignment = Alignment.Center
            ) { Text("0", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.SemiBold) }
            Box(
                Modifier.size(70.dp).clip(CircleShape).background(Surf).bounce(onClick = onBack),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.ArrowBack, null, tint = Dim, modifier = Modifier.size(22.dp)) }
        }
    }
}

// ---------------- unlock ----------------
@Composable
fun VaultPinGate(ctx: Context, onOpen: () -> Unit, onForgot: () -> Unit, onPhrase: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }

    fun submit(v: String) {
        if (VaultSecurity.checkPin(ctx, v)) onOpen()
        else {
            error = true
            note = "Wrong PIN"
            pin = ""
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(40.dp))
        Box(Modifier.size(74.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Lock, null, tint = A2, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("Enter your vault PIN", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            note ?: "Six digits. Your fingerprint works too.",
            color = if (note != null) A3 else Dim, fontSize = 13.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        PinDots(pin, error)
        Spacer(Modifier.height(28.dp))
        NumPad(
            onDigit = { ch ->
                if (pin.length < PIN_LEN) {
                    error = false
                    note = null
                    pin += ch
                    if (pin.length == PIN_LEN) submit(pin)
                }
            },
            onBack = { if (pin.isNotEmpty()) pin = pin.dropLast(1) },
            onFinger = {
                VaultSecurity.biometric(
                    ctx,
                    onOk = { onOpen() },
                    onFail = { msg -> note = msg }
                )
            }
        )
        Spacer(Modifier.weight(1f))
        Row {
            Text(
                "Forgot PIN?", color = A2, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.bounce(onClick = onForgot).padding(10.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                "Use recovery phrase", color = Dim, fontSize = 14.sp,
                modifier = Modifier.bounce(onClick = onPhrase).padding(10.dp)
            )
        }
    }
}

// ---------------- first setup ----------------
@Composable
fun VaultPinSetup(ctx: Context, onDone: () -> Unit, onBack: () -> Unit) {
    var step by remember { mutableStateOf(0) }
    var phone by remember { mutableStateOf(VaultSecurity.simNumber(ctx)) }
    var pin by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.ArrowBack) { if (step == 0) onBack() else step-- }
            Text("Vault security", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(3) { i ->
                Box(
                    Modifier.height(4.dp).width(if (i == step) 34.dp else 18.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (i <= step) A2 else Surf2)
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        AnimatedContent(
            targetState = step,
            transitionSpec = {
                (slideInHorizontally(tween(260)) { it / 3 } + fadeIn(tween(200))) togetherWith
                    (slideOutHorizontally(tween(220)) { -it / 3 } + fadeOut(tween(160)))
            },
            label = "pinsetup"
        ) { s ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                when (s) {
                    0 -> {
                        Text("Your phone number", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Used only to confirm it's you if you ever forget the PIN. It never leaves this phone.",
                            color = Dim, fontSize = 13.sp, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(20.dp))
                        InputField(phone, { phone = it }, "10-digit mobile number")
                        Spacer(Modifier.height(20.dp))
                        GradientButton("Continue") {
                            if (phone.filter { it.isDigit() }.length >= 10) {
                                VaultSecurity.setPhone(ctx, phone)
                                step = 1
                            } else error = "Enter a 10-digit number"
                        }
                    }
                    1 -> {
                        Text("Choose a 6-digit PIN", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Opens the vault when your fingerprint doesn't.", color = Dim, fontSize = 13.sp)
                        Spacer(Modifier.height(22.dp))
                        PinDots(pin, false)
                        Spacer(Modifier.height(26.dp))
                        NumPad(
                            onDigit = {
                                if (pin.length < PIN_LEN) {
                                    pin += it
                                    if (pin.length == PIN_LEN) { again = ""; step = 2 }
                                }
                            },
                            onBack = { if (pin.isNotEmpty()) pin = pin.dropLast(1) }
                        )
                    }
                    else -> {
                        Text("Type it once more", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("So we're sure it's the one you meant.", color = Dim, fontSize = 13.sp)
                        Spacer(Modifier.height(22.dp))
                        PinDots(again, error != null)
                        Spacer(Modifier.height(26.dp))
                        NumPad(
                            onDigit = {
                                if (again.length < PIN_LEN) {
                                    again += it
                                    if (again.length == PIN_LEN) {
                                        if (again == pin) {
                                            VaultSecurity.setPin(ctx, pin)
                                            onDone()
                                        } else {
                                            error = "They didn't match"
                                            again = ""
                                            pin = ""
                                            step = 1
                                        }
                                    }
                                }
                            },
                            onBack = { if (again.isNotEmpty()) again = again.dropLast(1) }
                        )
                    }
                }
            }
        }
        error?.let {
            Spacer(Modifier.height(14.dp))
            Text(it, color = A3, fontSize = 13.sp)
        }
    }
}

// ---------------- forgot PIN ----------------
@Composable
fun VaultForgot(ctx: Context, onDone: () -> Unit, onBack: () -> Unit) {
    var step by remember { mutableStateOf(0) }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.ArrowBack) { if (step == 0) onBack() else step-- }
            Text("Reset vault PIN", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(20.dp))
        AnimatedContent(
            targetState = step,
            transitionSpec = {
                (slideInHorizontally(tween(260)) { it / 3 } + fadeIn(tween(200))) togetherWith
                    (slideOutHorizontally(tween(220)) { -it / 3 } + fadeOut(tween(160)))
            },
            label = "forgot"
        ) { s ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                when (s) {
                    0 -> {
                        Text("Confirm your number", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Enter the number you saved. We'll show a one-time code as a notification — no internet, no server.",
                            color = Dim, fontSize = 13.sp, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(20.dp))
                        InputField(phone, { phone = it }, "10-digit mobile number")
                        Spacer(Modifier.height(18.dp))
                        GradientButton("Send code") {
                            if (VaultSecurity.phoneMatches(ctx, phone)) {
                                VaultSecurity.issueOtp(ctx)
                                note = "Code sent as a notification"
                                step = 1
                            } else error = "That number doesn't match the one saved"
                        }
                        if (VaultSecurity.phone(ctx).isNotEmpty()) {
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "Saved number ends with " + VaultSecurity.phone(ctx).takeLast(2),
                                color = Dim, fontSize = 11.sp
                            )
                        }
                    }
                    1 -> {
                        Text("Enter the 6-digit code", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            note ?: "Pull down your notifications to read it.",
                            color = A2, fontSize = 13.sp, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(20.dp))
                        PinDots(otp, error != null)
                        Spacer(Modifier.height(24.dp))
                        NumPad(
                            onDigit = {
                                if (otp.length < PIN_LEN) {
                                    otp += it
                                    if (otp.length == PIN_LEN) {
                                        if (VaultSecurity.checkOtp(ctx, otp)) {
                                            VaultSecurity.clearOtp(ctx)
                                            step = 2
                                        } else {
                                            error = "Wrong or expired code"
                                            otp = ""
                                        }
                                    }
                                }
                            },
                            onBack = { if (otp.isNotEmpty()) otp = otp.dropLast(1) }
                        )
                    }
                    2 -> {
                        Text("Set a new PIN", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Six digits you'll remember.", color = Dim, fontSize = 13.sp)
                        Spacer(Modifier.height(20.dp))
                        PinDots(pin, false)
                        Spacer(Modifier.height(24.dp))
                        NumPad(
                            onDigit = {
                                if (pin.length < PIN_LEN) {
                                    pin += it
                                    if (pin.length == PIN_LEN) { again = ""; step = 3 }
                                }
                            },
                            onBack = { if (pin.isNotEmpty()) pin = pin.dropLast(1) }
                        )
                    }
                    else -> {
                        Text("Confirm the new PIN", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(20.dp))
                        PinDots(again, error != null)
                        Spacer(Modifier.height(24.dp))
                        NumPad(
                            onDigit = {
                                if (again.length < PIN_LEN) {
                                    again += it
                                    if (again.length == PIN_LEN) {
                                        if (again == pin) {
                                            VaultSecurity.setPin(ctx, pin)
                                            onDone()
                                        } else {
                                            error = "They didn't match"
                                            again = ""
                                            pin = ""
                                            step = 2
                                        }
                                    }
                                }
                            },
                            onBack = { if (again.isNotEmpty()) again = again.dropLast(1) }
                        )
                    }
                }
            }
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = A3, fontSize = 13.sp)
        }
    }
}
