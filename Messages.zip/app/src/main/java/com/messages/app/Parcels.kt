@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class Parcel(val courier: String, val awb: String, val status: String, val body: String, val at: Long)
class Ride(val brand: String, val vehicle: String, val otp: String, val body: String, val at: Long)

object Parcels {
    private val couriers = listOf(
        "AMAZON", "FLIPKART", "DELHIVERY", "EKART", "BLUEDART", "BLUE DART", "DTDC",
        "INDIA POST", "SHADOWFAX", "XPRESSBEES", "ECOM", "SHIPROCKET", "MYNTRA", "AJIO",
        "MEESHO", "NYKAA", "SNAPDEAL", "BIGBASKET", "ZEPTO", "BLINKIT"
    )
    private val statusWords = listOf(
        "out for delivery", "delivered", "shipped", "dispatched", "in transit",
        "arriving", "packed", "picked up", "reached your", "handed over", "ofd"
    )
    private val awbRe = Regex("(?i)(?:awb|tracking|consignment|docket|order\\s*(?:id|no\\.?))[^A-Za-z0-9]{0,12}([A-Z0-9]{8,22})")
    private val rideBrands = listOf("OLA", "UBER", "RAPIDO", "NAMMA YATRI", "INDRIVE")
    private val vehicleRe = Regex("\\b([A-Z]{2}[\\s-]?\\d{1,2}[\\s-]?[A-Z]{1,3}[\\s-]?\\d{4})\\b")
    private val pinRe = Regex("(?i)(?:otp|pin|start otp)\\D{0,12}(\\d{4,6})")

    private fun inbox(ctx: Context, limit: Int = 400): List<Triple<String, String, Long>> {
        val out = ArrayList<Triple<String, String, Long>>()
        try {
            ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf("address", "body", "date"), null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    out.add(Triple(c.getString(0) ?: "", c.getString(1) ?: "", c.getLong(2)))
                }
            }
        } catch (_: Exception) { }
        return out
    }

    fun parcels(ctx: Context): List<Parcel> {
        val out = ArrayList<Parcel>()
        for ((addr, body, at) in inbox(ctx)) {
            val up = body.uppercase()
            val courier = couriers.firstOrNull { up.contains(it) } ?: continue
            val status = statusWords.firstOrNull { body.contains(it, true) } ?: continue
            val awb = awbRe.find(body)?.groupValues?.get(1) ?: ""
            if (awb.isEmpty() && status == "out for delivery") continue
            if (out.any { it.awb.isNotEmpty() && it.awb == awb }) continue
            if (out.any { it.courier == courier && it.status == status && kotlin.math.abs(it.at - at) < 86_400_000L }) continue
            out.add(Parcel(courier, awb, status, body, at))
            if (out.size >= 12) break
        }
        return out
    }

    fun rides(ctx: Context): List<Ride> {
        val out = ArrayList<Ride>()
        for ((_, body, at) in inbox(ctx, 200)) {
            val up = body.uppercase()
            val brand = rideBrands.firstOrNull { up.contains(it) } ?: continue
            val veh = vehicleRe.find(up)?.groupValues?.get(1)?.replace(" ", "") ?: ""
            val otp = pinRe.find(body)?.groupValues?.get(1) ?: ""
            if (veh.isEmpty() && otp.isEmpty()) continue
            if (out.any { it.vehicle == veh && it.vehicle.isNotEmpty() }) continue
            out.add(Ride(brand, veh, otp, body, at))
            if (out.size >= 8) break
        }
        return out
    }

    fun trackUrl(p: Parcel): String {
        val q = if (p.awb.isBlank()) p.courier + " order status" else p.awb + " " + p.courier + " tracking"
        return "https://www.google.com/search?q=" + Uri.encode(q)
    }
}

@Composable
fun ParcelsScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var parcels by remember { mutableStateOf(emptyList<Parcel>()) }
    var rides by remember { mutableStateOf(emptyList<Ride>()) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val r = withContext(Dispatchers.IO) { Parcels.parcels(ctx) to Parcels.rides(ctx) }
        parcels = r.first
        rides = r.second
        loaded = true
    }
    Page("Parcels & rides", onBack) {
        if (loaded && parcels.isEmpty() && rides.isEmpty()) {
            EmptyState(Icons.Rounded.LocalShipping, "Nothing on the way", "Delivery and cab messages will show up here")
        } else LazyColumn(contentPadding = PaddingValues(bottom = 26.dp)) {
            if (parcels.isNotEmpty()) {
                item { SectionLabel("DELIVERIES") }
                items(parcels.size) { i ->
                    val p = parcels[i]
                    Box(Modifier.animateItemPlacement()) { ParcelCard(p) { 
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Parcels.trackUrl(p)))) } catch (_: Exception) { }
                    } }
                }
            }
            if (rides.isNotEmpty()) {
                item { SectionLabel("RIDES") }
                items(rides.size) { i ->
                    val r = rides[i]
                    Box(Modifier.animateItemPlacement()) { RideCard(r) }
                }
            }
        }
    }
}

@Composable
private fun ParcelCard(p: Parcel, onTrack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(22.dp)).background(Surf).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(A1, A2))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                p.courier.take(1), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.courier, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(p.status.replaceFirstChar { it.uppercase() }, color = A2, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            if (p.awb.isNotBlank()) {
                Text(
                    p.awb, color = Dim, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box(
            Modifier.bounce(onClick = onTrack).clip(RoundedCornerShape(50))
                .background(Surf2).padding(horizontal = 14.dp, vertical = 8.dp)
        ) { Text("Track", color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun RideCard(r: Ride) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(22.dp)).background(Surf).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.NearMe, null, tint = A2, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(r.brand, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(
                listOf(if (r.vehicle.isBlank()) "" else r.vehicle, if (r.otp.isBlank()) "" else "OTP " + r.otp)
                    .filter { it.isNotBlank() }.joinToString("  \u00B7  "),
                color = Dim, fontSize = 13.sp, fontFamily = FontFamily.Monospace
            )
        }
        Text(fmt(r.at), color = Dim, fontSize = 11.sp)
    }
}
