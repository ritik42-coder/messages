package com.messages.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import android.widget.Toast
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput

object Notifier {
    const val CH = "messages_main"
    fun nid(address: String): Int = nk(address).hashCode()

    private fun allowed(c: Context) = Build.VERSION.SDK_INT < 33 ||
        c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun base(c: Context, address: String, id: Int, title: String, body: String): NotificationCompat.Builder {
        NotificationManagerCompat.from(c).createNotificationChannel(
            NotificationChannelCompat.Builder(CH, NotificationManagerCompat.IMPORTANCE_HIGH)
                .setName("Messages").setVibrationEnabled(true).setLightsEnabled(true).build()
        )
        val open = PendingIntent.getActivity(
            c, id,
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("address", address),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat).setColor(0xFF6D5BFF.toInt())
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).setContentIntent(open)
    }

    fun noteOtp(c: Context, address: String, body: String) {
        val code = Otp.find(body) ?: return
        val st = Store(c)
        if (nk(address) in st.privateSet) return
        st.setLastOtp(code, SmsRepo(c).name(address), System.currentTimeMillis())
        OtpWidget.refresh(c)
        Bus.tick.value++
    }

    fun show(c: Context, address: String, body0: String) {
        val st = Store(c)
        if (!allowed(c) || nk(address) in st.blocked) return
        val hide = st.hideNotif || nk(address) in st.privateSet
        val name = if (hide) "Messages" else SmsRepo(c).name(address)
        val body = if (hide) "New message" else body0
        val code = if (hide) null else Otp.find(body0)
        val scam = !hide && Scam.check(body0, address).risky
        val id = nid(address)
        val title = when {
            code != null -> "OTP $code  •  $name"
            scam -> "\u26A0 Possible scam  •  $name"
            else -> name
        }
        val b = base(c, address, id, title, body)
        if (code != null) {
            val copy = PendingIntent.getBroadcast(
                c, id + 1,
                Intent(c, CopyReceiver::class.java).putExtra("code", code).putExtra("nid", id),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(R.drawable.ic_stat, "Copy OTP", copy)
        }
        val mut = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val reply = PendingIntent.getBroadcast(
            c, id + 2,
            Intent(c, ReplyReceiver::class.java).putExtra("address", address).putExtra("nid", id),
            mut or PendingIntent.FLAG_UPDATE_CURRENT
        )
        b.addAction(
            NotificationCompat.Action.Builder(R.drawable.ic_stat, "Reply", reply)
                .addRemoteInput(RemoteInput.Builder("reply").setLabel("Reply").build()).build()
        )
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) { }
    }

    fun mesh(c: Context, title: String, body: String, conv: String) {
        if (!allowed(c)) return
        val id = 9000 + (conv.hashCode() and 0xFFF)
        NotificationManagerCompat.from(c).createNotificationChannel(
            NotificationChannelCompat.Builder(CH, NotificationManagerCompat.IMPORTANCE_HIGH).setName("Messages").build()
        )
        val open = PendingIntent.getActivity(
            c, id, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("mesh", true).putExtra("conv", conv),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(c, CH).setSmallIcon(R.drawable.ic_stat).setColor(0xFF6D5BFF.toInt())
            .setContentTitle(title).setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(open)
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) { }
    }

    fun remind(c: Context, address: String, body: String) {
        if (!allowed(c)) return
        val id = 7000 + (System.currentTimeMillis() % 100000).toInt()
        val b = base(c, address, id, "Reminder  •  " + SmsRepo(c).name(address), body)
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) { }
    }
}

object Alarms {
    private fun pi(c: Context, id: Long) = PendingIntent.getBroadcast(
        c, id.toInt(), Intent(c, AlarmReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
    fun set(c: Context, s: Sched) {
        try { c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.at, pi(c, s.id)) } catch (_: Exception) { }
    }
    fun cancel(c: Context, id: Long) {
        try { c.getSystemService(AlarmManager::class.java).cancel(pi(c, id)) } catch (_: Exception) { }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", -1L)
        val st = Store(c)
        val s = st.sched.firstOrNull { it.id == id } ?: return
        st.sched = st.sched.filter { it.id != id }
        if (s.kind == "send") SmsRepo(c).send(s.address, s.body) else Notifier.remind(c, s.address, s.body)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val now = System.currentTimeMillis()
        Store(c).sched.forEach { Alarms.set(c, it.copy(at = maxOf(it.at, now + 5000L))) }
    }
}

class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: "Unknown"
        val body = parts.joinToString("") { it.messageBody ?: "" }
        if (SmsPic.onChunk(c, addr, body)) return
        val blocked = nk(addr) in Store(c).blocked
        SmsRepo(c).saveIncoming(addr, body, System.currentTimeMillis(), read = blocked)
        if (!blocked) { Notifier.noteOtp(c, addr, body); Notifier.show(c, addr, body) }
    }
}

class SmsReceivedReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Telephony.Sms.getDefaultSmsPackage(c) == c.packageName) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: "Unknown"
        val body = parts.joinToString("") { it.messageBody ?: "" }
        if (SmsPic.onChunk(c, addr, body)) return
        if (nk(addr) !in Store(c).blocked) Notifier.noteOtp(c, addr, body)
        Notifier.show(c, addr, body)
    }
}

class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}

class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = i.getStringExtra("code") ?: return
        c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("OTP", code))
        Toast.makeText(c, "OTP $code copied", Toast.LENGTH_SHORT).show()
        NotificationManagerCompat.from(c).cancel(i.getIntExtra("nid", 0))
    }
}

class ReplyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val text = RemoteInput.getResultsFromIntent(i)?.getCharSequence("reply")?.toString() ?: return
        val addr = i.getStringExtra("address") ?: return
        SmsRepo(c).send(addr, text)
        NotificationManagerCompat.from(c).cancel(i.getIntExtra("nid", 0))
    }
}
