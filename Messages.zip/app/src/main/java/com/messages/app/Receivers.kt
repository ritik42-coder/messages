package com.messages.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import android.widget.Toast
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput

object Notifier {
    const val CH_MAIN = "messages_main"
    const val CH_OTP = "messages_otp"
    const val CH_PROMO = "messages_promo"
    const val CH_ALERT = "messages_alert"
    const val CH_VAULT = "vault_codes"
    private const val GROUP = "messages_group"

    /** Last few lines per conversation, so the notification looks like the chat. */
    private val history = HashMap<String, ArrayDeque<Pair<Long, String>>>()
    private val active = HashSet<Int>()

    fun nid(address: String): Int = nk(address).hashCode()

    private fun allowed(c: Context) = Build.VERSION.SDK_INT < 33 ||
        c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun channel(c: Context, id: String, name: String, desc: String, importance: Int, loud: Boolean) {
        val b = NotificationChannelCompat.Builder(id, importance).setName(name).setDescription(desc)
        if (loud) {
            b.setVibrationEnabled(true).setLightsEnabled(true)
        } else {
            b.setVibrationEnabled(false).setSound(null, null).setLightsEnabled(false)
        }
        NotificationManagerCompat.from(c).createNotificationChannel(b.build())
    }

    fun ensureChannels(c: Context) {
        channel(c, CH_MAIN, "Messages", "New SMS from people", NotificationManagerCompat.IMPORTANCE_HIGH, true)
        channel(c, CH_OTP, "One-time passwords", "Codes you asked for", NotificationManagerCompat.IMPORTANCE_HIGH, true)
        channel(c, CH_PROMO, "Offers", "Promotional messages, kept quiet", NotificationManagerCompat.IMPORTANCE_LOW, false)
        channel(c, CH_ALERT, "Reminders and trips", "Bills, journeys and reminders", NotificationManagerCompat.IMPORTANCE_DEFAULT, true)
        channel(c, CH_VAULT, "Vault codes", "Recovery codes for your vault", NotificationManagerCompat.IMPORTANCE_HIGH, true)
    }

    private fun openIntent(c: Context, address: String, id: Int): PendingIntent =
        PendingIntent.getActivity(
            c, id,
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("address", address),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun base(c: Context, address: String, id: Int, title: String, body: String): NotificationCompat.Builder {
        ensureChannels(c)
        return NotificationCompat.Builder(c, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat).setColor(0xFF6D5BFF.toInt())
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openIntent(c, address, id))
    }

    fun noteOtp(c: Context, address: String, body: String) {
        val code = Otp.find(body) ?: return
        val st = Store(c)
        if (nk(address) in st.privateSet) return
        st.setLastOtp(code, SmsRepo(c).name(address), System.currentTimeMillis())
        OtpWidget.refresh(c)
        Bus.tick.value++
    }

    fun show(c: Context, address: String, body0: String) {
        val st = Store(c)
        if (!allowed(c) || nk(address) in st.blocked) return
        if (Rules.muted(c, address, body0)) return
        Rules.forwardTarget(c, address, body0)?.let { target ->
            try { SmsRepo(c).send(target, body0) } catch (_: Exception) { }
        }
        ensureChannels(c)
        val hide = st.hideNotif || nk(address) in st.privateSet
        val name = if (hide) "Messages" else SmsRepo(c).name(address)
        val body = if (hide) "New message" else body0
        val code = if (hide) null else Otp.find(body0)
        val scam = !hide && Scam.check(body0, address).risky
        val cat = Cat.of(address, body0)
        val id = nid(address)
        val now = System.currentTimeMillis()

        val ch = when {
            code != null -> CH_OTP
            cat == 3 -> CH_PROMO
            else -> CH_MAIN
        }
        val quiet = ch == CH_PROMO

        val key = nk(address)
        val lines = history.getOrPut(key) { ArrayDeque() }
        lines.addLast(now to body)
        while (lines.size > 3) lines.removeFirst()

        val me = Person.Builder().setName("Me").build()
        val them = Person.Builder().setName(name).setImportant(!quiet).build()
        val style = NotificationCompat.MessagingStyle(me)
        for (line in lines) style.addMessage(line.second, line.first, them)
        style.conversationTitle = name

        val b = NotificationCompat.Builder(c, ch)
            .setSmallIcon(R.drawable.ic_stat).setColor(0xFF6D5BFF.toInt())
            .setStyle(style)
            .setContentTitle(
                when {
                    code != null -> "OTP " + code + "  \u2022  " + name
                    scam -> "\u26A0 Possible scam  \u2022  " + name
                    else -> name
                }
            )
            .setContentText(body)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(if (quiet) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .setWhen(now).setShowWhen(true)
            .setAutoCancel(true)
            .setGroup(GROUP)
            .setContentIntent(openIntent(c, address, id))

        if (code != null) {
            val copy = PendingIntent.getBroadcast(
                c, id + 1,
                Intent(c, CopyReceiver::class.java).putExtra("code", code).putExtra("nid", id),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(R.drawable.ic_stat, "Copy OTP", copy)
        }
        val read = PendingIntent.getBroadcast(
            c, id + 3,
            Intent(c, MarkReadReceiver::class.java).putExtra("address", address).putExtra("nid", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        b.addAction(R.drawable.ic_stat, "Mark read", read)

        val mut = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val reply = PendingIntent.getBroadcast(
            c, id + 2,
            Intent(c, ReplyReceiver::class.java).putExtra("address", address).putExtra("nid", id),
            mut or PendingIntent.FLAG_UPDATE_CURRENT
        )
        b.addAction(
            NotificationCompat.Action.Builder(R.drawable.ic_stat, "Reply", reply)
                .addRemoteInput(RemoteInput.Builder("reply").setLabel("Reply").build()).build()
        )

        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) { }
        active.add(id)
        if (active.size > 1) summary(c)

        if (!hide && st.announce) {
            try {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                val ears = am.isWiredHeadsetOn || am.isBluetoothA2dpOn || am.isBluetoothScoOn
                if (ears) Voice.speak(c, name + " says. " + body0)
            } catch (_: Exception) { }
        }
    }

    /** The bundle header Android shows above several conversations. */
    private fun summary(c: Context) {
        val b = NotificationCompat.Builder(c, CH_MAIN)
            .setSmallIcon(R.drawable.ic_stat).setColor(0xFF6D5BFF.toInt())
            .setContentTitle(active.size.toString() + " conversations")
            .setGroup(GROUP).setGroupSummary(true).setAutoCancel(true)
            .setStyle(NotificationCompat.InboxStyle())
        try { NotificationManagerCompat.from(c).notify(1010, b.build()) } catch (_: SecurityException) { }
    }

    fun clear(c: Context, address: String) {
        val id = nid(address)
        active.remove(id)
        try { NotificationManagerCompat.from(c).cancel(id) } catch (_: Exception) { }
    }

    fun mesh(c: Context, title: String, body: String, conv: String) {
        if (!allowed(c)) return
        ensureChannels(c)
        val id = 9000 + (conv.hashCode() and 0xFFF)
        val open = PendingIntent.getActivity(
            c, id, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("mesh", true).putExtra("conv", conv),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(c, CH_MAIN).setSmallIcon(R.drawable.ic_stat).setColor(0xFF6D5BFF.toInt())
            .setContentTitle(title).setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(open)
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) { }
    }

    fun trip(c: Context, title: String, body: String) {
        if (!allowed(c)) return
        val id = 8100 + (System.currentTimeMillis() % 900).toInt()
        val b = base(c, "", id, title, body)
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) { }
    }

    fun remind(c: Context, address: String, body: String) {
        if (!allowed(c)) return
        val id = 7000 + (System.currentTimeMillis() % 100000).toInt()
        val b = base(c, address, id, "Reminder  \u2022  " + SmsRepo(c).name(address), body)
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) { }
    }

    /** A document in the vault is about to expire. The text never contains a number. */
    fun vaultExpiry(c: Context, id: Int, title: String, text: String) {
        if (!allowed(c)) return
        ensureChannels(c)
        val open = c.packageManager.getLaunchIntentForPackage(c.packageName)
        val b = NotificationCompat.Builder(c, CH_VAULT)
            .setSmallIcon(R.drawable.ic_stat).setColor(0xFFFF5CA8.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
        if (open != null) {
            b.setContentIntent(PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        try { NotificationManagerCompat.from(c).notify(9300 + (id and 0xFF), b.build()) } catch (_: SecurityException) { }
    }

    /** The vault's offline recovery code. */
    fun vaultOtp(c: Context, code: String) {
        if (!allowed(c)) return
        ensureChannels(c)
        val b = NotificationCompat.Builder(c, CH_VAULT)
            .setSmallIcon(R.drawable.ic_stat).setColor(0xFFFF5CA8.toInt())
            .setContentTitle("Vault recovery code")
            .setContentText(code)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Your one-time code is " + code + ". It works for 5 minutes. Never share it with anyone.")
            )
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
        try { NotificationManagerCompat.from(c).notify(9911, b.build()) } catch (_: SecurityException) { }
    }
}

object Alarms {
    private fun pi(c: Context, id: Long) = PendingIntent.getBroadcast(
        c, id.toInt(), Intent(c, AlarmReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
    fun set(c: Context, s: Sched) {
        try { c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.at, pi(c, s.id)) } catch (_: Exception) { }
    }
    fun cancel(c: Context, id: Long) {
        try { c.getSystemService(AlarmManager::class.java).cancel(pi(c, id)) } catch (_: Exception) { }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", -1L)
        val st = Store(c)
        val s = st.sched.firstOrNull { it.id == id } ?: return
        st.sched = st.sched.filter { it.id != id }
        if (s.kind == "send") SmsRepo(c).send(s.address, s.body) else Notifier.remind(c, s.address, s.body)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val now = System.currentTimeMillis()
        Store(c).sched.forEach { Alarms.set(c, it.copy(at = maxOf(it.at, now + 5000L))) }
        VaultExpiry.schedule(c)
        if (SecureCore.instant(c)) {
            try { androidx.core.content.ContextCompat.startForegroundService(c, Intent(c, SecureService::class.java)) } catch (_: Exception) { }
        }
    }
}

class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: "Unknown"
        val body = parts.joinToString("") { it.messageBody ?: "" }
        if (SmsPic.onChunk(c, addr, body)) return
        val blocked = nk(addr) in Store(c).blocked
        SmsRepo(c).saveIncoming(addr, body, System.currentTimeMillis(), read = blocked)
        if (!blocked) { Notifier.noteOtp(c, addr, body); Notifier.show(c, addr, body) }
    }
}

class SmsReceivedReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Telephony.Sms.getDefaultSmsPackage(c) == c.packageName) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: "Unknown"
        val body = parts.joinToString("") { it.messageBody ?: "" }
        if (SmsPic.onChunk(c, addr, body)) return
        if (nk(addr) !in Store(c).blocked) Notifier.noteOtp(c, addr, body)
        Notifier.show(c, addr, body)
    }
}

class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}

class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = i.getStringExtra("code") ?: return
        c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("OTP", code))
        Toast.makeText(c, "OTP $code copied", Toast.LENGTH_SHORT).show()
        NotificationManagerCompat.from(c).cancel(i.getIntExtra("nid", 0))
    }
}

class MarkReadReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val address = i.getStringExtra("address") ?: return
        try {
            val thread = Telephony.Threads.getOrCreateThreadId(c, address)
            SmsRepo(c).markRead(thread)
        } catch (_: Exception) { }
        NotificationManagerCompat.from(c).cancel(i.getIntExtra("nid", 0))
        Bus.tick.value++
    }
}

class ReplyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val text = RemoteInput.getResultsFromIntent(i)?.getCharSequence("reply")?.toString() ?: return
        val addr = i.getStringExtra("address") ?: return
        SmsRepo(c).send(addr, text)
        NotificationManagerCompat.from(c).cancel(i.getIntExtra("nid", 0))
    }
}
