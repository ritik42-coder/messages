package com.messages.app

import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import android.widget.Toast
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput

object Notifier {
    const val CH = "messages_main"
    fun nid(address: String): Int = nk(address).hashCode()

    fun show(c: Context, address: String, body: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = NotificationManagerCompat.from(c)
        nm.createNotificationChannel(
            NotificationChannelCompat.Builder(CH, NotificationManagerCompat.IMPORTANCE_HIGH)
                .setName("Messages").setVibrationEnabled(true).setLightsEnabled(true).build()
        )
        val name = SmsRepo(c).name(address)
        val code = Otp.find(body)
        val id = nid(address)
        val open = PendingIntent.getActivity(
            c, id,
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("address", address),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFF6D5BFF.toInt())
            .setContentTitle(if (code != null) "OTP $code  •  $name" else name)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
        if (code != null) {
            val copy = PendingIntent.getBroadcast(
                c, id + 1,
                Intent(c, CopyReceiver::class.java).putExtra("code", code).putExtra("nid", id),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(R.drawable.ic_stat, "Copy OTP", copy)
        }
        val mut = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val reply = PendingIntent.getBroadcast(
            c, id + 2,
            Intent(c, ReplyReceiver::class.java).putExtra("address", address).putExtra("nid", id),
            mut or PendingIntent.FLAG_UPDATE_CURRENT
        )
        b.addAction(
            NotificationCompat.Action.Builder(R.drawable.ic_stat, "Reply", reply)
                .addRemoteInput(RemoteInput.Builder("reply").setLabel("Reply").build())
                .build()
        )
        try { nm.notify(id, b.build()) } catch (_: SecurityException) { }
    }
}

class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: "Unknown"
        val body = parts.joinToString("") { it.messageBody ?: "" }
        SmsRepo(c).saveIncoming(addr, body, System.currentTimeMillis())
        Notifier.show(c, addr, body)
    }
}

class SmsReceivedReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Telephony.Sms.getDefaultSmsPackage(c) == c.packageName) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: "Unknown"
        Notifier.show(c, addr, parts.joinToString("") { it.messageBody ?: "" })
    }
}

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { }
}

class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}

class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = i.getStringExtra("code") ?: return
        c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("OTP", code))
        Toast.makeText(c, "OTP $code copied", Toast.LENGTH_SHORT).show()
        NotificationManagerCompat.from(c).cancel(i.getIntExtra("nid", 0))
    }
}

class ReplyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val text = RemoteInput.getResultsFromIntent(i)?.getCharSequence("reply")?.toString() ?: return
        val addr = i.getStringExtra("address") ?: return
        SmsRepo(c).send(addr, text)
        NotificationManagerCompat.from(c).cancel(i.getIntExtra("nid", 0))
    }
}
