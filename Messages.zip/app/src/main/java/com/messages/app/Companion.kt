@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket

/**
 * A tiny web server inside the app: your laptop browser can read and send SMS over the
 * same Wi-Fi, with no Google account and no internet. Every request needs the random token
 * from the QR code, so a stranger on the network can't just open your inbox.
 */
object LanServer {
    val running = mutableStateOf(false)
    val hits = mutableStateOf(0)
    val token = mutableStateOf("")
    val port = mutableStateOf(8089)
    val url = mutableStateOf("")

    private var thread: Thread? = null
    private var server: ServerSocket? = null
    private var app: Context? = null

    fun start(ctx: Context): String {
        stop()
        app = ctx.applicationContext
        if (token.value.length < 12) token.value = newToken()
        var p = port.value
        var srv: ServerSocket? = null
        while (srv == null && p < port.value + 12) {
            srv = try { ServerSocket(p) } catch (_: Exception) { null }
            if (srv == null) p++
        }
        val socket = srv ?: return ""
        port.value = p
        server = socket
        val link = "http://" + ip() + ":" + p + "/?t=" + token.value
        url.value = link
        running.value = true
        thread = Thread {
            while (!socket.isClosed) {
                val s = try { socket.accept() } catch (_: Exception) { break }
                try { handle(s) } catch (_: Exception) { } finally { try { s.close() } catch (_: Exception) { } }
            }
            running.value = false
        }.also { it.isDaemon = true; it.start() }
        return link
    }

    fun stop() {
        running.value = false
        try { server?.close() } catch (_: Exception) { }
        server = null
        thread = null
    }

    fun newToken(): String {
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val sb = StringBuilder()
        for (i in 0 until 20) sb.append(chars[(Math.random() * chars.length).toInt().coerceIn(0, chars.length - 1)])
        return sb.toString()
    }

    fun ip(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        val h = a.hostAddress ?: continue
                        if (h.startsWith("192.168.") || h.startsWith("10.") || h.startsWith("172.")) return h
                    }
                }
            }
        } catch (_: Exception) { }
        return "127.0.0.1"
    }

    fun qr(text: String, size: Int = 512): Bitmap? = try {
        val hints = HashMap<EncodeHintType, Any>()
        hints[EncodeHintType.MARGIN] = 1
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) for (y in 0 until size) {
            bmp.setPixel(x, y, if (m[x, y]) AColor.BLACK else AColor.WHITE)
        }
        bmp
    } catch (_: Exception) { null }

    // ---------- http ----------
    private fun handle(s: Socket) {
        s.soTimeout = 8000
        val input: InputStream = BufferedInputStream(s.getInputStream())
        val out: OutputStream = BufferedOutputStream(s.getOutputStream())
        val head = StringBuilder()
        while (head.length < 16384) {
            val b = input.read()
            if (b < 0) return
            head.append(b.toChar())
            if (head.length >= 4 && head.endsWith("\r\n\r\n")) break
        }
        val lines = head.toString().split("\r\n")
        val first = lines.firstOrNull()?.split(" ") ?: return
        if (first.size < 2) return
        val method = first[0]
        val target = first[1]
        var len = 0
        for (l in lines) {
            if (l.startsWith("Content-Length:", true)) len = l.substringAfter(':').trim().toIntOrNull() ?: 0
        }
        var body = ""
        if (len > 0) {
            val buf = ByteArray(len.coerceAtMost(262144))
            var read = 0
            while (read < buf.size) {
                val r = input.read(buf, read, buf.size - read)
                if (r <= 0) break
                read += r
            }
            body = String(buf, 0, read, Charsets.UTF_8)
        }
        val ctx = app ?: return
        val u = Uri.parse(target)
        val path = u.path ?: "/"
        val t = u.getQueryParameter("t")
        if (path == "/favicon.ico") { respond(out, 204, "text/plain", ""); return }
        if (t != token.value) {
            respond(out, 403, "text/plain", "Wrong or missing token. Scan the QR code again.")
            return
        }
        hits.value = hits.value + 1
        when {
            path == "/" || path == "/index.html" -> respond(out, 200, "text/html", page())
            path == "/api/state" -> respond(out, 200, "application/json", stateJson(ctx, u.getQueryParameter("to")))
            path == "/api/send" && method == "POST" -> {
                try {
                    val o = JSONObject(body)
                    val to = o.optString("to")
                    val txt = o.optString("body")
                    if (to.isNotBlank() && txt.isNotBlank()) SmsRepo(ctx).send(to, txt)
                    respond(out, 200, "application/json", "{\"ok\":true}")
                } catch (e: Exception) {
                    respond(out, 500, "application/json", "{\"ok\":false}")
                }
            }
            else -> respond(out, 404, "text/plain", "Not found")
        }
    }

    private fun stateJson(ctx: Context, to: String?): String {
        val root = JSONObject()
        try {
            val repo = SmsRepo(ctx)
            val convos = repo.conversations()
            val arr = JSONArray()
            for (c in convos.take(120)) {
                arr.put(
                    JSONObject()
                        .put("name", c.name).put("address", c.address).put("snip", c.snippet)
                        .put("date", c.date).put("unread", c.unread)
                )
            }
            root.put("convos", arr)
            if (!to.isNullOrBlank()) {
                val chat = convos.firstOrNull { nk(it.address) == nk(to) }
                root.put("name", chat?.name ?: repo.name(to))
                root.put("address", to)
                val ms = repo.messages(chat?.threadId ?: -1L, to)
                val ma = JSONArray()
                for (m in ms.takeLast(300)) {
                    ma.put(JSONObject().put("b", m.body).put("o", m.outgoing).put("d", m.date).put("t", hm(m.date)))
                }
                root.put("msgs", ma)
                if (chat != null) repo.markRead(chat.threadId)
            }
        } catch (_: Exception) { }
        return root.toString()
    }

    private fun respond(out: OutputStream, code: Int, type: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val head = "HTTP/1.1 $code OK\r\nContent-Type: $type; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.UTF_8))
        out.write(bytes)
        out.flush()
    }

    private fun page(): String = WEB.replace("__TOKEN__", token.value)

    private val WEB = """
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Messages</title>
<style>
:root{--bg:#0b0b12;--surf:#16161f;--surf2:#1e1e2b;--ink:#f2f2f8;--dim:#9a9ab5;--a1:#6d5bff;--a2:#b04bff;--a3:#ff5ca8}
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:var(--ink);display:flex;overflow:hidden;
background:radial-gradient(1100px 600px at 8% -10%,rgba(109,91,255,.30),transparent 60%),radial-gradient(900px 520px at 92% 0%,rgba(255,92,168,.22),transparent 55%),var(--bg)}
#side{width:330px;border-right:1px solid #232334;display:flex;flex-direction:column;background:rgba(12,12,20,.55)}
#brand{padding:22px 20px 12px;font-weight:800;font-size:24px;letter-spacing:-.5px;
background:linear-gradient(90deg,var(--a1),var(--a2),var(--a3));-webkit-background-clip:text;background-clip:text;color:transparent}
#sub{font-size:12px;color:var(--dim);padding:0 20px 12px}
#list{overflow:auto;flex:1;padding:6px 8px}
.row{display:flex;gap:12px;padding:10px;border-radius:16px;cursor:pointer;transition:background .18s,transform .18s}
.row:hover{background:var(--surf);transform:translateX(3px)}
.row.on{background:var(--surf2)}
.av{width:42px;height:42px;border-radius:14px;display:grid;place-items:center;font-weight:800;color:#fff;flex:0 0 42px;font-size:16px}
.nm{font-weight:600;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:190px}
.sn{font-size:12px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:190px;margin-top:2px}
#main{flex:1;display:flex;flex-direction:column;min-width:0}
#top{padding:18px 24px;border-bottom:1px solid #232334;display:flex;align-items:center;gap:14px}
#who{font-weight:700;font-size:16px}
#addr{font-size:12px;color:var(--dim);margin-top:2px}
#msgs{flex:1;overflow:auto;padding:20px 24px;display:flex;flex-direction:column;gap:9px}
.b{max-width:62%;padding:11px 15px;border-radius:18px;font-size:14px;line-height:1.4;animation:pop .26s ease;word-wrap:break-word}
@keyframes pop{from{opacity:0;transform:translateY(7px) scale(.98)}to{opacity:1;transform:none}}
.in{background:var(--surf2);border-bottom-left-radius:6px;align-self:flex-start}
.out{background:linear-gradient(135deg,var(--a1),var(--a2));border-bottom-right-radius:6px;align-self:flex-end;color:#fff}
.t{font-size:10px;opacity:.65;margin-top:5px}
#bar{display:flex;gap:10px;padding:14px 24px;border-top:1px solid #232334}
input{background:var(--surf);border:1px solid #2a2a3d;color:var(--ink);border-radius:14px;padding:13px 15px;font-size:14px;outline:none;flex:1}
input:focus{border-color:var(--a2)}
button{background:linear-gradient(135deg,var(--a1),var(--a3));border:0;color:#fff;font-weight:700;border-radius:14px;padding:0 22px;cursor:pointer;font-size:14px;transition:transform .15s}
button:active{transform:scale(.96)}
#empty{color:var(--dim);margin:auto;font-size:14px}
</style></head><body>
<div id="side"><div id="brand">Messages</div><div id="sub">your phone, on this laptop</div><div id="list"></div></div>
<div id="main">
 <div id="top"><div><div id="who">Choose a chat</div><div id="addr">read and reply from here</div></div></div>
 <div id="msgs"><div id="empty">Pick a conversation on the left</div></div>
 <div id="bar"><input id="txt" placeholder="Write a message"><button id="send">Send</button></div>
</div>
<script>
var T="__TOKEN__", cur=null, sig="";
function el(i){return document.getElementById(i)}
function h(s){return (s||"").replace(/[&<>]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;"}[c]})}
function col(s){var x=0;for(var i=0;i<s.length;i++)x=(x*31+s.charCodeAt(i))%360;return "linear-gradient(135deg,hsl("+x+",62%,56%),hsl("+((x+45)%360)+",70%,44%))"}
function draw(st){
 var L=el("list"), out="";
 (st.convos||[]).forEach(function(c){
  out+='<div class="row'+(c.address===cur?" on":"")+'" data-a="'+h(c.address)+'"><div class="av" style="background:'+col(c.name)+'">'+h((c.name||"#").charAt(0).toUpperCase())+'</div><div><div class="nm">'+h(c.name)+'</div><div class="sn">'+h(c.snip)+'</div></div></div>';
 });
 L.innerHTML=out||'<div style="padding:16px;color:var(--dim)">No messages</div>';
 Array.prototype.forEach.call(L.querySelectorAll(".row"),function(r){r.onclick=function(){pick(r.getAttribute("data-a"))}});
 if(cur){
  el("who").textContent=st.name||cur;
  el("addr").textContent=st.address||"";
  var s=(st.msgs?st.msgs.length:0)+":"+((st.msgs&&st.msgs.length)?st.msgs[st.msgs.length-1].d:0);
  if(s!==sig){
   sig=s;
   var M=el("msgs"), html="";
   (st.msgs||[]).forEach(function(m){html+='<div class="b '+(m.o?"out":"in")+'">'+h(m.b)+'<div class="t">'+h(m.t)+'</div></div>'});
   M.innerHTML=html||'<div id="empty">No messages yet</div>';
   M.scrollTop=M.scrollHeight;
  }
 }
}
function poll(){
 fetch("/api/state?t="+T+(cur?"&to="+encodeURIComponent(cur):"")).then(function(r){return r.json()}).then(draw).catch(function(){});
}
function pick(a){cur=a;sig="";el("msgs").innerHTML="";poll()}
function send(){
 var b=el("txt").value.trim(); if(!b||!cur) return; el("txt").value="";
 fetch("/api/send?t="+T,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({to:cur,body:b})}).then(poll);
}
el("send").onclick=send;
el("txt").addEventListener("keydown",function(e){if(e.key==="Enter")send()});
poll(); setInterval(poll,1600);
</script></body></html>
"""
}

@Composable
fun CompanionScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val running = LanServer.running.value
    val link = LanServer.url.value
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(running, link) {
        bmp = if (running && link.isNotEmpty()) withContext(Dispatchers.Default) { LanServer.qr(link) } else null
    }
    DisposableEffect(Unit) {
        if (!LanServer.running.value) LanServer.start(ctx)
        onDispose { LanServer.stop() }
    }
    Page("Laptop companion", onBack) {
        Column(
            Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Open this on your laptop, on the same Wi-Fi. No account, no internet needed.",
                color = Dim, fontSize = 14.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier.size(230.dp).clip(RoundedCornerShape(28.dp)).background(Color.White).padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                val b = bmp
                if (b != null) Image(bitmap = b.asImageBitmap(), contentDescription = "Scan to open", modifier = Modifier.fillMaxSize())
                else Text("Starting…", color = Color(0xFF111111), fontSize = 14.sp)
            }
            Spacer(Modifier.height(16.dp))
            if (running) {
                Text(link, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Row {
                    Text(
                        "Copy link", color = A2, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.bounce(onClick = { clip.setText(AnnotatedString(link)) }).padding(10.dp)
                    )
                    Text(
                        "New code", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.bounce(onClick = {
                            LanServer.token.value = LanServer.newToken()
                            LanServer.start(ctx)
                        }).padding(10.dp)
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Requests this session: " + LanServer.hits.value,
                    color = Dim, fontSize = 12.sp
                )
            } else {
                GradientButton("Start companion") { LanServer.start(ctx) }
            }
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surf).padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(Icons.Rounded.Info, null, tint = A2, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    "Only works while this screen is open. Every request needs the code inside the QR, and the phone stays the one that sends the SMS. Use it on a Wi-Fi you trust — the page itself is plain HTTP on your local network.",
                    color = Dim, fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Lock, null, tint = A2, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Token protected · never leaves your network", color = Dim, fontSize = 12.sp)
            }
            Spacer(Modifier.weight(1f))
            if (running) {
                Text(
                    "Stop sharing", color = A3, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.bounce(onClick = { LanServer.stop() }).padding(12.dp)
                )
            }
        }
    }
}
