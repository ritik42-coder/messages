@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.CancellationSignal
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class VaultKind(
    val id: String, val label: String, val icon: ImageVector,
    val hint: String, val subHint: String, val preset: String
)

val VAULT_KINDS = listOf(
    VaultKind("pnr", "Ticket", Icons.Rounded.ConfirmationNumber, "PNR or booking ID", "Route, date or passengers", "Train ticket"),
    VaultKind("id", "ID", Icons.Rounded.AccountBalance, "Aadhaar, PAN, DL or voter number", "Name on the document", "Aadhaar"),
    VaultKind("card", "Card", Icons.Rounded.CreditCard, "Card or account number", "Bank name or expiry", "Bank card"),
    VaultKind("edu", "Study", Icons.Rounded.InsertDriveFile, "Roll number or application ID", "Exam, board or result", "Admit card"),
    VaultKind("wifi", "Wi-Fi", Icons.Rounded.Wifi, "Network password", "Network name", "Home Wi-Fi"),
    VaultKind("other", "Other", Icons.Rounded.Bookmark, "Anything you want to keep", "A short note", "Other")
)

fun vaultKind(id: String): VaultKind = VAULT_KINDS.firstOrNull { it.id == id } ?: VAULT_KINDS.last()

fun maskValue(v: String): String {
    val clean = v.filter { !it.isWhitespace() }
    if (clean.length <= 4) return "\u2022".repeat(clean.length.coerceAtLeast(4))
    return "\u2022".repeat((clean.length - 4).coerceAtMost(14)) + "  " + clean.takeLast(4)
}

fun maskCard(v: String): String {
    val d = v.filter { it.isDigit() }
    if (d.length < 8) return maskValue(v)
    return "\u2022\u2022\u2022\u2022   \u2022\u2022\u2022\u2022   \u2022\u2022\u2022\u2022   " + d.takeLast(4)
}

// ---------- biometric gate ----------
@Composable
fun VaultGate(onBack: () -> Unit, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var asking by remember { mutableStateOf(false) }
    val keyguard = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        asking = false
        if (r.resultCode == Activity.RESULT_OK) { open = true; msg = null } else msg = "Vault stays locked"
    }

    fun usePhoneLock() {
        val i = authIntent(ctx)
        if (i == null) open = true
        else { asking = true; keyguard.launch(i) }
    }

    fun unlock() {
        if (Build.VERSION.SDK_INT < 29) { usePhoneLock(); return }
        try {
            val exec = ContextCompat.getMainExecutor(ctx)
            val cancel = CancellationSignal()
            val b = android.hardware.biometrics.BiometricPrompt.Builder(ctx)
                .setTitle("Saved info vault")
                .setSubtitle("Unlock with fingerprint, face or phone PIN")
            if (Build.VERSION.SDK_INT >= 30) {
                b.setAllowedAuthenticators(
                    android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK or
                        android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
            } else {
                @Suppress("DEPRECATION")
                b.setDeviceCredentialAllowed(true)
            }
            asking = true
            b.build().authenticate(cancel, exec, object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                    asking = false; open = true; msg = null
                }

                override fun onAuthenticationError(code: Int, err: CharSequence?) {
                    asking = false
                    msg = err?.toString() ?: "Couldn't unlock"
                }
            })
        } catch (_: Exception) {
            usePhoneLock()
        }
    }

    LaunchedEffect(Unit) { unlock() }

    if (open) {
        content()
    } else {
        Page("Saved info vault", onBack) {
            Column(
                Modifier.fillMaxSize().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.size(96.dp).clip(CircleShape).background(Surf2),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Fingerprint, null, tint = A2, modifier = Modifier.size(46.dp)) }
                Spacer(Modifier.height(18.dp))
                Text("Locked", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    msg ?: "Tickets, IDs, cards and study documents, kept behind your phone lock.",
                    color = Dim, fontSize = 14.sp, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(22.dp))
                GradientButton(if (asking) "Waiting for unlock…" else "Unlock vault") { unlock() }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Use phone PIN instead", color = A2, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.bounce(onClick = { usePhoneLock() }).padding(10.dp)
                )
            }
        }
    }
}

// ---------- vault screen ----------
@Composable
fun VaultScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val items by vm.vault.collectAsState()
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var adding by remember { mutableStateOf<VaultKind?>(null) }
    var editing by remember { mutableStateOf<VaultItem?>(null) }
    var confirmDel by remember { mutableStateOf<VaultItem?>(null) }
    var menuFor by remember { mutableStateOf<VaultItem?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<List<Ticket>?>(null) }
    LaunchedEffect(scanning) {
        if (scanning) {
            found = withContext(Dispatchers.IO) { Tickets.scan(ctx, items.map { it.value }.toSet()) }
            scanning = false
        }
    }
    val list = remember(items, q, filter) {
        items
            .filter { filter == "all" || it.kind == filter }
            .filter {
                q.isBlank() || it.label.contains(q, true) || it.value.contains(q, true) ||
                    it.sub.contains(q, true) || vaultKind(it.kind).label.contains(q, true)
            }
            .sortedByDescending { it.at }
    }

    VaultGate(onBack) {
        Page("Saved info vault", onBack, actions = {
            IconBtn(Icons.Rounded.ConfirmationNumber, Dim) { scanning = true }
            IconBtn(Icons.Rounded.Add, A2) { adding = vaultKind("pnr") }
        }) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Fingerprint, null, tint = A2, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    items.size.toString() + if (items.size == 1) " item · unlocked for this session" else " items · unlocked for this session",
                    color = Dim, fontSize = 12.sp
                )
            }
            Box(Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) { SearchField(q, { q = it }, "Search tickets, IDs, cards") }
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip("All", filter == "all") { filter = "all" }
                VAULT_KINDS.forEach { k -> Chip(k.label, filter == k.id) { filter = k.id } }
            }
            if (items.isEmpty()) {
                EmptyState(Icons.Rounded.Lock, "Nothing saved yet", "Tap + or hold any message and choose Save to vault")
            } else if (list.isEmpty()) {
                EmptyState(Icons.Rounded.Search, "Nothing matches", "Try another word or filter")
            } else LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
                items(list, key = { it.id }) { v ->
                    Box(Modifier.animateItemPlacement()) {
                        VaultCard(
                            v,
                            onCopy = { ctx.copyText(v.value, "Copied " + (v.label.ifBlank { vaultKind(v.kind).label })) },
                            onLong = { menuFor = v }
                        )
                    }
                }
            }
        }

        found?.let { list ->
            AlertDialog(
                onDismissRequest = { found = null }, containerColor = Surf2,
                title = { Text(if (list.isEmpty()) "No tickets found" else "Tickets in your messages", color = Ink) },
                text = {
                    if (list.isEmpty()) {
                        Text("Nothing new. A ticket shows up here when IRCTC or an airline texts you a PNR.", color = Dim, fontSize = 13.sp)
                    } else Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                        list.forEach { t ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.ConfirmationNumber, null, tint = A2, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        t.title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        t.pnr + if (t.sub.isBlank()) "" else "  \u00B7  " + t.sub,
                                        color = Dim, fontSize = 12.sp, maxLines = 2
                                    )
                                }
                                Text(
                                    "Save", color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.bounce(onClick = {
                                        vm.saveVault(t.title, t.pnr, "pnr", t.sub, t.whenMs)
                                        Tickets.remind(ctx, t)
                                        found = list.filter { it.pnr != t.pnr }
                                    }).padding(8.dp)
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    if (list.isNotEmpty()) TextButton(onClick = {
                        list.forEach { t ->
                            vm.saveVault(t.title, t.pnr, "pnr", t.sub, t.whenMs)
                            Tickets.remind(ctx, t)
                        }
                        found = null
                    }) { Text("Save all", color = A2, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { found = null }) { Text("Close", color = Dim) } }
            )
        }
        adding?.let { k ->
            VaultEditDialog(null, k, onCancel = { adding = null }) { label, value, sub, kind ->
                vm.saveVault(label, value, kind, sub)
                adding = null
            }
        }
        editing?.let { v ->
            VaultEditDialog(v, vaultKind(v.kind), onCancel = { editing = null }) { label, value, sub, kind ->
                vm.updateVault(v.copy(label = label, value = value, sub = sub, kind = kind))
                editing = null
            }
        }
        menuFor?.let { v ->
            Scrim(true, { menuFor = null }) {
                ActionCard(listOf(
                    Act(Icons.Rounded.ContentCopy, "Copy") { ctx.copyText(v.value, "Copied"); menuFor = null },
                    Act(Icons.Rounded.Edit, "Edit") { menuFor = null; editing = v },
                    Act(Icons.Rounded.Share, "Share") {
                        try {
                            ctx.startActivity(
                                Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).setType("text/plain")
                                        .putExtra(Intent.EXTRA_TEXT, v.label + "\n" + v.value + if (v.sub.isBlank()) "" else "\n" + v.sub),
                                    "Share"
                                )
                            )
                        } catch (_: Exception) { }
                        menuFor = null
                    },
                    Act(Icons.Rounded.Delete, "Delete", true) { menuFor = null; confirmDel = v }
                ))
            }
        }
        confirmDel?.let { v ->
            AlertDialog(
                onDismissRequest = { confirmDel = null }, containerColor = Surf2,
                title = { Text("Delete from vault?", color = Ink) },
                text = { Text("“" + v.label.ifBlank { vaultKind(v.kind).label } + "” will be removed. This can't be undone.", color = Dim) },
                confirmButton = {
                    TextButton(onClick = { vm.deleteVault(v.id); confirmDel = null }) { Text("Delete", color = A3) }
                },
                dismissButton = { TextButton(onClick = { confirmDel = null }) { Text("Cancel", color = Dim) } }
            )
        }
    }
}

// ---------- one item, drawn like the thing it represents ----------
@Composable
fun VaultCard(v: VaultItem, onCopy: () -> Unit, onLong: () -> Unit) {
    var shown by remember(v.id) { mutableStateOf(false) }
    LaunchedEffect(shown) { if (shown) { delay(10_000); shown = false } }
    val k = vaultKind(v.kind)
    when (v.kind) {
        "pnr" -> TicketCard(v, onCopy, onLong)
        "id" -> IdCard(v, shown, onCopy, onLong) { shown = !shown }
        "card" -> BankCard(v, shown, onCopy, onLong) { shown = !shown }
        "edu" -> StudyCard(v, onCopy, onLong)
        else -> SimpleCard(v, k, onCopy, onLong)
    }
}

@Composable
private fun CardShell(
    onClick: () -> Unit, onLong: () -> Unit,
    brush: Brush, content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
            .shadow(10.dp, shape, ambientColor = A2.copy(alpha = 0.4f), spotColor = A2.copy(alpha = 0.4f))
            .clip(shape).background(brush).bounce(onClick = onClick, onLong = onLong).padding(16.dp),
        content = content
    )
}

@Composable
private fun TicketCard(v: VaultItem, onCopy: () -> Unit, onLong: () -> Unit) {
    val ctx = LocalContext.current
    val qr = remember(v.value) { LanServer.qr(v.value.ifBlank { " " }, 220) }
    CardShell(onCopy, onLong, Brush.linearGradient(listOf(A1, A2, A3))) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.ConfirmationNumber, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                "TICKET", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 2.sp, modifier = Modifier.weight(1f)
            )
            Icon(Icons.Rounded.ContentCopy, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(15.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(
            v.label.ifBlank { "Ticket" }, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        Text(
            v.value, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
            letterSpacing = 3.sp, fontFamily = FontFamily.Monospace, maxLines = 1
        )
        if (v.sub.isNotBlank()) Text(v.sub, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 2)
        if (v.whenMs > 0L) {
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.20f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    Tickets.whenLabel(v.whenMs), color = Color.White, fontSize = 11.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Canvas(Modifier.fillMaxWidth().height(18.dp)) {
            val y = size.height / 2f
            drawLine(
                color = Color.White.copy(alpha = 0.45f),
                start = Offset(0f, y), end = Offset(size.width, y),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 9f), 0f)
            )
            drawCircle(Bg, radius = 9.dp.toPx(), center = Offset(0f, y))
            drawCircle(Bg, radius = 9.dp.toPx(), center = Offset(size.width, y))
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            val b = qr
            if (b != null) {
                Box(
                    Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)).background(Color.White).padding(4.dp)
                ) { Image(bitmap = b.asImageBitmap(), contentDescription = "QR", modifier = Modifier.fillMaxSize()) }
                Spacer(Modifier.width(12.dp))
            }
            Column(
                Modifier.weight(1f).bounce(onClick = {
                    ctx.copyText(v.value, "PNR copied \u2014 paste it on the page")
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Tickets.IRCTC)))
                    } catch (_: Exception) { }
                })
            ) {
                Text("Check live status", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text("Opens IRCTC \u00B7 PNR copied for you", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            }
            Icon(Icons.Rounded.ConfirmationNumber, null, tint = Color.White.copy(alpha = 0.35f), modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun IdCard(v: VaultItem, shown: Boolean, onCopy: () -> Unit, onLong: () -> Unit, onReveal: () -> Unit) {
    CardShell(onCopy, onLong, Brush.linearGradient(listOf(Surf2, Surf2))) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.AccountBalance, null, tint = A2, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                (v.label.ifBlank { "ID document" }).uppercase(), color = Dim, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 2.sp, modifier = Modifier.weight(1f)
            )
            Icon(
                if (shown) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                null, tint = A2, modifier = Modifier.size(18.dp).bounce(onClick = onReveal)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (shown) v.value else maskValue(v.value),
            color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            letterSpacing = if (shown) 1.sp else 2.sp, fontFamily = FontFamily.Monospace, maxLines = 1
        )
        if (v.sub.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(v.sub, color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (shown) "Hides again in 10 seconds" else "Tap the eye to show for 10 seconds",
            color = Dim.copy(alpha = 0.75f), fontSize = 10.sp
        )
    }
}

@Composable
private fun BankCard(v: VaultItem, shown: Boolean, onCopy: () -> Unit, onLong: () -> Unit, onReveal: () -> Unit) {
    CardShell(onCopy, onLong, Brush.linearGradient(listOf(A1, A2))) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).clip(RoundedCornerShape(7.dp)).background(Color.White.copy(alpha = 0.28f)))
            Spacer(Modifier.weight(1f))
            Text(
                v.sub.ifBlank { "CARD" }, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1
            )
            Spacer(Modifier.width(8.dp))
            Icon(
                if (shown) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(18.dp).bounce(onClick = onReveal)
            )
        }
        Spacer(Modifier.height(18.dp))
        Text(
            if (shown) v.value.filter { !it.isWhitespace() }.chunked(4).joinToString("   ") else maskCard(v.value),
            color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp, fontFamily = FontFamily.Monospace, maxLines = 1
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                v.label.ifBlank { "Card" }, color = Color.White, fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1
            )
            Icon(Icons.Rounded.ContentCopy, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(15.dp))
        }
    }
}

@Composable
private fun StudyCard(v: VaultItem, onCopy: () -> Unit, onLong: () -> Unit) {
    CardShell(onCopy, onLong, Brush.linearGradient(listOf(Surf2, Surf2))) {
        Row {
            Box(Modifier.width(4.dp).height(52.dp).clip(RoundedCornerShape(4.dp)).background(Brand))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    (v.label.ifBlank { "Study document" }).uppercase(), color = A2, fontSize = 11.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, maxLines = 1
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    v.value, color = Ink, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace, maxLines = 1
                )
                if (v.sub.isNotBlank()) Text(v.sub, color = Dim, fontSize = 12.sp, maxLines = 2)
            }
            Icon(Icons.Rounded.ContentCopy, null, tint = Dim, modifier = Modifier.size(15.dp))
        }
    }
}

@Composable
private fun SimpleCard(v: VaultItem, k: VaultKind, onCopy: () -> Unit, onLong: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(22.dp)).background(Surf).bounce(onClick = onCopy, onLong = onLong).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Surf2), contentAlignment = Alignment.Center) {
            Icon(k.icon, null, tint = A2, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                v.label.ifBlank { k.label }, color = Ink, fontSize = 15.sp,
                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                v.value, color = Ink, fontSize = 15.sp, maxLines = 2,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp)
            )
            if (v.sub.isNotBlank()) Text(v.sub, color = Dim, fontSize = 12.sp, maxLines = 1)
        }
        Icon(Icons.Rounded.ContentCopy, null, tint = Dim, modifier = Modifier.size(16.dp))
    }
}

// ---------- add / edit ----------
@Composable
fun VaultEditDialog(
    existing: VaultItem?, startKind: VaultKind,
    onCancel: () -> Unit, onSave: (String, String, String, String) -> Unit
) {
    var kind by remember { mutableStateOf(existing?.kind ?: startKind.id) }
    var label by remember { mutableStateOf(existing?.label ?: "") }
    var value by remember { mutableStateOf(existing?.value ?: "") }
    var sub by remember { mutableStateOf(existing?.sub ?: "") }
    val k = vaultKind(kind)
    AlertDialog(
        onDismissRequest = onCancel, containerColor = Surf2,
        title = { Text(if (existing == null) "Add to vault" else "Edit item", color = Ink) },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VAULT_KINDS.forEach { vk ->
                        Box(
                            Modifier.bounce(onClick = {
                                kind = vk.id
                                if (label.isBlank() || VAULT_KINDS.any { it.preset == label }) label = vk.preset
                            }).clip(RoundedCornerShape(50))
                                .background(if (kind == vk.id) A1 else Surf).padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(vk.label, color = if (kind == vk.id) Color.White else Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                InputField(label, { label = it }, "Label — e.g. " + k.preset)
                Spacer(Modifier.height(8.dp))
                InputField(value, { value = it }, k.hint)
                Spacer(Modifier.height(8.dp))
                InputField(sub, { sub = it }, k.subHint)
                Spacer(Modifier.height(10.dp))
                Text("Saved only on this phone, behind your lock.", color = Dim, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (value.isNotBlank()) onSave(label.trim().ifBlank { k.preset }, value.trim(), sub.trim(), kind)
            }) { Text("Save", color = A2, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Dim) } }
    )
}

/** One-line text field in the app's own style. */
@Composable
fun InputField(value: String, onChange: (String) -> Unit, hint: String, single: Boolean = true) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surf)
            .padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = Dim, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = single,
            textStyle = TextStyle(color = Ink, fontSize = 15.sp), cursorBrush = SolidColor(A2),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
