@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.CancellationSignal
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class VaultKind(val id: String, val label: String, val icon: ImageVector)

val VAULT_KINDS = listOf(
    VaultKind("pnr", "PNR / ticket", Icons.Rounded.ConfirmationNumber),
    VaultKind("loan", "Loan / account", Icons.Rounded.AccountBalance),
    VaultKind("wifi", "Wi-Fi password", Icons.Rounded.Wifi),
    VaultKind("card", "Card / UPI", Icons.Rounded.CreditCard),
    VaultKind("other", "Other", Icons.Rounded.Bookmark)
)

fun vaultKind(id: String): VaultKind = VAULT_KINDS.firstOrNull { it.id == id } ?: VAULT_KINDS.last()

// ---------- biometric gate ----------
@Composable
fun VaultGate(onBack: () -> Unit, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var asking by remember { mutableStateOf(false) }
    val keyguard = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        asking = false
        if (r.resultCode == Activity.RESULT_OK) { open = true; msg = null } else msg = "Vault stays locked"
    }

    fun usePhoneLock() {
        val i = authIntent(ctx)
        if (i == null) open = true
        else { asking = true; keyguard.launch(i) }
    }

    fun unlock() {
        if (Build.VERSION.SDK_INT < 29) { usePhoneLock(); return }
        try {
            val exec = ContextCompat.getMainExecutor(ctx)
            val cancel = CancellationSignal()
            val b = android.hardware.biometrics.BiometricPrompt.Builder(ctx)
                .setTitle("Saved info vault")
                .setSubtitle("Unlock with fingerprint, face or phone PIN")
            if (Build.VERSION.SDK_INT >= 30) {
                b.setAllowedAuthenticators(
                    android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK or
                        android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
            } else {
                @Suppress("DEPRECATION")
                b.setDeviceCredentialAllowed(true)
            }
            asking = true
            b.build().authenticate(cancel, exec, object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                    asking = false; open = true; msg = null
                }

                override fun onAuthenticationError(code: Int, err: CharSequence?) {
                    asking = false
                    msg = err?.toString() ?: "Couldn't unlock"
                }
            })
        } catch (_: Exception) {
            usePhoneLock()
        }
    }

    LaunchedEffect(Unit) { unlock() }

    if (open) {
        content()
    } else {
        Page("Saved info vault", onBack) {
            Column(
                Modifier.fillMaxSize().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.size(96.dp).clip(CircleShape).background(Surf2),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Fingerprint, null, tint = A2, modifier = Modifier.size(46.dp)) }
                Spacer(Modifier.height(18.dp))
                Text("Locked", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    msg ?: "Your PNR, loan numbers and passwords are kept behind your phone lock.",
                    color = Dim, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(Modifier.height(22.dp))
                GradientButton(if (asking) "Waiting for unlock…" else "Unlock vault") { unlock() }
                Spacer(Modifier.height(10.dp))
                Text("Use phone PIN instead", color = A2, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.bounce(onClick = { usePhoneLock() }).padding(10.dp))
            }
        }
    }
}

// ---------- vault screen ----------
@Composable
fun VaultScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val items by vm.vault.collectAsState()
    var q by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<VaultItem?>(null) }
    var adding by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf<VaultItem?>(null) }
    val list = remember(items, q) {
        if (q.isBlank()) items.sortedByDescending { it.at }
        else items.filter { it.label.contains(q, true) || it.value.contains(q, true) || vaultKind(it.kind).label.contains(q, true) }
            .sortedByDescending { it.at }
    }
    VaultGate(onBack) {
        Page("Saved info vault", onBack, actions = {
            IconBtn(Icons.Rounded.Add, A2) { adding = true }
        }) {
            Text("Pinned numbers and passwords, unlocked with your fingerprint.", color = Dim, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp))
            Box(Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) { SearchField(q, { q = it }, "Search your vault") }
            if (list.isEmpty()) {
                EmptyState(Icons.Rounded.Lock, "Nothing saved yet", "Hold any message and tap Save to vault")
            } else LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
                items(list, key = { it.id }) { v ->
                    Box(Modifier.animateItemPlacement()) {
                        VaultRow(v, onCopy = { ctx.copyText(v.value, "Copied ${v.label}") }, onEdit = { editing = v }, onDelete = { confirmDel = v })
                    }
                }
            }
        }
        if (adding) VaultEditDialog(null, onCancel = { adding = false }) { label, value, kind ->
            vm.saveVault(label, value, kind); adding = false
        }
        editing?.let { v ->
            VaultEditDialog(v, onCancel = { editing = null }) { label, value, kind ->
                vm.updateVault(v.copy(label = label, value = value, kind = kind)); editing = null
            }
        }
        confirmDel?.let { v ->
            AlertDialog(
                onDismissRequest = { confirmDel = null }, containerColor = Surf2,
                title = { Text("Delete from vault?", color = Ink) },
                text = { Text("“${v.label}” will be removed. This can't be undone.", color = Dim) },
                confirmButton = {
                    TextButton(onClick = { vm.deleteVault(v.id); confirmDel = null }) { Text("Delete", color = A3) }
                },
                dismissButton = { TextButton(onClick = { confirmDel = null }) { Text("Cancel", color = Dim) } }
            )
        }
    }
}

@Composable
fun VaultRow(v: VaultItem, onCopy: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val k = vaultKind(v.kind)
    var tick by remember(v.value) { mutableStateOf(false) }
    LaunchedEffect(tick) { if (tick) { delay(1400); tick = false } }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(22.dp)).background(Surf).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Surf2), contentAlignment = Alignment.Center) {
            Icon(k.icon, null, tint = A2, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).bounce(onClick = onEdit)) {
            Text(v.label.ifBlank { k.label }, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(v.value, color = Ink, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Text(k.label, color = Dim, fontSize = 12.sp)
        }
        IconBtn(if (tick) Icons.Rounded.Check else Icons.Rounded.ContentCopy, if (tick) A2 else Dim) {
            onCopy(); tick = true
        }
        IconBtn(Icons.Rounded.DeleteOutline, Dim) { onDelete() }
    }
}

@Composable
fun VaultEditDialog(existing: VaultItem?, onCancel: () -> Unit, onSave: (String, String, String) -> Unit) {
    var label by remember { mutableStateOf(existing?.label ?: "") }
    var value by remember { mutableStateOf(existing?.value ?: "") }
    var kind by remember { mutableStateOf(existing?.kind ?: "other") }
    AlertDialog(
        onDismissRequest = onCancel, containerColor = Surf2,
        title = { Text(if (existing == null) "Save to vault" else "Edit item", color = Ink) },
        text = {
            Column {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VAULT_KINDS.forEach { k ->
                        Box(
                            Modifier.bounce(onClick = { kind = k.id }).clip(RoundedCornerShape(50))
                                .background(if (kind == k.id) A1 else Surf).padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(k.label, color = if (kind == k.id) Color.White else Dim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                InputField(label, { label = it }, "Label — e.g. Indigo PNR")
                Spacer(Modifier.height(10.dp))
                InputField(value, { value = it }, "Number or password")
                Spacer(Modifier.height(10.dp))
                Text("Saved only on this phone, behind your lock.", color = Dim, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = { if (value.isNotBlank()) onSave(label.trim(), value.trim(), kind) }) {
                Text("Save", color = A2, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Dim) } }
    )
}

/** One-line text field in the app's own style. */
@Composable
fun InputField(value: String, onChange: (String) -> Unit, hint: String, single: Boolean = true) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surf)
            .padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = Dim, fontSize = 15.sp)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = single,
            textStyle = TextStyle(color = Ink, fontSize = 15.sp), cursorBrush = SolidColor(A2),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
