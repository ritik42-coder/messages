@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class VaultField(val key: String, val label: String, val hint: String, val secret: Boolean = false, val lines: Int = 1)

class VaultKind(
    val id: String, val label: String, val icon: ImageVector,
    val primary: String, val fields: List<VaultField>
)

val VAULT_KINDS = listOf(
    VaultKind(
        "aadhaar", "Aadhaar", Icons.Rounded.AccountBalance, "number", listOf(
            VaultField("number", "Aadhaar number", "1234 5678 9012", secret = true),
            VaultField("name", "Name", "As printed on the card"),
            VaultField("dob", "Date of birth", "dd/mm/yyyy"),
            VaultField("gender", "Gender", "M / F / O"),
            VaultField("address", "Address", "Full address", lines = 3)
        )
    ),
    VaultKind(
        "pan", "PAN", Icons.Rounded.Description, "number", listOf(
            VaultField("number", "PAN", "ABCDE1234F", secret = true),
            VaultField("name", "Name", "As printed"),
            VaultField("father", "Father's name", "As printed"),
            VaultField("dob", "Date of birth", "dd/mm/yyyy")
        )
    ),
    VaultKind(
        "card", "Bank card", Icons.Rounded.CreditCard, "number", listOf(
            VaultField("number", "Card number", "1234 5678 9012 3456", secret = true),
            VaultField("holder", "Name on card", "As printed"),
            VaultField("expiry", "Expiry", "MM/YY"),
            VaultField("cvv", "CVV", "123", secret = true),
            VaultField("bank", "Bank", "HDFC, SBI…"),
            VaultField("pin", "ATM PIN", "4 digits", secret = true)
        )
    ),
    VaultKind(
        "account", "Bank account", Icons.Rounded.AccountBalanceWallet, "number", listOf(
            VaultField("number", "Account number", "Account number", secret = true),
            VaultField("ifsc", "IFSC", "HDFC0001234"),
            VaultField("holder", "Account holder", "Name"),
            VaultField("bank", "Bank and branch", "HDFC · Andheri")
        )
    ),
    VaultKind(
        "id", "Passport / DL", Icons.Rounded.InsertDriveFile, "number", listOf(
            VaultField("number", "Document number", "Passport, DL or voter number", secret = true),
            VaultField("type", "Type", "Passport / DL / Voter"),
            VaultField("name", "Name", "As printed"),
            VaultField("valid", "Valid till", "dd/mm/yyyy")
        )
    ),
    VaultKind(
        "study", "Marksheet", Icons.Rounded.Folder, "roll", listOf(
            VaultField("roll", "Roll or enrolment", "Roll number"),
            VaultField("board", "Board or university", "CBSE, AKTU…"),
            VaultField("year", "Year", "2026"),
            VaultField("result", "Result", "85% · First division")
        )
    ),
    VaultKind(
        "ticket", "Ticket / PNR", Icons.Rounded.ConfirmationNumber, "pnr", listOf(
            VaultField("pnr", "PNR or booking ID", "10-digit PNR"),
            VaultField("route", "Route", "NDLS → BCT"),
            VaultField("date", "Journey date", "dd/mm/yyyy"),
            VaultField("seat", "Class, coach, berth", "3A B4 32")
        )
    ),
    VaultKind(
        "password", "Password", Icons.Rounded.Lock, "password", listOf(
            VaultField("user", "Username or email", "you@example.com"),
            VaultField("password", "Password", "••••••••", secret = true),
            VaultField("site", "Website or app", "netflix.com"),
            VaultField("note", "Note", "Security answer, recovery code…", lines = 3)
        )
    ),
    VaultKind(
        "wifi", "Wi-Fi", Icons.Rounded.Wifi, "password", listOf(
            VaultField("ssid", "Network name", "Home Wi-Fi"),
            VaultField("password", "Password", "••••••••", secret = true)
        )
    ),
    VaultKind(
        "other", "Other", Icons.Rounded.Bookmark, "note", listOf(
            VaultField("note", "Anything", "What you want to keep", lines = 3)
        )
    )
)

fun vaultKind(id: String): VaultKind =
    VAULT_KINDS.firstOrNull { it.id == id }
        ?: VAULT_KINDS.firstOrNull { it.id == (if (id == "pnr") "ticket" else id) }
        ?: VAULT_KINDS.last()

fun vaultTitle(v: VaultItem): String {
    if (v.label.isNotBlank()) return v.label
    val k = vaultKind(v.kind)
    return when (v.kind) {
        "aadhaar" -> "Aadhaar"
        "pan" -> "PAN card"
        "card" -> v.fields["bank"].orEmpty().ifBlank { "Bank card" }
        "account" -> v.fields["bank"].orEmpty().ifBlank { "Account" }
        "id" -> v.fields["type"].orEmpty().ifBlank { "Document" }
        "study" -> v.fields["board"].orEmpty().ifBlank { "Marksheet" }
        "ticket" -> v.fields["route"].orEmpty().ifBlank { "Ticket" }
        "password" -> v.fields["site"].orEmpty().ifBlank { "Password" }
        "wifi" -> v.fields["ssid"].orEmpty().ifBlank { "Wi-Fi" }
        else -> k.label
    }
}

fun maskMiddle(v: String): String {
    val clean = v.filter { !it.isWhitespace() }
    if (clean.length <= 4) return "\u2022".repeat(clean.length.coerceAtLeast(4))
    return "\u2022".repeat((clean.length - 4).coerceAtMost(14)) + "  " + clean.takeLast(4)
}

fun maskCardNo(v: String): String {
    val d = v.filter { it.isDigit() }
    if (d.length < 8) return maskMiddle(v)
    return "\u2022\u2022\u2022\u2022   \u2022\u2022\u2022\u2022   \u2022\u2022\u2022\u2022   " + d.takeLast(4)
}

// ==================== the screen ====================
@Composable
fun VaultScreen(vm: MessagesVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val items by vm.vault.collectAsState()
    val setup by vm.vaultSetup.collectAsState()
    val open by vm.vaultOpen.collectAsState()
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var pickKind by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<VaultItem?>(null) }
    var addingKind by remember { mutableStateOf<VaultKind?>(null) }
    var viewing by remember { mutableStateOf<Pair<VaultItem, VaultRef>?>(null) }
    var menuFor by remember { mutableStateOf<VaultItem?>(null) }

    // no screenshots, no recents thumbnail, while the vault is on screen
    val view = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(Unit) {
        val act = view.context as? Activity
        act?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        onDispose {
            act?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    val hasPin = remember { VaultSecurity.hasPin(ctx) }
    var pinOk by remember { mutableStateOf(!hasPin) }
    var pinSetup by remember { mutableStateOf(!hasPin) }
    var forgot by remember { mutableStateOf(false) }

    if (!open) {
        VaultLock(ctx, setup, vm, onBack)
        return
    }
    if (pinSetup) {
        VaultPinSetup(ctx, onDone = { pinSetup = false; pinOk = true }, onBack = onBack)
        return
    }
    if (forgot) {
        VaultForgot(ctx, onDone = { forgot = false; pinOk = true }, onBack = { forgot = false })
        return
    }
    if (!pinOk) {
        VaultPinGate(
            ctx,
            onOpen = { pinOk = true },
            onForgot = { forgot = true },
            onPhrase = { vm.lockVault() }
        )
        return
    }

    val list = remember(items, q, filter) {
        items.filter { filter == "all" || it.kind == filter }
            .filter {
                q.isBlank() || vaultTitle(it).contains(q, true) ||
                    it.value.contains(q, true) || it.sub.contains(q, true) ||
                    it.fields.values.any { f -> f.contains(q, true) }
            }
            .sortedByDescending { it.at }
    }

    Page("Vault", onBack, actions = {
        IconBtn(Icons.Rounded.Add, A2) { pickKind = true }
    }) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Lock, null, tint = A2, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                items.size.toString() + if (items.size == 1) " item · encrypted in Downloads/MessagesVault" else " items · encrypted in Downloads/MessagesVault",
                color = Dim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Box(Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) { SearchField(q, { q = it }, "Search names, numbers, notes") }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Chip("All", filter == "all") { filter = "all" }
            VAULT_KINDS.forEach { k -> Chip(k.label, filter == k.id) { filter = k.id } }
        }
        if (items.isEmpty()) {
            EmptyState(Icons.Rounded.Lock, "Empty vault", "Tap + to add a document, card or password")
        } else if (list.isEmpty()) {
            EmptyState(Icons.Rounded.Search, "Nothing matches", "Try another word")
        } else LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
            items(list, key = { it.id }) { v ->
                Box(Modifier.animateItemPlacement()) {
                    VaultCard(v, onClick = { menuFor = v }, onFile = { ref -> viewing = v to ref })
                }
            }
        }
    }

    if (pickKind) {
        KindPicker(onClose = { pickKind = false }) { k ->
            pickKind = false
            addingKind = k
        }
    }
    addingKind?.let { k ->
        VaultEditor(vm, null, k, onClose = { addingKind = null })
    }
    editing?.let { v ->
        VaultEditor(vm, v, vaultKind(v.kind), onClose = { editing = null })
    }
    menuFor?.let { v ->
        Scrim(true, { menuFor = null }) {
            ActionGrid(
                listOf(
                    Act(Icons.Rounded.Edit, "Edit") { menuFor = null; editing = v },
                    Act(Icons.Rounded.ContentCopy, "Copy") {
                        ctx.copyText(v.value.ifBlank { vaultTitle(v) }, "Copied")
                        menuFor = null
                    },
                    Act(Icons.Rounded.Share, "Share") {
                        try {
                            ctx.startActivity(
                                Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).setType("text/plain")
                                        .putExtra(Intent.EXTRA_TEXT, vaultShareText(v)), "Share"
                                )
                            )
                        } catch (_: Exception) { }
                        menuFor = null
                    },
                    Act(Icons.Rounded.Delete, "Delete", true) { vm.deleteVault(v.id); menuFor = null }
                ), columns = 4
            )
        }
    }
    viewing?.let { (item, ref) ->
        FileViewer(item, ref, onClose = { viewing = null })
    }
}

fun vaultShareText(v: VaultItem): String {
    val sb = StringBuilder(vaultTitle(v))
    if (v.value.isNotBlank()) sb.append("\n").append(v.value)
    if (v.sub.isNotBlank()) sb.append("\n").append(v.sub)
    vaultKind(v.kind).fields.forEach { f ->
        val x = v.fields[f.key].orEmpty()
        if (x.isNotBlank() && x != v.value) sb.append("\n").append(f.label).append(": ").append(x)
    }
    return sb.toString()
}

// ==================== lock screen ====================
@Composable
fun VaultLock(ctx: Context, setup: Boolean, vm: MessagesVM, onBack: () -> Unit) {
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun go() {
        busy = true
        err = null
        scope.launch {
            val code = withContext(Dispatchers.Default) {
                when {
                    setup && pass.length < 6 -> -1
                    setup && pass != pass2 -> -2
                    setup -> if (vm.setupVault(pass)) 1 else 0
                    else -> if (vm.unlockVault(pass)) 1 else 0
                }
            }
            busy = false
            err = when (code) {
                -1 -> "Use at least 6 characters"
                -2 -> "The two phrases don't match"
                1 -> null
                else -> if (setup) "Couldn't create the vault" else "Wrong phrase"
            }
        }
    }

    Page(if (setup) "Create your vault" else "Unlock vault", onBack) {
        Column(
            Modifier.fillMaxSize().padding(26.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(84.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Fingerprint, null, tint = A2, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text(
                if (setup) "One phrase protects everything" else "Enter your recovery phrase",
                color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (setup)
                    "Your documents are encrypted with this phrase and kept in Downloads/MessagesVault. " +
                        "Even if you uninstall the app, the same phrase brings everything back."
                else "This is the phrase you set when the vault was created.",
                color = Dim, fontSize = 13.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
            InputField(pass, { pass = it }, "Recovery phrase")
            if (setup) {
                Spacer(Modifier.height(10.dp))
                InputField(pass2, { pass2 = it }, "Type it again")
            }
            err?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, color = A3, fontSize = 13.sp)
            }
            Spacer(Modifier.height(18.dp))
            GradientButton(if (busy) "Working…" else if (setup) "Create vault" else "Unlock") { if (!busy) go() }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Lock, null, tint = Dim, modifier = Modifier.size(13.dp))
                Spacer(Modifier.width(6.dp))
                Text("AES-256 · only this phone can read it", color = Dim, fontSize = 11.sp)
            }
        }
    }
}

// ==================== cards ====================
@Composable
fun VaultCard(v: VaultItem, onClick: () -> Unit, onFile: (VaultRef) -> Unit) {
    var shown by remember(v.id) { mutableStateOf(false) }
    LaunchedEffect(shown) { if (shown) { delay(12_000); shown = false } }
    when (vaultKind(v.kind).id) {
        "aadhaar" -> AadhaarCard(v, shown, onClick) { shown = !shown }
        "pan" -> PanCard(v, shown, onClick) { shown = !shown }
        "card" -> BankCard(v, shown, onClick) { shown = !shown }
        "password", "wifi" -> SecretCard(v, shown, onClick) { shown = !shown }
        "study" -> StudyCard(v, onClick)
        "ticket" -> TicketCard(v, onClick)
        "account", "id" -> DocCard(v, shown, onClick) { shown = !shown }
        else -> SimpleCard(v, onClick)
    }
    if (v.files.isNotEmpty()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 6.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            v.files.forEach { r ->
                Row(
                    Modifier.bounce(onClick = { onFile(r) }).clip(RoundedCornerShape(50))
                        .background(Surf2).padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(fileIcon(r.mime), null, tint = A2, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(r.name.take(18), color = Ink, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

private fun fileIcon(mime: String): ImageVector = when {
    mime.startsWith("image") -> Icons.Rounded.Image
    mime == "application/pdf" -> Icons.Rounded.PictureAsPdf
    else -> Icons.Rounded.InsertDriveFile
}

@Composable
private fun Shell(brush: Brush, onClick: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
            .shadow(10.dp, shape, ambientColor = A2.copy(alpha = 0.35f), spotColor = A2.copy(alpha = 0.35f))
            .clip(shape).background(brush).bounce(onClick = onClick).padding(16.dp),
        content = content
    )
}

@Composable
private fun AadhaarCard(v: VaultItem, shown: Boolean, onClick: () -> Unit, onReveal: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
            .shadow(10.dp, shape).clip(shape).background(Surf2).bounce(onClick = onClick)
    ) {
        Row(Modifier.fillMaxWidth().height(6.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFFFF9933)))
            Box(Modifier.weight(1f).fillMaxHeight().background(Color.White))
            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF138808)))
        }
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.AccountBalance, null, tint = A2, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "AADHAAR", color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp, modifier = Modifier.weight(1f)
                )
                Icon(
                    if (shown) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null,
                    tint = A2, modifier = Modifier.size(17.dp).bounce(onClick = onReveal)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (shown) v.value else maskMiddle(v.value), color = Ink, fontSize = 21.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
            )
            val name = v.fields["name"].orEmpty()
            if (name.isNotBlank()) Text(name, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            val extra = listOf(v.fields["dob"].orEmpty(), v.fields["gender"].orEmpty())
                .filter { it.isNotBlank() }.joinToString("  \u00B7  ")
            if (extra.isNotBlank()) Text(extra, color = Dim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PanCard(v: VaultItem, shown: Boolean, onClick: () -> Unit, onReveal: () -> Unit) {
    Shell(Brush.linearGradient(listOf(Color(0xFF1B2A4A), Color(0xFF0E1626))), onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Description, null, tint = Color(0xFF8FB8FF), modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                "INCOME TAX DEPARTMENT", color = Color(0xFF8FB8FF), fontSize = 9.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f)
            )
            Icon(
                if (shown) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null,
                tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(17.dp).bounce(onClick = onReveal)
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            if (shown) v.value else maskMiddle(v.value), color = Color.White, fontSize = 20.sp,
            fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
        )
        val name = v.fields["name"].orEmpty()
        if (name.isNotBlank()) Text(name, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
        val f = v.fields["father"].orEmpty()
        if (f.isNotBlank()) Text("s/o " + f, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
    }
}

@Composable
private fun BankCard(v: VaultItem, shown: Boolean, onClick: () -> Unit, onReveal: () -> Unit) {
    Shell(Brush.linearGradient(listOf(A1, A2)), onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(26.dp).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(alpha = 0.30f)))
            Spacer(Modifier.weight(1f))
            Text(
                v.fields["bank"].orEmpty().ifBlank { "CARD" },
                color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.width(8.dp))
            Icon(
                if (shown) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null,
                tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(17.dp).bounce(onClick = onReveal)
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            if (shown) v.value.filter { !it.isWhitespace() }.chunked(4).joinToString("   ") else maskCardNo(v.value),
            color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace, letterSpacing = 1.sp, maxLines = 1
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                v.fields["holder"].orEmpty().ifBlank { vaultTitle(v) },
                color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f),
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val exp = v.fields["expiry"].orEmpty()
            if (exp.isNotBlank()) Text(exp, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun SecretCard(v: VaultItem, shown: Boolean, onClick: () -> Unit, onReveal: () -> Unit) {
    Shell(Brush.linearGradient(listOf(Surf2, Surf2)), onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (v.kind == "wifi") Icons.Rounded.Wifi else Icons.Rounded.Lock, null,
                tint = A2, modifier = Modifier.size(15.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                vaultTitle(v).uppercase(), color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.6.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Icon(
                if (shown) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null,
                tint = A2, modifier = Modifier.size(17.dp).bounce(onClick = onReveal)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (shown) v.value else "\u2022".repeat(v.value.length.coerceIn(6, 18)),
            color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        val user = v.fields["user"].orEmpty()
        if (user.isNotBlank()) Text(user, color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            if (shown) "Hides again in 12 seconds" else "Tap the eye to reveal",
            color = Dim.copy(alpha = 0.7f), fontSize = 10.sp
        )
    }
}

@Composable
private fun StudyCard(v: VaultItem, onClick: () -> Unit) {
    Shell(Brush.linearGradient(listOf(Surf2, Surf2)), onClick) {
        Row {
            Box(Modifier.width(4.dp).height(54.dp).clip(RoundedCornerShape(4.dp)).background(Brand))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    v.fields["board"].orEmpty().ifBlank { "MARKSHEET" }.uppercase(), color = A2,
                    fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, maxLines = 1
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    v.value, color = Ink, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace, maxLines = 1
                )
                val sub = listOf(v.fields["year"].orEmpty(), v.fields["result"].orEmpty())
                    .filter { it.isNotBlank() }.joinToString("  \u00B7  ")
                if (sub.isNotBlank()) Text(sub, color = Dim, fontSize = 12.sp, maxLines = 2)
            }
        }
    }
}

@Composable
private fun TicketCard(v: VaultItem, onClick: () -> Unit) {
    Shell(Brush.linearGradient(listOf(A1, A2, A3)), onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.ConfirmationNumber, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                v.fields["route"].orEmpty().ifBlank { "TICKET" }, color = Color.White.copy(alpha = 0.9f),
                fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f),
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(Tickets.whenLabel(v.whenMs), color = Color.White.copy(alpha = 0.9f), fontSize = 10.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            v.value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
            letterSpacing = 3.sp, fontFamily = FontFamily.Monospace
        )
        val seat = v.fields["seat"].orEmpty()
        if (seat.isNotBlank()) Text(seat, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
        Text(
            "Check live status on IRCTC", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
private fun DocCard(v: VaultItem, shown: Boolean, onClick: () -> Unit, onReveal: () -> Unit) {
    Shell(Brush.linearGradient(listOf(Surf2, Surf2)), onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(vaultKind(v.kind).icon, null, tint = A2, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                vaultTitle(v).uppercase(), color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.6.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Icon(
                if (shown) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null,
                tint = A2, modifier = Modifier.size(17.dp).bounce(onClick = onReveal)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (shown) v.value else maskMiddle(v.value), color = Ink, fontSize = 19.sp,
            fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace
        )
        val sub = listOf(v.fields["ifsc"].orEmpty(), v.fields["holder"].orEmpty(), v.fields["valid"].orEmpty())
            .filter { it.isNotBlank() }.joinToString("  \u00B7  ")
        if (sub.isNotBlank()) Text(sub, color = Dim, fontSize = 12.sp, maxLines = 2)
    }
}

@Composable
private fun SimpleCard(v: VaultItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(22.dp)).background(Surf).bounce(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Surf2), contentAlignment = Alignment.Center) {
            Icon(vaultKind(v.kind).icon, null, tint = A2, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(vaultTitle(v), color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(v.value, color = Ink, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ==================== add / edit ====================
@Composable
fun KindPicker(onClose: () -> Unit, onPick: (VaultKind) -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, containerColor = Surf2,
        title = { Text("What are you saving?", color = Ink) },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                VAULT_KINDS.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { k ->
                            Column(
                                Modifier.weight(1f).bounce(onClick = { onPick(k) })
                                    .clip(RoundedCornerShape(16.dp)).padding(vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    Modifier.size(40.dp).clip(CircleShape).background(Surf),
                                    contentAlignment = Alignment.Center
                                ) { Icon(k.icon, null, tint = A2, modifier = Modifier.size(20.dp)) }
                                Spacer(Modifier.height(5.dp))
                                Text(k.label, color = Ink, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 2)
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel", color = Dim) } }
    )
}

@Composable
fun VaultEditor(vm: MessagesVM, existing: VaultItem?, kind: VaultKind, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val values = remember {
        mutableStateMapOf<String, String>().apply {
            kind.fields.forEach { f -> put(f.key, existing?.fields?.get(f.key) ?: "") }
            if (existing != null && existing.value.isNotBlank()) put(kind.primary, existing.value)
        }
    }
    val files = remember { mutableStateListOf<VaultRef>().apply { existing?.files?.let { addAll(it) } } }
    var title by remember { mutableStateOf(existing?.label ?: "") }
    var busy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            val bytes = try { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } } catch (_: Exception) { null }
            val name = try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                }
            } catch (_: Exception) { null } ?: "file"
            val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
            if (bytes != null && bytes.size < 25 * 1024 * 1024) {
                val ref = VaultStore.putAttachment(ctx, bytes, name, mime)
                if (ref != null) files.add(ref)
            } else {
                Toast.makeText(ctx, "File is too large (25 MB limit)", Toast.LENGTH_SHORT).show()
            }
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = onClose, containerColor = Surf2,
        title = { Text(if (existing == null) "New " + kind.label.lowercase() else "Edit " + kind.label.lowercase(), color = Ink) },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
                kind.fields.forEach { f ->
                    Text(
                        f.label, color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        letterSpacing = 0.6.sp, modifier = Modifier.padding(top = 6.dp, bottom = 3.dp)
                    )
                    InputField(values[f.key].orEmpty(), { values[f.key] = it }, f.hint, single = f.lines == 1)
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.bounce(onClick = { picker.launch(arrayOf("*/*")) })
                            .clip(RoundedCornerShape(50)).background(Surf).padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.AttachFile, null, tint = A2, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (busy) "Adding…" else "Attach file", color = A2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(files.size.toString() + " attached", color = Dim, fontSize = 11.sp)
                }
                files.forEach { r ->
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(fileIcon(r.mime), null, tint = Dim, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            r.name, color = Ink, fontSize = 12.sp, modifier = Modifier.weight(1f),
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "Remove", color = A3, fontSize = 11.sp,
                            modifier = Modifier.bounce(onClick = {
                                VaultStore.deleteAttachment(ctx, r)
                                files.remove(r)
                            }).padding(4.dp)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Stored encrypted in Downloads/MessagesVault.", color = Dim, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val primary = values[kind.primary].orEmpty().trim()
                val t = title.trim().ifBlank {
                    values["name"].orEmpty().ifBlank {
                        values["site"].orEmpty().ifBlank {
                            values["ssid"].orEmpty().ifBlank { values["bank"].orEmpty().ifBlank { kind.label } }
                        }
                    }
                }
                if (primary.isNotBlank() || files.isNotEmpty()) {
                    val item = VaultItem(
                        existing?.id ?: System.currentTimeMillis(),
                        t, primary, kind.id, existing?.at ?: System.currentTimeMillis(),
                        existing?.sub ?: "", existing?.whenMs ?: 0L,
                        values.filterValues { it.isNotBlank() },
                        files.toList()
                    )
                    if (existing == null) vm.addVaultItem(item) else vm.updateVaultItem(item)
                    onClose()
                }
            }) { Text("Save", color = A2, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel", color = Dim) } }
    )
}

// ==================== file viewer ====================
@Composable
fun FileViewer(item: VaultItem, ref: VaultRef, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var bytes by remember(ref.id) { mutableStateOf<ByteArray?>(null) }
    var pages by remember(ref.id) { mutableStateOf(emptyList<Bitmap>()) }
    var failed by remember(ref.id) { mutableStateOf(false) }
    var downloaded by remember(ref.id) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(ref.id) {
        val data = withContext(Dispatchers.IO) { VaultStore.readAttachment(ctx, ref) }
        bytes = data
        if (data == null) {
            failed = true
            return@LaunchedEffect
        }
        if (ref.mime == "application/pdf") {
            pages = withContext(Dispatchers.IO) { pdfPages(ctx, data) }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Rounded.Close, null, tint = Color.White,
                    modifier = Modifier.size(22.dp).bounce(onClick = onClose)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(ref.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        vaultTitle(item) + "  \u00B7  " + (ref.size / 1024).toString() + " KB",
                        color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp
                    )
                }
                Icon(
                    if (downloaded) Icons.Rounded.Check else Icons.Rounded.Backup, null,
                    tint = if (downloaded) A2 else Color.White,
                    modifier = Modifier.size(20.dp).bounce(onClick = {
                        scope.launch(Dispatchers.IO) {
                            val ok = VaultStore.export(ctx, ref)
                            withContext(Dispatchers.Main) {
                                downloaded = ok
                                Toast.makeText(
                                    ctx,
                                    if (ok) "Saved to Downloads" else "Couldn't save the file",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    })
                )
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                when {
                    failed -> Text("Couldn't open this file", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
                    ref.mime.startsWith("image") -> {
                        val b = bytes
                        if (b == null) Text("Opening…", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                        else {
                            val bmp = remember(b) {
                                try { android.graphics.BitmapFactory.decodeByteArray(b, 0, b.size) } catch (_: Exception) { null }
                            }
                            if (bmp != null) {
                                Image(
                                    bitmap = bmp.asImageBitmap(), contentDescription = ref.name,
                                    modifier = Modifier.fillMaxSize().padding(10.dp)
                                )
                            } else Text("Couldn't read the image", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                        }
                    }
                    ref.mime == "application/pdf" -> {
                        if (pages.isEmpty()) Text("Rendering…", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                        else LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(pages.size) { i ->
                                Image(
                                    bitmap = pages[i].asImageBitmap(), contentDescription = "Page " + (i + 1),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                    else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(fileIcon(ref.mime), null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(56.dp))
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "This file can't be previewed here. Download it and open it with another app.",
                            color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 30.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun pdfPages(ctx: Context, bytes: ByteArray): List<Bitmap> {
    val out = ArrayList<Bitmap>()
    var pfd: ParcelFileDescriptor? = null
    try {
        val f = File(ctx.cacheDir, "vault_view.pdf")
        FileOutputStream(f).use { it.write(bytes) }
        pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        val n = renderer.pageCount.coerceAtMost(6)
        for (i in 0 until n) {
            val page = renderer.openPage(i)
            val w = 900
            val h = (w * page.height / page.width.toFloat()).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(AColor.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            out.add(bmp)
        }
        renderer.close()
    } catch (_: Exception) {
    } finally {
        try { pfd?.close() } catch (_: Exception) { }
    }
    return out
}

/** One-line text field in the app's own style. */
@Composable
fun InputField(value: String, onChange: (String) -> Unit, hint: String, single: Boolean = true) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surf)
            .padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        if (value.isEmpty()) {
            Text(hint, color = Dim, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = single, maxLines = if (single) 1 else 4,
            textStyle = TextStyle(color = Ink, fontSize = 15.sp), cursorBrush = SolidColor(A2),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
