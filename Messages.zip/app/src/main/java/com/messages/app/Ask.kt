@file:OptIn(ExperimentalFoundationApi::class)

package com.messages.app

import android.content.Context
import android.provider.Telephony
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Answer(val title: String, val headline: String, val lines: List<String>, val go: String?)

/** Answers questions about your own messages, on the phone, with no model and no server. */
object Ask {
    private val balRe = Regex("(?i)(?:avl|available)\\s*bal(?:ance)?[^0-9]{0,14}([\\d,]+(?:\\.\\d{1,2})?)")

    private fun money2(v: Double): String {
        val whole = v.toLong()
        return "\u20B9" + String.format(Locale.getDefault(), "%,d", whole)
    }

    private fun lastBalance(ctx: Context): Triple<String, String, Long>? {
        try {
            ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"), null, null, "date DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 200) {
                    n++
                    val b = c.getString(1) ?: continue
                    if (!b.contains("bal", true)) continue
                    val m = balRe.find(b) ?: continue
                    return Triple(c.getString(0) ?: "", m.groupValues[1], c.getLong(2))
                }
            }
        } catch (_: Exception) { }
        return null
    }

    fun answer(ctx: Context, raw: String): List<Answer> {
        val q = raw.lowercase()
        val out = ArrayList<Answer>()
        fun has(vararg k: String) = k.any { q.contains(it) }

        if (has("bill", "due", "emi", "recharge")) {
            val bills = Money.compute(ctx).bills.filter { it.due != null }.take(3)
            if (bills.isEmpty()) {
                out.add(Answer("Bills", "Nothing due right now", emptyList(), "bills"))
            } else {
                val first = bills.first()
                val days = ((dayStart(first.due!!) - dayStart(System.currentTimeMillis())) / 86_400_000L).toInt()
                out.add(
                    Answer(
                        "Next bill",
                        (first.who.ifBlank { first.address }) + "  " +
                            (first.amount?.let { money2(it) } ?: "") + "  \u00B7  " +
                            (if (days <= 0) "due today" else "in " + days + " day" + (if (days == 1) "" else "s")),
                        bills.map {
                            (it.who.ifBlank { it.address }) + "  \u00B7  " +
                                (it.amount?.let { a -> money2(a) } ?: "") + "  \u00B7  " +
                                SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(it.due!!))
                        },
                        "bills"
                    )
                )
            }
        }

        if (has("balance", "bal", "account", "khata")) {
            val b = lastBalance(ctx)
            if (b != null) {
                out.add(
                    Answer(
                        "Balance",
                        "\u20B9" + b.second + "  \u00B7  " + fmt(b.third),
                        listOf(SmsRepo(ctx).name(b.first)),
                        null
                    )
                )
            }
        }

        if (has("otp", "code", "password")) {
            val last = OtpLog.scan(ctx, 3).firstOrNull()
            if (last != null) {
                out.add(
                    Answer(
                        "Latest OTP",
                        last.code,
                        listOf(SmsRepo(ctx).name(last.from) + "  \u00B7  " + fmt(last.at)),
                        "otps"
                    )
                )
            }
        }

        if (has("parcel", "deliver", "order", "courier", "shipment")) {
            val p = Parcels.parcels(ctx).take(3)
            if (p.isNotEmpty()) {
                out.add(
                    Answer(
                        "Parcels",
                        p.first().courier + "  \u00B7  " + p.first().status,
                        p.map { it.courier + "  \u00B7  " + it.status + (if (it.awb.isBlank()) "" else "  \u00B7  " + it.awb) },
                        "parcels"
                    )
                )
            }
        }

        if (has("ticket", "train", "pnr", "journey", "flight", "trip")) {
            val now = System.currentTimeMillis()
            val t = Store(ctx).vault.filter { (it.kind == "pnr" || it.kind == "ticket") && it.whenMs > now - 86_400_000L }
                .sortedBy { it.whenMs }.take(2)
            if (t.isNotEmpty()) {
                out.add(
                    Answer(
                        "Next trip",
                        t.first().label.ifBlank { "Ticket" } + "  \u00B7  " + Tickets.whenLabel(t.first().whenMs),
                        t.map { it.label + "  " + it.value + (if (it.sub.isBlank()) "" else "  \u00B7  " + it.sub) },
                        "vault"
                    )
                )
            }
        }

        if (has("spent", "spend", "expense", "money", "total", "kharch")) {
            val m = Money.compute(ctx)
            out.add(
                Answer(
                    "Spending this month",
                    money2(m.spent) + " out  \u00B7  " + money2(m.received) + " in",
                    m.byWho.take(3).map { it.first + "  \u00B7  " + money2(it.second) },
                    "money"
                )
            )
        }

        if (has("unread", "how many", "messages", "inbox")) {
            val repo = SmsRepo(ctx)
            val convos = repo.conversations()
            out.add(
                Answer(
                    "Inbox",
                    convos.sumOf { it.unread }.toString() + " unread  \u00B7  " + convos.size + " conversations",
                    convos.filter { it.unread > 0 }.take(3).map { it.name + "  \u00B7  " + it.unread },
                    null
                )
            )
        }

        if (out.isEmpty()) {
            val hits = SmsRepo(ctx).searchAll(raw.trim(), 4)
            if (hits.isEmpty()) {
                out.add(Answer("No answer", "Nothing matched “" + raw.trim() + "”", emptyList(), null))
            } else {
                out.add(
                    Answer(
                        "From your messages",
                        hits.size.toString() + " messages mention this",
                        hits.map { it.name + ": " + it.body.take(60) },
                        null
                    )
                )
            }
        }
        return out
    }
}

@Composable
fun AskScreen(vm: MessagesVM, onBack: () -> Unit, onGo: (String) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var res by remember { mutableStateOf(emptyList<Answer>()) }
    var busy by remember { mutableStateOf(false) }
    val ideas = listOf("Bill due?", "Balance", "Last OTP", "Where is my parcel", "Next trip", "Spending this month")

    LaunchedEffect(q) {
        if (q.trim().length < 3) {
            res = emptyList()
            busy = false
            return@LaunchedEffect
        }
        busy = true
        delay(220)
        res = withContext(Dispatchers.IO) { Ask.answer(ctx, q.trim()) }
        busy = false
    }

    Page("Ask your messages", onBack) {
        Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
            SearchField(q, { q = it }, "Ask anything about your messages", autofocus = true)
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ideas.forEach { idea ->
                Box(
                    Modifier.bounce(onClick = { q = idea }).clip(RoundedCornerShape(50))
                        .background(Surf).padding(horizontal = 14.dp, vertical = 8.dp)
                ) { Text(idea, color = Dim, fontSize = 13.sp) }
            }
        }
        if (q.trim().length < 3) {
            EmptyState(
                Icons.Rounded.Forum, "Ask your inbox",
                "Bills, balance, OTPs, parcels, trips — answered from your own SMS"
            )
        } else if (busy && res.isEmpty()) {
            Text("Reading your messages…", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(22.dp))
        } else LazyColumn(contentPadding = PaddingValues(bottom = 26.dp, top = 6.dp)) {
            items(res.size) { i ->
                val a = res[i]
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
                        .clip(RoundedCornerShape(22.dp)).background(Surf)
                        .bounce(onClick = { a.go?.let { onGo(it) } }).padding(16.dp)
                ) {
                    Text(
                        a.title.uppercase(), color = A2, fontSize = 10.sp,
                        fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        a.headline, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Default
                    )
                    if (a.lines.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        a.lines.forEach { l ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(4.dp).clip(RoundedCornerShape(50)).background(Dim))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    l, color = Dim, fontSize = 12.sp, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(Modifier.height(3.dp))
                        }
                    }
                    if (a.go != null) {
                        Spacer(Modifier.height(6.dp))
                        Text("Open", color = A2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
