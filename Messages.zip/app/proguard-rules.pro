-keep class com.messages.app.** { *; }
-dontwarn org.jetbrains.annotations.**

# ---------------------------------------------------------------------------
# R8 "Missing classes detected" fix.
# auto-value / javapoet are compile-time annotation helpers that a transitive
# dependency drags onto the runtime classpath. They reference the JDK's
# annotation-processing API (javax.lang.model.*), which simply does not exist
# on Android, so R8 reports them as missing classes and fails the build.
# Nothing in these packages is used at runtime, so silencing them is safe.
# ---------------------------------------------------------------------------
-dontwarn javax.lang.model.**
-dontwarn javax.lang.model.element.**
-dontwarn javax.lang.model.type.**
-dontwarn javax.lang.model.util.**
-dontwarn autovalue.shaded.**
-dontwarn com.google.auto.value.**
-dontwarn com.squareup.javapoet.**
