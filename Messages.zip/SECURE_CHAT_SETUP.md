# Secure Chat setup (do this once)

Secure Chat uses Firebase Realtime Database for tiny encrypted envelopes and your existing Supabase bucket
for encrypted files. Everything it writes is inside ONE node / ONE folder so BharatChat and BharatStore
are not touched.

## 1. Firebase (project bharatchat-d37fa)

1. Authentication > Sign-in method > turn ON **Email/Password**. (Phone numbers are never used. The app signs in
   with a hidden key-derived login, so no real email or number is stored.)
2. Realtime Database > **Rules**. DO NOT replace your rules. Open them and ADD this block inside the existing
   top-level `"rules": { ... }` object, next to your other nodes:

```json
"securechat_v1": {
  "owners": {
    ".read": false,
    "$id": {
      ".write": "auth != null && !data.exists() && newData.val() === auth.uid"
    }
  },
  "inbox": {
    ".read": false,
    "$id": {
      ".read": "auth != null && root.child('securechat_v1/owners/' + $id).val() === auth.uid",
      "$mid": {
        ".write": "auth != null && ((!data.exists() && newData.exists()) || (data.exists() && !newData.exists() && root.child('securechat_v1/owners/' + $id).val() === auth.uid))",
        ".validate": "newData.hasChildren(['f','e','s','i','c','t']) && newData.child('c').isString() && newData.child('c').val().length < 40000"
      }
    }
  },
  "acks": {
    ".read": false,
    "$id": {
      ".read": "auth != null && root.child('securechat_v1/owners/' + $id).val() === auth.uid",
      "$mid": {
        ".write": "auth != null && ((!data.exists() && newData.exists()) || (data.exists() && !newData.exists() && root.child('securechat_v1/owners/' + $id).val() === auth.uid))",
        ".validate": "newData.hasChildren(['m','s','f'])"
      }
    }
  }
}
```

3. IMPORTANT: BharatChat never signs in to Firebase, so its rules are almost certainly open (`".read": true,
   ".write": true` at the root). Rules cascade DOWN, so an open root also opens `securechat_v1` to everyone and the
   block above cannot close it. Message contents stay encrypted, but anyone could delete or flood inboxes and see
   which random ids talk. Safest fix: use a NEW free Firebase project just for Secure Chat (see section 4).
4. Also note: Email/Password users live in the same Auth user list as BharatChat. If any BharatChat rule only
   checks `auth != null`, Secure Chat accounts could pass that check. If so, tighten those rules.

## 2. Supabase (already filled in)

`SecureConfig.kt` already points at the same Supabase project and `images` bucket that BharatChat uses, with the same
public key. Secure Chat files live only inside the `securechat/` folder of that bucket, as random encrypted bytes.

BharatChat already uploads to and deletes from this bucket with the same key, so the policies it needs most likely
exist. Only if uploads or deletes fail, run this in the Supabase SQL editor (limited to the `securechat/` folder):

```sql
create policy "securechat insert" on storage.objects
  for insert to anon with check (bucket_id = 'images' and name like 'securechat/%');
create policy "securechat delete" on storage.objects
  for delete to anon using (bucket_id = 'images' and name like 'securechat/%');
create policy "securechat select" on storage.objects
  for select to anon using (bucket_id = 'images' and name like 'securechat/%');
```

## 3. Build
Push the project to GitHub as usual. The Firebase and Supabase keys in the app are the public client keys.

## 4. Recommended: a separate Firebase project for Secure Chat (free Spark plan)

1. Firebase console > Add project (any name) > Build > Realtime Database > Create (pick a region).
2. Authentication > Sign-in method > Email/Password > Enable.
3. Realtime Database > Rules > replace everything with:

```json
{
  "rules": {
    ".read": false,
    ".write": false,
    "securechat_v1": {
      "owners": {
        ".read": false,
        "$id": { ".write": "auth != null && !data.exists() && newData.val() === auth.uid" }
      },
      "inbox": {
        ".read": false,
        "$id": {
          ".read": "auth != null && root.child('securechat_v1/owners/' + $id).val() === auth.uid",
          "$mid": {
            ".write": "auth != null && ((!data.exists() && newData.exists()) || (data.exists() && !newData.exists() && root.child('securechat_v1/owners/' + $id).val() === auth.uid))",
            ".validate": "newData.hasChildren(['f','e','s','i','c','t']) && newData.child('c').isString() && newData.child('c').val().length < 40000"
          }
        }
      },
      "acks": {
        ".read": false,
        "$id": {
          ".read": "auth != null && root.child('securechat_v1/owners/' + $id).val() === auth.uid",
          "$mid": {
            ".write": "auth != null && ((!data.exists() && newData.exists()) || (data.exists() && !newData.exists() && root.child('securechat_v1/owners/' + $id).val() === auth.uid))",
            ".validate": "newData.hasChildren(['m','s','f'])"
          }
        }
      }
    }
  }
}
```

4. Project settings > Your apps > add a Web app > copy `apiKey`, `appId`, `projectId`, `databaseURL` into
   `FB_API_KEY`, `FB_APP_ID`, `FB_PROJECT`, `FB_DB` in `SecureConfig.kt`.
